from django.apps import AppConfig


class SchadmissionConfig(AppConfig):
    name = 'schAdmission'
