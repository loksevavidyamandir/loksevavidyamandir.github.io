from django import forms
from seedData.validators import file_size_pdf,file_size_photo,file_size_profile_photo
from django.core.validators import FileExtensionValidator
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from seedData.models import Year


GENDERS = (
    ('', 'Choose...'),
    ('MALE', 'MALE'),
    ('FEMALE', 'FEMALE'),
    ('OTHER', 'OTHER')
)


CLASS_PRISCHOOL = (
    ('', 'Choose...'),
    ('1', '1'),
    ('2', '2'),
    ('3', '3'),
    ('4', '4'),
   )

LAST_ATTENDED_CLASS_PRISCHOOL = (   
    ('', 'Choose...'),
    ('1', '1'),
    ('2', '2'),
    ('3', '3'),
)

CLASS_SECSCHOOL = (
    ('', 'Choose...'),
    ('5', '5'),
    ('6', '6'),
    ('7', '7'),
    ('8', '8'),
    ('9', '9'),
    ('10', '10'),
)

LAST_ATTENDED_CLASS_SECSCHOOL = (
    ('', 'Choose...'),
    ('4', '4'),
    ('5', '5'),
    ('6', '6'),
    ('7', '7'),
    ('8', '8'),
    ('9', '9'),
)

CLASS_ATKT = (
    ('11', '11'),
)

CLASS_COLLEGE = (
    ('', 'Choose...'),
    ('11', '11'),
    ('12', '12'),
)

LAST_ATTENDED_CLASS_COLLEGE = (
    ('', 'Choose...'),
    ('10', '10'),
    ('11', '11'),
)

LAST_ATTENDED_CLASS_FORM1710 = (
    ('', 'Choose...'),
    ('5', '5'),
    ('6', '6'),
    ('7', '7'),
    ('8', '8'),
    ('9', '9'),
    ('10', '10'),
)

LAST_ATTENDED_CLASS_FORM1712 = (
    ('', 'Choose...'),
    ('11', '11'),
    ('12', '12'),
)

FACULTY = (
    ('', 'Choose...'),
    ('SCIENCE', 'SCIENCE'),
    ('COMMERCE', 'COMMERCE'),
    ('ARTS', 'ARTS'),
    ('VOCATIONAL', 'VOCATIONAL')
)

FORM1710=(
    ('', 'Choose...'),
    ('10','10')
)

FORM1712=(
    ('', 'Choose...'),
    ('12','12')
)


MINORITY=(('', 'Choose...'),
    ('YES', 'YES'),
    ('NO', 'NO'),)

ADMTYPE=(('', 'Choose...'),
    ('FRESHER', 'FRESHER'),
    ('REPETER', 'REPETER'),('ONE TIME FAILED', 'ONE TIME FAILED'),)  

ADMLATE=(('', 'Choose...'),
    ('YES', 'YES'),
    ('NO', 'NO'),)  


HOSTEL=(('', 'Choose...'),
    ('YES', 'YES'),
    ('NO', 'NO'),) 

PWDS=(('', 'Choose...'),
    ('YES', 'YES'),
    ('NO', 'NO'),)  

BG=(
    ('', 'Choose...'),
    ('A', 'A'),
    ('A+', 'A+'),
    ('A-', 'A-'),
    ('B', 'B'),('B+', 'B+'),('B-', 'B-'),('AB', 'AB'),('AB+', 'AB+'),('AB-', 'AB-'),
    ('O', 'O'),
    ('O+', 'O+'),('O-', 'O-'),
) 

AREA=(('', 'Choose...'),
    ('RURAL', 'RURAL'),
    ('URBAN', 'URBAN'),) 

BPLEVEL=(('', 'Choose...'),
    ('YES', 'YES'),
    ('NO', 'NO'),)  

GURDIAN=(('', 'Choose...'),
    ('FATHER', 'FATHER'),
    ('MOTHER', 'MOTHER'),('OTHER', 'OTHER'),)    

NATION=(('', 'Choose...'),
    ('INDIAN', 'INDIAN'),
    ('AFGHAN', 'AFGHAN'),('BANGLADESHI', 'BANGLADESHI'),('NEPALESE', 'NEPALESE'),)  

IS=(('', 'Choose...'),
    ('YES', 'YES'),
    ('NO', 'NO'),) 

YEAR=(('', 'Choose...'),
    ('2019', '2019'),
    ('2020', '2020'),
    ('2021', '2021'),) 

ADMFOR=(
    ('','Choose'),
    ('Primary','Primary'),
    ('Secondary','Secondary'),
    ('11-ATKT','11-ATKT'),
    ('Jr.College','Jr.College'),
    ('Form1710','Form17 10'),
    ('Form1712','Form17 12'),
)
ADMCLASS=(
    ('', 'Choose...'),
    ('1', '1'),
    ('2', '2'),
    ('3', '3'),
    ('4', '4'),
    ('5', '5'),
    ('6', '6'),
    ('7', '7'),
    ('8', '8'),
    ('9', '9'),
    ('10', '10'),
    ('11', '11'),
    ('12', '12'),
)





#Rejoin Form
class RejoinForm(forms.Form):
    adm_from=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select Admission From"}),label="Admission From",choices=ADMFOR,required=True)
    adm_for=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select Admission For"}),label="Admission For",choices=ADMFOR,required=True)
    aadhar=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter Student Aadhar number",'placeholder': "विद्यार्थ्यांचे आधार कार्ड नंबर "}),label="Aadhar Number",max_length=12,min_length=12,required=True)
    adm_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select Admission Class"}),label="Admission Class",choices=ADMCLASS,required=True)
    admission_faculty=forms.ChoiceField(widget=forms.Select(attrs={'title': "Admission Stream"}),label="Admission Stream",choices=FACULTY,required=False)
    admdate=forms.CharField(label="Admission Date",widget=forms.TextInput(attrs={'title':"Enter Admission Date",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    prn=forms.CharField(widget=forms.TextInput(attrs={'title':"Student Registration Number",'placeholder': "रजिस्ट्रेशन नंबर"}),label="Registration Number",max_length=50,min_length=1,required=True)


#Primary Admission Form
class PriAdmForm(forms.ModelForm):
    #Student Details
    prn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Registration Number",'placeholder': "रजिस्ट्रेशन नंबर"}),label="Registration Number",max_length=50,min_length=1,required=True)
    lname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student surname",'placeholder': "विद्यार्थ्यांचे अडनाव "}),label="Student Last Name",max_length=20,min_length=2,required=True)   
    fname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student first name",'placeholder': "विद्यार्थ्यांचे नाव "}),label="Student First Name",max_length=20,min_length=2,required=True)   
    faname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father name",'placeholder': "विद्यार्थ्याच्या वडिलांचे नाव","onchange":'isguardian()'}),label="Student Father Name",max_length=20,min_length=2,required=True) 
    moname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother name",'placeholder': "विद्यार्थ्याच्या आईचे नाव","onchange":'isguardian()'}),label="Student Mother Name",max_length=20,min_length=2,required=True) 
    mrname=forms.CharField(widget=forms.TextInput(attrs={'title': "विद्यार्थ्यांचे पूर्ण नाव लिहा",'placeholder': "विद्यार्थ्यांचे पूर्ण नाव मराठी मध्ये "}),label="Student Name in Devnagari",max_length=50,min_length=2,required=False)  
    aadhar=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter Student Aadhar number",'placeholder': "विद्यार्थ्यांचे आधार कार्ड नंबर "}),label="Aadhar",max_length=12,min_length=12,required=True)
    saral_id=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student saral ID",'placeholder': "सरल नंबर "}),label="Saral ID",max_length=25,min_length=1,required=False) 
    nationality=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select nationality"}),label="Nationality",choices=NATION,initial="INDIAN",required=True)
    tongue=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select mother tongue"}),label="Mother Tongue",queryset=MTongue.objects.all(),required=True)
    religion=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select religion"}),label="Religion",queryset=Religion.objects.all(),required=True)
    cast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select caste"}),label="Caste",queryset=Cast.objects.all(),required=True)
    # category=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select cast-category"}),label="Cast category",queryset=CastCategory.objects.all(),required=True)
    subcast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select sub-caste"}),label="SubCaste",queryset=SubCast.objects.all(),required=False)
    minority=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select minority status"}),label="Minority",choices=MINORITY,initial="NO",required=True)
    pob=forms.CharField(widget=forms.TextInput(attrs={'title': "Student place of Birth",'placeholder': "जन्म ठिकाण "}),label="Place of Birth",max_length=100,min_length=3,required=True)  
    dob=forms.CharField(label="Date of Birth",widget=forms.TextInput(attrs={'title':"Enter student birthdate",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    last_school=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select student last attended school name",'placeholder': "शेवटच्या शिकत असलेलया शाळेचे नाव "}),label="Last attended school",queryset=OtherSch.objects.all(),required=False) 
    last_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Last Class Attended"}),label="Last Class Attended",choices=LAST_ATTENDED_CLASS_PRISCHOOL,required=False) 
    prevlcsrno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous LC Sr No.",'placeholder': " मागील एलसी क्र "}),label="Student Previous LC Sr No",max_length=10,min_length=1,required=False)
    prevprn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous Registration Number",'placeholder': " मागील रजिस्ट्रेशन नंबर"}),label="Previous Registration Number",max_length=50,min_length=1,required=False)
    admdate=forms.CharField(label="Admission Date",widget=forms.TextInput(attrs={'title':"Enter Admission Date",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    adm_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "In which class student want to get Admission"}),label="Admission Standard",choices=CLASS_PRISCHOOL,required=True) 
    division=forms.ModelChoiceField(widget=forms.Select(attrs={'title': "Select divisione",'placeholder': "तुकडी "}),label="Division",queryset=Division.objects.all(),required=False) 
    rollno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title': "Student Roll Number",'placeholder': "हजेरी क्रमांक "}),label="Roll Number ",max_length=10,min_length=1,required=False)    
    lateadm=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select late admission  "}),label="Late Admission",choices=ADMLATE,initial="NO",required=True)
    admtype=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select admission type "}),label="Admission Type",choices=ADMTYPE,initial="FRESHER",required=True)
    hostel=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select hostel required  "}),label="Hostel required",choices=HOSTEL,initial="NO",required=True)
    #Helth details
    sex=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select gender"}),label="Gender",choices=GENDERS,required=True)
    pwd=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select PWD status"}),label="Person With Disability",choices=PWDS,initial="NO",required=True)
    bgroup=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select blood group"}),label="Blood Group",choices=BG,required=False)     
    #Parents details
    fa_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Father mobile number",'placeholder': "वडिलांचा फोन नंबर","onchange":'isguardian()'}),label="Father Mobile",max_length=10,min_length=10,required=False)
    mo_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Mother mobile number",'placeholder': "आईचा फोन नंबर","onchange":'isguardian()'}),label="Mother Mobile",max_length=10,min_length=10,required=False)
    fa_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father occupation",'placeholder': "वडिलांचा व्यवसाय","onchange":'isguardian()'}),label="Father Occupation",max_length=15,min_length=3,required=False) 
    mo_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother occupation",'placeholder': "आईचा व्यवसाय ","onchange":'isguardian()'}),label="Mother Occupation",max_length=15,min_length=3,required=False) 
    fam_income=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter family Annual Income",'placeholder': "कुटुंबाचे वार्षिक उत्पन्न"}),label="Annual Income",max_length=10,min_length=3,required=False)
    bpl=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="BPL",choices=BPLEVEL,initial="NO",required=True) 
    #Guardian
    gis=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Guardian is ","onchange":'isguardian()'}),label="Guardian is",choices=GURDIAN,required=True)     
    ganame=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian full name",'placeholder': "विद्यार्थ्याच्या पालकाचे नाव"}),label="Guardian Name",max_length=50,min_length=4,required=False) 
    ga_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Guardian mobile number",'placeholder': "पालकाचे फोन नंबर"}),label="Guardian Mobile",max_length=10,min_length=10,required=False)
    ga_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian occupation",'placeholder': " पालकाचा व्यवसाय"}),label="Guardian Occupation",max_length=15,min_length=2,required=False) 
    gaddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter Guardian postal address",'placeholder': "पालकाचा पत्ता"}),label="Guardian Address",max_length=100,min_length=4,required=False) 
    ga_relation=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian Relation",'placeholder': "पालकाचे नाते"}),label="Guardian Relation",max_length=15,min_length=2,required=False) 
    #Address
    areaType=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Rural/Urban",choices=AREA,required=True) 
    email=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter your email",'placeholder': "Email"}),label="Email",max_length=50,min_length=4,required=True) 
    caddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter current postal address",'placeholder': "सध्याचा पत्ता","onchange":'address()'}),label="Current Address",max_length=100,min_length=4,required=True) 
    ca_is_pa_addr=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select if Current Address is Permanent Address ","onchange":'address()'}),label="Current Address is Permanent Address",choices=IS,initial="NO",required=True)     
    paddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter permanent postal address",'placeholder': "कायमचा पत्ता"}),label="Permanent Address",max_length=100,min_length=4,required=False) 
    #Bank Details
    baccount=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Bank account number",'placeholder': "बँक अकाऊंट नंबर"}),label="Bank Account Number",max_length=15,min_length=1,required=False)
    bankname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Name",'placeholder': "बँकेचे नाव "}),label=" Bank Name",max_length=20,min_length=2,required=False) 
    ifsc=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank IFSC",'placeholder': "IFSC नंबर"}),label=" IFSC Code",max_length=15,min_length=2,required=False) 
    branch=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Branch Name",'placeholder': "ब्रांचचे नाव "}),label="Branch Name",max_length=15,min_length=2,required=False) 
    micr=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank MICR Code",'placeholder': "MICR नंबर"}),label="MICR Code",max_length=15,min_length=2,required=False) 
    #Documents
    marks_img=forms.ImageField(allow_empty_file=True,label="Last year marksheet",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    prv_lc_img=forms.ImageField(allow_empty_file=True,label="Previous School LC",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    addhar_img=forms.ImageField(allow_empty_file=True,label="Aadhar Card",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    cast_img=forms.ImageField(allow_empty_file=True,label="Cast Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    castvald_img=forms.ImageField(allow_empty_file=True,label="Cast-Validity Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    nationality_img=forms.ImageField(allow_empty_file=True,label="Nationality Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    noncrimy_img=forms.ImageField(allow_empty_file=True,label="Non-Creamylayer Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    std_img=forms.ImageField(allow_empty_file=True,label="Student Photo",help_text='accept JPG/PNG file,max size 60 kb',required=False,validators=[file_size_profile_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    birth_img=forms.ImageField(allow_empty_file=True,label="Student Birth Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    note=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Note",'placeholder': "नोट"}),label="Note",max_length=100,min_length=4,required=False) 
    #message=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;'}),label='Message',max_length=200,min_length=4,initial="My Message is:: ",required=False)      
    class Meta:
        model = PrimAdm
        fields = ('note','prevprn','prevlcsrno','prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','subcast','minority','pob','dob','last_school','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','email','areaType','caddress','ca_is_pa_addr','paddress','baccount','bankname','ifsc','branch','micr','marks_img','prv_lc_img','addhar_img','cast_img','castvald_img','nationality_img','noncrimy_img','std_img','birth_img','last_class',)

    
# Admission Year Form
class GetAdmYearForm(forms.Form):
    year=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Year"}),label="Year",queryset=Year.objects.all(),required=False)          
    
   

# Secondary Admission Form
class SecondAdmForm(forms.ModelForm):
    prn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Registration Number",'placeholder': "रजिस्ट्रेशन नंबर"}),label="Registration Number",max_length=50,min_length=1,required=True)
    lname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student surname",'placeholder': "विद्यार्थ्यांचे अडनाव "}),label="Student Last Name",max_length=20,min_length=2,required=True)   
    fname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student first name",'placeholder': "विद्यार्थ्यांचे नाव "}),label="Student First Name",max_length=20,min_length=2,required=True)   
    faname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father name",'placeholder': "विद्यार्थ्याच्या वडिलांचे नाव","onchange":'isguardian()'}),label="Student Father Name",max_length=20,min_length=2,required=True) 
    moname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother name",'placeholder': "विद्यार्थ्याच्या आईचे नाव","onchange":'isguardian()'}),label="Student Mother Name",max_length=20,min_length=2,required=True) 
    mrname=forms.CharField(widget=forms.TextInput(attrs={'title': "विद्यार्थ्यांचे पूर्ण नाव लिहा",'placeholder': "विद्यार्थ्यांचे पूर्ण नाव मराठी मध्ये "}),label="Student Name in Devnagari",max_length=50,min_length=2,required=False)  
    aadhar=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter Student Aadhar number",'placeholder': "विद्यार्थ्यांचे आधार कार्ड नंबर "}),label="Aadhar",max_length=13,min_length=12,required=True)
    saral_id=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student saral ID",'placeholder': "सरल नंबर "}),label="Saral ID",max_length=25,min_length=1,required=False) 
    nationality=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select nationality"}),label="Nationality",choices=NATION,initial="INDIAN",required=True)
    tongue=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select mother tongue"}),label="Mother Tongue",queryset=MTongue.objects.all(),required=True)
    religion=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select religion"}),label="Religion",queryset=Religion.objects.all(),required=True)
    cast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select caste"}),label="Caste",queryset=Cast.objects.all(),required=True)
    # category=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select cast-category"}),label="Cast category",queryset=CastCategory.objects.all(),required=True)
    subcast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select sub-caste"}),label="SubCaste",queryset=SubCast.objects.all(),required=False)
    minority=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select minority status"}),label="Minority",choices=MINORITY,initial="NO",required=True)
    pob=forms.CharField(widget=forms.TextInput(attrs={'title': "Student place of Birth",'placeholder': "जन्म ठिकाण "}),label="Place of Birth",max_length=100,min_length=3,required=True)  
    dob=forms.CharField(label="Date of Birth",widget=forms.TextInput(attrs={'title':"Enter student birthdate",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    last_school=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select student last attended school name",'placeholder': "शेवटच्या शिकत असलेलया शाळेचे नाव "}),label="Last attended school",queryset=OtherSch.objects.all(),required=False) 
    last_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Last Class Attended"}),label="Last Class Attended",choices=LAST_ATTENDED_CLASS_SECSCHOOL,required=False) 
    prevlcsrno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous LC Sr No.",'placeholder': " मागील एलसी क्र "}),label="Student Previous LC Sr No",max_length=10,min_length=1,required=False)
    prevprn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous Registration Number",'placeholder': " मागील रजिस्ट्रेशन नंबर"}),label="Previous Registration Number",max_length=50,min_length=1,required=False)
    admdate=forms.CharField(label="Admission Date",widget=forms.TextInput(attrs={'title':"Enter Admission Date",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    adm_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "In which class student want to get Admission"}),label="Admission Standard",choices=CLASS_SECSCHOOL,required=True) 
    division=forms.ModelChoiceField(widget=forms.Select(attrs={'title': "Select divisione",'placeholder': "तुकडी "}),label="Division",queryset=Division.objects.all(),required=False) 
    rollno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title': "Student Roll Number",'placeholder': "हजेरी क्रमांक "}),label="Roll Number ",max_length=10,min_length=1,required=False)    
    lateadm=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select late admission  "}),label="Late Admission",choices=ADMLATE,initial="NO",required=True)
    admtype=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select admission type "}),label="Admission Type",choices=ADMTYPE,initial="FRESHER",required=True)
    hostel=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select hostel required  "}),label="Hostel required",choices=HOSTEL,initial="NO",required=True)
    #Helth details
    sex=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select gender"}),label="Gender",choices=GENDERS,required=True)
    pwd=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select PWD status"}),label="Person With Disability",choices=PWDS,initial="NO",required=True)
    bgroup=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select blood group"}),label="Blood Group",choices=BG,required=False)     
    #Parents details
    fa_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Father mobile number",'placeholder': "वडिलांचा फोन नंबर","onchange":'isguardian()'}),label="Father Mobile",max_length=10,min_length=10,required=False)
    mo_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Mother mobile number",'placeholder': "आईचा फोन नंबर","onchange":'isguardian()'}),label="Mother Mobile",max_length=10,min_length=10,required=False)
    fa_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father occupation",'placeholder': "वडिलांचा व्यवसाय","onchange":'isguardian()'}),label="Father Occupation",max_length=15,min_length=3,required=False) 
    mo_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother occupation",'placeholder': "आईचा व्यवसाय ","onchange":'isguardian()'}),label="Mother Occupation",max_length=15,min_length=3,required=False) 
    fam_income=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter family Annual Income",'placeholder': "कुटुंबाचे वार्षिक उत्पन्न"}),label="Annual Income",max_length=10,min_length=3,required=False)
    bpl=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="BPL",choices=BPLEVEL,initial="NO",required=True) 
    #Guardian
    gis=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Guardian is ","onchange":'isguardian()'}),label="Guardian is",choices=GURDIAN,required=True)     
    ganame=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian full name",'placeholder': "विद्यार्थ्याच्या पालकाचे नाव"}),label="Guardian Name",max_length=50,min_length=4,required=False) 
    ga_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Guardian mobile number",'placeholder': "पालकाचे फोन नंबर"}),label="Guardian Mobile",max_length=10,min_length=10,required=False)
    ga_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian occupation",'placeholder': " पालकाचा व्यवसाय"}),label="Guardian Occupation",max_length=15,min_length=2,required=False) 
    gaddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter Guardian postal address",'placeholder': "पालकाचा पत्ता"}),label="Guardian Address",max_length=100,min_length=4,required=False) 
    ga_relation=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian Relation",'placeholder': "पालकाचे नाते"}),label="Guardian Relation",max_length=15,min_length=2,required=False) 
    #Address
    areaType=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Rural/Urban",choices=AREA,required=True) 
    email=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter your email",'placeholder': "Email"}),label="Email",max_length=50,min_length=4,required=True) 
    caddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter current postal address",'placeholder': "सध्याचा पत्ता","onchange":'address()'}),label="Current Address",max_length=100,min_length=4,required=True) 
    ca_is_pa_addr=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select if Current Address is Permanent Address ","onchange":'address()'}),label="Current Address is Permanent Address",choices=IS,required=True)     
    paddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter permanent postal address",'placeholder': "कायमचा पत्ता"}),label="Permanent Address",max_length=100,min_length=4,required=False) 
    #Bank Details
    baccount=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Bank account number",'placeholder': "बँक अकाऊंट नंबर"}),label="Bank Account Number",max_length=15,min_length=1,required=False)
    bankname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Name",'placeholder': "बँकेचे नाव "}),label=" Bank Name",max_length=20,min_length=2,required=False) 
    ifsc=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank IFSC",'placeholder': "IFSC नंबर"}),label=" IFSC Code",max_length=15,min_length=2,required=False) 
    branch=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Branch Name",'placeholder': "ब्रांचचे नाव "}),label="Branch Name",max_length=15,min_length=2,required=False) 
    micr=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank MICR Code",'placeholder': "MICR नंबर"}),label="MICR Code",max_length=15,min_length=2,required=False) 
    #Documents
    marks_img=forms.ImageField(allow_empty_file=True,label="Last year marksheet",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    prv_lc_img=forms.ImageField(allow_empty_file=True,label="Previous School LC",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    addhar_img=forms.ImageField(allow_empty_file=True,label="Aadhar Card",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    cast_img=forms.ImageField(allow_empty_file=True,label="Cast Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    castvald_img=forms.ImageField(allow_empty_file=True,label="Cast-Validity Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    nationality_img=forms.ImageField(allow_empty_file=True,label="Nationality Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    noncrimy_img=forms.ImageField(allow_empty_file=True,label="Non-Creamylayer Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    std_img=forms.ImageField(allow_empty_file=True,label="Student Photo",help_text='accept JPG/PNG file,max size 60 kb',required=False,validators=[file_size_profile_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    birth_img=forms.ImageField(allow_empty_file=True,label="Student Birth Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    note=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Note",'placeholder': "नोट"}),label="Note",max_length=100,min_length=4,required=False) 
    #message=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;'}),label='Message',max_length=200,min_length=4,initial="My Message is:: ",required=False)      
    class Meta:
        model = SecondAdm
        fields = ('note','prevprn','prevlcsrno','prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','subcast','minority','pob','dob','last_school','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','email','areaType','caddress','ca_is_pa_addr','paddress','baccount','bankname','ifsc','branch','micr','marks_img','prv_lc_img','addhar_img','cast_img','castvald_img','nationality_img','noncrimy_img','std_img','birth_img','last_class',)



# College Admission Form
class ATKT11AdmForm(forms.ModelForm):
    prn=forms.CharField(widget=forms.TextInput(attrs={'title':"Student Registration Number",'placeholder': "रजिस्ट्रेशन नंबर"}),label="Registration Number",max_length=50,min_length=1,required=True)
    lname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student surname",'placeholder': "विद्यार्थ्यांचे अडनाव "}),label="Student Last Name",max_length=20,min_length=2,required=True)   
    fname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student first name",'placeholder': "विद्यार्थ्यांचे नाव "}),label="Student First Name",max_length=20,min_length=2,required=True)   
    faname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father name",'placeholder': "विद्यार्थ्याच्या वडिलांचे नाव","onchange":'isguardian()'}),label="Student Father Name",max_length=20,min_length=2,required=True) 
    moname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother name",'placeholder': "विद्यार्थ्याच्या आईचे नाव","onchange":'isguardian()'}),label="Student Mother Name",max_length=20,min_length=2,required=True) 
    mrname=forms.CharField(widget=forms.TextInput(attrs={'title': "विद्यार्थ्यांचे पूर्ण नाव लिहा",'placeholder': "विद्यार्थ्यांचे पूर्ण नाव मराठी मध्ये "}),label="Student Name in Devnagari",max_length=50,min_length=2,required=False)  
    aadhar=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter Student Aadhar number",'placeholder': "विद्यार्थ्यांचे आधार कार्ड नंबर "}),label="Aadhar",max_length=13,min_length=12,required=True)
    saral_id=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student saral ID",'placeholder': "सरल नंबर "}),label="Saral ID",max_length=25,min_length=1,required=False) 
    nationality=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select nationality"}),label="Nationality",choices=NATION,initial="INDIAN",required=True)
    tongue=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select mother tongue"}),label="Mother Tongue",queryset=MTongue.objects.all(),required=True)
    religion=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select religion"}),label="Religion",queryset=Religion.objects.all(),required=True)
    cast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select caste"}),label="Caste",queryset=Cast.objects.all(),required=True)
    # category=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select cast-category"}),label="Cast category",queryset=CastCategory.objects.all(),required=True)
    subcast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select sub-caste"}),label="SubCaste",queryset=SubCast.objects.all(),required=False)
    minority=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select minority status"}),label="Minority",choices=MINORITY,initial="NO",required=True)
    pob=forms.CharField(widget=forms.TextInput(attrs={'title': "Student place of Birth",'placeholder': "जन्म ठिकाण "}),label="Place of Birth",max_length=100,min_length=3,required=True)  
    dob=forms.CharField(label="Date of Birth",widget=forms.TextInput(attrs={'title':"Enter student birthdate",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    last_school=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select student last attended school name",'placeholder': "शेवटच्या शिकत असलेलया शाळेचे नाव "}),label="Last attended school",queryset=OtherSch.objects.all(),required=False) 
    last_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Last Class Attended"}),label="Last Class Attended",choices=(('10', '10'),),required=False) 
    prevlcsrno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous LC Sr No.",'placeholder': " मागील एलसी क्र "}),label="Student Previous LC Sr No",max_length=10,min_length=1,required=False)
    prevprn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous Registration Number",'placeholder': " मागील रजिस्ट्रेशन नंबर"}),label="Previous Registration Number",max_length=50,min_length=1,required=False)
    admdate=forms.CharField(label="Admission Date",widget=forms.TextInput(attrs={'title':"Enter Admission Date",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    adm_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "In which class you want to get Admission"}),label="Admission Standard",choices=CLASS_ATKT,required=True)
    admission_faculty=forms.ChoiceField(widget=forms.Select(attrs={'title': "In which Stream you want to get Admission"}),label="Admission Stream",choices=FACULTY,required=True)
    division=forms.ModelChoiceField(widget=forms.Select(attrs={'title': "Select divisione",'placeholder': "तुकडी "}),label="Division",queryset=Division.objects.all(),required=False) 
    rollno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title': "Student Roll Number",'placeholder': "हजेरी क्रमांक "}),label="Roll Number ",max_length=10,min_length=1,required=False)    
    lateadm=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select late admission  "}),label="Late Admission",choices=ADMLATE,initial="NO",required=True)
    admtype=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select admission type "}),label="Admission Type",choices=ADMTYPE,initial="FRESHER",required=True)
    hostel=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select hostel required  "}),label="Hostel required",choices=HOSTEL,initial="NO",required=True)
    #Helth details
    sex=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select gender"}),label="Gender",choices=GENDERS,required=True)
    pwd=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select PWD status"}),label="Person With Disability",choices=PWDS,initial="NO",required=True)
    bgroup=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select blood group"}),label="Blood Group",choices=BG,required=False)     
    #Parents details
    fa_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Father mobile number",'placeholder': "वडिलांचा फोन नंबर","onchange":'isguardian()'}),label="Father Mobile",max_length=10,min_length=10,required=False)
    mo_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Mother mobile number",'placeholder': "आईचा फोन नंबर","onchange":'isguardian()'}),label="Mother Mobile",max_length=10,min_length=10,required=False)
    fa_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father occupation",'placeholder': "वडिलांचा व्यवसाय","onchange":'isguardian()'}),label="Father Occupation",max_length=15,min_length=3,required=False) 
    mo_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother occupation",'placeholder': "आईचा व्यवसाय ","onchange":'isguardian()'}),label="Mother Occupation",max_length=15,min_length=3,required=False) 
    fam_income=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter family Annual Income",'placeholder': "कुटुंबाचे वार्षिक उत्पन्न"}),label="Annual Income",max_length=10,min_length=3,required=False)
    bpl=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="BPL",choices=BPLEVEL,initial="NO",required=True) 
    #Guardian
    gis=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Guardian is ","onchange":'isguardian()'}),label="Guardian is",choices=GURDIAN,required=True)     
    ganame=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian full name",'placeholder': "विद्यार्थ्याच्या पालकाचे नाव"}),label="Guardian Name",max_length=50,min_length=4,required=False) 
    ga_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Guardian mobile number",'placeholder': "पालकाचे फोन नंबर"}),label="Guardian Mobile",max_length=10,min_length=10,required=False)
    ga_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian occupation",'placeholder': " पालकाचा व्यवसाय"}),label="Guardian Occupation",max_length=15,min_length=2,required=False) 
    gaddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter Guardian postal address",'placeholder': "पालकाचा पत्ता"}),label="Guardian Address",max_length=100,min_length=4,required=False) 
    ga_relation=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian Relation",'placeholder': "पालकाचे नाते"}),label="Guardian Relation",max_length=15,min_length=2,required=False) 
    #Address
    areaType=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Rural/Urban",choices=AREA,required=True) 
    email=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter your email",'placeholder': "Email"}),label="Email",max_length=50,min_length=4,required=True) 
    caddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter current postal address",'placeholder': "सध्याचा पत्ता","onchange":'address()'}),label="Current Address",max_length=100,min_length=4,required=True) 
    ca_is_pa_addr=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select if Current Address is Permanent Address ","onchange":'address()'}),label="Current Address is Permanent Address",choices=IS,required=True)     
    paddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter permanent postal address",'placeholder': "कायमचा पत्ता"}),label="Permanent Address",max_length=100,min_length=4,required=False) 
    #Bank Details
    baccount=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Bank account number",'placeholder': "बँक अकाऊंट नंबर"}),label="Bank Account Number",max_length=15,min_length=1,required=False)
    bankname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Name",'placeholder': "बँकेचे नाव "}),label=" Bank Name",max_length=20,min_length=2,required=False) 
    ifsc=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank IFSC",'placeholder': "IFSC नंबर"}),label=" IFSC Code",max_length=15,min_length=2,required=False) 
    branch=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Branch Name",'placeholder': "ब्रांचचे नाव "}),label="Branch Name",max_length=15,min_length=2,required=False) 
    micr=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank MICR Code",'placeholder': "MICR नंबर"}),label="MICR Code",max_length=15,min_length=2,required=False)
    #Bonafide
    bonaissuedate=forms.CharField(label="Bonafide Issued Date",widget=forms.TextInput(attrs={'title':"Enter student Bonafide Issued Date",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    bonasrno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Bonafide Sr No.",'placeholder': "मागील बोनफाइड क्र "}),label="Student Previous Bonafide Sr No",max_length=10,min_length=1,required=True)
    #Documents
    marks_img=forms.ImageField(allow_empty_file=True,label="Last year marksheet",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    prv_lc_img=forms.ImageField(allow_empty_file=True,label="Previous School LC",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    addhar_img=forms.ImageField(allow_empty_file=True,label="Aadhar Card",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    cast_img=forms.ImageField(allow_empty_file=True,label="Cast Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    castvald_img=forms.ImageField(allow_empty_file=True,label="Cast-Validity Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    nationality_img=forms.ImageField(allow_empty_file=True,label="Nationality Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    noncrimy_img=forms.ImageField(allow_empty_file=True,label="Non-Creamylayer Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    std_img=forms.ImageField(allow_empty_file=True,label="Student Photo",help_text='accept JPG/PNG file,max size 60 kb',required=False,validators=[file_size_profile_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    birth_img=forms.ImageField(allow_empty_file=True,label="Student Birth Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    bonafide_img=forms.ImageField(allow_empty_file=True,label="Student Bonafide Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    note=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Note",'placeholder': "नोट"}),label="Note",max_length=100,min_length=4,required=False) 
    #message=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;'}),label='Message',max_length=200,min_length=4,initial="My Message is:: ",required=False)      
    class Meta:
        model = ATKT11Adm
        fields = ('bonaissuedate','bonasrno','bonafide_img','note','prevprn','prevlcsrno','prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','subcast','minority','pob','dob','last_school','admdate','adm_class','admission_faculty','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','email','areaType','caddress','ca_is_pa_addr','paddress','baccount','bankname','ifsc','branch','micr','marks_img','prv_lc_img','addhar_img','cast_img','castvald_img','nationality_img','noncrimy_img','std_img','birth_img','last_class',)




# College Admission Form
class CollegeAdmForm(forms.ModelForm):
    prn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Registration Number",'placeholder': "रजिस्ट्रेशन नंबर"}),label="Registration Number",max_length=50,min_length=1,required=True)
    lname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student surname",'placeholder': "विद्यार्थ्यांचे अडनाव "}),label="Student Last Name",max_length=20,min_length=2,required=True)   
    fname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student first name",'placeholder': "विद्यार्थ्यांचे नाव "}),label="Student First Name",max_length=20,min_length=2,required=True)   
    faname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father name",'placeholder': "विद्यार्थ्याच्या वडिलांचे नाव","onchange":'isguardian()'}),label="Student Father Name",max_length=20,min_length=2,required=True) 
    moname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother name",'placeholder': "विद्यार्थ्याच्या आईचे नाव","onchange":'isguardian()'}),label="Student Mother Name",max_length=20,min_length=2,required=True) 
    mrname=forms.CharField(widget=forms.TextInput(attrs={'title': "विद्यार्थ्यांचे पूर्ण नाव लिहा",'placeholder': "विद्यार्थ्यांचे पूर्ण नाव मराठी मध्ये "}),label="Student Name in Devnagari",max_length=50,min_length=2,required=False)  
    aadhar=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter Student Aadhar number",'placeholder': "विद्यार्थ्यांचे आधार कार्ड नंबर "}),label="Aadhar",max_length=13,min_length=12,required=True)
    saral_id=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student saral ID",'placeholder': "सरल नंबर "}),label="Saral ID",max_length=25,min_length=1,required=False) 
    nationality=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select nationality"}),label="Nationality",choices=NATION,initial="INDIAN",required=True)
    tongue=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select mother tongue"}),label="Mother Tongue",queryset=MTongue.objects.all(),required=True)
    religion=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select religion"}),label="Religion",queryset=Religion.objects.all(),required=True)
    cast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select caste"}),label="Caste",queryset=Cast.objects.all(),required=True)
    # category=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select cast-category"}),label="Cast category",queryset=CastCategory.objects.all(),required=True)
    subcast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select sub-caste"}),label="SubCaste",queryset=SubCast.objects.all(),required=False)
    minority=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select minority status"}),label="Minority",choices=MINORITY,initial="NO",required=True)
    pob=forms.CharField(widget=forms.TextInput(attrs={'title': "Student place of Birth",'placeholder': "जन्म ठिकाण "}),label="Place of Birth",max_length=100,min_length=3,required=True)  
    dob=forms.CharField(label="Date of Birth",widget=forms.TextInput(attrs={'title':"Enter student birthdate",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    last_school=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select student last attended school name",'placeholder': "शेवटच्या शिकत असलेलया शाळेचे नाव "}),label="Last attended school",queryset=OtherSch.objects.all(),required=False) 
    last_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Last Class Attended"}),label="Last Class Attended",choices=LAST_ATTENDED_CLASS_COLLEGE,required=False) 
    prevlcsrno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous LC Sr No.",'placeholder': " मागील एलसी क्र "}),label="Student Previous LC Sr No",max_length=10,min_length=1,required=False)
    prevprn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous Registration Number",'placeholder': " मागील रजिस्ट्रेशन नंबर"}),label="Previous Registration Number",max_length=50,min_length=1,required=False)
    admdate=forms.CharField(label="Admission Date",widget=forms.TextInput(attrs={'title':"Enter Admission Date",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    adm_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "In which class you want to get Admission"}),label="Admission Standard",choices=CLASS_COLLEGE,required=True) 
    admission_faculty=forms.ChoiceField(widget=forms.Select(attrs={'title': "In which Stream you want to get Admission"}),label="Admission Stream",choices=FACULTY,required=True)
    division=forms.ModelChoiceField(widget=forms.Select(attrs={'title': "Select divisione",'placeholder': "तुकडी "}),label="Division",queryset=Division.objects.all(),required=False) 
    rollno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title': "Student Roll Number",'placeholder': "हजेरी क्रमांक "}),label="Roll Number ",max_length=10,min_length=1,required=False)    
    lateadm=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select late admission  "}),label="Late Admission",choices=ADMLATE,initial="NO",required=True)
    admtype=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select admission type "}),label="Admission Type",choices=ADMTYPE,initial="FRESHER",required=True)
    hostel=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select hostel required  "}),label="Hostel required",choices=HOSTEL,initial="NO",required=True)
    #Helth details
    sex=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select gender"}),label="Gender",choices=GENDERS,required=True)
    pwd=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select PWD status"}),label="Person With Disability",choices=PWDS,initial="NO",required=True)
    bgroup=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select blood group"}),label="Blood Group",choices=BG,required=False)     
    #Parents details
    fa_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Father mobile number",'placeholder': "वडिलांचा फोन नंबर","onchange":'isguardian()'}),label="Father Mobile",max_length=10,min_length=10,required=False)
    mo_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Mother mobile number",'placeholder': "आईचा फोन नंबर","onchange":'isguardian()'}),label="Mother Mobile",max_length=10,min_length=10,required=False)
    fa_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father occupation",'placeholder': "वडिलांचा व्यवसाय","onchange":'isguardian()'}),label="Father Occupation",max_length=15,min_length=3,required=False) 
    mo_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother occupation",'placeholder': "आईचा व्यवसाय ","onchange":'isguardian()'}),label="Mother Occupation",max_length=15,min_length=3,required=False) 
    fam_income=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter family Annual Income",'placeholder': "कुटुंबाचे वार्षिक उत्पन्न"}),label="Annual Income",max_length=10,min_length=3,required=False)
    bpl=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="BPL",choices=BPLEVEL,initial="NO",required=True) 
    #Guardian
    gis=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Guardian is ","onchange":'isguardian()'}),label="Guardian is",choices=GURDIAN,required=True)     
    ganame=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian full name",'placeholder': "विद्यार्थ्याच्या पालकाचे नाव"}),label="Guardian Name",max_length=50,min_length=4,required=False) 
    ga_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Guardian mobile number",'placeholder': "पालकाचे फोन नंबर"}),label="Guardian Mobile",max_length=10,min_length=10,required=False)
    ga_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian occupation",'placeholder': " पालकाचा व्यवसाय"}),label="Guardian Occupation",max_length=15,min_length=2,required=False) 
    gaddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter Guardian postal address",'placeholder': "पालकाचा पत्ता"}),label="Guardian Address",max_length=100,min_length=4,required=False) 
    ga_relation=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian Relation",'placeholder': "पालकाचे नाते"}),label="Guardian Relation",max_length=15,min_length=2,required=False) 
    #Address
    areaType=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Rural/Urban",choices=AREA,required=True) 
    email=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter your email",'placeholder': "Email"}),label="Email",max_length=50,min_length=4,required=True) 
    caddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter current postal address",'placeholder': "सध्याचा पत्ता","onchange":'address()'}),label="Current Address",max_length=100,min_length=4,required=True) 
    ca_is_pa_addr=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select if Current Address is Permanent Address ","onchange":'address()'}),label="Current Address is Permanent Address",choices=IS,required=True)     
    paddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter permanent postal address",'placeholder': "कायमचा पत्ता"}),label="Permanent Address",max_length=100,min_length=4,required=False) 
    #Bank Details
    baccount=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Bank account number",'placeholder': "बँक अकाऊंट नंबर"}),label="Bank Account Number",max_length=15,min_length=1,required=False)
    bankname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Name",'placeholder': "बँकेचे नाव "}),label=" Bank Name",max_length=20,min_length=2,required=False) 
    ifsc=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank IFSC",'placeholder': "IFSC नंबर"}),label=" IFSC Code",max_length=15,min_length=2,required=False) 
    branch=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Branch Name",'placeholder': "ब्रांचचे नाव "}),label="Branch Name",max_length=15,min_length=2,required=False) 
    micr=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank MICR Code",'placeholder': "MICR नंबर"}),label="MICR Code",max_length=15,min_length=2,required=False) 
    #Documents
    marks_img=forms.ImageField(allow_empty_file=True,label="Last year marksheet",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    prv_lc_img=forms.ImageField(allow_empty_file=True,label="Previous School LC",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    addhar_img=forms.ImageField(allow_empty_file=True,label="Aadhar Card",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    cast_img=forms.ImageField(allow_empty_file=True,label="Cast Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    castvald_img=forms.ImageField(allow_empty_file=True,label="Cast-Validity Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    nationality_img=forms.ImageField(allow_empty_file=True,label="Nationality Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    noncrimy_img=forms.ImageField(allow_empty_file=True,label="Non-Creamylayer Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    std_img=forms.ImageField(allow_empty_file=True,label="Student Photo",help_text='accept JPG/PNG file,max size 60 kb',required=False,validators=[file_size_profile_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    birth_img=forms.ImageField(allow_empty_file=True,label="Student Birth Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    note=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Note",'placeholder': "नोट"}),label="Note",max_length=100,min_length=4,required=False) 
    #message=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;'}),label='Message',max_length=200,min_length=4,initial="My Message is:: ",required=False)      
    class Meta:
        model = CollegeAdm
        fields = ('note','prevprn','prevlcsrno','prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','subcast','minority','pob','dob','last_school','admdate','adm_class','admission_faculty','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','email','areaType','caddress','ca_is_pa_addr','paddress','baccount','bankname','ifsc','branch','micr','marks_img','prv_lc_img','addhar_img','cast_img','castvald_img','nationality_img','noncrimy_img','std_img','birth_img','last_class',)




#Form1710 Admission Form
class Form1710AdmForm(forms.ModelForm):
    #Student Details
    prn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Registration Number",'placeholder': "रजिस्ट्रेशन नंबर"}),label="Registration Number",max_length=50,min_length=1,required=True)
    lname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student surname",'placeholder': "विद्यार्थ्यांचे अडनाव"}),label="Student Last Name",max_length=20,min_length=2,required=True)   
    fname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student first name",'placeholder': "विद्यार्थ्यांचे नाव"}),label="Student First Name",max_length=20,min_length=2,required=True)   
    faname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father name",'placeholder': "विद्यार्थ्याच्या वडिलांचे नाव","onchange":'isguardian()'}),label="Student Father Name",max_length=20,min_length=2,required=True) 
    moname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother name",'placeholder': "विद्यार्थ्याच्या आईचे नाव","onchange":'isguardian()'}),label="Student Mother Name",max_length=20,min_length=2,required=True) 
    mrname=forms.CharField(widget=forms.TextInput(attrs={'title': "विद्यार्थ्यांचे पूर्ण नाव लिहा",'placeholder': "विद्यार्थ्यांचे पूर्ण नाव मराठी मध्ये "}),label="Student Name in Devnagari",max_length=50,min_length=2,required=False)  
    aadhar=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter Student Aadhar number",'placeholder': "विद्यार्थ्यांचे आधार कार्ड नंबर "}),label="Aadhar",max_length=12,min_length=12,required=True)
    saral_id=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student saral ID",'placeholder': "सरल नंबर "}),label="Saral ID",max_length=25,min_length=1,required=False) 
    nationality=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select nationality"}),label="Nationality",choices=NATION,initial="INDIAN",required=True)
    tongue=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select mother tongue"}),label="Mother Tongue",queryset=MTongue.objects.all(),required=True)
    religion=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select religion"}),label="Religion",queryset=Religion.objects.all(),required=True)
    cast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select caste"}),label="Caste",queryset=Cast.objects.all(),required=True)
    # category=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select cast-category"}),label="Cast category",queryset=CastCategory.objects.all(),required=True)
    subcast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select sub-caste"}),label="SubCaste",queryset=SubCast.objects.all(),required=False)
    minority=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select minority status"}),label="Minority",choices=MINORITY,initial="NO",required=True)
    pob=forms.CharField(widget=forms.TextInput(attrs={'title': "Student place of Birth",'placeholder': "जन्म ठिकाण "}),label="Place of Birth",max_length=100,min_length=3,required=True)  
    dob=forms.CharField(label="Date of Birth",widget=forms.TextInput(attrs={'title':"Enter student birthdate",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    last_school=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select student last attended school name",'placeholder': "शेवटच्या शिकत असलेलया शाळेचे नाव "}),label="Last attended school",queryset=OtherSch.objects.all(),required=True) 
    last_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Last Class Attended"}),label="Last Class Attended",choices=LAST_ATTENDED_CLASS_FORM1710,required=True) 
    prevlcsrno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous LC Sr No.",'placeholder': " मागील एलसी क्र "}),label="Student Previous LC Sr No",max_length=10,min_length=1,required=True)
    prevprn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous Registration Number",'placeholder': " मागील रजिस्ट्रेशन नंबर"}),label="Previous Registration Number",max_length=50,min_length=1,required=True)
    admdate=forms.CharField(label="Admission Date",widget=forms.TextInput(attrs={'title':"Enter Admission Date",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    adm_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "In which class student want to get Admission"}),label="Admission Standard",choices=FORM1710,initial="10",required=True) 
    rollno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title': "Student Roll Number",'placeholder': "हजेरी क्रमांक "}),label="Roll Number ",max_length=10,min_length=1,required=False)    
    lateadm=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select late admission  "}),label="Late Admission",choices=ADMLATE,initial="NO",required=True)
    admtype=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select admission type "}),label="Admission Type",choices=ADMTYPE,initial="FRESHER",required=True)
    hostel=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select hostel required  "}),label="Hostel required",choices=HOSTEL,initial="NO",required=True)
    #Helth details
    sex=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select gender"}),label="Gender",choices=GENDERS,required=True)
    pwd=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select PWD status"}),label="Person With Disability",choices=PWDS,initial="NO",required=True)
    bgroup=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select blood group"}),label="Blood Group",choices=BG,required=False)     
    #Parents details
    fa_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Father mobile number",'placeholder': "वडिलांचा फोन नंबर","onchange":'isguardian()'}),label="Father Mobile",max_length=10,min_length=10,required=False)
    mo_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Mother mobile number",'placeholder': "आईचा फोन नंबर","onchange":'isguardian()'}),label="Mother Mobile",max_length=10,min_length=10,required=False)
    fa_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father occupation",'placeholder': "वडिलांचा व्यवसाय","onchange":'isguardian()'}),label="Father Occupation",max_length=15,min_length=3,required=False) 
    mo_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother occupation",'placeholder': "आईचा व्यवसाय ","onchange":'isguardian()'}),label="Mother Occupation",max_length=15,min_length=3,required=False) 
    fam_income=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter family Annual Income",'placeholder': "कुटुंबाचे वार्षिक उत्पन्न"}),label="Annual Income",max_length=10,min_length=3,required=False)
    bpl=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="BPL",choices=BPLEVEL,initial="NO",required=True) 
    #Guardian
    gis=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Guardian is ","onchange":'isguardian()'}),label="Guardian is",choices=GURDIAN,required=True)     
    ganame=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian full name",'placeholder': "विद्यार्थ्याच्या पालकाचे नाव"}),label="Guardian Name",max_length=50,min_length=4,required=False) 
    ga_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Guardian mobile number",'placeholder': "पालकाचे फोन नंबर"}),label="Guardian Mobile",max_length=10,min_length=10,required=False)
    ga_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian occupation",'placeholder': " पालकाचा व्यवसाय"}),label="Guardian Occupation",max_length=15,min_length=2,required=False) 
    gaddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter Guardian postal address",'placeholder': "पालकाचा पत्ता"}),label="Guardian Address",max_length=100,min_length=4,required=False) 
    ga_relation=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian Relation",'placeholder': "पालकाचे नाते"}),label="Guardian Relation",max_length=15,min_length=2,required=False) 
    #Address
    areaType=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Rural/Urban",choices=AREA,required=True) 
    email=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter your email",'placeholder': "Email"}),label="Email",max_length=50,min_length=4,required=True) 
    caddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter current postal address",'placeholder': "सध्याचा पत्ता","onchange":'address()'}),label="Current Address",max_length=100,min_length=4,required=True) 
    ca_is_pa_addr=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select if Current Address is Permanent Address","onchange":'address()'}),label="Current Address is Permanent Address",choices=IS,required=True)     
    paddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter permanent postal address",'placeholder': "कायमचा पत्ता"}),label="Permanent Address",max_length=100,min_length=4,required=False) 
    #Bank Details
    baccount=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Bank account number",'placeholder': "बँक अकाऊंट नंबर"}),label="Bank Account Number",max_length=15,min_length=1,required=False)
    bankname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Name",'placeholder': "बँकेचे नाव "}),label=" Bank Name",max_length=20,min_length=2,required=False) 
    ifsc=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank IFSC",'placeholder': "IFSC नंबर"}),label=" IFSC Code",max_length=15,min_length=2,required=False) 
    branch=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Branch Name",'placeholder': "ब्रांचचे नाव "}),label="Branch Name",max_length=15,min_length=2,required=False) 
    micr=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank MICR Code",'placeholder': "MICR नंबर"}),label="MICR Code",max_length=15,min_length=2,required=False) 
    #Documents
    marks_img=forms.ImageField(allow_empty_file=True,label="Last year marksheet",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    prv_lc_img=forms.ImageField(allow_empty_file=True,label="Previous School LC",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    addhar_img=forms.ImageField(allow_empty_file=True,label="Aadhar Card",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    cast_img=forms.ImageField(allow_empty_file=True,label="Cast Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    castvald_img=forms.ImageField(allow_empty_file=True,label="Cast-Validity Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    nationality_img=forms.ImageField(allow_empty_file=True,label="Nationality Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    noncrimy_img=forms.ImageField(allow_empty_file=True,label="Non-Creamylayer Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    std_img=forms.ImageField(allow_empty_file=True,label="Student Photo",help_text='accept JPG/PNG file,max size 60 kb',required=False,validators=[file_size_profile_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    birth_img=forms.ImageField(allow_empty_file=True,label="Student Birth Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    note=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Note",'placeholder': "नोट"}),label="Note",max_length=100,min_length=4,required=False) 
    #message=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;'}),label='Message',max_length=200,min_length=4,initial="My Message is:: ",required=False)      
    class Meta:
        model = Form1710Adm
        fields = ('note','prevprn','prevlcsrno','prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','subcast','minority','pob','dob','last_school','admdate','adm_class','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','email','areaType','caddress','ca_is_pa_addr','paddress','baccount','bankname','ifsc','branch','micr','marks_img','prv_lc_img','addhar_img','cast_img','castvald_img','nationality_img','noncrimy_img','std_img','birth_img','last_class',)




# Form1712 Admission Form
class Form1712AdmForm(forms.ModelForm):
    prn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Registration Number",'placeholder': "रजिस्ट्रेशन नंबर"}),label="Registration Number",max_length=50,min_length=1,required=True)
    lname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student surname",'placeholder': "विद्यार्थ्यांचे अडनाव "}),label="Student Last Name",max_length=20,min_length=2,required=True)   
    fname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student first name",'placeholder': "विद्यार्थ्यांचे नाव "}),label="Student First Name",max_length=20,min_length=2,required=True)   
    faname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father name",'placeholder': "विद्यार्थ्याच्या वडिलांचे नाव","onchange":'isguardian()'}),label="Student Father Name",max_length=20,min_length=2,required=True) 
    moname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother name",'placeholder': "विद्यार्थ्याच्या आईचे नाव","onchange":'isguardian()'}),label="Student Mother Name",max_length=20,min_length=2,required=True) 
    mrname=forms.CharField(widget=forms.TextInput(attrs={'title': "विद्यार्थ्यांचे पूर्ण नाव लिहा",'placeholder': "विद्यार्थ्यांचे पूर्ण नाव मराठी मध्ये "}),label="Student Name in Devnagari",max_length=50,min_length=2,required=False)  
    aadhar=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter Student Aadhar number",'placeholder': "विद्यार्थ्यांचे आधार कार्ड नंबर "}),label="Aadhar",max_length=13,min_length=12,required=True)
    saral_id=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter student saral ID",'placeholder': "सरल नंबर "}),label="Saral ID",max_length=25,min_length=1,required=False) 
    nationality=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select nationality"}),label="Nationality",choices=NATION,initial="INDIAN",required=True)
    tongue=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select mother tongue"}),label="Mother Tongue",queryset=MTongue.objects.all(),required=True)
    religion=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select religion"}),label="Religion",queryset=Religion.objects.all(),required=True)
    cast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select caste"}),label="Caste",queryset=Cast.objects.all(),required=True)
    # category=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select cast-category"}),label="Cast category",queryset=CastCategory.objects.all(),required=True)
    subcast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select sub-caste"}),label="SubCaste",queryset=SubCast.objects.all(),required=False)
    minority=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select minority status"}),label="Minority",choices=MINORITY,initial="NO",required=True)
    pob=forms.CharField(widget=forms.TextInput(attrs={'title': "Student place of Birth",'placeholder': "जन्म ठिकाण "}),label="Place of Birth",max_length=100,min_length=3,required=True)  
    dob=forms.CharField(label="Date of Birth",widget=forms.TextInput(attrs={'title':"Enter student birthdate",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    last_school=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select student last attended school name",'placeholder': "शेवटच्या शिकत असलेलया शाळेचे नाव "}),label="Last attended school",queryset=OtherSch.objects.all(),required=True) 
    last_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Last Class Attended"}),label="Last Class Attended",choices=LAST_ATTENDED_CLASS_FORM1712,required=True) 
    prevlcsrno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous LC Sr No.",'placeholder': " मागील एलसी क्र "}),label="Student Previous LC Sr No",max_length=10,min_length=1,required=True)
    prevprn=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Student Previous Registration Number",'placeholder': " मागील रजिस्ट्रेशन नंबर"}),label="Previous Registration Number",max_length=50,min_length=1,required=True)
    admdate=forms.CharField(label="Admission Date",widget=forms.TextInput(attrs={'title':"Enter Admission Date",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    adm_class=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "In which class you want to get Admission"}),label="Admission Standard",choices=FORM1712,initial="12",required=True) 
    admission_faculty=forms.ChoiceField(widget=forms.Select(attrs={'title': "In which faculty you want to get Admission"}),label="Admission Stream",choices=FACULTY,required=True)
    rollno=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title': "Student Roll Number",'placeholder': "हजेरी क्रमांक "}),label="Roll Number ",max_length=10,min_length=1,required=False)    
    lateadm=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select late admission  "}),label="Late Admission",choices=ADMLATE,initial="NO",required=True)
    admtype=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select admission type "}),label="Admission Type",choices=ADMTYPE,initial="FRESHER",required=True)
    hostel=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select hostel required  "}),label="Hostel required",choices=HOSTEL,initial="NO",required=True)
    #Helth details
    sex=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select gender"}),label="Gender",choices=GENDERS,required=True)
    pwd=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select PWD status"}),label="Person With Disability",choices=PWDS,initial="NO",required=True)
    bgroup=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select blood group"}),label="Blood Group",choices=BG,required=False)     
    #Parents details
    fa_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Father mobile number",'placeholder': "वडिलांचा फोन नंबर","onchange":'isguardian()'}),label="Father Mobile",max_length=10,min_length=10,required=False)
    mo_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Mother mobile number",'placeholder': "आईचा फोन नंबर","onchange":'isguardian()'}),label="Mother Mobile",max_length=10,min_length=10,required=False)
    fa_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter father occupation",'placeholder': "वडिलांचा व्यवसाय","onchange":'isguardian()'}),label="Father Occupation",max_length=15,min_length=3,required=False) 
    mo_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter mother occupation",'placeholder': "आईचा व्यवसाय","onchange":'isguardian()'}),label="Mother Occupation",max_length=15,min_length=3,required=False) 
    fam_income=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter family Annual Income",'placeholder': "कुटुंबाचे वार्षिक उत्पन्न"}),label="Annual Income",max_length=10,min_length=3,required=False)
    bpl=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="BPL",choices=BPLEVEL,initial="NO",required=True) 
    #Guardian
    gis=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Guardian is","onchange":'isguardian()'}),label="Guardian is",choices=GURDIAN,required=True)     
    ganame=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian full name",'placeholder': "विद्यार्थ्याच्या पालकाचे नाव"}),label="Guardian Name",max_length=50,min_length=4,required=False) 
    ga_mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Guardian mobile number",'placeholder': "पालकाचे फोन नंबर"}),label="Guardian Mobile",max_length=10,min_length=10,required=False)
    ga_occu=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian occupation",'placeholder': " पालकाचा व्यवसाय"}),label="Guardian Occupation",max_length=15,min_length=2,required=False) 
    gaddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter Guardian postal address",'placeholder': "पालकाचा पत्ता"}),label="Guardian Address",max_length=100,min_length=4,required=False) 
    ga_relation=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Guardian Relation",'placeholder': "पालकाचे नाते"}),label="Guardian Relation",max_length=15,min_length=2,required=False) 
    #Address
    areaType=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Rural/Urban",choices=AREA,required=True) 
    email=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter your email",'placeholder': "Email"}),label="Email",max_length=50,min_length=4,required=True) 
    caddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter current postal address",'placeholder': "सध्याचा पत्ता","onchange":'address()'}),label="Current Address",max_length=100,min_length=4,required=True) 
    ca_is_pa_addr=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select if Current Address is Permanent Address","onchange":'address()'}),label="Current Address is Permanent Address",choices=IS,required=True)     
    paddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter permanent postal address",'placeholder': "कायमचा पत्ता"}),label="Permanent Address",max_length=100,min_length=4,required=False) 
    #Bank Details
    baccount=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Bank account number",'placeholder': "बँक अकाऊंट नंबर"}),label="Bank Account Number",max_length=15,min_length=1,required=False)
    bankname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Name",'placeholder': "बँकेचे नाव "}),label=" Bank Name",max_length=20,min_length=2,required=False) 
    ifsc=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank IFSC",'placeholder': "IFSC नंबर"}),label=" IFSC Code",max_length=15,min_length=2,required=False) 
    branch=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Branch Name",'placeholder': "ब्रांचचे नाव "}),label="Branch Name",max_length=15,min_length=2,required=False) 
    micr=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank MICR Code",'placeholder': "MICR नंबर"}),label="MICR Code",max_length=15,min_length=2,required=False) 
    #Documents
    marks_img=forms.ImageField(allow_empty_file=True,label="Last year marksheet",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    prv_lc_img=forms.ImageField(allow_empty_file=True,label="Previous School LC",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    addhar_img=forms.ImageField(allow_empty_file=True,label="Aadhar Card",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    cast_img=forms.ImageField(allow_empty_file=True,label="Cast Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    castvald_img=forms.ImageField(allow_empty_file=True,label="Cast-Validity Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    nationality_img=forms.ImageField(allow_empty_file=True,label="Nationality Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    noncrimy_img=forms.ImageField(allow_empty_file=True,label="Non-Creamylayer Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    std_img=forms.ImageField(allow_empty_file=True,label="Student Photo",help_text='accept JPG/PNG file,max size 60 kb',required=False,validators=[file_size_profile_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    birth_img=forms.ImageField(allow_empty_file=True,label="Student Birth Certificate",help_text='accept JPG/PNG file,max size 150 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    note=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Note",'placeholder': "नोट"}),label="Note",max_length=100,min_length=4,required=False) 
    #message=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;'}),label='Message',max_length=200,min_length=4,initial="My Message is:: ",required=False)      
    class Meta:
        model = Form1712Adm
        fields = ('note','prevprn','prevlcsrno','prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','subcast','minority','pob','dob','last_school','admdate','adm_class','admission_faculty','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','email','areaType','caddress','ca_is_pa_addr','paddress','baccount','bankname','ifsc','branch','micr','marks_img','prv_lc_img','addhar_img','cast_img','castvald_img','nationality_img','noncrimy_img','std_img','birth_img','last_class',)







# # School Information Form
# class AdmissionForm(forms.ModelForm):
#     orgName=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Organization Name",'placeholder': 'संस्थेचे पूर्ण नाव'}),label='Organization Name',max_length=100,min_length=5,required=True)
#     schName=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter School Name",'placeholder': 'शाळेचे पूर्ण नाव'}),label='School Name',max_length=100,min_length=5,required=True)
#     areaType=forms.ChoiceField(widget=forms.Select(attrs={'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Rural/Urban",choices=CLASS_SCHOOL,required=True) 
#     address=forms.CharField(widget=forms.Textarea(attrs={'title': "Enter School Address",'cols':20,'rows':1,'style':'height:2.5em;','placeholder': 'शाळेचा पत्ता '}),label='School Address',max_length=200,min_length=4,required=True)      
#     state=forms.ChoiceField(widget=forms.Select(attrs={'title': "Select State",'class':"form-control select2bs4",'style':"width: 100%;"}),label="State",choices=CLASS_SCHOOL,required=True) 
#     district=forms.ChoiceField(widget=forms.Select(attrs={'title': "Select District Name",'class':"form-control select2bs4",'style':"width: 100%;"}),label="District",choices=CLASS_SCHOOL,required=True) 
#     taluka=forms.ChoiceField(widget=forms.Select(attrs={'title': "Select Taluka Name",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Taluka",choices=CLASS_SCHOOL,required=True) 
#     village=forms.ChoiceField(widget=forms.Select(attrs={'title': "Select Village Name",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Village",choices=CLASS_SCHOOL,required=True)       
#     email_sch=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter School email",'placeholder': "शाळेचा ई-मेल"}),label="School Email",max_length=50,min_length=8,required=True) 
#     email_org=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter Organization email",'placeholder': "संस्थेचा ई-मेल"}),label="Organization Email",max_length=50,min_length=8,required=False) 
#     phone1=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Phone/Mobile Number",'placeholder': "फोन किंवा मोबाईल क्रमांक "}),label="Phone/Mobile Number1",max_length=10,min_length=6,required=True)     
#     phone2=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Phone/Mobile Number",'placeholder': "फोन किंवा मोबाईल क्रमांक "}),label="Phone/Mobile Number2",max_length=10,min_length=6,required=False)     
#     fax=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter FAX Number",'placeholder': "फॅक्स क्रमांक"}),label="FAX Number",max_length=10,min_length=4,required=False)     
#     doe=forms.CharField(label="Date of Establishment",widget=forms.TextInput(attrs={'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)       
#     udise=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter U-DISE Number",'placeholder': "U-DISE क्रमांक"}),label="U-DISE Number",max_length=50,min_length=4,required=True)     
#     indxNumber=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Index Number",'placeholder': "इंडेक्स क्रमांक "}),label="Index Number",max_length=50,min_length=4,required=False)     
#     grn=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Government Recognition Number",'placeholder': "शासकीय मान्यता क्रमांक "}),label="Government Recognition Number",max_length=50,min_length=4,required=True)     
#     website=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Website domain Name",'placeholder': "वेबसाइटचे नाव"}),label="Website domain Name",max_length=50,min_length=4,required=True)     
#     class Meta:
#         model = SchInfo
#         fields = ('orgName','schName','areaType','address','state','district','taluka','village','email_sch','email_org','phone1','phone2','fax','doe','udise','indxNumber','grn','website')
