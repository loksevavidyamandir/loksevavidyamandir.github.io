from django.urls import path,include
from schAdmission.admViews.admAddViews import admissionAddViews as admadd
from schAdmission.admViews.admAddViews import admissionRejoinViews as admrejoin
from schAdmission.admViews.admAddViews import primarylcGenerateViews as admprilc
from schAdmission.admViews.admAddViews import secondarylcGenerateViews as admseclc
from schAdmission.admViews.admAddViews import collegelcGenerateViews as admcollc
from schAdmission.admViews.admAddViews import atkt11lcGenerateViews as admatkt11lc
from schAdmission.admViews.admAddViews import form1710lcGenerateViews as admform1710lc
from schAdmission.admViews.admAddViews import form1712lcGenerateViews as admform1712lc
from schAdmission.admViews.admAddViews import primarybonafideViews as pribonafide
from schAdmission.admViews.admAddViews import secondarybonafideViews as secbonafide
from schAdmission.admViews.admAddViews import collegebonafideViews as colbonafide
from schAdmission.admViews.admAddViews import atkt11bonafideViews as atkt11bonafide
from schAdmission.admViews.admAddViews import form17sscbonafideViews as f17sscbonafide
from schAdmission.admViews.admAddViews import form17hscbonafideViews as f17hscbonafide
from schAdmission.admViews.admAddViews import identityCardViews as idviews
from schAdmission.admViews.admListViews import admissionListViews as admlist
from schAdmission.admViews.admEditViews import admissionEditViews as admedit
from schAdmission.admViews.admDelViews import admissionDelViews as admdel
from schAdmission.admViews.admExportViews import admissionExportViews as admexp
from schAdmission.admViews.admImportViews import admissionImportViews as admimp


#from django.conf import settings
#from django.conf.urls.static import static

urlpatterns = [
    # Primary Id Generate
    path('admissionpriidgenerate',idviews.admissionpri_idgenerate,name='admissionpri_idgenerate'),
    path('admissionsecidgenerate',idviews.admissionsec_idgenerate,name='admissionsec_idgenerate'),
    path('admissioncolidgenerate',idviews.admissioncol_idgenerate,name='admissioncol_idgenerate'),
    path('admissionstaffidgenerate',idviews.admissionstaff_idgenerate,name='admissionstaff_idgenerate'),

    # Primary Id ajax
    path('loadpristudentsid',idviews.load_pristudentsid,name='load_pristudentsid'),
    path('loadsecstudentsid',idviews.load_secstudentsid,name='load_secstudentsid'),
    path('loadcolstudentsid',idviews.load_colstudentsid,name='load_colstudentsid'),

    #8th pass Certificate View generate
    path('admissionsec8passcertigen',admseclc.admission_sec8passcertigen,name='admission_sec8passcertigen'),

    #8th pass Certificate ajax
    path('loadsec8passstudents',admseclc.load_sec8passstudents,name='load_sec8passstudents'),

    #8th pass Certificate View
    path('admissionsec8passcertiview/<int:user_id>',admseclc.admission_sec8passcertiview,name='admission_sec8passcertiview'),

    #8th pass Certificate View list
    path('admissionsec8passcertilist',admseclc.admission_sec8passcertilist,name='admission_sec8passcertilist'),

    #8th pass Certificate Delete
    path('admissionsec8passcertidelete/<int:user_id>',admseclc.admission_sec8passcertidelete,name='admission_sec8passcertidelete'),

    #8th pass Certificate Delete
    path('admissionsec8passcertiexport/<str:cy>',admseclc.admission_sec8passcertiexport,name='admission_sec8passcertiexport'),


    #Repeater View
    path('admissioncolrepeaterview/<int:user_id>',admadd.admissioncol_repeaterview,name='admissioncol_repeaterview'),

    # Bonafide Issue
    path('admissionpribonafide',pribonafide.admission_pribonafide,name='admission_pribonafide'),
    path('admissionsecbonafide',secbonafide.admission_secbonafide,name='admission_secbonafide'),
    path('admissioncolbonafide',colbonafide.admission_colbonafide,name='admission_colbonafide'),
    path('admissionatkt11bonafide',atkt11bonafide.admission_atkt11bonafide,name='admission_atkt11bonafide'),
    path('admissionf17sscbonafide',f17sscbonafide.admission_f17sscbonafide,name='admission_f17sscbonafide'),
    path('admissionf17hscbonafide',f17hscbonafide.admission_f17hscbonafide,name='admission_f17hscbonafide'),

    # ajax for Bonafide Issue
    path('loadpristudentsbona',pribonafide.load_pristudentsbona,name='load_pristudentsbona'),
    path('loadsecstudentsbona',secbonafide.load_secstudentsbona,name='load_secstudentsbona'),
    path('loadcolstudentsbona',colbonafide.load_colstudentsbona,name='load_colstudentsbona'),
    path('loadatkt11studentsbona',atkt11bonafide.load_atkt11studentsbona,name='load_atkt11studentsbona'),
    path('loadf17sscstudentsbona',f17sscbonafide.load_f17sscstudentsbona,name='load_f17sscstudentsbona'),
    path('loadf17hscstudentsbona',f17hscbonafide.load_f17hscstudentsbona,name='load_f17hscstudentsbona'),

    # Bonafide List
    path('admissionpribonafidelist',pribonafide.admission_pribonafidelist,name='admission_pribonafidelist'),
    path('admissionsecbonafidelist',secbonafide.admission_secbonafidelist,name='admission_secbonafidelist'),
    path('admissioncolbonafidelist',colbonafide.admission_colbonafidelist,name='admission_colbonafidelist'),
    path('admissionatkt11bonafidelist',atkt11bonafide.admission_atkt11bonafidelist,name='admission_atkt11bonafidelist'),
    path('admissionf17sscbonafidelist',f17sscbonafide.admission_f17sscbonafidelist,name='admission_f17sscbonafidelist'),
    path('admissionf17hscbonafidelist',f17hscbonafide.admission_f17hscbonafidelist,name='admission_f17hscbonafidelist'),

    # Bonafide List
    path('admissionpribonafideview/<int:id>',pribonafide.admission_pribonafideview,name='admission_pribonafideview'),
    path('admissionsecbonafideview/<int:id>',secbonafide.admission_secbonafideview,name='admission_secbonafideview'),
    path('admissioncolbonafideview/<int:id>',colbonafide.admission_colbonafideview,name='admission_colbonafideview'),
    path('admissionatkt11bonafideview/<int:id>',atkt11bonafide.admission_atkt11bonafideview,name='admission_atkt11bonafideview'),
    path('admissionf17sscbonafideview/<int:id>',f17sscbonafide.admission_f17sscbonafideview,name='admission_f17sscbonafideview'),
    path('admissionf17hscbonafideview/<int:id>',f17hscbonafide.admission_f17hscbonafideview,name='admission_f17hscbonafideview'),

    # Bonafide Delete
    path('admissionpribonafidedelete/<int:id>',pribonafide.admission_pribonafidedelete,name='admission_pribonafidedelete'),
    path('admissionsecbonafidedelete/<int:id>',secbonafide.admission_secbonafidedelete,name='admission_secbonafidedelete'),
    path('admissioncolbonafidedelete/<int:id>',colbonafide.admission_colbonafidedelete,name='admission_colbonafidedelete'),
    path('admissionatkt11bonafidedelete/<int:id>',atkt11bonafide.admission_atkt11bonafidedelete,name='admission_atkt11bonafidedelete'),
    path('admissionf17sscbonafidedelete/<int:id>',f17sscbonafide.admission_f17sscbonafidedelete,name='admission_f17sscbonafidedelete'),
    path('admissionf17hscbonafidedelete/<int:id>',f17hscbonafide.admission_f17hscbonafidedelete,name='admission_f17hscbonafidedelete'),


    # for division assign 
    path('admissionpridivassign',admadd.admission_pridivassign,name='admission_pridivassign'),
    path('admissionsecdivassign',admadd.admission_secdivassign,name='admission_secdivassign'),
    path('admissioncoldivassign',admadd.admission_coldivassign,name='admission_coldivassign'),

    # ajax urls for division
    path('loadpristudents',admadd.load_pristudents,name='load_pristudents'),
    path('loadsecstudents',admadd.load_secstudents,name='load_secstudents'),
    path('loadcolstudents',admadd.load_colstudents,name='load_colstudents'),

    # for Rollno assign 
    path('admissionprirollno',admadd.admissionpri_rollno,name='admissionpri_rollno'),
    path('admissionsecrollno',admadd.admissionsec_rollno,name='admissionsec_rollno'),
    path('admissioncolrollno',admadd.admissioncol_rollno,name='admissioncol_rollno'),
    # ajax urls for Rollno
    path('loadpristudentsrollno',admadd.load_pristudentsrollno,name='load_pristudentsrollno'),
    path('loadsecstudentsrollno',admadd.load_secstudentsrollno,name='load_secstudentsrollno'),
    path('loadcolstudentsrollno',admadd.load_colstudentsrollno,name='load_colstudentsrollno'),

    # for standard promote
    path('admissionpristdpromote',admadd.admission_pristdpromote,name='admission_pristdpromote'),
    path('admissionsecstdpromote',admadd.admission_secstdpromote,name='admission_secstdpromote'),
    path('admissioncolstdpromote',admadd.admission_colstdpromote,name='admission_colstdpromote'),

    # ajax urls for Promote
    path('loadpristudentspro',admadd.load_pristudents_pro,name='load_pristudents_pro'),
    path('loadsecstudentspro',admadd.load_secstudents_pro,name='load_secstudents_pro'),
    path('loadcolstudentspro',admadd.load_colstudents_pro,name='load_colstudents_pro'),

    # for standard demote
    path('admissionpristddemote',admadd.admission_pristddemote,name='admission_pristddemote'),
    path('admissionsecstddemote',admadd.admission_secstddemote,name='admission_secstddemote'),
    path('admissioncolstddemote',admadd.admission_colstddemote,name='admission_colstddemote'),

    # ajax urls for Demote
    path('loadpristudentsde',admadd.load_pristudents_de,name='load_pristudents_de'),
    path('loadsecstudentsde',admadd.load_secstudents_de,name='load_secstudents_de'),
    path('loadcolstudentsde',admadd.load_colstudents_de,name='load_colstudents_de'),

    # for primary student terminate
    path('admissionpriterminate',admadd.admission_priterminate,name='admission_priterminate'),
    path('admissionsecterminate',admadd.admission_secterminate,name='admission_secterminate'),
    path('admissioncolterminate',admadd.admission_colterminate,name='admission_colterminate'),

    # for primary student terminate
    path('loadpriterminate',admadd.load_priterminate,name='load_priterminate'),
    path('loadsecterminate',admadd.load_secterminate,name='load_secterminate'),
    path('loadcolterminate',admadd.load_colterminate,name='load_colterminate'),

    # Student Terminate Decision list Views
    path('academicpriterminatedeclist',admlist.academic_priterminatedeclist,name='academic_priterminatedeclist'),
    path('academicsecterminatedeclist',admlist.academic_secterminatedeclist,name='academic_secterminatedeclist'),
    path('academiccolterminatedeclist',admlist.academic_colterminatedeclist,name='academic_colterminatedeclist'),

    # Student Terminate Approval view
    path('academicpriterminateapproval/<int:user_id>',admedit.academic_priterminateapproval,name='academic_priterminateapproval'),
    path('academicsecterminateapproval/<int:user_id>',admedit.academic_secterminateapproval,name='academic_secterminateapproval'),
    path('academiccolterminateapproval/<int:user_id>',admedit.academic_colterminateapproval,name='academic_colterminateapproval'),

    # Student Terminate list Views
    path('academicpriterminatelist',admlist.academic_priterminatelist,name='academic_priterminatelist'),
    path('academicsecterminatelist',admlist.academic_secterminatelist,name='academic_secterminatelist'),
    path('academiccolterminatelist',admlist.academic_colterminatelist,name='academic_colterminatelist'),

    # Academics list Views
    path('academicpriAcademiclist',admlist.academic_priAcademiclist,name='academic_priAcademiclist'),
    path('academicsecAcademiclist',admlist.academic_secAcademiclist,name='academic_secAcademiclist'),
    path('academiccolAcademiclist',admlist.academic_colAcademiclist,name='academic_colAcademiclist'),

    # Academics Export View
    path('primary_academic_export/<str:cy>',admexp.acad_export_prim_xls,name='acad_export_prim_xls'),
    path('secondary_academic_export/<str:cy>',admexp.acad_export_sec_xls,name='acad_export_sec_xls'),
    path('college_academic_export/<str:cy>',admexp.acad_export_col_xls,name='acad_export_col_xls'),

    # Rejoin Views
    path('admissionrejoin',admrejoin.admission_rejoin,name='admission_rejoin'),

    # LC Generate Views
    path('admissionprilcgenerate',admprilc.admission_prilcgenerate,name='admission_prilcgenerate'),
    path('admissionseclcgenerate',admseclc.admission_seclcgenerate,name='admission_seclcgenerate'),
    path('admissioncollcgenerate',admcollc.admission_collcgenerate,name='admission_collcgenerate'),
    path('admissionatkt11lcgenerate',admatkt11lc.admission_atkt11lcgenerate,name='admission_atkt11lcgenerate'),
    path('admissionform1710lcgenerate',admform1710lc.admission_form1710lcgenerate,name='admission_form1710lcgenerate'),
    path('admissionform1712lcgenerate',admform1712lc.admission_form1712lcgenerate,name='admission_form1712lcgenerate'),

    # Terminate LC Generate Views
    path('admissionpriterlcgenerate/<int:user_id>',admprilc.admission_priterlcgenerate,name='admission_priterlcgenerate'),
    path('admissionsecterlcgenerate/<int:user_id>',admseclc.admission_secterlcgenerate,name='admission_secterlcgenerate'),
    path('admissioncolterlcgenerate/<int:user_id>',admcollc.admission_colterlcgenerate,name='admission_colterlcgenerate'),

    # ajax urls for LC Generate
    path('loadpristudentslc',admprilc.load_pristudentslc,name='load_pristudentslc'),
    path('loadsecstudentslc',admseclc.load_secstudentslc,name='load_secstudentslc'),
    path('loadcolstudentslc',admcollc.load_colstudentslc,name='load_colstudentslc'),
    path('loadatkt11studentslc',admatkt11lc.load_atkt11studentslc,name='load_atkt11studentslc'),
    path('loadform1710studentslc',admform1710lc.load_form1710studentslc,name='load_form1710studentslc'),
    path('loadform1712studentslc',admform1712lc.load_form1712studentslc,name='load_form1712studentslc'),

    # LC List
    path('admissionprilclist',admprilc.admission_prilclist,name='admission_prilclist'),
    path('admissionseclclist',admseclc.admission_seclclist,name='admission_seclclist'),
    path('admissioncollclist',admcollc.admission_collclist,name='admission_collclist'),
    path('admissionatkt11lclist',admatkt11lc.admission_atkt11lclist,name='admission_atkt11lclist'),
    path('admissionform1710lclist',admform1710lc.admission_form1710lclist,name='admission_form1710lclist'),
    path('admissionform1712lclist',admform1712lc.admission_form1712lclist,name='admission_form1712lclist'),

    #LC View
    path('admissionprilcview/<int:user_id>',admprilc.admission_prilcview,name='admission_prilcview'),
    path('admissionseclcview/<int:user_id>',admseclc.admission_seclcview,name='admission_seclcview'),
    path('admissioncollcview/<int:user_id>',admcollc.admission_collcview,name='admission_collcview'),
    path('admissionatkt11lcview/<int:user_id>',admatkt11lc.admission_atkt11lcview,name='admission_atkt11lcview'),
    path('admissionform1710lcview/<int:user_id>',admform1710lc.admission_form1710lcview,name='admission_form1710lcview'),
    path('admissionform1712lcview/<int:user_id>',admform1712lc.admission_form1712lcview,name='admission_form1712lcview'),

    #LC Delete
    path('admissionprilcdelete/<int:user_id>',admprilc.admission_prilcdelete,name='admission_prilcdelete'),
    path('admissionseclcdelete/<int:user_id>',admseclc.admission_seclcdelete,name='admission_seclcdelete'),
    path('admissioncollcdelete/<int:user_id>',admcollc.admission_collcdelete,name='admission_collcdelete'),
    path('admissionatkt11lcdelete/<int:user_id>',admatkt11lc.admission_atkt11lcdelete,name='admission_atkt11lcdelete'),
    path('admissionform1710lcdelete/<int:user_id>',admform1710lc.admission_form1710lcdelete,name='admission_form1710lcdelete'),
    path('admissionform1712lcdelete/<int:user_id>',admform1712lc.admission_form1712lcdelete,name='admission_form1712lcdelete'),

    #LC Original Print
    path('admissionprilcorigprint/<int:user_id>',admprilc.admission_prilcorigprint,name='admission_prilcorigprint'),
    path('admissionseclcorigprint/<int:user_id>',admseclc.admission_seclcorigprint,name='admission_seclcorigprint'),
    path('admissioncollcorigprint/<int:user_id>',admcollc.admission_collcorigprint,name='admission_collcorigprint'),
    path('admissionatkt11lcorigprint/<int:user_id>',admatkt11lc.admission_atkt11lcorigprint,name='admission_atkt11lcorigprint'),

    #LC Export
    path('admissionprilcexport/<str:cy>',admprilc.admission_prilcexport,name='admission_prilcexport'),
    path('admissionseclcexport/<str:cy>',admseclc.admission_seclcexport,name='admission_seclcexport'),
    path('admissioncollcexport/<str:cy>',admcollc.admission_collcexport,name='admission_collcexport'),
    path('admissionatkt11lcexport/<str:cy>',admatkt11lc.admission_atkt11lcexport,name='admission_atkt11lcexport'),
    path('admissionform1710lcexport/<str:cy>',admform1710lc.admission_form1710lcexport,name='admission_form1710lcexport'),
    path('admissionform1712lcexport/<str:cy>',admform1712lc.admission_form1712lcexport,name='admission_form1712lcexport'),

    # ajax for caste Category
    path('loadcastCat',admadd.load_castCat,name='load_castCat'),

    # Add Views
    path('primary_admission',admadd.admission_addPrim,name='admission_primadd'),
    path('secondary_admission',admadd.admission_addSec,name='admission_secadd'),
    path('college_admission',admadd.admission_addCol,name='admission_coladd'),
    path('atkt11_admission',admadd.admission_addATKT11,name='admission_addATKT11'),
    path('form1710_admission',admadd.admission_addForm1710,name='admission_form1710add'),
    path('form1712_admission',admadd.admission_addForm1712,name='admission_form1712add'),

    # List Views
    path('primary_admission_list',admlist.admission_listPrim,name='admission_primlist'),
    path('secondary_admission_list',admlist.admission_listSec,name='admission_seclist'),
    path('college_admission_list',admlist.admission_listCol,name='admission_collist'),
    path('atkt11_admission_list',admlist.admission_atkt11list,name='admission_atkt11list'),
    path('form1710_admission_list',admlist.admission_listForm1710,name='admission_form1710list'),
    path('form1712_admission_list',admlist.admission_listForm1712,name='admission_form1712list'),

    # Edit Views
    path('primary_admission_edit/<int:user_id>',admedit.admission_editPrim,name='admission_primedit'),
    path('secondary_admission_edit/<int:user_id>',admedit.admission_editSec,name='admission_secedit'),
    path('college_admission_edit/<int:user_id>',admedit.admission_editCol,name='admission_coledit'),
    path('atkt11_admission_edit/<int:user_id>',admedit.admission_edit11ATKT,name='admission_edit11ATKT'),
    path('form1710_admission_edit/<int:user_id>',admedit.admission_editForm1710,name='admission_form1710edit'),
    path('form1712_admission_edit/<int:user_id>',admedit.admission_editForm1712,name='admission_form1712edit'),

     # Delete Views
    path('primary_admission_delete/<int:user_id>',admdel.admission_delPrimStd,name='admission_primdel'),
    path('secondary_admission_delete/<int:user_id>',admdel.admission_delSecStd,name='admission_secdel'),
    path('college_admission_delete/<int:user_id>',admdel.admission_delColStd,name='admission_coldel'),
    path('atkt11_admission_delete/<int:user_id>',admdel.admission_del11AtktStd,name='admission_del11AtktStd'),
    path('form1710_admission_delete/<int:user_id>',admdel.admission_delform1710Std,name='admission_form1710del'),
    path('form1712_admission_delete/<int:user_id>',admdel.admission_delform1712Std,name='admission_form1712del'),
    
    # Export Views
    path('primary_admission_export/<str:cy>',admexp.adm_export_prim_xls,name='admission_primexp'),
    path('secondary_admission_export/<str:cy>',admexp.adm_export_sec_xls,name='admission_secexp'),
    path('college_admission_export/<str:cy>',admexp.adm_export_col_xls,name='admission_colexp'),
    path('atkt11_admission_export/<str:cy>',admexp.adm_export_atkt11_xls,name='admission_atkt11exp'),
    path('form1710_admission_export/<str:cy>',admexp.adm_export_form1710_xls,name='admission_form1710exp'),
    path('form1712_admission_export/<str:cy>',admexp.adm_export_form1712_xls,name='admission_form1712exp'),

    #Import Views
    path('primary_admission_import',admimp.admission_prim_import,name='admission_primimport'),
    path('secondary_admission_import',admimp.admission_sec_import,name='admission_secimport'),
    path('college_admission_import',admimp.admission_clg_import,name='admission_clgimport'),
    path('atkt11_admission_import',admimp.admission_atkt11_import,name='admission_atkt11import'),
    path('form17ssc_admission_import',admimp.admission_f1710_import,name='admission_f1710import'),
    path('form17hsc_admission_import',admimp.admission_f1712_import,name='admission_f1712import'),

]
