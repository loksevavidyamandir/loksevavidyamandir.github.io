from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User,auth
from django.conf import settings as conf_set
from django.contrib import messages
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm,ATKT11AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
# This Edit Views Included ::-->  
# Primary,Secondary,College,Form1710,Form1712

#Terminate Approval Views Included ::-->  
# Primary,Secondary,College


sname=conf_set.SCHOOL_NAME



# Primary Admission Edit View
def admission_editPrim(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        #priAdmData=PrimAdm.objects.all()
        if request.method == 'POST':
            pi=PrimAdm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            adm_class=pi.adm_class
            year=pi.admdate
            # print("user ID",ui.id)
            # print("student ID",pi.user_id)
            priAdmForm = PriAdmForm(request.POST,request.FILES,instance=pi)
            if priAdmForm.is_valid():
                try:
                    ui.username=priAdmForm.cleaned_data['aadhar']
                    ui.email=priAdmForm.cleaned_data['email']
                    #password="Admin@123"
                    ui.first_name=priAdmForm.cleaned_data['fname']
                    ui.last_name=priAdmForm.cleaned_data['lname']
                    ui.save()
                    y=priAdmForm.cleaned_data['admdate']                   
                    pi.admyear=y[0:4]
                    print(adm_class,priAdmForm.cleaned_data['adm_class'])
                    #for Academics
                    if priAdmForm.cleaned_data['adm_class'] == adm_class:
                        pass
                        print(priAdmForm.cleaned_data['adm_class']+"a")
                    else:
                        no=int(priAdmForm.cleaned_data['adm_class'])
                        print(no,"b")
                        if no==1:
                            pi.updateclass1 = priAdmForm.cleaned_data['adm_class']
                            pi.updateyear1 = y[0:4]
                            pi.updatedivision1 = str(priAdmForm.cleaned_data['division'])
                            pi.updaterollno1 = priAdmForm.cleaned_data['rollno']

                            pi.updateclass2 = pi.updateyear2 = pi.updatedivision2 = pi.updaterollno2 = None
                            pi.updateclass3 = pi.updateyear3 = pi.updatedivision3 = pi.updaterollno3 = None
                            pi.updateclass4 = pi.updateyear4 = pi.updatedivision4 = pi.updaterollno4 = None
                        elif no==2:
                            pi.updateclass2 = priAdmForm.cleaned_data['adm_class']
                            pi.updateyear2 = y[0:4]
                            pi.updatedivision2 = str(priAdmForm.cleaned_data['division'])
                            pi.updaterollno2 = priAdmForm.cleaned_data['rollno']

                            pi.updateclass1 = pi.updateyear1 = pi.updatedivision1 = pi.updaterollno1 = None
                            pi.updateclass3 = pi.updateyear3 = pi.updatedivision3 = pi.updaterollno3 = None
                            pi.updateclass4 = pi.updateyear4 = pi.updatedivision4 = pi.updaterollno4 = None
                        elif no==3:
                            pi.updateclass3 = priAdmForm.cleaned_data['adm_class']
                            pi.updateyear3 = y[0:4]
                            pi.updatedivision3 = str(priAdmForm.cleaned_data['division'])
                            pi.updaterollno3 = priAdmForm.cleaned_data['rollno']

                            pi.updateclass1 = pi.updateyear1 = pi.updatedivision1 = pi.updaterollno1 = None
                            pi.updateclass2 = pi.updateyear2 = pi.updatedivision2 = pi.updaterollno2 = None
                            pi.updateclass4 = pi.updateyear4 = pi.updatedivision4 = pi.updaterollno4 = None
                        elif no==4:
                            pi.updateclass4 = priAdmForm.cleaned_data['adm_class']
                            pi.updateyear4 = y[0:4]
                            pi.updatedivision4 = str(priAdmForm.cleaned_data['division'])
                            pi.updaterollno4 = priAdmForm.cleaned_data['rollno']

                            pi.updateclass1 = pi.updateyear1 = pi.updatedivision1 = pi.updaterollno1 = None
                            pi.updateclass2 = pi.updateyear2 = pi.updatedivision2 = pi.updaterollno2 = None
                            pi.updateclass3 = pi.updateyear3 = pi.updatedivision3 = pi.updaterollno3 = None
                    
                    if  y[0:4] == year[0:4]:
                        pass
                        print(y[0:4],"a")
                    else:
                        no=int(priAdmForm.cleaned_data['adm_class'])
                        print(y[0:4],"b")
                        if no==1:
                            pi.updateclass1 = priAdmForm.cleaned_data['adm_class']
                            pi.updateyear1 = y[0:4]
                            pi.updatedivision1 = str(priAdmForm.cleaned_data['division'])
                            pi.updaterollno1 = priAdmForm.cleaned_data['rollno']

                            pi.updateclass2 = pi.updateyear2 = pi.updatedivision2 = pi.updaterollno2 = None
                            pi.updateclass3 = pi.updateyear3 = pi.updatedivision3 = pi.updaterollno3 = None
                            pi.updateclass4 = pi.updateyear4 = pi.updatedivision4 = pi.updaterollno4 = None

                        elif no==2:
                            pi.updateclass2 = priAdmForm.cleaned_data['adm_class']
                            pi.updateyear2 = y[0:4]
                            pi.updatedivision2 = str(priAdmForm.cleaned_data['division'])
                            pi.updaterollno2 = priAdmForm.cleaned_data['rollno']

                            pi.updateclass1 = pi.updateyear1 = pi.updatedivision1 = pi.updaterollno1 = None
                            pi.updateclass3 = pi.updateyear3 = pi.updatedivision3 = pi.updaterollno3 = None
                            pi.updateclass4 = pi.updateyear4 = pi.updatedivision4 = pi.updaterollno4 = None
                            
                        elif no==3:
                            pi.updateclass3 = priAdmForm.cleaned_data['adm_class']
                            pi.updateyear3 = y[0:4]
                            pi.updatedivision3 = str(priAdmForm.cleaned_data['division'])
                            pi.updaterollno3 = priAdmForm.cleaned_data['rollno']

                            pi.updateclass1 = pi.updateyear1 = pi.updatedivision1 = pi.updaterollno1 = None
                            pi.updateclass2 = pi.updateyear2 = pi.updatedivision2 = pi.updaterollno2 = None
                            pi.updateclass4 = pi.updateyear4 = pi.updatedivision4 = pi.updaterollno4 = None
                            
                        elif no==4:
                            pi.updateclass4 = priAdmForm.cleaned_data['adm_class']
                            pi.updateyear4 = y[0:4]
                            pi.updatedivision4 = str(priAdmForm.cleaned_data['division'])
                            pi.updaterollno4 = priAdmForm.cleaned_data['rollno']

                            pi.updateclass1 = pi.updateyear1 = pi.updatedivision1 = pi.updaterollno1 = None
                            pi.updateclass2 = pi.updateyear2 = pi.updatedivision2 = pi.updaterollno2 = None
                            pi.updateclass3 = pi.updateyear3 = pi.updatedivision3 = pi.updaterollno3 = None

                    pi.save()
                    priAdmForm.save()
                    messages.success(request,priAdmForm.cleaned_data['fname']+" "+priAdmForm.cleaned_data['faname']+" "+priAdmForm.cleaned_data['lname']+' Student Admission Fileds Edited Successfully!')
                    return redirect('admission_primlist')
                except:
                    messages.error(request,"Invalid header found in Edit Student Admission form... Try again")
                    return redirect('admission_primlist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=PrimAdm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            priAdmForm= PriAdmForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" Primary Admission / Edit-Student",
            "menu_icon":"nav-icon fas fa-address-card",
            "priAdmForm":priAdmForm,
            "update":True,
            # "priAdmData":priAdmData,
            }     
        return render(request, 'schoolviews/admission/prim_adm.html',context) 
    else:
        return redirect('login')




# Secondary Admission Edit View
def admission_editSec(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        #priAdmData=PrimAdm.objects.all()
        if request.method == 'POST':
            pi=SecondAdm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            adm_class=pi.adm_class
            year=pi.admdate
            # print("user ID",ui.id)
            # print("student ID",pi.user_id)
            secAdmForm= SecondAdmForm(request.POST,request.FILES,instance=pi)
            if secAdmForm.is_valid():
                try:
                    ui.username=secAdmForm.cleaned_data['aadhar']
                    ui.email=secAdmForm.cleaned_data['email']
                    #password="Admin@123"
                    ui.first_name=secAdmForm.cleaned_data['fname']
                    ui.last_name=secAdmForm.cleaned_data['lname']
                    ui.save()
                    y=secAdmForm.cleaned_data['admdate']                   
                    pi.admyear=y[0:4]
                    #for Academics
                    print(1)
                    if secAdmForm.cleaned_data['adm_class'] == adm_class:
                        pass
                        print(secAdmForm.cleaned_data['adm_class']+"a")
                    else:
                        print(1)
                        no=int(secAdmForm.cleaned_data['adm_class'])
                        print(1)
                        print(no)
                        if no==5:
                            pi.updateclass5 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear5 = y[0:4]
                            pi.updatedivision5 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno5 = secAdmForm.cleaned_data['rollno']

                            pi.updateclass6 = pi.updateyear6 = pi.updatedivision6 = pi.updaterollno6 = None
                            pi.updateclass7 = pi.updateyear7 = pi.updatedivision7 = pi.updaterollno7 = None
                            pi.updateclass8 = pi.updateyear8 = pi.updatedivision8 = pi.updaterollno8 = None
                            pi.updateclass9 = pi.updateyear9 = pi.updatedivision9 = pi.updaterollno9 = None
                            pi.updateclass10 = pi.updateyear10 = pi.updatedivision10 = pi.updaterollno10 = None
                        elif no==6:
                            pi.updateclass6 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear6 = y[0:4]
                            pi.updatedivision6 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno6 = secAdmForm.cleaned_data['rollno']

                            pi.updateclass5 = pi.updateyear5 = pi.updatedivision5 = pi.updaterollno5 = None
                            pi.updateclass7 = pi.updateyear7 = pi.updatedivision7 = pi.updaterollno7 = None
                            pi.updateclass8 = pi.updateyear8 = pi.updatedivision8 = pi.updaterollno8 = None
                            pi.updateclass9 = pi.updateyear9 = pi.updatedivision9 = pi.updaterollno9 = None
                            pi.updateclass10 = pi.updateyear10 = pi.updatedivision10 = pi.updaterollno10 = None
                        elif no==7:
                            pi.updateclass7 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear7 = y[0:4]
                            pi.updatedivision7 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno7 = secAdmForm.cleaned_data['rollno']

                            pi.updateclass5 = pi.updateyear5 = pi.updatedivision5 = pi.updaterollno5 = None
                            pi.updateclass6 = pi.updateyear6 = pi.updatedivision6 = pi.updaterollno6 = None
                            pi.updateclass8 = pi.updateyear8 = pi.updatedivision8 = pi.updaterollno8 = None
                            pi.updateclass9 = pi.updateyear9 = pi.updatedivision9 = pi.updaterollno9 = None
                            pi.updateclass10 = pi.updateyear10 = pi.updatedivision10 = pi.updaterollno10 = None
                        elif no==8:
                            pi.updateclass8 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear8 = y[0:4]
                            pi.updatedivision8 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno8 = secAdmForm.cleaned_data['rollno']

                            pi.updateclass5 = pi.updateyear5 = pi.updatedivision5 = pi.updaterollno5 = None
                            pi.updateclass6 = pi.updateyear6 = pi.updatedivision6 = pi.updaterollno6 = None
                            pi.updateclass7 = pi.updateyear7 = pi.updatedivision7 = pi.updaterollno7 = None
                            pi.updateclass9 = pi.updateyear9 = pi.updatedivision9 = pi.updaterollno9 = None
                            pi.updateclass10 = pi.updateyear10 = pi.updatedivision10 = pi.updaterollno10 = None
                        elif no==9:
                            pi.updateclass9 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear9 = y[0:4]
                            pi.updatedivision9 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno9 = secAdmForm.cleaned_data['rollno']
                            
                            pi.updateclass5 = pi.updateyear5 = pi.updatedivision5 = pi.updaterollno5 = None
                            pi.updateclass6 = pi.updateyear6 = pi.updatedivision6 = pi.updaterollno6 = None
                            pi.updateclass7 = pi.updateyear7 = pi.updatedivision7 = pi.updaterollno7 = None
                            pi.updateclass8 = pi.updateyear8 = pi.updatedivision8 = pi.updaterollno8 = None
                            pi.updateclass10 = pi.updateyear10 = pi.updatedivision10 = pi.updaterollno10 = None
                        elif no==10:
                            pi.updateclass10 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear10 = y[0:4]
                            pi.updatedivision10 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno10 = secAdmForm.cleaned_data['rollno']

                            pi.updateclass5 = pi.updateyear5 = pi.updatedivision5 = pi.updaterollno5 = None
                            pi.updateclass6 = pi.updateyear6 = pi.updatedivision6 = pi.updaterollno6 = None
                            pi.updateclass7 = pi.updateyear7 = pi.updatedivision7 = pi.updaterollno7 = None
                            pi.updateclass8 = pi.updateyear8 = pi.updatedivision8 = pi.updaterollno8 = None
                            pi.updateclass9 = pi.updateyear9 = pi.updatedivision9 = pi.updaterollno9 = None
                    print(2)
                    if y[0:4] == year[0:4]:
                        pass
                        print(y[0:4],"a")
                    else:
                        no=int(secAdmForm.cleaned_data['adm_class'])
                        print(y[0:4],"b")
                        if no==5:
                            pi.updateclass5 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear5 = y[0:4]
                            pi.updatedivision5 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno5 = secAdmForm.cleaned_data['rollno']

                            pi.updateclass6 = pi.updateyear6 = pi.updatedivision6 = pi.updaterollno6 = None
                            pi.updateclass7 = pi.updateyear7 = pi.updatedivision7 = pi.updaterollno7 = None
                            pi.updateclass8 = pi.updateyear8 = pi.updatedivision8 = pi.updaterollno8 = None
                            pi.updateclass9 = pi.updateyear9 = pi.updatedivision9 = pi.updaterollno9 = None
                            pi.updateclass10 = pi.updateyear10 = pi.updatedivision10 = pi.updaterollno10 = None

                        elif no==6:
                            pi.updateclass6 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear6 = y[0:4]
                            pi.updatedivision6 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno6 = secAdmForm.cleaned_data['rollno']

                            pi.updateclass5 = pi.updateyear5 = pi.updatedivision5 = pi.updaterollno5 = None
                            pi.updateclass7 = pi.updateyear7 = pi.updatedivision7 = pi.updaterollno7 = None
                            pi.updateclass8 = pi.updateyear8 = pi.updatedivision8 = pi.updaterollno8 = None
                            pi.updateclass9 = pi.updateyear9 = pi.updatedivision9 = pi.updaterollno9 = None
                            pi.updateclass10 = pi.updateyear10 = pi.updatedivision10 = pi.updaterollno10 = None

                        elif no==7:
                            pi.updateclass7 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear7 = y[0:4]
                            pi.updatedivision7 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno7 = secAdmForm.cleaned_data['rollno']

                            pi.updateclass5 = pi.updateyear5 = pi.updatedivision5 = pi.updaterollno5 = None
                            pi.updateclass6 = pi.updateyear6 = pi.updatedivision6 = pi.updaterollno6 = None
                            pi.updateclass8 = pi.updateyear8 = pi.updatedivision8 = pi.updaterollno8 = None
                            pi.updateclass9 = pi.updateyear9 = pi.updatedivision9 = pi.updaterollno9 = None
                            pi.updateclass10 = pi.updateyear10 = pi.updatedivision10 = pi.updaterollno10 = None

                        elif no==8:
                            pi.updateclass8 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear8 = y[0:4]
                            pi.updatedivision8 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno8 = secAdmForm.cleaned_data['rollno']

                            pi.updateclass5 = pi.updateyear5 = pi.updatedivision5 = pi.updaterollno5 = None
                            pi.updateclass6 = pi.updateyear6 = pi.updatedivision6 = pi.updaterollno6 = None
                            pi.updateclass7 = pi.updateyear7 = pi.updatedivision7 = pi.updaterollno7 = None
                            pi.updateclass9 = pi.updateyear9 = pi.updatedivision9 = pi.updaterollno9 = None
                            pi.updateclass10 = pi.updateyear10 = pi.updatedivision10 = pi.updaterollno10 = None

                        elif no==9:
                            pi.updateclass9 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear9 = y[0:4]
                            pi.updatedivision9 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno9 = secAdmForm.cleaned_data['rollno']
                            
                            pi.updateclass5 = pi.updateyear5 = pi.updatedivision5 = pi.updaterollno5 = None
                            pi.updateclass6 = pi.updateyear6 = pi.updatedivision6 = pi.updaterollno6 = None
                            pi.updateclass7 = pi.updateyear7 = pi.updatedivision7 = pi.updaterollno7 = None
                            pi.updateclass8 = pi.updateyear8 = pi.updatedivision8 = pi.updaterollno8 = None
                            pi.updateclass10 = pi.updateyear10 = pi.updatedivision10 = pi.updaterollno10 = None

                        elif no==10:
                            pi.updateclass10 = secAdmForm.cleaned_data['adm_class']
                            pi.updateyear10 = y[0:4]
                            pi.updatedivision10 = str(secAdmForm.cleaned_data['division'])
                            pi.updaterollno10 = secAdmForm.cleaned_data['rollno']

                            pi.updateclass5 = pi.updateyear5 = pi.updatedivision5 = pi.updaterollno5 = None
                            pi.updateclass6 = pi.updateyear6 = pi.updatedivision6 = pi.updaterollno6 = None
                            pi.updateclass7 = pi.updateyear7 = pi.updatedivision7 = pi.updaterollno7 = None
                            pi.updateclass8 = pi.updateyear8 = pi.updatedivision8 = pi.updaterollno8 = None
                            pi.updateclass9 = pi.updateyear9 = pi.updatedivision9 = pi.updaterollno9 = None

                    pi.save()
                    secAdmForm.save()
                    messages.success(request,secAdmForm.cleaned_data['fname']+" "+secAdmForm.cleaned_data['faname']+" "+secAdmForm.cleaned_data['lname']+' Student Admission Fileds Edited Successfully!')
                    return redirect('admission_seclist')
                except:
                    messages.error(request,"Invalid header found in Edit Student Admission form... Try again")
                    return redirect('admission_seclist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=SecondAdm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            secAdmForm= SecondAdmForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" Secondary Admission / Edit-Student",
            "menu_icon":"nav-icon fas fa-address-card",
            "secAdmForm":secAdmForm,
            "update":True,
            # "priAdmData":priAdmData,
            }     
        return render(request, 'schoolviews/admission/secondary_adm.html',context) 
    else:
        return redirect('login')




# College Admission Edit View
def admission_editCol(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        #priAdmData=PrimAdm.objects.all()
        if request.method == 'POST':
            pi=CollegeAdm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            adm_class=pi.adm_class
            year=pi.admdate
            adm_faculty=pi.admission_faculty
            # print("user ID",ui.id)
            # print("student ID",pi.user_id)
            colAdmForm= CollegeAdmForm(request.POST,request.FILES,instance=pi)
            if colAdmForm.is_valid():
                try:
                    ui.username=colAdmForm.cleaned_data['aadhar']
                    ui.email=colAdmForm.cleaned_data['email']
                    #password="Admin@123"
                    ui.first_name=colAdmForm.cleaned_data['fname']
                    ui.last_name=colAdmForm.cleaned_data['lname']
                    ui.save()
                    y=colAdmForm.cleaned_data['admdate']                   
                    pi.admyear=y[0:4]
                    #for Academics
                    if colAdmForm.cleaned_data['adm_class'] == adm_class:
                        pass
                        print(colAdmForm.cleaned_data['adm_class']+"a")
                    else:
                        no=int(colAdmForm.cleaned_data['adm_class'])
                        print(no)
                        if no==11:
                            pi.updateclass11 = colAdmForm.cleaned_data['adm_class']
                            pi.updateyear11 = y[0:4]
                            pi.updatedivision11 = str(colAdmForm.cleaned_data['division'])
                            pi.updaterollno11 = colAdmForm.cleaned_data['rollno']
                            pi.updatestream11 = colAdmForm.cleaned_data['admission_faculty']

                            pi.updateclass12 = pi.updateyear12 = pi.updatedivision12 = pi.updaterollno12 = pi.updatestream12 =None
                        elif no==12:
                            pi.updateclass12 = colAdmForm.cleaned_data['adm_class']
                            pi.updateyear12 = y[0:4]
                            pi.updatedivision12 = str(colAdmForm.cleaned_data['division'])
                            pi.updaterollno12 = colAdmForm.cleaned_data['rollno']
                            pi.updatestream12 = colAdmForm.cleaned_data['admission_faculty']

                            pi.updateclass11 = pi.updateyear11 = pi.updatedivision11 = pi.updaterollno11 = pi.updatestream11 = None
                    
                    if y[0:4] == year[0:4]:
                        pass
                        print(y[0:4],"a")
                    else:
                        no=int(colAdmForm.cleaned_data['adm_class'])
                        print(y[0:4],"b")
                        if no==11:
                            pi.updateclass11 = colAdmForm.cleaned_data['adm_class']
                            pi.updateyear11 = y[0:4]
                            pi.updatedivision11 = str(colAdmForm.cleaned_data['division'])
                            pi.updaterollno11 = colAdmForm.cleaned_data['rollno']
                            pi.updatestream11 = colAdmForm.cleaned_data['admission_faculty']

                            pi.updateclass12 = pi.updateyear12 = pi.updatedivision12 = pi.updaterollno12 = pi.updatestream12 =None
                        elif no==12:
                            pi.updateclass12 = colAdmForm.cleaned_data['adm_class']
                            pi.updateyear12 = y[0:4]
                            pi.updatedivision12 = str(colAdmForm.cleaned_data['division'])
                            pi.updaterollno12 = colAdmForm.cleaned_data['rollno']
                            pi.updatestream12 = colAdmForm.cleaned_data['admission_faculty']

                            pi.updateclass11 = pi.updateyear11 = pi.updatedivision11 = pi.updaterollno11 = pi.updatestream11 = None

                    if adm_faculty == colAdmForm.cleaned_data['admission_faculty']:
                        pass
                        print(colAdmForm.cleaned_data['admission_faculty'],"a")
                    else:
                        no=int(colAdmForm.cleaned_data['adm_class'])
                        print(colAdmForm.cleaned_data['admission_faculty'],"b")
                        if no==11:
                            pi.updateclass11 = colAdmForm.cleaned_data['adm_class']
                            pi.updateyear11 = y[0:4]
                            pi.updatedivision11 = str(colAdmForm.cleaned_data['division'])
                            pi.updaterollno11 = colAdmForm.cleaned_data['rollno']
                            pi.updatestream11 = colAdmForm.cleaned_data['admission_faculty']

                            pi.updateclass12 = pi.updateyear12 = pi.updatedivision12 = pi.updaterollno12 = pi.updatestream12 =None
                        elif no==12:
                            pi.updateclass12 = colAdmForm.cleaned_data['adm_class']
                            pi.updateyear12 = y[0:4]
                            pi.updatedivision12 = str(colAdmForm.cleaned_data['division'])
                            pi.updaterollno12 = colAdmForm.cleaned_data['rollno']
                            pi.updatestream12 = colAdmForm.cleaned_data['admission_faculty']

                            pi.updateclass11 = pi.updateyear11 = pi.updatedivision11 = pi.updaterollno11 = pi.updatestream11 = None

                    pi.save()
                    colAdmForm.save()
                    messages.success(request,colAdmForm.cleaned_data['fname']+" "+colAdmForm.cleaned_data['faname']+" "+colAdmForm.cleaned_data['lname']+' Student Admission Fileds Edited Successfully!')
                    return redirect('admission_collist')
                except:
                    messages.error(request,"Invalid header found in Edit Student Admission form... Try again")
                    return redirect('admission_collist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=CollegeAdm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            colAdmForm= CollegeAdmForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" College Admission / Edit-Student",
            "menu_icon":"nav-icon fas fa-address-card",
            "colAdmForm":colAdmForm,
            "update":True,
            # "priAdmData":priAdmData,
            }     
        return render(request, 'schoolviews/admission/college_adm.html',context) 
    else:
        return redirect('login')




# Form1710 Admission Edit View
def admission_editForm1710(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        #priAdmData=PrimAdm.objects.all()
        if request.method == 'POST':
            pi=Form1710Adm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            # print("user ID",ui.id)
            # print("student ID",pi.user_id)
            form1710Form= Form1710AdmForm(request.POST,request.FILES,instance=pi)
            if form1710Form.is_valid():
                try:
                    ui.username=form1710Form.cleaned_data['aadhar']
                    ui.email=form1710Form.cleaned_data['email']
                    #password="Admin@123"
                    ui.first_name=form1710Form.cleaned_data['fname']
                    ui.last_name=form1710Form.cleaned_data['lname']
                    ui.save()
                    y=form1710Form.cleaned_data['admdate']                   
                    pi.admyear=y[0:4]
                    pi.save()
                    form1710Form.save()
                    messages.success(request,form1710Form.cleaned_data['fname']+" "+form1710Form.cleaned_data['faname']+" "+form1710Form.cleaned_data['lname']+' Student Admission Fileds Edited Successfully!')
                    return redirect('admission_form1710list')
                except:
                    messages.error(request,"Invalid header found in Edit Student Admission form... Try again")
                    return redirect('admission_form1710list')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=Form1710Adm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            form1710Form= Form1710AdmForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" Primary Admission / Edit-Student",
            "menu_icon":"nav-icon fas fa-address-card",
            "form1710Form":form1710Form,
            "update":True,
            # "priAdmData":priAdmData,
            }     
        return render(request, 'schoolviews/admission/form1710_adm.html',context) 
    else:
        return redirect('login')




# College Admission Edit View
def admission_editForm1712(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        #priAdmData=PrimAdm.objects.all()
        if request.method == 'POST':
            pi=Form1712Adm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            # print("user ID",ui.id)
            # print("student ID",pi.user_id)
            form1712Form= Form1712AdmForm(request.POST,request.FILES,instance=pi)
            if form1712Form.is_valid():
                try:
                    ui.username=form1712Form.cleaned_data['aadhar']
                    ui.email=form1712Form.cleaned_data['email']
                    #password="Admin@123"
                    ui.first_name=form1712Form.cleaned_data['fname']
                    ui.last_name=form1712Form.cleaned_data['lname']
                    ui.save()
                    y=form1712Form.cleaned_data['admdate']                   
                    pi.admyear=y[0:4]
                    pi.save()
                    form1712Form.save()
                    messages.success(request,form1712Form.cleaned_data['fname']+" "+form1712Form.cleaned_data['faname']+" "+form1712Form.cleaned_data['lname']+' Student Admission Fileds Edited Successfully!')
                    return redirect('admission_form1712list')
                except:
                    messages.error(request,"Invalid header found in Edit Student Admission form... Try again")
                    return redirect('admission_form1712list')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=Form1712Adm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            form1712Form= Form1712AdmForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" College Admission / Edit-Student",
            "menu_icon":"nav-icon fas fa-address-card",
            "form1712Form":form1712Form,
            "update":True,
            # "priAdmData":priAdmData,
            }     
        return render(request, 'schoolviews/admission/form1712_adm.html',context) 
    else:
        return redirect('login')



# 11-ATKT Admission Edit View
def admission_edit11ATKT(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        #priAdmData=PrimAdm.objects.all()
        if request.method == 'POST':
            pi=ATKT11Adm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            # print("user ID",ui.id)
            # print("student ID",pi.user_id)
            atkt11Form= ATKT11AdmForm(request.POST,request.FILES,instance=pi)
            if atkt11Form.is_valid():
                try:
                    ui.username=atkt11Form.cleaned_data['aadhar']
                    ui.email=atkt11Form.cleaned_data['email']
                    #password="Admin@123"
                    ui.first_name=atkt11Form.cleaned_data['fname']
                    ui.last_name=atkt11Form.cleaned_data['lname']
                    ui.save()
                    y=atkt11Form.cleaned_data['admdate']                   
                    pi.admyear=y[0:4]
                    pi.save()
                    atkt11Form.save()
                    messages.success(request,atkt11Form.cleaned_data['fname']+" "+atkt11Form.cleaned_data['faname']+" "+atkt11Form.cleaned_data['lname']+' Student Admission Fileds Edited Successfully!')
                    return redirect('admission_atkt11list')
                except:
                    messages.error(request,"Invalid header found in Edit Student Admission form... Try again")
                    return redirect('admission_atkt11list')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=ATKT11Adm.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            atktAdmForm= ATKT11AdmForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" 11-ATKT Admission / Edit-Student",
            "menu_icon":"nav-icon fas fa-address-card",
            "atktAdmForm":atktAdmForm,
            "update":True,
            }     
        return render(request, 'schoolviews/admission/atkt11_adm.html',context) 
    else:
        return redirect('login')



# Primary Academic Terminate Approval View
def academic_priterminateapproval(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name
        fname=request.user.first_name
        try:
            print(1)
            pi=PrimAdm.objects.get(pk=user_id)
            pi.terminatebyteacher=False
            pi.tclass=None
            pi.treason=None
            pi.tyear=None
            pi.tdate=None
            pi.save()
            print(2)
            messages.success(request,'Student Terminate Disapproved')
            return redirect('academic_priterminatedeclist') 
        except:
            messages.error(request,"Invalid header found in Terminate Approval View Try again")
            return redirect('academic_priterminatedeclist') 
    else:
        return redirect('login')



# Secondary Academic Terminate Approval View
def academic_secterminateapproval(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name
        fname=request.user.first_name
        try:
            print(1)
            pi=SecondAdm.objects.get(pk=user_id)
            pi.terminatebyteacher=False
            pi.tclass=None
            pi.treason=None
            pi.tyear=None
            pi.tdate=None
            pi.save()
            print(2)
            messages.success(request,'Student Terminate Disapproved')
            return redirect('academic_secterminatedeclist') 
        except:
            messages.error(request,"Invalid header found in Terminate Approval View Try again")
            return redirect('academic_secterminatedeclist') 
    else:
        return redirect('login')



# College Academic Terminate Approval View
def academic_colterminateapproval(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name
        fname=request.user.first_name
        try:
            print(1)
            pi=CollegeAdm.objects.get(pk=user_id)
            pi.terminatebyteacher=False
            pi.tclass=None
            pi.tstream=None
            pi.treason=None
            pi.tyear=None
            pi.tdate=None
            pi.save()
            print(2)
            messages.success(request,'Student Terminate Disapproved')
            return redirect('academic_colterminatedeclist') 
        except:
            messages.error(request,"Invalid header found in Terminate Approval View Try again")
            return redirect('academic_colterminatedeclist') 
    else:
        return redirect('login')

