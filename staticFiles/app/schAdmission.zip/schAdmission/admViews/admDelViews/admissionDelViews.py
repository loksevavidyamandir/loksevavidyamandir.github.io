from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User,auth
from django.conf import settings as conf_set
from django.contrib import messages
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
# This Delete Views Included ::-->  
#



# Primary Delete View
def admission_delPrimStd(request,user_id):
    if request.method == 'POST':
        pi=PrimAdm.objects.get(pk=user_id)
        ui=User.objects.get(pk=user_id)
        pi.delete()
        ui.delete()
        messages.success(request, 'Student Deleted Successfully!')
        return redirect('admission_primlist')




# Secondary Delete View
def admission_delSecStd(request,user_id):
    if request.method == 'POST':
        pi=SecondAdm.objects.get(pk=user_id)
        ui=User.objects.get(pk=user_id)
        pi.delete()
        ui.delete()
        messages.success(request, 'Student Deleted Successfully!')
        return redirect('admission_seclist')



# College Delete View
def admission_delColStd(request,user_id):
    if request.method == 'POST':
        pi=CollegeAdm.objects.get(pk=user_id)
        ui=User.objects.get(pk=user_id)
        pi.delete()
        ui.delete()
        messages.success(request, 'Student Deleted Successfully!')
        return redirect('admission_collist')


# 11-ATKT Delete View
def admission_del11AtktStd(request,user_id):
    if request.method == 'POST':
        pi=ATKT11Adm.objects.get(pk=user_id)
        ui=User.objects.get(pk=user_id)
        pi.delete()
        ui.delete()
        messages.success(request, 'Student Deleted Successfully!')
        return redirect('admission_atkt11list')


# Form17 10 Delete View
def admission_delform1710Std(request,user_id):
    if request.method == 'POST':
        pi=Form1710Adm.objects.get(pk=user_id)
        ui=User.objects.get(pk=user_id)
        pi.delete()
        ui.delete()
        messages.success(request, 'Student Deleted Successfully!')
        return redirect('admission_form1710list')


# Form17 12 Delete View
def admission_delform1712Std(request,user_id):
    if request.method == 'POST':
        pi=Form1712Adm.objects.get(pk=user_id)
        ui=User.objects.get(pk=user_id)
        pi.delete()
        ui.delete()
        messages.success(request, 'Student Deleted Successfully!')
        return redirect('admission_form1712list')