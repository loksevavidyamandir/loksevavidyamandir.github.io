from django.shortcuts import redirect,render
from django.http import HttpResponse, HttpResponseRedirect
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue
import xlwt
from xlwt.Formatting import Borders


# This Export Views Included only excel export ::-->  
# Admission , Academics of all 3 below
# Primary ,Secondary,College

# # Primary Admission Export View
# def adm_export_prim_xls(request,cy):
#     print(cy)
#     response = HttpResponse(content_type='application/ms-excel')
#     response['Content-Disposition'] = 'attachment; filename="PrimaryList"'+cy+'".xls"'
#     wb = xlwt.Workbook(encoding='utf-8')
#     ws = wb.add_sheet('PrimaryList')
#     # Sheet header, first row
#     row_num = 0
#     excel_style = xlwt.XFStyle()
#     excel_style.font.bold = True
#     borders = xlwt.Borders()
#     borders.left = 1
#     borders.right = 1
#     borders.top = 1
#     borders.bottom = 1
#     excel_style.borders = borders
#     columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Minority","Place of Birth","Date of Birth","Last attended school","Admission Date","Admission Standard","Division","Roll Number","Late Admission","Admission Type","Hostel required","Gender","Person With Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Mother Mobile","Father Occupation","Mother Occupation","Annual Income","BPL","Guardian is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","IFSC Code","Branch Name","MICR Code"]
#     for col_num in range(len(columns)):
#         ws.write(row_num, col_num, columns[col_num], excel_style)
#     # Sheet body, remaining rows
#     excel_style = xlwt.XFStyle()
#     excel_style.borders = borders
#     rows = PrimAdm.objects.all().values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','category','subcast','minority','pob','dob','last_school','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','ifsc','branch','micr')
#     for row in rows:
#         y=row[18]
#         print(y[0:4])
#         if y[0:4] == cy:
#             row_num += 1
#             for col_num in range(len(row)):
#                 ws.write(row_num, col_num, row[col_num], excel_style)
#     wb.save(response)
#     return response




# Primary Admission Export View
def adm_export_prim_xls(request,cy):
    print("export",cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=PrimaryAdmissionList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('PrimaryAdmissionList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste Category","SubCaste","Minority","Place of Birth","Date of Birth(YYYY-MM-DD)","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(YYYY-MM-DD)","Admission Standard","Division","Roll Number","Late Admission","Admission Type","Hostel required","Gender","Person With Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Mother Mobile","Father Occupation","Mother Occupation","Annual Income","BPL","Guardian is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","IFSC Code","Branch Name","MICR Code","Note"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = PrimAdm.objects.filter(admyear=cy).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','ifsc','branch','micr','note')
    for row in rows:
        # row[9]-m_tongue,row[10]-religion,row[11]-cast,
        # row[12]- category,row[13]-subcast,row[17]-last_school,row[23]-division
        row=list(row)
        t=MTongue.objects.get(id=row[9])
        row[9]=t.m_tongue

        r=Religion.objects.get(id=row[10])
        row[10]=r.religionName

        c=Cast.objects.get(id=row[11])
        row[11]=c.castName
        row[12]=c.castCat.castCategoryName

        if row[13]!=None:
            sc=SubCast.objects.get(id=row[13])
            row[13]=sc.subCastName

        if row[17]!=None:
            os=OtherSch.objects.get(id=row[17])
            row[17]=os.schName

        if row[23]!=None:
            d=Division.objects.get(id=row[23])
            row[23]=d.division
            
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response



# Secondary Admission Export View
def adm_export_sec_xls(request,cy):
    print(cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=SecondaryAdmissionList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('SecondaryAdmissionList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Minority","Place of Birth","Date of Birth(YYYY-MM-DD)","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(YYYY-MM-DD)","Admission Standard","Division","Roll Number","Late Admission","Admission Type","Hostel required","Gender","Person With Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Mother Mobile","Father Occupation","Mother Occupation","Annual Income","BPL","Guardian is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","IFSC Code","Branch Name","MICR Code","Note"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = SecondAdm.objects.filter(admyear=cy).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','ifsc','branch','micr','note')
    for row in rows:
        # row[9]-m_tongue,row[10]-religion,row[11]-cast,
        # row[12]- category,row[13]-subcast,row[17]-last_school,row[23]-division
        row=list(row)
        t=MTongue.objects.get(id=row[9])
        row[9]=t.m_tongue

        r=Religion.objects.get(id=row[10])
        row[10]=r.religionName

        c=Cast.objects.get(id=row[11])
        row[11]=c.castName
        row[12]=c.castCat.castCategoryName

        if row[13]!=None:
            sc=SubCast.objects.get(id=row[13])
            row[13]=sc.subCastName   

        if row[17]!=None:
            os=OtherSch.objects.get(id=row[17])
            row[17]=os.schName

        if row[23]!=None:
            d=Division.objects.get(id=row[23])
            row[23]=d.division
            
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
             ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response




# College Admission Export View
def adm_export_col_xls(request,cy):
    print(cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=CollegeAdmissionList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('CollegeAdmissionList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Minority","Place of Birth","Date of Birth(YYYY-MM-DD)","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(YYYY-MM-DD)","Admission Standard","Admission Stream","Division","Roll Number","Late Admission","Admission Type","Hostel required","Gender","Person With Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Mother Mobile","Father Occupation","Mother Occupation","Annual Income","BPL","Guardian is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","IFSC Code","Branch Name","MICR Code","Note"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = CollegeAdm.objects.filter(admyear=cy).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','ifsc','branch','micr','note')
    for row in rows:
        # row[9]-m_tongue,row[10]-religion,row[11]-cast,
        # row[12]- category,row[13]-subcast,row[17]-last_school,row[24]-division
        row=list(row)
        t=MTongue.objects.get(id=row[9])
        row[9]=t.m_tongue

        r=Religion.objects.get(id=row[10])
        row[10]=r.religionName

        c=Cast.objects.get(id=row[11])
        row[11]=c.castName
        row[12]=c.castCat.castCategoryName

        if row[13]!=None:
            sc=SubCast.objects.get(id=row[13])
            row[13]=sc.subCastName   

        if row[17]!=None:
            os=OtherSch.objects.get(id=row[17])
            row[17]=os.schName

        if row[24]!=None:
            d=Division.objects.get(id=row[24])
            row[24]=d.division
            
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response




# 11-ATKT Admission Export View
def adm_export_atkt11_xls(request,cy):
    print(cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=ATKT11AdmissionList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('ATKT11AdmissionList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Minority","Place of Birth","Date of Birth(YYYY-MM-DD)","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(YYYY-MM-DD)","Admission Standard","Admission Stream","Division","Roll Number","Late Admission","Admission Type","Hostel required","Gender","Person With Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Mother Mobile","Father Occupation","Mother Occupation","Annual Income","BPL","Guardian is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bonafide Issued Date","Bonafide Sr No","Bank Account Number","Bank Name","IFSC Code","Branch Name","MICR Code","Note"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = ATKT11Adm.objects.filter(admyear=cy).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','bonaissuedate','bonasrno','baccount','bankname','ifsc','branch','micr','note')
    for row in rows:
        # row[9]-m_tongue,row[10]-religion,row[11]-cast,
        # row[12]- category,row[13]-subcast,row[17]-last_school,row[24]-division
        row=list(row)
        t=MTongue.objects.get(id=row[9])
        row[9]=t.m_tongue

        r=Religion.objects.get(id=row[10])
        row[10]=r.religionName

        c=Cast.objects.get(id=row[11])
        row[11]=c.castName
        row[12]=c.castCat.castCategoryName

        if row[13]!=None:
            sc=SubCast.objects.get(id=row[13])
            row[13]=sc.subCastName   

        if row[17]!=None:
            os=OtherSch.objects.get(id=row[17])
            row[17]=os.schName

        if row[24]!=None:
            d=Division.objects.get(id=row[24])
            row[24]=d.division
            
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response





# Form17 10 Admission Export View
def adm_export_form1710_xls(request,cy):
    print(cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=Form17-SSCAdmissionList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Form17-SSCAdmissionList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Minority","Place of Birth","Date of Birth(YYYY-MM-DD)","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(YYYY-MM-DD)","Admission Standard","Roll Number","Late Admission","Admission Type","Hostel required","Gender","Person With Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Mother Mobile","Father Occupation","Mother Occupation","Annual Income","BPL","Guardian is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","IFSC Code","Branch Name","MICR Code","Note"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = Form1710Adm.objects.filter(admyear=cy).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','ifsc','branch','micr','note')
    for row in rows:
        # row[9]-m_tongue,row[10]-religion,row[11]-cast,
        # row[12]- category,row[13]-subcast,row[17]-last_school
        row=list(row)
        t=MTongue.objects.get(id=row[9])
        row[9]=t.m_tongue

        r=Religion.objects.get(id=row[10])
        row[10]=r.religionName

        c=Cast.objects.get(id=row[11])
        row[11]=c.castName
        row[12]=c.castCat.castCategoryName


        if row[13]!=None:
            sc=SubCast.objects.get(id=row[13])
            row[13]=sc.subCastName   

        if row[17]!=None:
            os=OtherSch.objects.get(id=row[17])
            row[17]=os.schName
            
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response




# Form17 12 Admission Export View
def adm_export_form1712_xls(request,cy):
    print("export",cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=Form17-HSCAdmissionList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Form17-HSCAdmissionList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Minority","Place of Birth","Date of Birth(YYYY-MM-DD)","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(YYYY-MM-DD)","Admission Standard","Admission Stream","Roll Number","Late Admission","Admission Type","Hostel required","Gender","Person With Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Mother Mobile","Father Occupation","Mother Occupation","Annual Income","BPL","Guardian is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","IFSC Code","Branch Name","MICR Code","Note"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = Form1712Adm.objects.filter(admyear=cy).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','mo_mob','fa_occu','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','ifsc','branch','micr','note')
    for row in rows:
        # row[9]-m_tongue,row[10]-religion,row[11]-cast,
        # row[12]- category,row[13]-subcast,row[17]-last_school
        row=list(row)
        t=MTongue.objects.get(id=row[9])
        row[9]=t.m_tongue

        r=Religion.objects.get(id=row[10])
        row[10]=r.religionName

        c=Cast.objects.get(id=row[11])
        row[11]=c.castName
        row[12]=c.castCat.castCategoryName


        if row[13]!=None:
            sc=SubCast.objects.get(id=row[13])
            row[13]=sc.subCastName   

        if row[17]!=None:
            os=OtherSch.objects.get(id=row[17])
            row[17]=os.schName

            
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response




# Primary Academics Export View
def acad_export_prim_xls(request,cy):
    print("export",cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=PrimaryAcademicsList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('PrimaryAcademicsList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Registration Number","Last Name","First Name","Father Name","Admission Date","Standard 1st Year","Standard 1st","Standard 1st Division","Standard 1st Roll No","Standard 2nd Year","Standard 2nd","Standard 2nd Division","Standard 2nd Roll No","Standard 3rd Year","Standard 1rd","Standard 3rd Division","Standard 3rd Roll No","Standard 4th Year","Standard 4th","Standard 4th Division","Standard 4th Roll No"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = PrimAdm.objects.filter(admyear=cy).values_list('prn','lname','fname','faname','admdate','updateyear1','updateclass1','updatedivision1','updaterollno1','updateyear2','updateclass2','updatedivision2','updaterollno2','updateyear3','updateclass3','updatedivision3','updaterollno3','updateyear4','updateclass4','updatedivision4','updaterollno4')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response




# Secondary Academics Export View
def acad_export_sec_xls(request,cy):
    print(cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=SecondaryAcademicsList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('SecondaryAcademicsList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Registration Number","Last Name","First Name","Father Name","Admission Date","Standard 5th Year","Standard 5th","Standard 5th Division","Standard 5th Roll","Standard 6th Year","Standard 6th","Standard 6th Division","Standard 6th Roll","Standard 7th Year","Standard 7th","Standard 7th Division","Standard 7th Roll","Standard 8th Year","Standard 8th","Standard 8th Division","Standard 8th Roll","Standard 9th Year","Standard 9th","Standard 9th Division","Standard 9th Roll","Standard 10th Year","Standard 10th","Standard 10th Division","Standard 10th Roll"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = SecondAdm.objects.filter(admyear=cy).values_list('prn','lname','fname','faname','admdate','updateyear5','updateclass5','updatedivision5','updaterollno5','updateyear6','updateclass6','updatedivision6','updaterollno6','updateyear7','updateclass7','updatedivision7','updaterollno7','updateyear8','updateclass8','updatedivision8','updaterollno8','updateyear9','updateclass9','updatedivision9','updaterollno9','updateyear10','updateclass10','updatedivision10','updaterollno10')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response



# College Academics Export View
def acad_export_col_xls(request,cy):
    print(cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=CollegeAcademicsList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('CollegeAcademicsList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Registration Number","Last Name","First Name","Father Name","Admission Date","Admission Stream","Standard 11th Year","Standard 11th","Standard 11th Admission Stream","Standard 11th Division","Standard 11th Roll","Standard 12th Year","Standard 12th","Standard 12th Admission Stream","Standard 12th Division","Standard 12th Roll"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = CollegeAdm.objects.filter(admyear=cy).values_list('prn','lname','fname','faname','admdate','admission_faculty','updateyear11','updateclass11','updatestream11','updatedivision11','updaterollno11','updateyear12','updateclass12','updatestream12','updatedivision12','updaterollno12')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response