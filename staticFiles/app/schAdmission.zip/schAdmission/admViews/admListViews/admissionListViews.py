from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue,LCRemark
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schAdmission.admForms.admissionForms import GetAdmYearForm
import datetime



sname=conf_set.SCHOOL_NAME



# Primary admission List View
def admission_listPrim(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    priAdmData=PrimAdm.objects.filter(admyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Admission /",
                    'fname':fname,
                    "page_path":" Primary-Admission / Student List",
                    "menu_icon":"nav-icon fas fa-school",
                    "priAdmData":priAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/admission/prim_adm_lis.html',context) 
                except:
                    messages.error(request,"Invalid header found in Primary Student List form... Try again")
                    return redirect('admission_primlist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            priAdmData=PrimAdm.objects.filter(admyear=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" Primary Admission / List Student",
            "menu_icon":"nav-icon fas fa-school",
            "priAdmData":priAdmData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/admission/prim_adm_lis.html',context) 
    else:
        return redirect('login') 



# Secondary admission List View
def admission_listSec(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate= GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    secAdmData=SecondAdm.objects.filter(admyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Admission /",
                    'fname':fname,
                    "page_path":" Secondary-Admission / Student List",
                    "menu_icon":"nav-icon fas fa-school",
                    "secAdmData":secAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/admission/secondary_adm_lis.html',context) 
                except:
                    messages.error(request,"Invalid header found in Secondary Student List form... Try again")
                    return redirect('admission_seclist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            getAdmDate= GetAdmYearForm()
            secAdmData=SecondAdm.objects.filter(admyear=cy)
            # print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" Secondary Admission / List Student",
            "menu_icon":"nav-icon fas fa-school",
            "secAdmData":secAdmData,    
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/admission/secondary_adm_lis.html',context) 
    else:
        return redirect('login') 




# College admission List View
def admission_listCol(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate= GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    colAdmData=CollegeAdm.objects.filter(admyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Admission /",
                    'fname':fname,
                    "page_path":" College-Admission / Student List",
                    "menu_icon":"nav-icon fas fa-school",
                    "colAdmData":colAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/admission/college_adm_lis.html',context) 
                except:
                    messages.error(request,"Invalid header found in College Student List form... Try again")
                    return redirect('admission_collist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            getAdmDate= GetAdmYearForm()
            colAdmData=CollegeAdm.objects.filter(admyear=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" College Admission / List Student",
            "menu_icon":"nav-icon fas fa-school",
            "colAdmData":colAdmData,    
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/admission/college_adm_lis.html',context) 
    else:
        return redirect('login')



# College admission List View
def admission_atkt11list(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate= GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    atkt11AdmData=ATKT11Adm.objects.filter(admyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Admission /",
                    'fname':fname,
                    "page_path":" 11-ATKT-Admission / Student List",
                    "menu_icon":"nav-icon fas fa-school",
                    "atkt11AdmData":atkt11AdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/admission/atkt11_adm_list.html',context) 
                except:
                    messages.error(request,"Invalid header found in 11-ATKT Student List form... Try again")
                    return redirect('admission_atkt11list')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            getAdmDate= GetAdmYearForm()
            atkt11AdmData=ATKT11Adm.objects.filter(admyear=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" 11-ATKT Admission / List Student",
            "menu_icon":"nav-icon fas fa-school",
            "atkt11AdmData":atkt11AdmData,    
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/admission/atkt11_adm_list.html',context) 
    else:
        return redirect('login')




# Form1710 admission List View
def admission_listForm1710(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate= GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    form1710Data=Form1710Adm.objects.filter(admyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Admission /",
                    'fname':fname,
                    "page_path":" Form17 10-Admission / Student List",
                    "menu_icon":"nav-icon fas fa-school",
                    "form1710Data":form1710Data,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/admission/form1710_adm_lis.html',context) 
                except:
                    messages.error(request,"Invalid header found in Form17 10 Student List form... Try again")
                    return redirect('admission_form1710list')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            form1710Data=Form1710Adm.objects.filter(admyear=cy[0:4])
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" Form17 10 Admission / List Student",
            "menu_icon":"nav-icon fas fa-school",
            "form1710Data":form1710Data,
            "getAdmDate":getAdmDate,
            "cy" : cy[0:4]
            }    
        return render(request, 'schoolviews/admission/form1710_adm_lis.html',context) 
    else:
        return redirect('login') 




# Form1713 admission List View
def admission_listForm1712(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate= GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    form1712Data=Form1712Adm.objects.filter(admyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Admission /",
                    'fname':fname,
                    "page_path":" Form17 10-Admission / Student List",
                    "menu_icon":"nav-icon fas fa-school",
                    "form1712Data":form1712Data,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/admission/form1712_adm_lis.html',context) 
                except:
                    messages.error(request,"Invalid header found in Form17 12 Student List form... Try again")
                    return redirect('admission_form1712list')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            form1712Data=Form1712Adm.objects.filter(admyear=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Admission /",
            'fname':fname,
            "page_path":" Form17 12 Admission / List Student",
            "menu_icon":"nav-icon fas fa-school",
            "form1712Data":form1712Data,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/admission/form1712_adm_lis.html',context) 
    else:
        return redirect('login')






# Primary Academic List View
def academic_priAcademiclist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    priAdmData=PrimAdm.objects.filter(admyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Academic /",
                    'fname':fname,
                    "page_path":" Primary Academic / Student Academic List",
                    "menu_icon":"nav-icon fas fa-university",
                    "priAdmData":priAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/academics/priAcademiclist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Primary Student Academic  List form... Try again")
                    return redirect('academic_priAcademiclist')
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            priAdmData=PrimAdm.objects.filter(admyear=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Academic /",
            'fname':fname,
            "page_path":" Primary Academic / Student Academic List",
            "menu_icon":"nav-icon fas fa-university",
            "priAdmData":priAdmData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/academics/priAcademiclist.html',context) 
    else:
        return redirect('login')




# Secondary Academic List View
def academic_secAcademiclist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate= GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    secAdmData=SecondAdm.objects.filter(admyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Academic /",
                    'fname':fname,
                    "page_path":" Secondary Academic / Student Academic List",
                    "menu_icon":"nav-icon fas fa-university",
                    "secAdmData":secAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/academics/secAcademiclist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Secondary Student List form... Try again")
                    return redirect('academic_secAcademiclist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            getAdmDate= GetAdmYearForm()
            secAdmData=SecondAdm.objects.filter(admyear=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Academic /",
            'fname':fname,
            "page_path":" Secondary Academic / Student Academic List",
            "menu_icon":"nav-icon fas fa-university",
            "secAdmData":secAdmData,    
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/academics/secAcademiclist.html',context) 
    else:
        return redirect('login') 




# College Academic List View
def academic_colAcademiclist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate= GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    colAdmData=CollegeAdm.objects.filter(admyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Academic /",
                    'fname':fname,
                    "page_path":" College Academic / Student Academic List",
                    "menu_icon":"nav-icon fas fa-school",
                    "colAdmData":colAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                    }
                    return render(request, 'schoolviews/academics/colAcademiclist.html',context) 
                except:
                    messages.error(request,"Invalid header found in College Student List form... Try again")
                    return redirect('academic_colAcademiclist')
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            getAdmDate= GetAdmYearForm()
            colAdmData=CollegeAdm.objects.filter(admyear=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Academic /",
            'fname':fname,
            "page_path":" College Academic / Student Academic List",
            "menu_icon":"nav-icon fas fa-school",
            "colAdmData":colAdmData,    
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/academics/colAcademiclist.html',context) 
    else:
        return redirect('login')



# Primary Student Terminate
def academic_priterminatelist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    priAdmData=PrimAdm.objects.filter(terminatebyprincipal=True,tyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Academic /",
                    'fname':fname,
                    "page_path":" Primary Terminate / Student Terminate List",
                    "menu_icon":"nav-icon fas fa-university",
                    "priAdmData":priAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/academics/priTerminatelist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Primary Student Terminate List form... Try again")
                    return redirect('academic_priterminatelist')
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            priAdmData=PrimAdm.objects.filter(terminatebyprincipal=True,tyear=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Academic /",
            'fname':fname,
            "page_path":" Primary Terminate / Student Terminate List",
            "menu_icon":"nav-icon fas fa-university",
            "priAdmData":priAdmData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/academics/priTerminatelist.html',context) 
    else:
        return redirect('login')



# Secondary Student Terminate
def academic_secterminatelist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    secAdmData=SecondAdm.objects.filter(terminatebyprincipal=True,tyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Academic /",
                    'fname':fname,
                    "page_path":" Secondary Terminate / Student Terminate List",
                    "menu_icon":"nav-icon fas fa-university",
                    "secAdmData":secAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/academics/secTerminatelist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Secondary Student Terminate List form... Try again")
                    return redirect('academic_secterminatelist')
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            secAdmData=SecondAdm.objects.filter(terminatebyprincipal=True,tyear=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Academic /",
            'fname':fname,
            "page_path":" Secondary Terminate / Student Terminate List",
            "menu_icon":"nav-icon fas fa-university",
            "secAdmData":secAdmData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/academics/secTerminatelist.html',context) 
    else:
        return redirect('login')


# College Student Terminate
def academic_colterminatelist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    colAdmData=CollegeAdm.objects.filter(terminatebyprincipal=True,tyear=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Academic /",
                    'fname':fname,
                    "page_path":" College Terminate / Student Terminate List",
                    "menu_icon":"nav-icon fas fa-university",
                    "colAdmData":colAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/academics/secTerminatelist.html',context) 
                except:
                    messages.error(request,"Invalid header found in College Student Terminate List form... Try again")
                    return redirect('academic_colterminatelist')
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            colAdmData=CollegeAdm.objects.filter(terminatebyprincipal=True,tyear=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Academic /",
            'fname':fname,
            "page_path":" College Terminate / Student Terminate List",
            "menu_icon":"nav-icon fas fa-university",
            "colAdmData":colAdmData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/academics/colTerminatelist.html',context) 
    else:
        return redirect('login')



# Primary Student Terminate decision
def academic_priterminatedeclist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        remarkData = LCRemark.objects.all()
        priAdmData=PrimAdm.objects.filter(terminatebyteacher=True,terminatebyprincipal=False)
        # print(1,priAdmData)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Academic /",
            'fname':fname,
            "remarkData":remarkData,
            "page_path":" Primary Terminate / Student Terminate Approval List",
            "menu_icon":"nav-icon fas fa-university",
            "priAdmData":priAdmData,
            }    
        return render(request, 'schoolviews/academics/priTerminatedeclist.html',context) 
    else:
        return redirect('login')



# Secondary Student Terminate decision
def academic_secterminatedeclist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        remarkData = LCRemark.objects.all()
        secAdmData=SecondAdm.objects.filter(terminatebyteacher=True,terminatebyprincipal=False)
        # print(1,secAdmData)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Academic /",
            'fname':fname,
            "remarkData":remarkData,
            "page_path":" Secondary Terminate / Student Terminate Approval List",
            "menu_icon":"nav-icon fas fa-university",
            "secAdmData":secAdmData,
            }    
        return render(request, 'schoolviews/academics/secTerminatedeclist.html',context) 
    else:
        return redirect('login')


# College Student Terminate decision
def academic_colterminatedeclist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        remarkData = LCRemark.objects.all()
        colAdmData=CollegeAdm.objects.filter(terminatebyteacher=True,terminatebyprincipal=False)
        # print(1,colAdmData)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Academic /",
            'fname':fname,
            "remarkData":remarkData,
            "page_path":" College Terminate / Student Terminate Approval List",
            "menu_icon":"nav-icon fas fa-university",
            "colAdmData":colAdmData,
            }    
        return render(request, 'schoolviews/academics/colTerminatedeclist.html',context) 
    else:
        return redirect('login')
