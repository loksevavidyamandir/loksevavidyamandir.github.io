from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm
from schStaff.staffModels.empModels import EmployeeEnrol
from schSetup.setupModels.setup_models import Division
from seedData.models import Year
from schAdmission.admForms.admissionForms import GetAdmYearForm
import datetime

sname=conf_set.SCHOOL_NAME
schnameabove=conf_set.SCHNAME_ABOVE
schname=conf_set.SCHNAME
schnamebelow=conf_set.SCHNAME_BELOW
schUDISEno=conf_set.SCH_UDISE_NO
schboard=conf_set.SCH_BOARD
schreg=conf_set.SCH_REG

# All Identity Card Views

# for primary Identity Card
def admissionpri_idgenerate(request):
    if request.session.has_key('username'):
        lname=request.user.last_name
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        if request.method == 'POST':
            try:
                year = int(request.POST['priyear_id'])
                year1=year+1
                class1 = int(request.POST['priclass_id'])
                div = request.POST['pridivision_id'] 
                stud_id=[]
                studid=request.POST['studid'].split(",")
                for x in range(0,len(studid)):
                    stud_id.append(int(studid[x]))
                    priData=PrimAdm.objects.get(pk=int(studid[x]))
                    date=priData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    priData.lcdob=dobirth
                    priData.save()
                priData=PrimAdm.objects.all()
                context = {
                    'priData':priData,
                    'stud_id':stud_id,
                    'year':year,
                    'year1':year1,
                    'class1':class1,
                    'div':div,
                    'schnameabove':schnameabove,
                    'schname':schname,
                    'schnamebelow':schnamebelow,
                    }
                return render(request,'schoolviews/identitycard/primarystudentidview.html',context)
            except:
                messages.error(request,"Invalid header found in Identity Card form... Try again")
                return redirect('admissionpri_idgenerate')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" ID-Card /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "page_path":" Primary ID Generate",
            "menu_icon":"nav-icon fas fa-id-card",
            }
        return render(request,'schoolviews/identitycard/primaryidgenerate.html',context) 
    else:
        return redirect('login')


# for primary Identity Card
def load_pristudentsid(request):
    class1 = int(request.GET.get('class1'))
    year = request.GET.get('year')
    div = request.GET.get('div')
    if class1 == 1:
        students = PrimAdm.objects.filter(updateclass1=class1,updateyear1=year,updatedivision1=div,updateclass2=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 2:
        students = PrimAdm.objects.filter(updateclass2=class1,updateyear2=year,updatedivision2=div,updateclass3=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 3:
        students = PrimAdm.objects.filter(updateclass3=class1,updateyear3=year,updatedivision3=div,updateclass4=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 4:
        students = PrimAdm.objects.filter(updateclass4=class1,updateyear4=year,updatedivision4=div,lcgenerated=0,terminatebyprincipal=0)
    return render(request,'schoolviews/identitycard/studentsid.html',{"students":students})




# for Secondary Identity Card
def admissionsec_idgenerate(request):
    if request.session.has_key('username'):
        lname=request.user.last_name
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        if request.method == 'POST':
            try:
                year = int(request.POST['secyear_id'])
                year1=year+1
                class1 = int(request.POST['secclass_id'])
                div = request.POST['secdivision_id'] 
                stud_id=[]
                studid=request.POST['studid'].split(",")
                for x in range(0,len(studid)):
                    stud_id.append(int(studid[x]))
                    secData=SecondAdm.objects.get(pk=int(studid[x]))
                    date=secData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    secData.lcdob=dobirth
                    secData.save()
                secData=SecondAdm.objects.all()
                context = {
                    'secData':secData,
                    'stud_id':stud_id,
                    'year':year,
                    'year1':year1,
                    'class1':class1,
                    'div':div,
                    'schnameabove':schnameabove,
                    'schname':schname,
                    'schnamebelow':schnamebelow,
                    }
                return render(request,'schoolviews/identitycard/secondarystudentidview.html',context)
            except:
                messages.error(request,"Invalid header found in Identity Card form... Try again")
                return redirect('admissionsec_idgenerate')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" ID-Card /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "page_path":" Secondary ID Generate",
            "menu_icon":"nav-icon fas fa-id-card",
            }
        return render(request,'schoolviews/identitycard/secondaryidgenerate.html',context) 
    else:
        return redirect('login')



# for Secondary Identity Card
def load_secstudentsid(request):
    class1 = int(request.GET.get('class1'))
    year = request.GET.get('year')
    div = request.GET.get('div')
    if class1 == 5:
        students = SecondAdm.objects.filter(updateclass5=class1,updateyear5=year,updatedivision5=div,updateclass6=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 6:
        students = SecondAdm.objects.filter(updateclass6=class1,updateyear6=year,updatedivision6=div,updateclass7=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 7:
        students = SecondAdm.objects.filter(updateclass7=class1,updateyear7=year,updatedivision7=div,updateclass8=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 8:
        students = SecondAdm.objects.filter(updateclass8=class1,updateyear8=year,updatedivision8=div,updateclass9=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 9:
        students = SecondAdm.objects.filter(updateclass9=class1,updateyear9=year,updatedivision9=div,updateclass10=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 10:
        students = SecondAdm.objects.filter(updateclass10=class1,updateyear10=year,updatedivision10=div,lcgenerated=0,terminatebyprincipal=0)
    return render(request,'schoolviews/identitycard/studentsid.html',{"students":students})




# for College Identity Card
def admissioncol_idgenerate(request):
    if request.session.has_key('username'):
        lname=request.user.last_name
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        if request.method == 'POST':
            try:
                year = int(request.POST['colyear_id'])
                year1=year+1
                class1 = int(request.POST['colclass_id'])
                stream = request.POST['colstream_id']
                div = request.POST['coldivision_id']
                stud_id=[]
                studid=request.POST['studid'].split(",")
                for x in range(0,len(studid)):
                    stud_id.append(int(studid[x]))
                    colData=CollegeAdm.objects.get(pk=int(studid[x]))
                    date=colData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    colData.lcdob=dobirth
                    colData.save()
                colData=CollegeAdm.objects.all()
                context = {
                    'colData':colData,
                    'stud_id':stud_id,
                    'year':year,
                    'year1':year1,
                    'class1':class1,
                    'stream':stream,
                    'div':div,
                    'schnameabove':schnameabove,
                    'schname':schname,
                    'schnamebelow':schnamebelow,
                    }
                return render(request,'schoolviews/identitycard/collegestudentidview.html',context)
            except:
                messages.error(request,"Invalid header found in Identity Card form... Try again")
                return redirect('admissioncol_idgenerate')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" ID-Card /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "page_path":" College ID Generate",
            "menu_icon":"nav-icon fas fa-id-card",
            }
        return render(request,'schoolviews/identitycard/collegeidgenerate.html',context) 
    else:
        return redirect('login')



# for College Identity Card
def load_colstudentsid(request):
    class1 = int(request.GET.get('class1'))
    year = request.GET.get('year')
    div = request.GET.get('div')
    stream = request.GET.get('stream')
    if class1 == 11:
        students = CollegeAdm.objects.filter(updateclass11=class1,updateyear11=year,updatedivision11=div,updatestream11=stream,updateclass12=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 12:
        students = CollegeAdm.objects.filter(updateclass12=class1,updateyear12=year,updatedivision11=div,updatestream12=stream,lcgenerated=0,terminatebyprincipal=0)
    return render(request,'schoolviews/identitycard/studentsid.html',{"students":students})





# for Staff Identity Card
def admissionstaff_idgenerate(request):
    if request.session.has_key('username'):
        lname=request.user.last_name
        fname=request.user.first_name
        if request.method == 'POST':
            try:
                staff_id=[]
                staffid=request.POST['studid'].split(",")
                for x in range(0,len(staffid)):
                    staff_id.append(int(staffid[x]))
                    staffData=EmployeeEnrol.objects.get(pk=int(staffid[x]))
                    date=staffData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    staffData.id_dob=dobirth
                    staffData.save()
                staffData=EmployeeEnrol.objects.all()
                print(staffData)
                context = {
                    'staffData':staffData,
                    'staff_id':staff_id,
                    'schnameabove':schnameabove,
                    'schname':schname,
                    'schnamebelow':schnamebelow,
                    }
                return render(request,'schoolviews/identitycard/staffidview.html',context)
            except:
                messages.error(request,"Invalid header found in Identity Card form... Try again")
                return redirect('admissionstaff_idgenerate')
        else:
            staffData=EmployeeEnrol.objects.all()
        context = {
            'sname':sname,
            'lname':lname,
            'staffData':staffData,
            'page_title':" ID-Card /",
            'fname':fname,
            "page_path":" Staff ID Generate",
            "menu_icon":"nav-icon fas fa-id-card",
            }
        return render(request,'schoolviews/identitycard/staffidgenerate.html',context) 
    else:
        return redirect('login')