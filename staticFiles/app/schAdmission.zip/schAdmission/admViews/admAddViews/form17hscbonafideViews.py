from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm
from schAdmission.admModels.academicModels import PrimBonafide,SecBonafide,ColBonafide,Form17SSCBonafide,Form17HSCBonafide
from schSetup.setupModels.setup_models import Division
from schAdmission.admForms.admissionForms import GetAdmYearForm
from seedData.models import Year
import inflect
import datetime
import xlwt
from xlwt.Formatting import Borders
  
p=inflect.engine()
sname=conf_set.SCHOOL_NAME
schnameabove=conf_set.SCHNAME_ABOVE
schname=conf_set.SCHNAME
schnamebelow=conf_set.SCHNAME_BELOW
schUDISEno=conf_set.SCH_UDISE_NO


# Form17ssc Bonafide views   

dd = ['','FIRST','SECOND','THIRD','FOURTH','FIFTH','SIXTH','SEVENTH','EIGHTH','NINTH','TENTH','ELEVENTH','TWELVETH','THIRTEENTH','FOURTEENTH','FIFTEENTH','SIXTEENTH','SEVENTEENTH','EIGHTEENTH','NINETEENTH','TWENTIETH','TWENTY FIRST','TWENTY SECOND','TWENTY THIRD','TWENTY FOURTH','TWENTY FIFTH','TWENTY SIXTH','TWENTY SEVENTH','TWENTY EIFHTH','TWENTY NINTH','Thirtieth','THIRTY FIRST']
mm = ['','JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER']


# for Form17ssc Student 
def admission_f17hscbonafide(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        if request.method == 'POST':
            try:
                studid=request.POST['studid'].split(",")
                year = int(request.POST['f17hscbonayear'])
                stream = str(request.POST['f17hscbonastream'])
                for x in range(0,len(studid)):
                    f17hscData=Form1712Adm.objects.get(pk=studid[x])
                    f17hscbona=Form17HSCBonafide()
                    f17hscbona.prn=f17hscData.prn
                    f17hscbona.lname=f17hscData.lname
                    f17hscbona.fname=f17hscData.fname
                    f17hscbona.faname=f17hscData.faname
                    f17hscbona.breligion=f17hscData.religion
                    f17hscbona.bcast=f17hscData.cast
                    f17hscbona.f17hsc_academic=f17hscData
                    f17hscbona.bona_class="12"
                    f17hscbona.bona_stream=stream
                    f17hscbona.bona_year=str(year)

                    # from adm to bonafide
                    date=f17hscData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    print(dobirth)
                    f17hscbona.dob=dobirth

                     # for dob in words
                    yy=p.number_to_words(y).capitalize()
                    yy=yy.replace(" and",'')
                    print(dd[d],mm[m],yy.upper())
                    f17hscbona.dobinwords=dd[d]+' '+mm[m]+' '+yy.upper()

                    # for issuedate
                    date=request.POST['dateofissue'].split('-')
                    doissue=date[2]+'-'+date[1]+'-'+date[0]
                    print(doissue)
                    f17hscbona.issuedate=doissue

                    print(1)
                    f17hscbona.save()
                    print(1)
                messages.success(request,'Bonafide issued Successfully!')
                return redirect('admission_f17hscbonafide')
            except:
                messages.error(request,"Invalid header found in Student Bonafide form... Try again")
                return redirect('admission_f17hscbonafide')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Bonafide /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "page_path":"Form17-HSC Bonafide Issue",
            "menu_icon":"far fa-address-card nav-icon",
            }    
        return render(request,'schoolviews/bonafide/form17hscbonafidegenerate.html',context)
    else:
        return redirect('login')


# for Form17ssc Student  
def load_f17hscstudentsbona(request):
    year = request.GET.get('year')
    stream = request.GET.get('stream')
    students = Form1712Adm.objects.filter(admyear=year,admission_faculty=stream,lcgenerated=0)
    print(students)
    return render(request,'schoolviews/bonafide/studentsbona.html',{"students":students})




# for Form17ssc bonafide  list 
def admission_f17hscbonafidelist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    f17hscbonaData=Form17HSCBonafide.objects.filter(bona_year=cy)
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Bonafide /",
                    'fname':fname,
                    "page_path":" Form17-HSC Bonafide List",
                    "menu_icon":"far fa-address-card nav-icon",
                    "f17hscbonaData":f17hscbonaData,
                    "getAdmDate":getAdmDate,
                    "cy": cy
                     }    
                    return render(request, 'schoolviews/bonafide/form17hsc_bonafidelist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Form17-SSC Student List form... Try again")
                    return redirect('admission_f17hscbonafidelist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            f17hscbonaData=Form17HSCBonafide.objects.filter(bona_year=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Bonafide /",
            'fname':fname,
            "page_path":" Form17-HSC Bonafide List",
            "menu_icon":"nav-icon far fa-address-card",
            "f17hscbonaData":f17hscbonaData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request,'schoolviews/bonafide/form17hsc_bonafidelist.html',context) 
    else:
        return redirect('login')




# for Form17ssc bonafide  View 
def admission_f17hscbonafideview(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        f17hscbonaData=Form17HSCBonafide.objects.get(pk=id)
        f17hscData=Form1712Adm.objects.get(prn=f17hscbonaData.prn)
        acad_year=int(f17hscbonaData.bona_year)
        acad_year+=1
        context = {
            "f17hscData":f17hscData,
            "f17hscbonaData":f17hscbonaData,
            "acad_year":acad_year,
            "schnameabove":schnameabove,
            "schname":schname,
            "schnamebelow":schnamebelow,
            "schUDISEno":schUDISEno,
            }
        return render(request, 'schoolviews/bonafide/form17hscbonafide_view.html',context)
    else:
        return redirect('login')



# for Form17ssc bonafide Delete 
def admission_f17hscbonafidedelete(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            f17hscbona=Form17HSCBonafide.objects.get(pk=id)
            f17hscbona.delete()
            messages.success(request,'Bonafide Deleted Sucessfully!')
            return redirect('admission_f17hscbonafidelist')
        except:
            messages.error(request,"Invalid header found in Bonafide form... Try again")
            return redirect('admission_f17hscbonafidelist')    
    else:
        return redirect('login') 