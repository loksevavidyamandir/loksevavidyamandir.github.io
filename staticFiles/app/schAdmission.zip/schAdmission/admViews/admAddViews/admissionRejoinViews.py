from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schSetup.setupModels.setup_models import Division
from seedData.models import Year
from schAdmission.admForms.admissionForms import GetAdmYearForm
import datetime



sname=conf_set.SCHOOL_NAME




# Rejoin Add View
def admission_rejoin(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            rejoinForm= RejoinForm(request.POST,request.FILES)
            if rejoinForm.is_valid():
                try:
                    adm_from=rejoinForm.cleaned_data['adm_from']
                    adm_for=rejoinForm.cleaned_data['adm_for']
                    aadhar=rejoinForm.cleaned_data['aadhar']
                    adm_class=rejoinForm.cleaned_data['adm_class']
                    admission_faculty=rejoinForm.cleaned_data['admission_faculty']
                    admdate=rejoinForm.cleaned_data['admdate']
                    prn=rejoinForm.cleaned_data['prn']
                    if User.objects.filter(username__iexact=aadhar,is_active=False).exists():
                        user=User.objects.get(username=aadhar)
                        uid=user.id
                        if PrimAdm.objects.filter(user_id=uid,lcgenerated=True,aadhar__iexact=aadhar).exists():
                            priAdmGet=PrimAdm.objects.get(user_id=uid,aadhar=aadhar)
                        elif SecondAdm.objects.filter(user_id=uid,lcgenerated=True,aadhar__iexact=aadhar).exists():
                            secAdmGet=SecondAdm.objects.get(user_id=uid,aadhar=aadhar)
                        elif CollegeAdm.objects.filter(user_id=uid,lcgenerated=True,aadhar__iexact=aadhar).exists():
                            colAdmGet=CollegeAdm.objects.get(user_id=uid,aadhar=aadhar)
                        elif ATKT11Adm.objects.filter(user_id=uid,lcgenerated=True,aadhar__iexact=aadhar).exists():
                            atkt11AdmGet=ATKT11Adm.objects.get(user_id=uid,aadhar=aadhar)
                        elif Form1710Adm.objects.filter(user_id=uid,lcgenerated=True,aadhar__iexact=aadhar).exists():
                            form1710AdmGet=Form1710Adm.objects.get(user_id=uid,aadhar=aadhar)
                        elif Form1712Adm.objects.filter(user_id=uid,lcgenerated=True,aadhar__iexact=aadhar).exists():
                            form1712AdmGet=Form1712Adm.objects.get(user_id=uid,aadhar=aadhar) 
                            
                        print(123)
                        if adm_for=="Primary":
                        #     p to p
                            if PrimAdm.objects.filter(prn=prn).exists():
                                messages.error(request, 'Registration Number Number Already Exists in Primary Admission')
                                return redirect('admission_rejoin')
                            if adm_from == "Primary":
                                print("fdsb")
                                user.username=str(priAdmGet.stud_id)
                                user.save()
                                priAdmModule=PrimAdm()
                                priAdmModule.prn=prn
                                priAdmModule.lname=priAdmGet.lname
                                priAdmModule.fname=priAdmGet.fname
                                priAdmModule.faname=priAdmGet.faname
                                priAdmModule.moname=priAdmGet.moname
                                priAdmModule.mrname=priAdmGet.mrname
                                priAdmModule.aadhar=priAdmGet.aadhar
                                priAdmModule.saral_id=priAdmGet.saral_id
                                priAdmModule.nationality=priAdmGet.nationality
                                priAdmModule.tongue=priAdmGet.tongue
                                priAdmModule.religion=priAdmGet.religion
                                priAdmModule.cast=priAdmGet.cast
                                priAdmModule.subcast=priAdmGet.subcast
                                priAdmModule.minority=priAdmGet.minority
                                priAdmModule.pob=priAdmGet.pob
                                priAdmModule.dob=priAdmGet.dob
                                priAdmModule.last_school=priAdmGet.last_school
                                priAdmModule.last_class=priAdmGet.last_class
                                priAdmModule.admdate=admdate
                                y=admdate
                                priAdmModule.admyear=y[0:4]
                                priAdmModule.adm_class=adm_class
                                priAdmModule.division=priAdmGet.division
                                priAdmModule.rollno=priAdmGet.rollno
                                priAdmModule.lateadm=priAdmGet.lateadm
                                priAdmModule.admtype=priAdmGet.admtype
                                priAdmModule.hostel=priAdmGet.hostel
                                priAdmModule.sex=priAdmGet.sex
                                priAdmModule.pwd=priAdmGet.pwd
                                priAdmModule.bgroup=priAdmGet.bgroup
                                priAdmModule.fa_mob=priAdmGet.fa_mob
                                priAdmModule.mo_mob=priAdmGet.mo_mob
                                priAdmModule.fa_occu=priAdmGet.fa_occu
                                priAdmModule.mo_occu=priAdmGet.mo_occu
                                priAdmModule.fam_income=priAdmGet.fam_income
                                priAdmModule.bpl=priAdmGet.bpl
                                priAdmModule.gis=priAdmGet.gis
                                priAdmModule.ganame=priAdmGet.ganame
                                priAdmModule.ga_mob=priAdmGet.ga_mob
                                priAdmModule.ga_occu=priAdmGet.ga_occu
                                priAdmModule.gaddress=priAdmGet.gaddress
                                priAdmModule.ga_relation=priAdmGet.ga_relation
                                priAdmModule.email=priAdmGet.email
                                priAdmModule.areaType=priAdmGet.areaType
                                priAdmModule.caddress=priAdmGet.caddress
                                priAdmModule.ca_is_pa_addr=priAdmGet.ca_is_pa_addr
                                priAdmModule.paddress=priAdmGet.paddress
                                priAdmModule.baccount=priAdmGet.baccount
                                priAdmModule.bankname=priAdmGet.bankname
                                priAdmModule.ifsc=priAdmGet.ifsc
                                priAdmModule.branch=priAdmGet.branch
                                priAdmModule.micr=priAdmGet.micr
                                priAdmModule.marks_img=priAdmGet.marks_img
                                priAdmModule.prv_lc_img=priAdmGet.prv_lc_img
                                priAdmModule.addhar_img=priAdmGet.addhar_img
                                priAdmModule.cast_img=priAdmGet.cast_img
                                priAdmModule.castvald_img=priAdmGet.castvald_img
                                priAdmModule.nationality_img=priAdmGet.nationality_img
                                priAdmModule.noncrimy_img=priAdmGet.noncrimy_img
                                priAdmModule.std_img=priAdmGet.std_img
                                priAdmModule.birth_img=priAdmGet.birth_img
                                #for Academics  
                                no=int(adm_class)
                                print(no)
                                if no==1:
                                    priAdmModule.updateclass1 = adm_class
                                    priAdmModule.updateyear1 = y[0:4]
                                    priAdmModule.updatedivision1 = str(priAdmGet.division)
                                    priAdmModule.updaterollno1 = priAdmGet.rollno
                                elif no==2:
                                    priAdmModule.updateclass2 = adm_class
                                    priAdmModule.updateyear2 = y[0:4]
                                    priAdmModule.updatedivision2 = str(priAdmGet.division)
                                    priAdmModule.updaterollno2 = priAdmGet.rollno
                                elif no==3:
                                    priAdmModule.updateclass3 = adm_class
                                    priAdmModule.updateyear3 = y[0:4]
                                    priAdmModule.updatedivision3 = str(priAdmGet.division)
                                    priAdmModule.updaterollno3 = priAdmGet.rollno
                                elif no==4:
                                    priAdmModule.updateclass4 = adm_class
                                    priAdmModule.updateyear4 = y[0:4]
                                    priAdmModule.updatedivision4 = str(priAdmGet.division)
                                    priAdmModule.updaterollno4 = priAdmGet.rollno
                                # Create User for Student
                                user=User.objects.create_user(username=priAdmGet.aadhar,email=priAdmGet.email,password="Admin@123",first_name=priAdmGet.fname,last_name=priAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                priAdmModule.stud_id="p"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                #priAdmModule.u_ref_student=User.objects.get(username=priAdmGet.cleaned_data['aadhar'])
                                priAdmModule.user=user
                                # priAdmModule.lcgenerated=False
                                priAdmModule.save()
                                #for Adademic table
                                # priacd=PrimAcademic()
                                # priacd.prim_admission=priAdmModule
                                # priacd.save()
                                messages.success(request, priAdmGet.fname+" "+priAdmGet.faname +" "+ priAdmGet.lname +' Student Admitted Sucessfully!')
                                return redirect('admission_primlist')
                        # for secondary                            
                        elif adm_for=="Secondary":
                        #     p to s  
                            if SecondAdm.objects.filter(prn=prn).exists():
                                messages.error(request, 'Registration Number Number Already Exists in Secondary Admission')
                                return redirect('admission_rejoin')
                            if adm_from == "Primary":
                                user.username=str(priAdmGet.stud_id)
                                user.save()
                                secAdmModule=SecondAdm()
                                secAdmModule.prn=prn
                                secAdmModule.lname=priAdmGet.lname
                                secAdmModule.fname=priAdmGet.fname
                                secAdmModule.faname=priAdmGet.faname
                                secAdmModule.moname=priAdmGet.moname
                                secAdmModule.mrname=priAdmGet.mrname
                                secAdmModule.aadhar=priAdmGet.aadhar
                                secAdmModule.saral_id=priAdmGet.saral_id
                                secAdmModule.nationality=priAdmGet.nationality
                                secAdmModule.tongue=priAdmGet.tongue
                                secAdmModule.religion=priAdmGet.religion
                                secAdmModule.cast=priAdmGet.cast
                                secAdmModule.subcast=priAdmGet.subcast
                                secAdmModule.minority=priAdmGet.minority
                                secAdmModule.pob=priAdmGet.pob
                                secAdmModule.dob=priAdmGet.dob
                                secAdmModule.last_school=priAdmGet.last_school
                                secAdmModule.last_class=priAdmGet.last_class
                                secAdmModule.admdate=admdate
                                y=admdate
                                secAdmModule.admyear=y[0:4]
                                secAdmModule.adm_class=adm_class
                                secAdmModule.division=priAdmGet.division
                                secAdmModule.rollno=priAdmGet.rollno
                                secAdmModule.lateadm=priAdmGet.lateadm
                                secAdmModule.admtype=priAdmGet.admtype
                                secAdmModule.hostel=priAdmGet.hostel
                                secAdmModule.sex=priAdmGet.sex
                                secAdmModule.pwd=priAdmGet.pwd
                                secAdmModule.bgroup=priAdmGet.bgroup
                                secAdmModule.fa_mob=priAdmGet.fa_mob
                                secAdmModule.mo_mob=priAdmGet.mo_mob
                                secAdmModule.fa_occu=priAdmGet.fa_occu
                                secAdmModule.mo_occu=priAdmGet.mo_occu
                                secAdmModule.fam_income=priAdmGet.fam_income
                                secAdmModule.bpl=priAdmGet.bpl
                                secAdmModule.gis=priAdmGet.gis
                                secAdmModule.ganame=priAdmGet.ganame
                                secAdmModule.ga_mob=priAdmGet.ga_mob
                                secAdmModule.ga_occu=priAdmGet.ga_occu
                                secAdmModule.gaddress=priAdmGet.gaddress
                                secAdmModule.ga_relation=priAdmGet.ga_relation
                                secAdmModule.email=priAdmGet.email
                                secAdmModule.areaType=priAdmGet.areaType
                                secAdmModule.caddress=priAdmGet.caddress
                                secAdmModule.ca_is_pa_addr=priAdmGet.ca_is_pa_addr
                                secAdmModule.paddress=priAdmGet.paddress
                                secAdmModule.baccount=priAdmGet.baccount
                                secAdmModule.bankname=priAdmGet.bankname
                                secAdmModule.ifsc=priAdmGet.ifsc
                                secAdmModule.branch=priAdmGet.branch
                                secAdmModule.micr=priAdmGet.micr
                                secAdmModule.marks_img=priAdmGet.marks_img
                                secAdmModule.prv_lc_img=priAdmGet.prv_lc_img
                                secAdmModule.addhar_img=priAdmGet.addhar_img
                                secAdmModule.cast_img=priAdmGet.cast_img
                                secAdmModule.castvald_img=priAdmGet.castvald_img
                                secAdmModule.nationality_img=priAdmGet.nationality_img
                                secAdmModule.noncrimy_img=priAdmGet.noncrimy_img
                                secAdmModule.std_img=priAdmGet.std_img
                                secAdmModule.birth_img=priAdmGet.birth_img
                                #for Academics  
                                no=int(adm_class)
                                print(no)
                                if no==5:
                                    secAdmModule.updateclass5 = adm_class
                                    secAdmModule.updateyear5 = y[0:4]
                                    secAdmModule.updatedivision5 = str(priAdmGet.division)
                                    secAdmModule.updaterollno5 = priAdmGet.rollno
                                elif no==6:
                                    secAdmModule.updateclass6 = adm_class
                                    secAdmModule.updateyear6 = y[0:4]
                                    secAdmModule.updatedivision6 = str(priAdmGet.division)
                                    secAdmModule.updaterollno6 = priAdmGet.rollno
                                elif no==7:
                                    secAdmModule.updateclass7 = adm_class
                                    secAdmModule.updateyear7 = y[0:4]
                                    secAdmModule.updatedivision7 = str(priAdmGet.division)
                                    secAdmModule.updaterollno7 = priAdmGet.rollno
                                elif no==8:
                                    secAdmModule.updateclass8 = adm_class
                                    secAdmModule.updateyear8 = y[0:4]
                                    secAdmModule.updatedivision8 = str(priAdmGet.division)
                                    secAdmModule.updaterollno8 = priAdmGet.rollno
                                elif no==9:
                                    secAdmModule.updateclass9 = adm_class
                                    secAdmModule.updateyear9 = y[0:4]
                                    secAdmModule.updatedivision9 = str(priAdmGet.division)
                                    secAdmModule.updaterollno9 = priAdmGet.rollno
                                elif no==10:
                                    secAdmModule.updateclass10 = adm_class
                                    secAdmModule.updateyear10 = y[0:4]
                                    secAdmModule.updatedivision10 = str(priAdmGet.division)
                                    secAdmModule.updaterollno10 = priAdmGet.rollno    
                                # Create User for Student
                                user=User.objects.create_user(username=priAdmGet.aadhar,email=priAdmGet.email,password="Admin@123",first_name=priAdmGet.fname,last_name=priAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                secAdmModule.stud_id="s"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                #secAdmModule.u_ref_student=User.objects.get(username=priAdmGet.cleaned_data['aadhar'])
                                secAdmModule.user=user
                                # secAdmModule.lcgenerated=False
                                secAdmModule.save()
                                #for Adademic table
                                # secacd=PrimAcademic()
                                # secacd.sec_admission=secAdmModule
                                # secacd.save()
                                messages.success(request, priAdmGet.fname+" "+priAdmGet.faname +" "+ priAdmGet.lname +' Student Admitted Sucessfully!')
                                return redirect('admission_seclist')
                            elif adm_from=="Secondary":
                                # s to s
                                user.username=str(secAdmGet.stud_id)
                                user.save()
                                secAdmModule=SecondAdm()
                                secAdmModule.prn=prn
                                secAdmModule.lname=secAdmGet.lname
                                secAdmModule.fname=secAdmGet.fname
                                secAdmModule.faname=secAdmGet.faname
                                secAdmModule.moname=secAdmGet.moname
                                secAdmModule.mrname=secAdmGet.mrname
                                secAdmModule.aadhar=secAdmGet.aadhar
                                secAdmModule.saral_id=secAdmGet.saral_id
                                secAdmModule.nationality=secAdmGet.nationality
                                secAdmModule.tongue=secAdmGet.tongue
                                secAdmModule.religion=secAdmGet.religion
                                secAdmModule.cast=secAdmGet.cast
                                secAdmModule.subcast=secAdmGet.subcast
                                secAdmModule.minority=secAdmGet.minority
                                secAdmModule.pob=secAdmGet.pob
                                secAdmModule.dob=secAdmGet.dob
                                secAdmModule.last_school=secAdmGet.last_school
                                secAdmModule.last_class=secAdmGet.last_class
                                secAdmModule.admdate=admdate
                                y=admdate                 
                                secAdmModule.admyear=y[0:4]
                                secAdmModule.adm_class=adm_class
                                secAdmModule.division=secAdmGet.division
                                secAdmModule.rollno=secAdmGet.rollno
                                secAdmModule.lateadm=secAdmGet.lateadm
                                secAdmModule.admtype=secAdmGet.admtype
                                secAdmModule.hostel=secAdmGet.hostel
                                secAdmModule.sex=secAdmGet.sex
                                secAdmModule.pwd=secAdmGet.pwd
                                secAdmModule.bgroup=secAdmGet.bgroup
                                secAdmModule.fa_mob=secAdmGet.fa_mob
                                secAdmModule.mo_mob=secAdmGet.mo_mob
                                secAdmModule.fa_occu=secAdmGet.fa_occu
                                secAdmModule.mo_occu=secAdmGet.mo_occu
                                secAdmModule.fam_income=secAdmGet.fam_income
                                secAdmModule.bpl=secAdmGet.bpl
                                secAdmModule.gis=secAdmGet.gis
                                secAdmModule.ganame=secAdmGet.ganame
                                secAdmModule.ga_mob=secAdmGet.ga_mob
                                secAdmModule.ga_occu=secAdmGet.ga_occu
                                secAdmModule.gaddress=secAdmGet.gaddress
                                secAdmModule.ga_relation=secAdmGet.ga_relation
                                secAdmModule.email=secAdmGet.email
                                secAdmModule.areaType=secAdmGet.areaType
                                secAdmModule.caddress=secAdmGet.caddress
                                secAdmModule.ca_is_pa_addr=secAdmGet.ca_is_pa_addr
                                secAdmModule.paddress=secAdmGet.paddress
                                secAdmModule.baccount=secAdmGet.baccount
                                secAdmModule.bankname=secAdmGet.bankname
                                secAdmModule.ifsc=secAdmGet.ifsc
                                secAdmModule.branch=secAdmGet.branch
                                secAdmModule.micr=secAdmGet.micr
                                secAdmModule.marks_img=secAdmGet.marks_img
                                secAdmModule.prv_lc_img=secAdmGet.prv_lc_img
                                secAdmModule.addhar_img=secAdmGet.addhar_img
                                secAdmModule.cast_img=secAdmGet.cast_img
                                secAdmModule.castvald_img=secAdmGet.castvald_img
                                secAdmModule.nationality_img=secAdmGet.nationality_img
                                secAdmModule.noncrimy_img=secAdmGet.noncrimy_img
                                secAdmModule.std_img=secAdmGet.std_img
                                secAdmModule.birth_img=secAdmGet.birth_img
                                #for Academics  
                                no=int(adm_class)
                                print(no)
                                if no==5:
                                    secAdmModule.updateclass5 = adm_class
                                    secAdmModule.updateyear5 = y[0:4]
                                    secAdmModule.updatedivision5 = str(secAdmGet.division)
                                    secAdmModule.updaterollno5 = secAdmGet.rollno
                                elif no==6:
                                    secAdmModule.updateclass6 = adm_class
                                    secAdmModule.updateyear6 = y[0:4]
                                    secAdmModule.updatedivision6 = str(secAdmGet.division)
                                    secAdmModule.updaterollno6 = secAdmGet.rollno
                                elif no==7:
                                    secAdmModule.updateclass7 = adm_class
                                    secAdmModule.updateyear7 = y[0:4]
                                    secAdmModule.updatedivision7 = str(secAdmGet.division)
                                    secAdmModule.updaterollno7 = secAdmGet.rollno
                                elif no==8:
                                    secAdmModule.updateclass8 = adm_class
                                    secAdmModule.updateyear8 = y[0:4]
                                    secAdmModule.updatedivision8 = str(secAdmGet.division)
                                    secAdmModule.updaterollno8 = secAdmGet.rollno
                                elif no==9:
                                    secAdmModule.updateclass9 = adm_class
                                    secAdmModule.updateyear9 = y[0:4]
                                    secAdmModule.updatedivision9 = str(secAdmGet.division)
                                    secAdmModule.updaterollno9 = secAdmGet.rollno
                                elif no==10:
                                    secAdmModule.updateclass10 = adm_class
                                    secAdmModule.updateyear10 = y[0:4]
                                    secAdmModule.updatedivision10 = str(secAdmGet.division)
                                    secAdmModule.updaterollno10 = secAdmGet.rollno
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=secAdmGet.aadhar,email=secAdmGet.email,password="Admin@123",first_name=secAdmGet.fname,last_name=secAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                secAdmModule.stud_id="s"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                secAdmModule.user=user
                                secAdmModule.save()
                                #for Adademic table
                                # secacd=PrimAcademic()
                                # secacd.sec_admission=secAdmModule
                                # secacd.save()
                                messages.success(request, secAdmGet.fname+" "+secAdmGet.faname+" "+secAdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_seclist')
                        elif adm_for=="Jr.College":
                        #     c to c , p to c , s to c ,atkt11 to c , f1710 to c
                            if CollegeAdm.objects.filter(prn=prn).exists():
                                messages.error(request, 'Registration Number Number Already Exists in Jr.College Admission')
                                return redirect('admission_rejoin')
                            if adm_from == "Primary":
                                user.username=str(priAdmGet.stud_id)
                                user.save()
                                colAdmModule=CollegeAdm()
                                colAdmModule.prn=prn
                                colAdmModule.lname=priAdmGet.lname
                                colAdmModule.fname=priAdmGet.fname
                                colAdmModule.faname=priAdmGet.faname
                                colAdmModule.moname=priAdmGet.moname
                                colAdmModule.mrname=priAdmGet.mrname
                                colAdmModule.aadhar=priAdmGet.aadhar
                                colAdmModule.saral_id=priAdmGet.saral_id
                                colAdmModule.nationality=priAdmGet.nationality
                                colAdmModule.tongue=priAdmGet.tongue
                                colAdmModule.religion=priAdmGet.religion
                                colAdmModule.cast=priAdmGet.cast
                                colAdmModule.subcast=priAdmGet.subcast
                                colAdmModule.minority=priAdmGet.minority
                                colAdmModule.pob=priAdmGet.pob
                                colAdmModule.dob=priAdmGet.dob
                                colAdmModule.last_school=priAdmGet.last_school
                                colAdmModule.last_class=priAdmGet.last_class
                                colAdmModule.admdate=admdate
                                y=admdate
                                colAdmModule.admyear=y[0:4]
                                colAdmModule.adm_class=adm_class
                                colAdmModule.admission_faculty=admission_faculty
                                colAdmModule.division=priAdmGet.division
                                colAdmModule.rollno=priAdmGet.rollno
                                colAdmModule.lateadm=priAdmGet.lateadm
                                colAdmModule.admtype=priAdmGet.admtype
                                colAdmModule.hostel=priAdmGet.hostel
                                colAdmModule.sex=priAdmGet.sex
                                colAdmModule.pwd=priAdmGet.pwd
                                colAdmModule.bgroup=priAdmGet.bgroup
                                colAdmModule.fa_mob=priAdmGet.fa_mob
                                colAdmModule.mo_mob=priAdmGet.mo_mob
                                colAdmModule.fa_occu=priAdmGet.fa_occu
                                colAdmModule.mo_occu=priAdmGet.mo_occu
                                colAdmModule.fam_income=priAdmGet.fam_income
                                colAdmModule.bpl=priAdmGet.bpl
                                colAdmModule.gis=priAdmGet.gis
                                colAdmModule.ganame=priAdmGet.ganame
                                colAdmModule.ga_mob=priAdmGet.ga_mob
                                colAdmModule.ga_occu=priAdmGet.ga_occu
                                colAdmModule.gaddress=priAdmGet.gaddress
                                colAdmModule.ga_relation=priAdmGet.ga_relation
                                colAdmModule.email=priAdmGet.email
                                colAdmModule.areaType=priAdmGet.areaType
                                colAdmModule.caddress=priAdmGet.caddress
                                colAdmModule.ca_is_pa_addr=priAdmGet.ca_is_pa_addr
                                colAdmModule.paddress=priAdmGet.paddress
                                colAdmModule.baccount=priAdmGet.baccount
                                colAdmModule.bankname=priAdmGet.bankname
                                colAdmModule.ifsc=priAdmGet.ifsc
                                colAdmModule.branch=priAdmGet.branch
                                colAdmModule.micr=priAdmGet.micr
                                colAdmModule.marks_img=priAdmGet.marks_img
                                colAdmModule.prv_lc_img=priAdmGet.prv_lc_img
                                colAdmModule.addhar_img=priAdmGet.addhar_img
                                colAdmModule.cast_img=priAdmGet.cast_img
                                colAdmModule.castvald_img=priAdmGet.castvald_img
                                colAdmModule.nationality_img=priAdmGet.nationality_img
                                colAdmModule.noncrimy_img=priAdmGet.noncrimy_img
                                colAdmModule.std_img=priAdmGet.std_img
                                colAdmModule.birth_img=priAdmGet.birth_img
                                #for Academics  
                                no=int(adm_class)
                                print(no)
                                if no==11:
                                    colAdmModule.updateclass11 = adm_class
                                    colAdmModule.updatestream11 = admission_faculty
                                    colAdmModule.updateyear11 = y[0:4]
                                    colAdmModule.updatedivision11 = str(priAdmGet.division)
                                    colAdmModule.updaterollno11 = priAdmGet.rollno
                                elif no==12:
                                    colAdmModule.updateclass12 = adm_class
                                    colAdmModule.updatestream12 = admission_faculty
                                    colAdmModule.updateyear12 = y[0:4]
                                    colAdmModule.updatedivision12 = str(priAdmGet.division)
                                    colAdmModule.updaterollno12 = priAdmGet.rollno
                                # Create User for Student
                                user=User.objects.create_user(username=priAdmGet.aadhar,email=priAdmGet.email,password="Admin@123",first_name=priAdmGet.fname,last_name=priAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                colAdmModule.stud_id="c"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                #colAdmModule.u_ref_student=User.objects.get(username=priAdmGet.cleaned_data['aadhar'])
                                colAdmModule.user=user
                                # colAdmModule.lcgenerated=False
                                colAdmModule.save()
                                #for Adademic table
                                # colacd=ColAcademic()
                                # colacd.col_admission=colAdmModule
                                # colacd.save()
                                messages.success(request, priAdmGet.fname+" "+priAdmGet.faname +" "+ priAdmGet.lname +' Student Admitted Sucessfully!')
                                return redirect('admission_collist')
                            elif adm_from == "Secondary":
                                user.username=str(secAdmGet.stud_id)
                                user.save()
                                colAdmModule=CollegeAdm()
                                colAdmModule.prn=prn
                                colAdmModule.lname=secAdmGet.lname
                                colAdmModule.fname=secAdmGet.fname
                                colAdmModule.faname=secAdmGet.faname
                                colAdmModule.moname=secAdmGet.moname
                                colAdmModule.mrname=secAdmGet.mrname
                                colAdmModule.aadhar=secAdmGet.aadhar
                                colAdmModule.saral_id=secAdmGet.saral_id
                                colAdmModule.nationality=secAdmGet.nationality
                                colAdmModule.tongue=secAdmGet.tongue
                                colAdmModule.religion=secAdmGet.religion
                                colAdmModule.cast=secAdmGet.cast
                                colAdmModule.subcast=secAdmGet.subcast
                                colAdmModule.minority=secAdmGet.minority
                                colAdmModule.pob=secAdmGet.pob
                                colAdmModule.dob=secAdmGet.dob
                                colAdmModule.last_school=secAdmGet.last_school
                                colAdmModule.last_class=secAdmGet.last_class
                                colAdmModule.admdate=admdate
                                y=admdate                 
                                colAdmModule.admyear=y[0:4]
                                colAdmModule.adm_class=adm_class
                                colAdmModule.admission_faculty=admission_faculty
                                colAdmModule.division=secAdmGet.division
                                colAdmModule.rollno=secAdmGet.rollno
                                colAdmModule.lateadm=secAdmGet.lateadm
                                colAdmModule.admtype=secAdmGet.admtype
                                colAdmModule.hostel=secAdmGet.hostel
                                colAdmModule.sex=secAdmGet.sex
                                colAdmModule.pwd=secAdmGet.pwd
                                colAdmModule.bgroup=secAdmGet.bgroup
                                colAdmModule.fa_mob=secAdmGet.fa_mob
                                colAdmModule.mo_mob=secAdmGet.mo_mob
                                colAdmModule.fa_occu=secAdmGet.fa_occu
                                colAdmModule.mo_occu=secAdmGet.mo_occu
                                colAdmModule.fam_income=secAdmGet.fam_income
                                colAdmModule.bpl=secAdmGet.bpl
                                colAdmModule.gis=secAdmGet.gis
                                colAdmModule.ganame=secAdmGet.ganame
                                colAdmModule.ga_mob=secAdmGet.ga_mob
                                colAdmModule.ga_occu=secAdmGet.ga_occu
                                colAdmModule.gaddress=secAdmGet.gaddress
                                colAdmModule.ga_relation=secAdmGet.ga_relation
                                colAdmModule.email=secAdmGet.email
                                colAdmModule.areaType=secAdmGet.areaType
                                colAdmModule.caddress=secAdmGet.caddress
                                colAdmModule.ca_is_pa_addr=secAdmGet.ca_is_pa_addr
                                colAdmModule.paddress=secAdmGet.paddress
                                colAdmModule.baccount=secAdmGet.baccount
                                colAdmModule.bankname=secAdmGet.bankname
                                colAdmModule.ifsc=secAdmGet.ifsc
                                colAdmModule.branch=secAdmGet.branch
                                colAdmModule.micr=secAdmGet.micr
                                colAdmModule.marks_img=secAdmGet.marks_img
                                colAdmModule.prv_lc_img=secAdmGet.prv_lc_img
                                colAdmModule.addhar_img=secAdmGet.addhar_img
                                colAdmModule.cast_img=secAdmGet.cast_img
                                colAdmModule.castvald_img=secAdmGet.castvald_img
                                colAdmModule.nationality_img=secAdmGet.nationality_img
                                colAdmModule.noncrimy_img=secAdmGet.noncrimy_img
                                colAdmModule.std_img=secAdmGet.std_img
                                colAdmModule.birth_img=secAdmGet.birth_img
                                #for Academics  
                                no=int(adm_class)
                                print(no)
                                if no==11:
                                    colAdmModule.updateclass11 = adm_class
                                    colAdmModule.updatestream11 = admission_faculty
                                    colAdmModule.updateyear11 = y[0:4]
                                    colAdmModule.updatedivision11 = str(secAdmGet.division)
                                    colAdmModule.updaterollno11 = secAdmGet.rollno
                                elif no==12:
                                    colAdmModule.updateclass12 = adm_class
                                    colAdmModule.updatestream12 = admission_faculty
                                    colAdmModule.updateyear12 = y[0:4]
                                    colAdmModule.updatedivision12 = str(secAdmGet.division)
                                    colAdmModule.updaterollno12 = secAdmGet.rollno
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=secAdmGet.aadhar,email=secAdmGet.email,password="Admin@123",first_name=secAdmGet.fname,last_name=secAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                colAdmModule.stud_id="c"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                colAdmModule.user=user
                                colAdmModule.save()
                                #for Adademic table
                                # colacd=ColAcademic()
                                # colacd.col_admission=colAdmModule
                                # colacd.save()
                                messages.success(request, secAdmGet.fname+" "+secAdmGet.faname+" "+secAdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_collist')
                            elif adm_from=="Jr.College":
                                user.username=str(colAdmGet.stud_id)
                                user.save()
                                colAdmModule=CollegeAdm()
                                colAdmModule.prn=prn
                                colAdmModule.lname=colAdmGet.lname
                                colAdmModule.fname=colAdmGet.fname
                                colAdmModule.faname=colAdmGet.faname
                                colAdmModule.moname=colAdmGet.moname
                                colAdmModule.mrname=colAdmGet.mrname
                                colAdmModule.aadhar=colAdmGet.aadhar
                                colAdmModule.saral_id=colAdmGet.saral_id
                                colAdmModule.nationality=colAdmGet.nationality
                                colAdmModule.tongue=colAdmGet.tongue
                                colAdmModule.religion=colAdmGet.religion
                                colAdmModule.cast=colAdmGet.cast
                                colAdmModule.subcast=colAdmGet.subcast
                                colAdmModule.minority=colAdmGet.minority
                                colAdmModule.pob=colAdmGet.pob
                                colAdmModule.dob=colAdmGet.dob
                                colAdmModule.last_school=colAdmGet.last_school
                                colAdmModule.last_class=colAdmGet.last_class
                                colAdmModule.admdate=admdate
                                y=admdate                 
                                colAdmModule.admyear=y[0:4]
                                colAdmModule.adm_class=adm_class
                                colAdmModule.admission_faculty=admission_faculty
                                colAdmModule.division=colAdmGet.division
                                colAdmModule.rollno=colAdmGet.rollno
                                colAdmModule.lateadm=colAdmGet.lateadm
                                colAdmModule.admtype=colAdmGet.admtype
                                colAdmModule.hostel=colAdmGet.hostel
                                colAdmModule.sex=colAdmGet.sex
                                colAdmModule.pwd=colAdmGet.pwd
                                colAdmModule.bgroup=colAdmGet.bgroup
                                colAdmModule.fa_mob=colAdmGet.fa_mob
                                colAdmModule.mo_mob=colAdmGet.mo_mob
                                colAdmModule.fa_occu=colAdmGet.fa_occu
                                colAdmModule.mo_occu=colAdmGet.mo_occu
                                colAdmModule.fam_income=colAdmGet.fam_income
                                colAdmModule.bpl=colAdmGet.bpl
                                colAdmModule.gis=colAdmGet.gis
                                colAdmModule.ganame=colAdmGet.ganame
                                colAdmModule.ga_mob=colAdmGet.ga_mob
                                colAdmModule.ga_occu=colAdmGet.ga_occu
                                colAdmModule.gaddress=colAdmGet.gaddress
                                colAdmModule.ga_relation=colAdmGet.ga_relation
                                colAdmModule.email=colAdmGet.email
                                colAdmModule.areaType=colAdmGet.areaType
                                colAdmModule.caddress=colAdmGet.caddress
                                colAdmModule.ca_is_pa_addr=colAdmGet.ca_is_pa_addr
                                colAdmModule.paddress=colAdmGet.paddress
                                colAdmModule.baccount=colAdmGet.baccount
                                colAdmModule.bankname=colAdmGet.bankname
                                colAdmModule.ifsc=colAdmGet.ifsc
                                colAdmModule.branch=colAdmGet.branch
                                colAdmModule.micr=colAdmGet.micr
                                colAdmModule.marks_img=colAdmGet.marks_img
                                colAdmModule.prv_lc_img=colAdmGet.prv_lc_img
                                colAdmModule.addhar_img=colAdmGet.addhar_img
                                colAdmModule.cast_img=colAdmGet.cast_img
                                colAdmModule.castvald_img=colAdmGet.castvald_img
                                colAdmModule.nationality_img=colAdmGet.nationality_img
                                colAdmModule.noncrimy_img=colAdmGet.noncrimy_img
                                colAdmModule.std_img=colAdmGet.std_img
                                colAdmModule.birth_img=colAdmGet.birth_img
                                #for Academics  
                                no=int(adm_class)
                                print(no)
                                if no==11:
                                    colAdmModule.updateclass11 = adm_class
                                    colAdmModule.updatestream11 = admission_faculty
                                    colAdmModule.updateyear11 = y[0:4]
                                    colAdmModule.updatedivision11 = str(colAdmGet.division)
                                    colAdmModule.updaterollno11 = colAdmGet.rollno
                                elif no==12:
                                    colAdmModule.updateclass12 = adm_class
                                    colAdmModule.updatestream12 = admission_faculty
                                    colAdmModule.updateyear12 = y[0:4]
                                    colAdmModule.updatedivision12 = str(colAdmGet.division)
                                    colAdmModule.updaterollno12 = colAdmGet.rollno
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=colAdmGet.aadhar,email=colAdmGet.email,password="Admin@123",first_name=colAdmGet.fname,last_name=colAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                colAdmModule.stud_id="c"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                colAdmModule.user=user
                                # colAdmModule.lcgenerated=False
                                colAdmModule.save()
                                #for Adademic table
                                # colacd=ColAcademic()
                                # colacd.col_admission=colAdmModule
                                # colacd.save()
                                messages.success(request, colAdmGet.fname+" "+colAdmGet.faname+" "+colAdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_collist')
                            elif adm_from=="Form1710":
                                user.username=str(form1710AdmGet.stud_id)
                                user.save()
                                colAdmModule=CollegeAdm()
                                colAdmModule.prn=prn
                                colAdmModule.lname=form1710AdmGet.lname
                                colAdmModule.fname=form1710AdmGet.fname
                                colAdmModule.faname=form1710AdmGet.faname
                                colAdmModule.moname=form1710AdmGet.moname
                                colAdmModule.mrname=form1710AdmGet.mrname
                                colAdmModule.aadhar=form1710AdmGet.aadhar
                                colAdmModule.saral_id=form1710AdmGet.saral_id
                                colAdmModule.nationality=form1710AdmGet.nationality
                                colAdmModule.tongue=form1710AdmGet.tongue
                                colAdmModule.religion=form1710AdmGet.religion
                                colAdmModule.cast=form1710AdmGet.cast
                                colAdmModule.subcast=form1710AdmGet.subcast
                                colAdmModule.minority=form1710AdmGet.minority
                                colAdmModule.pob=form1710AdmGet.pob
                                colAdmModule.dob=form1710AdmGet.dob
                                colAdmModule.last_school=form1710AdmGet.last_school
                                colAdmModule.last_class=form1710AdmGet.last_class
                                colAdmModule.admdate=admdate
                                y=admdate                 
                                colAdmModule.admyear=y[0:4]
                                colAdmModule.adm_class=adm_class
                                colAdmModule.admission_faculty=admission_faculty
                                colAdmModule.rollno=form1710AdmGet.rollno
                                colAdmModule.lateadm=form1710AdmGet.lateadm
                                colAdmModule.admtype=form1710AdmGet.admtype
                                colAdmModule.hostel=form1710AdmGet.hostel
                                colAdmModule.sex=form1710AdmGet.sex
                                colAdmModule.pwd=form1710AdmGet.pwd
                                colAdmModule.bgroup=form1710AdmGet.bgroup
                                colAdmModule.fa_mob=form1710AdmGet.fa_mob
                                colAdmModule.mo_mob=form1710AdmGet.mo_mob
                                colAdmModule.fa_occu=form1710AdmGet.fa_occu
                                colAdmModule.mo_occu=form1710AdmGet.mo_occu
                                colAdmModule.fam_income=form1710AdmGet.fam_income
                                colAdmModule.bpl=form1710AdmGet.bpl
                                colAdmModule.gis=form1710AdmGet.gis
                                colAdmModule.ganame=form1710AdmGet.ganame
                                colAdmModule.ga_mob=form1710AdmGet.ga_mob
                                colAdmModule.ga_occu=form1710AdmGet.ga_occu
                                colAdmModule.gaddress=form1710AdmGet.gaddress
                                colAdmModule.ga_relation=form1710AdmGet.ga_relation
                                colAdmModule.email=form1710AdmGet.email
                                colAdmModule.areaType=form1710AdmGet.areaType
                                colAdmModule.caddress=form1710AdmGet.caddress
                                colAdmModule.ca_is_pa_addr=form1710AdmGet.ca_is_pa_addr
                                colAdmModule.paddress=form1710AdmGet.paddress
                                colAdmModule.baccount=form1710AdmGet.baccount
                                colAdmModule.bankname=form1710AdmGet.bankname
                                colAdmModule.ifsc=form1710AdmGet.ifsc
                                colAdmModule.branch=form1710AdmGet.branch
                                colAdmModule.micr=form1710AdmGet.micr
                                colAdmModule.marks_img=form1710AdmGet.marks_img
                                colAdmModule.prv_lc_img=form1710AdmGet.prv_lc_img
                                colAdmModule.addhar_img=form1710AdmGet.addhar_img
                                colAdmModule.cast_img=form1710AdmGet.cast_img
                                colAdmModule.castvald_img=form1710AdmGet.castvald_img
                                colAdmModule.nationality_img=form1710AdmGet.nationality_img
                                colAdmModule.noncrimy_img=form1710AdmGet.noncrimy_img
                                colAdmModule.std_img=form1710AdmGet.std_img
                                colAdmModule.birth_img=form1710AdmGet.birth_img
                                #for Academics  
                                no=int(adm_class)
                                print(no)
                                if no==11:
                                    colAdmModule.updateclass11 = adm_class
                                    colAdmModule.updatestream11 = admission_faculty
                                    colAdmModule.updateyear11 = y[0:4]
                                    colAdmModule.updaterollno11 = form1710AdmGet.rollno
                                elif no==12:
                                    colAdmModule.updateclass12 = adm_class
                                    colAdmModule.updatestream12 = admission_faculty
                                    colAdmModule.updateyear12 = y[0:4]
                                    colAdmModule.updaterollno12 = form1710AdmGet.rollno
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=form1710AdmGet.aadhar,email=form1710AdmGet.email,password="Admin@123",first_name=form1710AdmGet.fname,last_name=form1710AdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                colAdmModule.stud_id="c"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                colAdmModule.user=user
                                # colAdmModule.lcgenerated=False
                                colAdmModule.save()
                                #for Adademic table
                                # colacd=ColAcademic()
                                # colacd.col_admission=colAdmModule
                                # colacd.save()
                                messages.success(request, form1710AdmGet.fname+" "+form1710AdmGet.faname+" "+form1710AdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_collist')
                            elif adm_from=="11-ATKT":
                                user.username=str(atkt11AdmGet.stud_id)
                                user.save()
                                colAdmModule=CollegeAdm()
                                colAdmModule.prn=prn
                                colAdmModule.lname=atkt11AdmGet.lname
                                colAdmModule.fname=atkt11AdmGet.fname
                                colAdmModule.faname=atkt11AdmGet.faname
                                colAdmModule.moname=atkt11AdmGet.moname
                                colAdmModule.mrname=atkt11AdmGet.mrname
                                colAdmModule.aadhar=atkt11AdmGet.aadhar
                                colAdmModule.saral_id=atkt11AdmGet.saral_id
                                colAdmModule.nationality=atkt11AdmGet.nationality
                                colAdmModule.tongue=atkt11AdmGet.tongue
                                colAdmModule.religion=atkt11AdmGet.religion
                                colAdmModule.cast=atkt11AdmGet.cast
                                colAdmModule.subcast=atkt11AdmGet.subcast
                                colAdmModule.minority=atkt11AdmGet.minority
                                colAdmModule.pob=atkt11AdmGet.pob
                                colAdmModule.dob=atkt11AdmGet.dob
                                colAdmModule.last_school=atkt11AdmGet.last_school
                                colAdmModule.last_class=atkt11AdmGet.last_class
                                colAdmModule.admdate=admdate
                                y=admdate                 
                                colAdmModule.admyear=y[0:4]
                                colAdmModule.adm_class="12"
                                colAdmModule.admission_faculty=admission_faculty
                                colAdmModule.division=atkt11AdmGet.division
                                colAdmModule.rollno=atkt11AdmGet.rollno
                                colAdmModule.lateadm=atkt11AdmGet.lateadm
                                colAdmModule.admtype=atkt11AdmGet.admtype
                                colAdmModule.hostel=atkt11AdmGet.hostel
                                colAdmModule.sex=atkt11AdmGet.sex
                                colAdmModule.pwd=atkt11AdmGet.pwd
                                colAdmModule.bgroup=atkt11AdmGet.bgroup
                                colAdmModule.fa_mob=atkt11AdmGet.fa_mob
                                colAdmModule.mo_mob=atkt11AdmGet.mo_mob
                                colAdmModule.fa_occu=atkt11AdmGet.fa_occu
                                colAdmModule.mo_occu=atkt11AdmGet.mo_occu
                                colAdmModule.fam_income=atkt11AdmGet.fam_income
                                colAdmModule.bpl=atkt11AdmGet.bpl
                                colAdmModule.gis=atkt11AdmGet.gis
                                colAdmModule.ganame=atkt11AdmGet.ganame
                                colAdmModule.ga_mob=atkt11AdmGet.ga_mob
                                colAdmModule.ga_occu=atkt11AdmGet.ga_occu
                                colAdmModule.gaddress=atkt11AdmGet.gaddress
                                colAdmModule.ga_relation=atkt11AdmGet.ga_relation
                                colAdmModule.email=atkt11AdmGet.email
                                colAdmModule.areaType=atkt11AdmGet.areaType
                                colAdmModule.caddress=atkt11AdmGet.caddress
                                colAdmModule.ca_is_pa_addr=atkt11AdmGet.ca_is_pa_addr
                                colAdmModule.paddress=atkt11AdmGet.paddress
                                colAdmModule.baccount=atkt11AdmGet.baccount
                                colAdmModule.bankname=atkt11AdmGet.bankname
                                colAdmModule.ifsc=atkt11AdmGet.ifsc
                                colAdmModule.branch=atkt11AdmGet.branch
                                colAdmModule.micr=atkt11AdmGet.micr
                                colAdmModule.marks_img=atkt11AdmGet.marks_img
                                colAdmModule.prv_lc_img=atkt11AdmGet.prv_lc_img
                                colAdmModule.addhar_img=atkt11AdmGet.addhar_img
                                colAdmModule.cast_img=atkt11AdmGet.cast_img
                                colAdmModule.castvald_img=atkt11AdmGet.castvald_img
                                colAdmModule.nationality_img=atkt11AdmGet.nationality_img
                                colAdmModule.noncrimy_img=atkt11AdmGet.noncrimy_img
                                colAdmModule.std_img=atkt11AdmGet.std_img
                                colAdmModule.birth_img=atkt11AdmGet.birth_img
                                #for Academics  
                                no=int(adm_class)
                                print(no)
                                if no==11:
                                    colAdmModule.updateclass11 = adm_class
                                    colAdmModule.updatestream11 = admission_faculty
                                    colAdmModule.updateyear11 = y[0:4]
                                    colAdmModule.updatedivision11 = str(atkt11AdmGet.division)
                                    colAdmModule.updaterollno11 = atkt11AdmGet.rollno
                                elif no==12:
                                    colAdmModule.updateclass12 = adm_class
                                    colAdmModule.updatestream12 = admission_faculty
                                    colAdmModule.updateyear12 = y[0:4]
                                    colAdmModule.updatedivision12 = str(atkt11AdmGet.division)
                                    colAdmModule.updaterollno12 = atkt11AdmGet.rollno
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=atkt11AdmGet.aadhar,email=atkt11AdmGet.email,password="Admin@123",first_name=atkt11AdmGet.fname,last_name=atkt11AdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                colAdmModule.stud_id="c"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                colAdmModule.user=user
                                # colAdmModule.lcgenerated=False
                                colAdmModule.save()
                                #for Adademic table
                                # colacd=ColAcademic()
                                # colacd.col_admission=colAdmModule
                                # colacd.save()
                                messages.success(request, atkt11AdmGet.fname+" "+atkt11AdmGet.faname+" "+atkt11AdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_collist')
                        #  form 10 form1710=p form1710=s form1710=form1710
                        elif adm_for=="Form1710":
                            if Form1710Adm.objects.filter(prn=prn).exists():
                                messages.error(request, 'Registration Number Number Already Exists in Form17-SSC Admission')
                                return redirect('admission_rejoin')
                            if adm_from == "Primary":
                                user.username=str(priAdmGet.stud_id)
                                user.save()
                                form1710AdmModule=Form1710Adm()
                                form1710AdmModule.prn=prn
                                form1710AdmModule.lname=priAdmGet.lname
                                form1710AdmModule.fname=priAdmGet.fname
                                form1710AdmModule.faname=priAdmGet.faname
                                form1710AdmModule.moname=priAdmGet.moname
                                form1710AdmModule.mrname=priAdmGet.mrname
                                form1710AdmModule.aadhar=priAdmGet.aadhar
                                form1710AdmModule.saral_id=priAdmGet.saral_id
                                form1710AdmModule.nationality=priAdmGet.nationality
                                form1710AdmModule.tongue=priAdmGet.tongue
                                form1710AdmModule.religion=priAdmGet.religion
                                form1710AdmModule.cast=priAdmGet.cast
                                form1710AdmModule.subcast=priAdmGet.subcast
                                form1710AdmModule.minority=priAdmGet.minority
                                form1710AdmModule.pob=priAdmGet.pob
                                form1710AdmModule.dob=priAdmGet.dob
                                form1710AdmModule.last_school=priAdmGet.last_school
                                form1710AdmModule.last_class=priAdmGet.last_class
                                form1710AdmModule.admdate=admdate
                                y=admdate
                                form1710AdmModule.admyear=y[0:4]
                                form1710AdmModule.adm_class="10"
                                form1710AdmModule.admission_faculty=admission_faculty
                                form1710AdmModule.rollno=priAdmGet.rollno
                                form1710AdmModule.lateadm=priAdmGet.lateadm
                                form1710AdmModule.admtype=priAdmGet.admtype
                                form1710AdmModule.hostel=priAdmGet.hostel
                                form1710AdmModule.sex=priAdmGet.sex
                                form1710AdmModule.pwd=priAdmGet.pwd
                                form1710AdmModule.bgroup=priAdmGet.bgroup
                                form1710AdmModule.fa_mob=priAdmGet.fa_mob
                                form1710AdmModule.mo_mob=priAdmGet.mo_mob
                                form1710AdmModule.fa_occu=priAdmGet.fa_occu
                                form1710AdmModule.mo_occu=priAdmGet.mo_occu
                                form1710AdmModule.fam_income=priAdmGet.fam_income
                                form1710AdmModule.bpl=priAdmGet.bpl
                                form1710AdmModule.gis=priAdmGet.gis
                                form1710AdmModule.ganame=priAdmGet.ganame
                                form1710AdmModule.ga_mob=priAdmGet.ga_mob
                                form1710AdmModule.ga_occu=priAdmGet.ga_occu
                                form1710AdmModule.gaddress=priAdmGet.gaddress
                                form1710AdmModule.ga_relation=priAdmGet.ga_relation
                                form1710AdmModule.email=priAdmGet.email
                                form1710AdmModule.areaType=priAdmGet.areaType
                                form1710AdmModule.caddress=priAdmGet.caddress
                                form1710AdmModule.ca_is_pa_addr=priAdmGet.ca_is_pa_addr
                                form1710AdmModule.paddress=priAdmGet.paddress
                                form1710AdmModule.baccount=priAdmGet.baccount
                                form1710AdmModule.bankname=priAdmGet.bankname
                                form1710AdmModule.ifsc=priAdmGet.ifsc
                                form1710AdmModule.branch=priAdmGet.branch
                                form1710AdmModule.micr=priAdmGet.micr
                                form1710AdmModule.marks_img=priAdmGet.marks_img
                                form1710AdmModule.prv_lc_img=priAdmGet.prv_lc_img
                                form1710AdmModule.addhar_img=priAdmGet.addhar_img
                                form1710AdmModule.cast_img=priAdmGet.cast_img
                                form1710AdmModule.castvald_img=priAdmGet.castvald_img
                                form1710AdmModule.nationality_img=priAdmGet.nationality_img
                                form1710AdmModule.noncrimy_img=priAdmGet.noncrimy_img
                                form1710AdmModule.std_img=priAdmGet.std_img
                                form1710AdmModule.birth_img=priAdmGet.birth_img
                                # Create User for Student
                                user=User.objects.create_user(username=priAdmGet.aadhar,email=priAdmGet.email,password="Admin@123",first_name=priAdmGet.fname,last_name=priAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                form1710AdmModule.stud_id="f10"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                #form1710AdmModule.u_ref_student=User.objects.get(username=priAdmGet.cleaned_data['aadhar'])
                                form1710AdmModule.user=user
                                # form1710AdmModule.lcgenerated=False
                                form1710AdmModule.save()
                                messages.success(request, priAdmGet.fname+" "+priAdmGet.faname +" "+ priAdmGet.lname +' Student Admitted Sucessfully!')
                                return redirect('admission_form1710list')
                            elif adm_from == "Secondary":
                                user.username=str(secAdmGet.stud_id)
                                user.save()
                                form1710AdmModule=Form1710Adm()
                                form1710AdmModule.prn=prn
                                form1710AdmModule.lname=secAdmGet.lname
                                form1710AdmModule.fname=secAdmGet.fname
                                form1710AdmModule.faname=secAdmGet.faname
                                form1710AdmModule.moname=secAdmGet.moname
                                form1710AdmModule.mrname=secAdmGet.mrname
                                form1710AdmModule.aadhar=secAdmGet.aadhar
                                form1710AdmModule.saral_id=secAdmGet.saral_id
                                form1710AdmModule.nationality=secAdmGet.nationality
                                form1710AdmModule.tongue=secAdmGet.tongue
                                form1710AdmModule.religion=secAdmGet.religion
                                form1710AdmModule.cast=secAdmGet.cast
                                form1710AdmModule.subcast=secAdmGet.subcast
                                form1710AdmModule.minority=secAdmGet.minority
                                form1710AdmModule.pob=secAdmGet.pob
                                form1710AdmModule.dob=secAdmGet.dob
                                form1710AdmModule.last_school=secAdmGet.last_school
                                form1710AdmModule.last_class=secAdmGet.last_class
                                form1710AdmModule.admdate=admdate
                                y=admdate                 
                                form1710AdmModule.admyear=y[0:4]
                                form1710AdmModule.adm_class="10"
                                form1710AdmModule.admission_faculty=admission_faculty
                                form1710AdmModule.rollno=secAdmGet.rollno
                                form1710AdmModule.lateadm=secAdmGet.lateadm
                                form1710AdmModule.admtype=secAdmGet.admtype
                                form1710AdmModule.hostel=secAdmGet.hostel
                                form1710AdmModule.sex=secAdmGet.sex
                                form1710AdmModule.pwd=secAdmGet.pwd
                                form1710AdmModule.bgroup=secAdmGet.bgroup
                                form1710AdmModule.fa_mob=secAdmGet.fa_mob
                                form1710AdmModule.mo_mob=secAdmGet.mo_mob
                                form1710AdmModule.fa_occu=secAdmGet.fa_occu
                                form1710AdmModule.mo_occu=secAdmGet.mo_occu
                                form1710AdmModule.fam_income=secAdmGet.fam_income
                                form1710AdmModule.bpl=secAdmGet.bpl
                                form1710AdmModule.gis=secAdmGet.gis
                                form1710AdmModule.ganame=secAdmGet.ganame
                                form1710AdmModule.ga_mob=secAdmGet.ga_mob
                                form1710AdmModule.ga_occu=secAdmGet.ga_occu
                                form1710AdmModule.gaddress=secAdmGet.gaddress
                                form1710AdmModule.ga_relation=secAdmGet.ga_relation
                                form1710AdmModule.email=secAdmGet.email
                                form1710AdmModule.areaType=secAdmGet.areaType
                                form1710AdmModule.caddress=secAdmGet.caddress
                                form1710AdmModule.ca_is_pa_addr=secAdmGet.ca_is_pa_addr
                                form1710AdmModule.paddress=secAdmGet.paddress
                                form1710AdmModule.baccount=secAdmGet.baccount
                                form1710AdmModule.bankname=secAdmGet.bankname
                                form1710AdmModule.ifsc=secAdmGet.ifsc
                                form1710AdmModule.branch=secAdmGet.branch
                                form1710AdmModule.micr=secAdmGet.micr
                                form1710AdmModule.marks_img=secAdmGet.marks_img
                                form1710AdmModule.prv_lc_img=secAdmGet.prv_lc_img
                                form1710AdmModule.addhar_img=secAdmGet.addhar_img
                                form1710AdmModule.cast_img=secAdmGet.cast_img
                                form1710AdmModule.castvald_img=secAdmGet.castvald_img
                                form1710AdmModule.nationality_img=secAdmGet.nationality_img
                                form1710AdmModule.noncrimy_img=secAdmGet.noncrimy_img
                                form1710AdmModule.std_img=secAdmGet.std_img
                                form1710AdmModule.birth_img=secAdmGet.birth_img
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=secAdmGet.aadhar,email=secAdmGet.email,password="Admin@123",first_name=secAdmGet.fname,last_name=secAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                form1710AdmModule.stud_id="f10"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                form1710AdmModule.user=user
                                form1710AdmModule.save()
                                messages.success(request, secAdmGet.fname+" "+secAdmGet.faname+" "+secAdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_form1710list')
                            elif adm_from=="Form1710": 
                                user.username=str(form1710AdmGet.stud_id)
                                user.save()
                                form1710AdmModule=Form1710Adm()
                                form1710AdmModule.prn=prn
                                form1710AdmModule.lname=form1710AdmGet.lname
                                form1710AdmModule.fname=form1710AdmGet.fname
                                form1710AdmModule.faname=form1710AdmGet.faname
                                form1710AdmModule.moname=form1710AdmGet.moname
                                form1710AdmModule.mrname=form1710AdmGet.mrname
                                form1710AdmModule.aadhar=form1710AdmGet.aadhar
                                form1710AdmModule.saral_id=form1710AdmGet.saral_id
                                form1710AdmModule.nationality=form1710AdmGet.nationality
                                form1710AdmModule.tongue=form1710AdmGet.tongue
                                form1710AdmModule.religion=form1710AdmGet.religion
                                form1710AdmModule.cast=form1710AdmGet.cast
                                form1710AdmModule.subcast=form1710AdmGet.subcast
                                form1710AdmModule.minority=form1710AdmGet.minority
                                form1710AdmModule.pob=form1710AdmGet.pob
                                form1710AdmModule.dob=form1710AdmGet.dob
                                form1710AdmModule.last_school=form1710AdmGet.last_school
                                form1710AdmModule.last_class=form1710AdmGet.last_class
                                form1710AdmModule.admdate=admdate
                                y=admdate                 
                                form1710AdmModule.admyear=y[0:4]
                                form1710AdmModule.adm_class="10"
                                form1710AdmModule.admission_faculty=admission_faculty
                                form1710AdmModule.rollno=form1710AdmGet.rollno
                                form1710AdmModule.lateadm=form1710AdmGet.lateadm
                                form1710AdmModule.admtype=form1710AdmGet.admtype
                                form1710AdmModule.hostel=form1710AdmGet.hostel
                                form1710AdmModule.sex=form1710AdmGet.sex
                                form1710AdmModule.pwd=form1710AdmGet.pwd
                                form1710AdmModule.bgroup=form1710AdmGet.bgroup
                                form1710AdmModule.fa_mob=form1710AdmGet.fa_mob
                                form1710AdmModule.mo_mob=form1710AdmGet.mo_mob
                                form1710AdmModule.fa_occu=form1710AdmGet.fa_occu
                                form1710AdmModule.mo_occu=form1710AdmGet.mo_occu
                                form1710AdmModule.fam_income=form1710AdmGet.fam_income
                                form1710AdmModule.bpl=form1710AdmGet.bpl
                                form1710AdmModule.gis=form1710AdmGet.gis
                                form1710AdmModule.ganame=form1710AdmGet.ganame
                                form1710AdmModule.ga_mob=form1710AdmGet.ga_mob
                                form1710AdmModule.ga_occu=form1710AdmGet.ga_occu
                                form1710AdmModule.gaddress=form1710AdmGet.gaddress
                                form1710AdmModule.ga_relation=form1710AdmGet.ga_relation
                                form1710AdmModule.email=form1710AdmGet.email
                                form1710AdmModule.areaType=form1710AdmGet.areaType
                                form1710AdmModule.caddress=form1710AdmGet.caddress
                                form1710AdmModule.ca_is_pa_addr=form1710AdmGet.ca_is_pa_addr
                                form1710AdmModule.paddress=form1710AdmGet.paddress
                                form1710AdmModule.baccount=form1710AdmGet.baccount
                                form1710AdmModule.bankname=form1710AdmGet.bankname
                                form1710AdmModule.ifsc=form1710AdmGet.ifsc
                                form1710AdmModule.branch=form1710AdmGet.branch
                                form1710AdmModule.micr=form1710AdmGet.micr
                                form1710AdmModule.marks_img=form1710AdmGet.marks_img
                                form1710AdmModule.prv_lc_img=form1710AdmGet.prv_lc_img
                                form1710AdmModule.addhar_img=form1710AdmGet.addhar_img
                                form1710AdmModule.cast_img=form1710AdmGet.cast_img
                                form1710AdmModule.castvald_img=form1710AdmGet.castvald_img
                                form1710AdmModule.nationality_img=form1710AdmGet.nationality_img
                                form1710AdmModule.noncrimy_img=form1710AdmGet.noncrimy_img
                                form1710AdmModule.std_img=form1710AdmGet.std_img
                                form1710AdmModule.birth_img=form1710AdmGet.birth_img
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=form1710AdmGet.aadhar,email=form1710AdmGet.email,password="Admin@123",first_name=form1710AdmGet.fname,last_name=form1710AdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                form1710AdmModule.stud_id="f10"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                form1710AdmModule.user=user
                                # form1710AdmModule.lcgenerated=False
                                form1710AdmModule.save()
                                messages.success(request, form1710AdmGet.fname+" "+form1710AdmGet.faname+" "+form1710AdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_form1710list')
                        #  form 12 form1712=p form1712=s form1712=c form1712=atkt11 form1712=form1710 form1712=form1712
                        elif adm_for=="Form1712":
                            if Form1712Adm.objects.filter(prn=prn).exists():
                                messages.error(request, 'Registration Number Number Already Exists in Form17-HSC Admission')
                                return redirect('admission_rejoin')
                            if adm_from == "Primary":
                                user.username=str(priAdmGet.stud_id)
                                user.save()
                                form1712AdmModule=Form1712Adm()
                                form1712AdmModule.prn=prn
                                form1712AdmModule.lname=priAdmGet.lname
                                form1712AdmModule.fname=priAdmGet.fname
                                form1712AdmModule.faname=priAdmGet.faname
                                form1712AdmModule.moname=priAdmGet.moname
                                form1712AdmModule.mrname=priAdmGet.mrname
                                form1712AdmModule.aadhar=priAdmGet.aadhar
                                form1712AdmModule.saral_id=priAdmGet.saral_id
                                form1712AdmModule.nationality=priAdmGet.nationality
                                form1712AdmModule.tongue=priAdmGet.tongue
                                form1712AdmModule.religion=priAdmGet.religion
                                form1712AdmModule.cast=priAdmGet.cast
                                form1712AdmModule.subcast=priAdmGet.subcast
                                form1712AdmModule.minority=priAdmGet.minority
                                form1712AdmModule.pob=priAdmGet.pob
                                form1712AdmModule.dob=priAdmGet.dob
                                form1712AdmModule.last_school=priAdmGet.last_school
                                form1712AdmModule.last_class=priAdmGet.last_class
                                form1712AdmModule.admdate=admdate
                                y=admdate
                                form1712AdmModule.admyear=y[0:4]
                                form1712AdmModule.adm_class="12"
                                form1712AdmModule.admission_faculty=admission_faculty
                                form1712AdmModule.rollno=priAdmGet.rollno
                                form1712AdmModule.lateadm=priAdmGet.lateadm
                                form1712AdmModule.admtype=priAdmGet.admtype
                                form1712AdmModule.hostel=priAdmGet.hostel
                                form1712AdmModule.sex=priAdmGet.sex
                                form1712AdmModule.pwd=priAdmGet.pwd
                                form1712AdmModule.bgroup=priAdmGet.bgroup
                                form1712AdmModule.fa_mob=priAdmGet.fa_mob
                                form1712AdmModule.mo_mob=priAdmGet.mo_mob
                                form1712AdmModule.fa_occu=priAdmGet.fa_occu
                                form1712AdmModule.mo_occu=priAdmGet.mo_occu
                                form1712AdmModule.fam_income=priAdmGet.fam_income
                                form1712AdmModule.bpl=priAdmGet.bpl
                                form1712AdmModule.gis=priAdmGet.gis
                                form1712AdmModule.ganame=priAdmGet.ganame
                                form1712AdmModule.ga_mob=priAdmGet.ga_mob
                                form1712AdmModule.ga_occu=priAdmGet.ga_occu
                                form1712AdmModule.gaddress=priAdmGet.gaddress
                                form1712AdmModule.ga_relation=priAdmGet.ga_relation
                                form1712AdmModule.email=priAdmGet.email
                                form1712AdmModule.areaType=priAdmGet.areaType
                                form1712AdmModule.caddress=priAdmGet.caddress
                                form1712AdmModule.ca_is_pa_addr=priAdmGet.ca_is_pa_addr
                                form1712AdmModule.paddress=priAdmGet.paddress
                                form1712AdmModule.baccount=priAdmGet.baccount
                                form1712AdmModule.bankname=priAdmGet.bankname
                                form1712AdmModule.ifsc=priAdmGet.ifsc
                                form1712AdmModule.branch=priAdmGet.branch
                                form1712AdmModule.micr=priAdmGet.micr
                                form1712AdmModule.marks_img=priAdmGet.marks_img
                                form1712AdmModule.prv_lc_img=priAdmGet.prv_lc_img
                                form1712AdmModule.addhar_img=priAdmGet.addhar_img
                                form1712AdmModule.cast_img=priAdmGet.cast_img
                                form1712AdmModule.castvald_img=priAdmGet.castvald_img
                                form1712AdmModule.nationality_img=priAdmGet.nationality_img
                                form1712AdmModule.noncrimy_img=priAdmGet.noncrimy_img
                                form1712AdmModule.std_img=priAdmGet.std_img
                                form1712AdmModule.birth_img=priAdmGet.birth_img
                                # Create User for Student
                                user=User.objects.create_user(username=priAdmGet.aadhar,email=priAdmGet.email,password="Admin@123",first_name=priAdmGet.fname,last_name=priAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                form1712AdmModule.stud_id="f12"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                #form1712AdmModule.u_ref_student=User.objects.get(username=priAdmGet.cleaned_data['aadhar'])
                                form1712AdmModule.user=user
                                # form1712AdmModule.lcgenerated=False
                                form1712AdmModule.save()
                                messages.success(request, priAdmGet.fname+" "+priAdmGet.faname +" "+ priAdmGet.lname +' Student Admitted Sucessfully!')
                                return redirect('admission_form1712list')
                            elif adm_from == "Secondary":
                                user.username=str(secAdmGet.stud_id)
                                user.save()
                                form1712AdmModule=Form1712Adm()
                                form1712AdmModule.prn=prn
                                form1712AdmModule.lname=secAdmGet.lname
                                form1712AdmModule.fname=secAdmGet.fname
                                form1712AdmModule.faname=secAdmGet.faname
                                form1712AdmModule.moname=secAdmGet.moname
                                form1712AdmModule.mrname=secAdmGet.mrname
                                form1712AdmModule.aadhar=secAdmGet.aadhar
                                form1712AdmModule.saral_id=secAdmGet.saral_id
                                form1712AdmModule.nationality=secAdmGet.nationality
                                form1712AdmModule.tongue=secAdmGet.tongue
                                form1712AdmModule.religion=secAdmGet.religion
                                form1712AdmModule.cast=secAdmGet.cast
                                form1712AdmModule.subcast=secAdmGet.subcast
                                form1712AdmModule.minority=secAdmGet.minority
                                form1712AdmModule.pob=secAdmGet.pob
                                form1712AdmModule.dob=secAdmGet.dob
                                form1712AdmModule.last_school=secAdmGet.last_school
                                form1712AdmModule.last_class=secAdmGet.last_class
                                form1712AdmModule.admdate=admdate
                                y=admdate                 
                                form1712AdmModule.admyear=y[0:4]
                                form1712AdmModule.adm_class="12"
                                form1712AdmModule.admission_faculty=admission_faculty
                                form1712AdmModule.rollno=secAdmGet.rollno
                                form1712AdmModule.lateadm=secAdmGet.lateadm
                                form1712AdmModule.admtype=secAdmGet.admtype
                                form1712AdmModule.hostel=secAdmGet.hostel
                                form1712AdmModule.sex=secAdmGet.sex
                                form1712AdmModule.pwd=secAdmGet.pwd
                                form1712AdmModule.bgroup=secAdmGet.bgroup
                                form1712AdmModule.fa_mob=secAdmGet.fa_mob
                                form1712AdmModule.mo_mob=secAdmGet.mo_mob
                                form1712AdmModule.fa_occu=secAdmGet.fa_occu
                                form1712AdmModule.mo_occu=secAdmGet.mo_occu
                                form1712AdmModule.fam_income=secAdmGet.fam_income
                                form1712AdmModule.bpl=secAdmGet.bpl
                                form1712AdmModule.gis=secAdmGet.gis
                                form1712AdmModule.ganame=secAdmGet.ganame
                                form1712AdmModule.ga_mob=secAdmGet.ga_mob
                                form1712AdmModule.ga_occu=secAdmGet.ga_occu
                                form1712AdmModule.gaddress=secAdmGet.gaddress
                                form1712AdmModule.ga_relation=secAdmGet.ga_relation
                                form1712AdmModule.email=secAdmGet.email
                                form1712AdmModule.areaType=secAdmGet.areaType
                                form1712AdmModule.caddress=secAdmGet.caddress
                                form1712AdmModule.ca_is_pa_addr=secAdmGet.ca_is_pa_addr
                                form1712AdmModule.paddress=secAdmGet.paddress
                                form1712AdmModule.baccount=secAdmGet.baccount
                                form1712AdmModule.bankname=secAdmGet.bankname
                                form1712AdmModule.ifsc=secAdmGet.ifsc
                                form1712AdmModule.branch=secAdmGet.branch
                                form1712AdmModule.micr=secAdmGet.micr
                                form1712AdmModule.marks_img=secAdmGet.marks_img
                                form1712AdmModule.prv_lc_img=secAdmGet.prv_lc_img
                                form1712AdmModule.addhar_img=secAdmGet.addhar_img
                                form1712AdmModule.cast_img=secAdmGet.cast_img
                                form1712AdmModule.castvald_img=secAdmGet.castvald_img
                                form1712AdmModule.nationality_img=secAdmGet.nationality_img
                                form1712AdmModule.noncrimy_img=secAdmGet.noncrimy_img
                                form1712AdmModule.std_img=secAdmGet.std_img
                                form1712AdmModule.birth_img=secAdmGet.birth_img
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=secAdmGet.aadhar,email=secAdmGet.email,password="Admin@123",first_name=secAdmGet.fname,last_name=secAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                form1712AdmModule.stud_id="f12"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                form1712AdmModule.user=user
                                form1712AdmModule.save()
                                messages.success(request, secAdmGet.fname+" "+secAdmGet.faname+" "+secAdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_form1712list')
                            elif adm_from=="Jr.College":
                                user.username=str(colAdmGet.stud_id)
                                user.save()
                                form1712AdmModule=Form1712Adm()
                                form1712AdmModule.prn=prn
                                form1712AdmModule.lname=colAdmGet.lname
                                form1712AdmModule.fname=colAdmGet.fname
                                form1712AdmModule.faname=colAdmGet.faname
                                form1712AdmModule.moname=colAdmGet.moname
                                form1712AdmModule.mrname=colAdmGet.mrname
                                form1712AdmModule.aadhar=colAdmGet.aadhar
                                form1712AdmModule.saral_id=colAdmGet.saral_id
                                form1712AdmModule.nationality=colAdmGet.nationality
                                form1712AdmModule.tongue=colAdmGet.tongue
                                form1712AdmModule.religion=colAdmGet.religion
                                form1712AdmModule.cast=colAdmGet.cast
                                form1712AdmModule.subcast=colAdmGet.subcast
                                form1712AdmModule.minority=colAdmGet.minority
                                form1712AdmModule.pob=colAdmGet.pob
                                form1712AdmModule.dob=colAdmGet.dob
                                form1712AdmModule.last_school=colAdmGet.last_school
                                form1712AdmModule.last_class=colAdmGet.last_class
                                form1712AdmModule.admdate=admdate
                                y=admdate                 
                                form1712AdmModule.admyear=y[0:4]
                                form1712AdmModule.adm_class="12"
                                form1712AdmModule.admission_faculty=admission_faculty
                                form1712AdmModule.rollno=colAdmGet.rollno
                                form1712AdmModule.lateadm=colAdmGet.lateadm
                                form1712AdmModule.admtype=colAdmGet.admtype
                                form1712AdmModule.hostel=colAdmGet.hostel
                                form1712AdmModule.sex=colAdmGet.sex
                                form1712AdmModule.pwd=colAdmGet.pwd
                                form1712AdmModule.bgroup=colAdmGet.bgroup
                                form1712AdmModule.fa_mob=colAdmGet.fa_mob
                                form1712AdmModule.mo_mob=colAdmGet.mo_mob
                                form1712AdmModule.fa_occu=colAdmGet.fa_occu
                                form1712AdmModule.mo_occu=colAdmGet.mo_occu
                                form1712AdmModule.fam_income=colAdmGet.fam_income
                                form1712AdmModule.bpl=colAdmGet.bpl
                                form1712AdmModule.gis=colAdmGet.gis
                                form1712AdmModule.ganame=colAdmGet.ganame
                                form1712AdmModule.ga_mob=colAdmGet.ga_mob
                                form1712AdmModule.ga_occu=colAdmGet.ga_occu
                                form1712AdmModule.gaddress=colAdmGet.gaddress
                                form1712AdmModule.ga_relation=colAdmGet.ga_relation
                                form1712AdmModule.email=colAdmGet.email
                                form1712AdmModule.areaType=colAdmGet.areaType
                                form1712AdmModule.caddress=colAdmGet.caddress
                                form1712AdmModule.ca_is_pa_addr=colAdmGet.ca_is_pa_addr
                                form1712AdmModule.paddress=colAdmGet.paddress
                                form1712AdmModule.baccount=colAdmGet.baccount
                                form1712AdmModule.bankname=colAdmGet.bankname
                                form1712AdmModule.ifsc=colAdmGet.ifsc
                                form1712AdmModule.branch=colAdmGet.branch
                                form1712AdmModule.micr=colAdmGet.micr
                                form1712AdmModule.marks_img=colAdmGet.marks_img
                                form1712AdmModule.prv_lc_img=colAdmGet.prv_lc_img
                                form1712AdmModule.addhar_img=colAdmGet.addhar_img
                                form1712AdmModule.cast_img=colAdmGet.cast_img
                                form1712AdmModule.castvald_img=colAdmGet.castvald_img
                                form1712AdmModule.nationality_img=colAdmGet.nationality_img
                                form1712AdmModule.noncrimy_img=colAdmGet.noncrimy_img
                                form1712AdmModule.std_img=colAdmGet.std_img
                                form1712AdmModule.birth_img=colAdmGet.birth_img
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=colAdmGet.aadhar,email=colAdmGet.email,password="Admin@123",first_name=colAdmGet.fname,last_name=colAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                form1712AdmModule.stud_id="f12"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                form1712AdmModule.user=user
                                # form1712AdmModule.lcgenerated=False
                                form1712AdmModule.save()
                                messages.success(request, colAdmGet.fname+" "+colAdmGet.faname+" "+colAdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_form1712list')
                            elif adm_from=="Form1710":
                                user.username=str(form1710AdmGet.stud_id)
                                user.save()
                                form1712AdmModule=Form1712Adm()
                                form1712AdmModule.prn=prn
                                form1712AdmModule.lname=form1710AdmGet.lname
                                form1712AdmModule.fname=form1710AdmGet.fname
                                form1712AdmModule.faname=form1710AdmGet.faname
                                form1712AdmModule.moname=form1710AdmGet.moname
                                form1712AdmModule.mrname=form1710AdmGet.mrname
                                form1712AdmModule.aadhar=form1710AdmGet.aadhar
                                form1712AdmModule.saral_id=form1710AdmGet.saral_id
                                form1712AdmModule.nationality=form1710AdmGet.nationality
                                form1712AdmModule.tongue=form1710AdmGet.tongue
                                form1712AdmModule.religion=form1710AdmGet.religion
                                form1712AdmModule.cast=form1710AdmGet.cast
                                form1712AdmModule.subcast=form1710AdmGet.subcast
                                form1712AdmModule.minority=form1710AdmGet.minority
                                form1712AdmModule.pob=form1710AdmGet.pob
                                form1712AdmModule.dob=form1710AdmGet.dob
                                form1712AdmModule.last_school=form1710AdmGet.last_school
                                form1712AdmModule.last_class=form1710AdmGet.last_class
                                form1712AdmModule.admdate=admdate
                                y=admdate                 
                                form1712AdmModule.admyear=y[0:4]
                                form1712AdmModule.adm_class="12"
                                form1712AdmModule.admission_faculty=admission_faculty
                                form1712AdmModule.rollno=form1710AdmGet.rollno
                                form1712AdmModule.lateadm=form1710AdmGet.lateadm
                                form1712AdmModule.admtype=form1710AdmGet.admtype
                                form1712AdmModule.hostel=form1710AdmGet.hostel
                                form1712AdmModule.sex=form1710AdmGet.sex
                                form1712AdmModule.pwd=form1710AdmGet.pwd
                                form1712AdmModule.bgroup=form1710AdmGet.bgroup
                                form1712AdmModule.fa_mob=form1710AdmGet.fa_mob
                                form1712AdmModule.mo_mob=form1710AdmGet.mo_mob
                                form1712AdmModule.fa_occu=form1710AdmGet.fa_occu
                                form1712AdmModule.mo_occu=form1710AdmGet.mo_occu
                                form1712AdmModule.fam_income=form1710AdmGet.fam_income
                                form1712AdmModule.bpl=form1710AdmGet.bpl
                                form1712AdmModule.gis=form1710AdmGet.gis
                                form1712AdmModule.ganame=form1710AdmGet.ganame
                                form1712AdmModule.ga_mob=form1710AdmGet.ga_mob
                                form1712AdmModule.ga_occu=form1710AdmGet.ga_occu
                                form1712AdmModule.gaddress=form1710AdmGet.gaddress
                                form1712AdmModule.ga_relation=form1710AdmGet.ga_relation
                                form1712AdmModule.email=form1710AdmGet.email
                                form1712AdmModule.areaType=form1710AdmGet.areaType
                                form1712AdmModule.caddress=form1710AdmGet.caddress
                                form1712AdmModule.ca_is_pa_addr=form1710AdmGet.ca_is_pa_addr
                                form1712AdmModule.paddress=form1710AdmGet.paddress
                                form1712AdmModule.baccount=form1710AdmGet.baccount
                                form1712AdmModule.bankname=form1710AdmGet.bankname
                                form1712AdmModule.ifsc=form1710AdmGet.ifsc
                                form1712AdmModule.branch=form1710AdmGet.branch
                                form1712AdmModule.micr=form1710AdmGet.micr
                                form1712AdmModule.marks_img=form1710AdmGet.marks_img
                                form1712AdmModule.prv_lc_img=form1710AdmGet.prv_lc_img
                                form1712AdmModule.addhar_img=form1710AdmGet.addhar_img
                                form1712AdmModule.cast_img=form1710AdmGet.cast_img
                                form1712AdmModule.castvald_img=form1710AdmGet.castvald_img
                                form1712AdmModule.nationality_img=form1710AdmGet.nationality_img
                                form1712AdmModule.noncrimy_img=form1710AdmGet.noncrimy_img
                                form1712AdmModule.std_img=form1710AdmGet.std_img
                                form1712AdmModule.birth_img=form1710AdmGet.birth_img
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=form1710AdmGet.aadhar,email=form1710AdmGet.email,password="Admin@123",first_name=form1710AdmGet.fname,last_name=form1710AdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                form1712AdmModule.stud_id="f12"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                form1712AdmModule.user=user
                                # form1712AdmModule.lcgenerated=False
                                form1712AdmModule.save()
                                messages.success(request, form1710AdmGet.fname+" "+form1710AdmGet.faname+" "+form1710AdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_form1712list')
                            elif adm_from=="Form1712": 
                                user.username=str(form1712AdmGet.stud_id)
                                user.save()
                                form1712AdmModule=Form1712Adm()
                                form1712AdmModule.prn=prn
                                form1712AdmModule.lname=form1712AdmGet.lname
                                form1712AdmModule.fname=form1712AdmGet.fname
                                form1712AdmModule.faname=form1712AdmGet.faname
                                form1712AdmModule.moname=form1712AdmGet.moname
                                form1712AdmModule.mrname=form1712AdmGet.mrname
                                form1712AdmModule.aadhar=form1712AdmGet.aadhar
                                form1712AdmModule.saral_id=form1712AdmGet.saral_id
                                form1712AdmModule.nationality=form1712AdmGet.nationality
                                form1712AdmModule.tongue=form1712AdmGet.tongue
                                form1712AdmModule.religion=form1712AdmGet.religion
                                form1712AdmModule.cast=form1712AdmGet.cast
                                form1712AdmModule.subcast=form1712AdmGet.subcast
                                form1712AdmModule.minority=form1712AdmGet.minority
                                form1712AdmModule.pob=form1712AdmGet.pob
                                form1712AdmModule.dob=form1712AdmGet.dob
                                form1712AdmModule.last_school=form1712AdmGet.last_school
                                form1712AdmModule.last_class=form1712AdmGet.last_class
                                form1712AdmModule.admdate=admdate
                                y=admdate                 
                                form1712AdmModule.admyear=y[0:4]
                                form1712AdmModule.adm_class="12"
                                form1712AdmModule.admission_faculty=admission_faculty
                                form1712AdmModule.rollno=form1712AdmGet.rollno
                                form1712AdmModule.lateadm=form1712AdmGet.lateadm
                                form1712AdmModule.admtype=form1712AdmGet.admtype
                                form1712AdmModule.hostel=form1712AdmGet.hostel
                                form1712AdmModule.sex=form1712AdmGet.sex
                                form1712AdmModule.pwd=form1712AdmGet.pwd
                                form1712AdmModule.bgroup=form1712AdmGet.bgroup
                                form1712AdmModule.fa_mob=form1712AdmGet.fa_mob
                                form1712AdmModule.mo_mob=form1712AdmGet.mo_mob
                                form1712AdmModule.fa_occu=form1712AdmGet.fa_occu
                                form1712AdmModule.mo_occu=form1712AdmGet.mo_occu
                                form1712AdmModule.fam_income=form1712AdmGet.fam_income
                                form1712AdmModule.bpl=form1712AdmGet.bpl
                                form1712AdmModule.gis=form1712AdmGet.gis
                                form1712AdmModule.ganame=form1712AdmGet.ganame
                                form1712AdmModule.ga_mob=form1712AdmGet.ga_mob
                                form1712AdmModule.ga_occu=form1712AdmGet.ga_occu
                                form1712AdmModule.gaddress=form1712AdmGet.gaddress
                                form1712AdmModule.ga_relation=form1712AdmGet.ga_relation
                                form1712AdmModule.email=form1712AdmGet.email
                                form1712AdmModule.areaType=form1712AdmGet.areaType
                                form1712AdmModule.caddress=form1712AdmGet.caddress
                                form1712AdmModule.ca_is_pa_addr=form1712AdmGet.ca_is_pa_addr
                                form1712AdmModule.paddress=form1712AdmGet.paddress
                                form1712AdmModule.baccount=form1712AdmGet.baccount
                                form1712AdmModule.bankname=form1712AdmGet.bankname
                                form1712AdmModule.ifsc=form1712AdmGet.ifsc
                                form1712AdmModule.branch=form1712AdmGet.branch
                                form1712AdmModule.micr=form1712AdmGet.micr
                                form1712AdmModule.marks_img=form1712AdmGet.marks_img
                                form1712AdmModule.prv_lc_img=form1712AdmGet.prv_lc_img
                                form1712AdmModule.addhar_img=form1712AdmGet.addhar_img
                                form1712AdmModule.cast_img=form1712AdmGet.cast_img
                                form1712AdmModule.castvald_img=form1712AdmGet.castvald_img
                                form1712AdmModule.nationality_img=form1712AdmGet.nationality_img
                                form1712AdmModule.noncrimy_img=form1712AdmGet.noncrimy_img
                                form1712AdmModule.std_img=form1712AdmGet.std_img
                                form1712AdmModule.birth_img=form1712AdmGet.birth_img
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=form1712AdmGet.aadhar,email=form1712AdmGet.email,password="Admin@123",first_name=form1712AdmGet.fname,last_name=form1712AdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                form1712AdmModule.stud_id="f12"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                form1712AdmModule.user=user
                                # form1712AdmModule.lcgenerated=False
                                form1712AdmModule.save()
                                messages.success(request, form1712AdmGet.fname+" "+form1712AdmGet.faname+" "+form1712AdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_form1712list')
                            elif adm_from=="11-ATKT": 
                                user.username=str(atkt11AdmGet.stud_id)
                                user.save()
                                form1712AdmModule=Form1712Adm()
                                form1712AdmModule.prn=prn
                                form1712AdmModule.lname=atkt11AdmGet.lname
                                form1712AdmModule.fname=atkt11AdmGet.fname
                                form1712AdmModule.faname=atkt11AdmGet.faname
                                form1712AdmModule.moname=atkt11AdmGet.moname
                                form1712AdmModule.mrname=atkt11AdmGet.mrname
                                form1712AdmModule.aadhar=atkt11AdmGet.aadhar
                                form1712AdmModule.saral_id=atkt11AdmGet.saral_id
                                form1712AdmModule.nationality=atkt11AdmGet.nationality
                                form1712AdmModule.tongue=atkt11AdmGet.tongue
                                form1712AdmModule.religion=atkt11AdmGet.religion
                                form1712AdmModule.cast=atkt11AdmGet.cast
                                form1712AdmModule.subcast=atkt11AdmGet.subcast
                                form1712AdmModule.minority=atkt11AdmGet.minority
                                form1712AdmModule.pob=atkt11AdmGet.pob
                                form1712AdmModule.dob=atkt11AdmGet.dob
                                form1712AdmModule.last_school=atkt11AdmGet.last_school
                                form1712AdmModule.last_class=atkt11AdmGet.last_class
                                form1712AdmModule.admdate=admdate
                                y=admdate                 
                                form1712AdmModule.admyear=y[0:4]
                                form1712AdmModule.adm_class="12"
                                form1712AdmModule.admission_faculty=admission_faculty
                                form1712AdmModule.rollno=atkt11AdmGet.rollno
                                form1712AdmModule.lateadm=atkt11AdmGet.lateadm
                                form1712AdmModule.admtype=atkt11AdmGet.admtype
                                form1712AdmModule.hostel=atkt11AdmGet.hostel
                                form1712AdmModule.sex=atkt11AdmGet.sex
                                form1712AdmModule.pwd=atkt11AdmGet.pwd
                                form1712AdmModule.bgroup=atkt11AdmGet.bgroup
                                form1712AdmModule.fa_mob=atkt11AdmGet.fa_mob
                                form1712AdmModule.mo_mob=atkt11AdmGet.mo_mob
                                form1712AdmModule.fa_occu=atkt11AdmGet.fa_occu
                                form1712AdmModule.mo_occu=atkt11AdmGet.mo_occu
                                form1712AdmModule.fam_income=atkt11AdmGet.fam_income
                                form1712AdmModule.bpl=atkt11AdmGet.bpl
                                form1712AdmModule.gis=atkt11AdmGet.gis
                                form1712AdmModule.ganame=atkt11AdmGet.ganame
                                form1712AdmModule.ga_mob=atkt11AdmGet.ga_mob
                                form1712AdmModule.ga_occu=atkt11AdmGet.ga_occu
                                form1712AdmModule.gaddress=atkt11AdmGet.gaddress
                                form1712AdmModule.ga_relation=atkt11AdmGet.ga_relation
                                form1712AdmModule.email=atkt11AdmGet.email
                                form1712AdmModule.areaType=atkt11AdmGet.areaType
                                form1712AdmModule.caddress=atkt11AdmGet.caddress
                                form1712AdmModule.ca_is_pa_addr=atkt11AdmGet.ca_is_pa_addr
                                form1712AdmModule.paddress=atkt11AdmGet.paddress
                                form1712AdmModule.baccount=atkt11AdmGet.baccount
                                form1712AdmModule.bankname=atkt11AdmGet.bankname
                                form1712AdmModule.ifsc=atkt11AdmGet.ifsc
                                form1712AdmModule.branch=atkt11AdmGet.branch
                                form1712AdmModule.micr=atkt11AdmGet.micr
                                form1712AdmModule.marks_img=atkt11AdmGet.marks_img
                                form1712AdmModule.prv_lc_img=atkt11AdmGet.prv_lc_img
                                form1712AdmModule.addhar_img=atkt11AdmGet.addhar_img
                                form1712AdmModule.cast_img=atkt11AdmGet.cast_img
                                form1712AdmModule.castvald_img=atkt11AdmGet.castvald_img
                                form1712AdmModule.nationality_img=atkt11AdmGet.nationality_img
                                form1712AdmModule.noncrimy_img=atkt11AdmGet.noncrimy_img
                                form1712AdmModule.std_img=atkt11AdmGet.std_img
                                form1712AdmModule.birth_img=atkt11AdmGet.birth_img
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=atkt11AdmGet.aadhar,email=atkt11AdmGet.email,password="Admin@123",first_name=atkt11AdmGet.fname,last_name=atkt11AdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                form1712AdmModule.stud_id="f12"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                form1712AdmModule.user=user
                                # form1712AdmModule.lcgenerated=False
                                form1712AdmModule.save()
                                messages.success(request, atkt11AdmGet.fname+" "+atkt11AdmGet.faname+" "+atkt11AdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_form1712list')
                        #  11-ATKT p=11-ATKT,s=11-ATKT
                        elif adm_for=="11-ATKT":
                            if ATKT11Adm.objects.filter(prn=prn).exists():
                                messages.error(request, 'Registration Number Number Already Exists in 11-ATKT Admission')
                                return redirect('admission_rejoin')
                            if adm_from == "Primary":
                                user.username=str(priAdmGet.stud_id)
                                user.save()
                                atkt11AdmModule=ATKT11Adm()
                                atkt11AdmModule.prn=prn
                                atkt11AdmModule.lname=priAdmGet.lname
                                atkt11AdmModule.fname=priAdmGet.fname
                                atkt11AdmModule.faname=priAdmGet.faname
                                atkt11AdmModule.moname=priAdmGet.moname
                                atkt11AdmModule.mrname=priAdmGet.mrname
                                atkt11AdmModule.aadhar=priAdmGet.aadhar
                                atkt11AdmModule.saral_id=priAdmGet.saral_id
                                atkt11AdmModule.nationality=priAdmGet.nationality
                                atkt11AdmModule.tongue=priAdmGet.tongue
                                atkt11AdmModule.religion=priAdmGet.religion
                                atkt11AdmModule.cast=priAdmGet.cast
                                atkt11AdmModule.subcast=priAdmGet.subcast
                                atkt11AdmModule.minority=priAdmGet.minority
                                atkt11AdmModule.pob=priAdmGet.pob
                                atkt11AdmModule.dob=priAdmGet.dob
                                atkt11AdmModule.last_school=priAdmGet.last_school
                                atkt11AdmModule.last_class=priAdmGet.last_class
                                atkt11AdmModule.admdate=admdate
                                y=admdate
                                atkt11AdmModule.admyear=y[0:4]
                                atkt11AdmModule.adm_class="11"
                                atkt11AdmModule.admission_faculty=admission_faculty
                                atkt11AdmModule.division=priAdmGet.division
                                atkt11AdmModule.rollno=priAdmGet.rollno
                                atkt11AdmModule.lateadm=priAdmGet.lateadm
                                atkt11AdmModule.admtype=priAdmGet.admtype
                                atkt11AdmModule.hostel=priAdmGet.hostel
                                atkt11AdmModule.sex=priAdmGet.sex
                                atkt11AdmModule.pwd=priAdmGet.pwd
                                atkt11AdmModule.bgroup=priAdmGet.bgroup
                                atkt11AdmModule.fa_mob=priAdmGet.fa_mob
                                atkt11AdmModule.mo_mob=priAdmGet.mo_mob
                                atkt11AdmModule.fa_occu=priAdmGet.fa_occu
                                atkt11AdmModule.mo_occu=priAdmGet.mo_occu
                                atkt11AdmModule.fam_income=priAdmGet.fam_income
                                atkt11AdmModule.bpl=priAdmGet.bpl
                                atkt11AdmModule.gis=priAdmGet.gis
                                atkt11AdmModule.ganame=priAdmGet.ganame
                                atkt11AdmModule.ga_mob=priAdmGet.ga_mob
                                atkt11AdmModule.ga_occu=priAdmGet.ga_occu
                                atkt11AdmModule.gaddress=priAdmGet.gaddress
                                atkt11AdmModule.ga_relation=priAdmGet.ga_relation
                                atkt11AdmModule.email=priAdmGet.email
                                atkt11AdmModule.areaType=priAdmGet.areaType
                                atkt11AdmModule.caddress=priAdmGet.caddress
                                atkt11AdmModule.ca_is_pa_addr=priAdmGet.ca_is_pa_addr
                                atkt11AdmModule.paddress=priAdmGet.paddress
                                atkt11AdmModule.baccount=priAdmGet.baccount
                                atkt11AdmModule.bankname=priAdmGet.bankname
                                atkt11AdmModule.ifsc=priAdmGet.ifsc
                                atkt11AdmModule.branch=priAdmGet.branch
                                atkt11AdmModule.micr=priAdmGet.micr
                                atkt11AdmModule.marks_img=priAdmGet.marks_img
                                atkt11AdmModule.prv_lc_img=priAdmGet.prv_lc_img
                                atkt11AdmModule.addhar_img=priAdmGet.addhar_img
                                atkt11AdmModule.cast_img=priAdmGet.cast_img
                                atkt11AdmModule.castvald_img=priAdmGet.castvald_img
                                atkt11AdmModule.nationality_img=priAdmGet.nationality_img
                                atkt11AdmModule.noncrimy_img=priAdmGet.noncrimy_img
                                atkt11AdmModule.std_img=priAdmGet.std_img
                                atkt11AdmModule.birth_img=priAdmGet.birth_img
                                # Create User for Student
                                user=User.objects.create_user(username=priAdmGet.aadhar,email=priAdmGet.email,password="Admin@123",first_name=priAdmGet.fname,last_name=priAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                atkt11AdmModule.stud_id="atkt"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                #atkt11AdmModule.u_ref_student=User.objects.get(username=priAdmGet.cleaned_data['aadhar'])
                                atkt11AdmModule.user=user
                                # atkt11AdmModule.lcgenerated=False
                                atkt11AdmModule.save()
                                messages.success(request, priAdmGet.fname+" "+priAdmGet.faname +" "+ priAdmGet.lname +' Student Admitted Sucessfully!')
                                return redirect('admission_atkt11list')
                            elif adm_from == "Secondary":
                                user.username=str(secAdmGet.stud_id)
                                user.save()
                                atkt11AdmModule=ATKT11Adm()
                                atkt11AdmModule.prn=prn
                                atkt11AdmModule.lname=secAdmGet.lname
                                atkt11AdmModule.fname=secAdmGet.fname
                                atkt11AdmModule.faname=secAdmGet.faname
                                atkt11AdmModule.moname=secAdmGet.moname
                                atkt11AdmModule.mrname=secAdmGet.mrname
                                atkt11AdmModule.aadhar=secAdmGet.aadhar
                                atkt11AdmModule.saral_id=secAdmGet.saral_id
                                atkt11AdmModule.nationality=secAdmGet.nationality
                                atkt11AdmModule.tongue=secAdmGet.tongue
                                atkt11AdmModule.religion=secAdmGet.religion
                                atkt11AdmModule.cast=secAdmGet.cast
                                atkt11AdmModule.subcast=secAdmGet.subcast
                                atkt11AdmModule.minority=secAdmGet.minority
                                atkt11AdmModule.pob=secAdmGet.pob
                                atkt11AdmModule.dob=secAdmGet.dob
                                atkt11AdmModule.last_school=secAdmGet.last_school
                                atkt11AdmModule.last_class=secAdmGet.last_class
                                atkt11AdmModule.admdate=admdate
                                y=admdate                 
                                atkt11AdmModule.admyear=y[0:4]
                                atkt11AdmModule.adm_class="11"
                                atkt11AdmModule.admission_faculty=admission_faculty
                                atkt11AdmModule.division=secAdmGet.division
                                atkt11AdmModule.rollno=secAdmGet.rollno
                                atkt11AdmModule.lateadm=secAdmGet.lateadm
                                atkt11AdmModule.admtype=secAdmGet.admtype
                                atkt11AdmModule.hostel=secAdmGet.hostel
                                atkt11AdmModule.sex=secAdmGet.sex
                                atkt11AdmModule.pwd=secAdmGet.pwd
                                atkt11AdmModule.bgroup=secAdmGet.bgroup
                                atkt11AdmModule.fa_mob=secAdmGet.fa_mob
                                atkt11AdmModule.mo_mob=secAdmGet.mo_mob
                                atkt11AdmModule.fa_occu=secAdmGet.fa_occu
                                atkt11AdmModule.mo_occu=secAdmGet.mo_occu
                                atkt11AdmModule.fam_income=secAdmGet.fam_income
                                atkt11AdmModule.bpl=secAdmGet.bpl
                                atkt11AdmModule.gis=secAdmGet.gis
                                atkt11AdmModule.ganame=secAdmGet.ganame
                                atkt11AdmModule.ga_mob=secAdmGet.ga_mob
                                atkt11AdmModule.ga_occu=secAdmGet.ga_occu
                                atkt11AdmModule.gaddress=secAdmGet.gaddress
                                atkt11AdmModule.ga_relation=secAdmGet.ga_relation
                                atkt11AdmModule.email=secAdmGet.email
                                atkt11AdmModule.areaType=secAdmGet.areaType
                                atkt11AdmModule.caddress=secAdmGet.caddress
                                atkt11AdmModule.ca_is_pa_addr=secAdmGet.ca_is_pa_addr
                                atkt11AdmModule.paddress=secAdmGet.paddress
                                atkt11AdmModule.baccount=secAdmGet.baccount
                                atkt11AdmModule.bankname=secAdmGet.bankname
                                atkt11AdmModule.ifsc=secAdmGet.ifsc
                                atkt11AdmModule.branch=secAdmGet.branch
                                atkt11AdmModule.micr=secAdmGet.micr
                                atkt11AdmModule.marks_img=secAdmGet.marks_img
                                atkt11AdmModule.prv_lc_img=secAdmGet.prv_lc_img
                                atkt11AdmModule.addhar_img=secAdmGet.addhar_img
                                atkt11AdmModule.cast_img=secAdmGet.cast_img
                                atkt11AdmModule.castvald_img=secAdmGet.castvald_img
                                atkt11AdmModule.nationality_img=secAdmGet.nationality_img
                                atkt11AdmModule.noncrimy_img=secAdmGet.noncrimy_img
                                atkt11AdmModule.std_img=secAdmGet.std_img
                                atkt11AdmModule.birth_img=secAdmGet.birth_img
                                # Create User for Student
                                print("sgds")
                                user=User.objects.create_user(username=secAdmGet.aadhar,email=secAdmGet.email,password="Admin@123",first_name=secAdmGet.fname,last_name=secAdmGet.lname)
                                user.save()
                                # create student id for rejoin
                                # studid=StudID()
                                # studid.stud_id=user
                                # studid.save()
                                atkt11AdmModule.stud_id="atkt"+str(user.id)+""+prn
                                my_group=Group.objects.get(name='student')
                                #my_group.user_set.add(user)
                                user.groups.add(my_group)
                                atkt11AdmModule.user=user
                                atkt11AdmModule.save()
                                messages.success(request, secAdmGet.fname+" "+secAdmGet.faname+" "+secAdmGet.lname+' Student Admitted Sucessfully!')
                                return redirect('admission_atkt11list')
                    else:
                        if User.objects.filter(username=aadhar,is_active=True).exists():
                            messages.error(request,"LC Not Generated Yet")
                            return redirect('admission_rejoin')    
                        else:
                            messages.error(request,"Student Not present with "+aadhar+" This Aadhar Number")
                            return redirect('admission_rejoin')
                except:
                    messages.error(request,"Invalid header found in Rejoin form... Try again")
                    return redirect('admission_rejoin')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            rejoinForm= RejoinForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Student Admission /",
            'fname':fname,
            "page_path":" Rejoin Admission ",
            "menu_icon":"nav-icon fas fa-address-card",
            "rejoinForm":rejoinForm,
            }
        return render(request, 'schoolviews/admission/rejoin.html',context) 
    else:
        return redirect('login')