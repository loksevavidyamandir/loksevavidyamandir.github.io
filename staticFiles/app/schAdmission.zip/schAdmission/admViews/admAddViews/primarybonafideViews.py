from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm
from schAdmission.admModels.academicModels import PrimBonafide
from schSetup.setupModels.setup_models import Division
from schAdmission.admForms.admissionForms import GetAdmYearForm
from seedData.models import Year
import inflect
import datetime
import xlwt
from xlwt.Formatting import Borders
  
p=inflect.engine()
sname=conf_set.SCHOOL_NAME
schnameabove=conf_set.SCHNAME_ABOVE
schname=conf_set.SCHNAME
schnamebelow=conf_set.SCHNAME_BELOW
schUDISEno=conf_set.SCH_UDISE_NO


# Primary Bonafide views 

dd = ['','FIRST','SECOND','THIRD','FOURTH','FIFTH','SIXTH','SEVENTH','EIGHTH','NINTH','TENTH','ELEVENTH','TWELVETH','THIRTEENTH','FOURTEENTH','FIFTEENTH','SIXTEENTH','SEVENTEENTH','EIGHTEENTH','NINETEENTH','TWENTIETH','TWENTY FIRST','TWENTY SECOND','TWENTY THIRD','TWENTY FOURTH','TWENTY FIFTH','TWENTY SIXTH','TWENTY SEVENTH','TWENTY EIGHTH','TWENTY NINTH','THIRTIETH','THIRTY FIRST']
mm = ['','JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER']

# for Primary Student 
def admission_pribonafide(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        if request.method == 'POST':
            try:
                studid=request.POST['studid'].split(",")
                class1 = int(request.POST['pribonaclass'])
                year = int(request.POST['pribonayear'])
                for x in range(0,len(studid)):
                    priData=PrimAdm.objects.get(pk=studid[x])
                    pribona=PrimBonafide()
                    pribona.prn=priData.prn
                    pribona.lname=priData.lname
                    pribona.fname=priData.fname
                    pribona.faname=priData.faname
                    pribona.breligion=priData.religion
                    pribona.bcast=priData.cast
                    pribona.prim_academic=priData
                    pribona.bona_class=class1

                    # from adm to bonafide
                    date=priData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    print(dobirth)
                    pribona.dob=dobirth

                     # for dob in words
                    yy=p.number_to_words(y).capitalize()
                    yy=yy.replace(" and",'')
                    print(dd[d],mm[m],yy.upper())
                    pribona.dobinwords=dd[d]+' '+mm[m]+' '+yy.upper()

                    pribona.bona_year=str(year)

                    # for issuedate
                    date=request.POST['dateofissue'].split('-')
                    doissue=date[2]+'-'+date[1]+'-'+date[0]
                    print(doissue)
                    pribona.issuedate=doissue

                    pribona.save()
                messages.success(request,'Bonafide issued Successfully!')
                return redirect('admission_pribonafide')
            except:
                messages.error(request,"Invalid header found in Student Bonafide form... Try again")
                return redirect('admission_pribonafide')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Bonafide /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "page_path":"Primary Bonafide Issue",
            "menu_icon":"far fa-address-card nav-icon",
            }    
        return render(request,'schoolviews/bonafide/primarybonafidegenerate.html',context) 
    else:
        return redirect('login')


# for Primary Student  
def load_pristudentsbona(request):
    class1 = int(request.GET.get('class1'))
    year = request.GET.get('year')
    div = request.GET.get('div')
    if class1 == 1:
        students = PrimAdm.objects.filter(updateclass1=class1,updateyear1=year,updatedivision1=div,updateclass2=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 2:
        students = PrimAdm.objects.filter(updateclass2=class1,updateyear2=year,updatedivision2=div,updateclass3=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 3:
        students = PrimAdm.objects.filter(updateclass3=class1,updateyear3=year,updatedivision3=div,updateclass4=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 4:
        students = PrimAdm.objects.filter(updateclass4=class1,updateyear4=year,updatedivision4=div,lcgenerated=0,terminatebyprincipal=0)
    print(students)
    return render(request,'schoolviews/bonafide/studentsbona.html',{"students":students})




# for Primary bonafide  list 
def admission_pribonafidelist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    pribonaData=PrimBonafide.objects.filter(bona_year=cy)
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Bonafide /",
                    'fname':fname,
                    "page_path":" Primary Bonafide List",
                    "menu_icon":"far fa-address-card nav-icon",
                    "pribonaData":pribonaData,
                    "getAdmDate":getAdmDate,
                    "cy": cy
                     }    
                    return render(request, 'schoolviews/bonafide/primary_bonafidelist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Primary Student List form... Try again")
                    return redirect('admission_pribonafidelist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            pribonaData=PrimBonafide.objects.filter(bona_year=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Bonafide /",
            'fname':fname,
            "page_path":" Primary Bonafide List",
            "menu_icon":"nav-icon far fa-address-card",
            "pribonaData":pribonaData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/bonafide/primary_bonafidelist.html',context) 
    else:
        return redirect('login')




# for Primary bonafide  View 
def admission_pribonafideview(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        pribonaData=PrimBonafide.objects.get(pk=id)
        priData=PrimAdm.objects.get(prn=pribonaData.prn)
        acad_year=int(pribonaData.bona_year)
        acad_year+=1        
        context = {
            "priData":priData,
            "pribonaData":pribonaData,
            "acad_year":acad_year,
            "schnameabove":schnameabove,
            "schname":schname,
            "schnamebelow":schnamebelow,
            "schUDISEno":schUDISEno,
            }
        return render(request, 'schoolviews/bonafide/primarybonafide_view.html',context)
    else:
        return redirect('login')




# for Primary bonafide  Delete 
def admission_pribonafidedelete(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            pribona=PrimBonafide.objects.get(pk=id)
            pribona.delete()
            messages.success(request,'Bonafide Deleted Sucessfully!')
            return redirect('admission_pribonafidelist')
        except:
            messages.error(request,"Invalid header found in Bonafide form... Try again")
            return redirect('admission_pribonafidelist')    
    else:
        return redirect('login') 