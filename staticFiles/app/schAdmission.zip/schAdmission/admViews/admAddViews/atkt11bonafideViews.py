from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schAdmission.admModels.academicModels import PrimBonafide,SecBonafide,ColBonafide,ATKT11Bonafide
from schSetup.setupModels.setup_models import Division
from schAdmission.admForms.admissionForms import GetAdmYearForm
from seedData.models import Year
import inflect
import datetime
import xlwt
from xlwt.Formatting import Borders
  
p=inflect.engine()
sname=conf_set.SCHOOL_NAME
schnameabove=conf_set.SCHNAME_ABOVE
schname=conf_set.SCHNAME
schnamebelow=conf_set.SCHNAME_BELOW
schUDISEno=conf_set.SCH_UDISE_NO


# 11-ATKT Bonafide views   

dd = ['','FIRST','SECOND','THIRD','FOURTH','FIFTH','SIXTH','SEVENTH','EIGHTH','NINTH','TENTH','ELEVENTH','TWELVETH','THIRTEENTH','FOURTEENTH','FIFTEENTH','SIXTEENTH','SEVENTEENTH','EIGHTEENTH','NINETEENTH','TWENTIETH','TWENTY FIRST','TWENTY SECOND','TWENTY THIRD','TWENTY FOURTH','TWENTY FIFTH','TWENTY SIXTH','TWENTY SEVENTH','TWENTY EIGHTH','TWENTY NINTH','THIRTIETH','THIRTY FIRST']
mm = ['','JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER']


# for 11-ATKT Student 
def admission_atkt11bonafide(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        if request.method == 'POST':
            try:
                studid=request.POST['studid'].split(",")
                year = int(request.POST['atkt11bonayear'])
                stream = str(request.POST['atkt11bonastream'])
                for x in range(0,len(studid)):
                    atkt11Data=ATKT11Adm.objects.get(pk=studid[x])
                    atkt11bona=ATKT11Bonafide()
                    atkt11bona.prn=atkt11Data.prn
                    atkt11bona.lname=atkt11Data.lname
                    atkt11bona.fname=atkt11Data.fname
                    atkt11bona.faname=atkt11Data.faname
                    atkt11bona.breligion=atkt11Data.religion
                    atkt11bona.bcast=atkt11Data.cast
                    atkt11bona.atkt11_academic=atkt11Data
                    atkt11bona.bona_class="11"
                    atkt11bona.bona_stream=stream
                    atkt11bona.bona_year=str(year)

                    # from adm to bonafide
                    date=atkt11Data.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    print(dobirth)
                    atkt11bona.dob=dobirth

                     # for dob in words
                    yy=p.number_to_words(y).capitalize()
                    yy=yy.replace(" and",'')
                    print(dd[d],mm[m],yy.upper())
                    atkt11bona.dobinwords=dd[d]+' '+mm[m]+' '+yy.upper()


                    # for issuedate
                    date=request.POST['dateofissue'].split('-')
                    doissue=date[2]+'-'+date[1]+'-'+date[0]
                    print(doissue)
                    atkt11bona.issuedate=doissue

                    atkt11bona.save()
                messages.success(request,'Bonafide issued Successfully!')
                return redirect('admission_atkt11bonafide')
            except:
                messages.error(request,"Invalid header found in Student Bonafide form... Try again")
                return redirect('admission_atkt11bonafide')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Bonafide /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "page_path":"11-ATKT Bonafide Issue",
            "menu_icon":"far fa-address-card nav-icon",
            }    
        return render(request,'schoolviews/bonafide/atkt11bonafidegenerate.html',context) 
    else:
        return redirect('login')


# for 11-ATKT Student  
def load_atkt11studentsbona(request):
    year = request.GET.get('year')
    div = request.GET.get('div')
    divData = Division.objects.get(division=div)
    stream = request.GET.get('stream')
    students = ATKT11Adm.objects.filter(admyear=year,division=divData.id,admission_faculty=stream,lcgenerated=0)
    print(students)
    return render(request,'schoolviews/bonafide/studentsbona.html',{"students":students})




# for 11-ATKT bonafide  list 
def admission_atkt11bonafidelist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    atkt11bonaData=ATKT11Bonafide.objects.filter(bona_year=cy)
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Bonafide /",
                    'fname':fname,
                    "page_path":" 11-ATKT Bonafide List",
                    "menu_icon":"far fa-address-card nav-icon",
                    "atkt11bonaData":atkt11bonaData,
                    "getAdmDate":getAdmDate,
                    "cy": cy
                     }    
                    return render(request, 'schoolviews/bonafide/atkt11_bonafidelist.html',context) 
                except:
                    messages.error(request,"Invalid header found in 11-ATKT Student List form... Try again")
                    return redirect('admission_atkt11bonafidelist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            atkt11bonaData=ATKT11Bonafide.objects.filter(bona_year=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Bonafide /",
            'fname':fname,
            "page_path":" 11-ATKT Bonafide List",
            "menu_icon":"nav-icon far fa-address-card",
            "atkt11bonaData":atkt11bonaData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request,'schoolviews/bonafide/atkt11_bonafidelist.html',context) 
    else:
        return redirect('login')




# for 11-ATKT bonafide  View 
def admission_atkt11bonafideview(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        atkt11bonaData=ATKT11Bonafide.objects.get(pk=id)
        atkt11Data=ATKT11Adm.objects.get(prn=atkt11bonaData.prn)
        acad_year=int(atkt11bonaData.bona_year)
        acad_year+=1
        context = {
            "atkt11Data":atkt11Data,
            "atkt11bonaData":atkt11bonaData,
            "acad_year":acad_year,
            "schnameabove":schnameabove,
            "schname":schname,
            "schnamebelow":schnamebelow,
            "schUDISEno":schUDISEno,
            }
        return render(request, 'schoolviews/bonafide/atkt11bonafide_view.html',context)
    else:
        return redirect('login')



# for 11-ATKT bonafide Delete 
def admission_atkt11bonafidedelete(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            atkt11bona=ATKT11Bonafide.objects.get(pk=id)
            atkt11bona.delete()
            messages.success(request,'Bonafide Deleted Sucessfully!')
            return redirect('admission_atkt11bonafidelist')
        except:
            messages.error(request,"Invalid header found in Bonafide form... Try again")
            return redirect('admission_atkt11bonafidelist')    
    else:
        return redirect('login') 