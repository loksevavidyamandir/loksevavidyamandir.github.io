from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,PriLCSrNo,SecLCSrNo,ColLCSrNo,Form1710LCSrNo,Form1712LCSrNo
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue,LCRemark
from schAdmission.admForms.admissionForms import GetAdmYearForm
from seedData.models import Year
import inflect
import datetime
import xlwt
from xlwt.Formatting import Borders
p=inflect.engine()
        
  

sname=conf_set.SCHOOL_NAME 
schnameabove=conf_set.SCHNAME_ABOVE
schname=conf_set.SCHNAME
schnamebelow=conf_set.SCHNAME_BELOW
schUDISEno=conf_set.SCH_UDISE_NO
schboard=conf_set.SCH_BOARD
schreg=conf_set.SCH_REG



dd = ['','FIRST','SECOND','THIRD','FOURTH','FIFTH','SIXTH','SEVENTH','EIGHTH','NINTH','TENTH','ELEVENTH','TWELVETH','THIRTEENTH','FOURTEENTH','FIFTEENTH','SIXTEENTH','SEVENTEENTH','EIGHTEENTH','NINETEENTH','TWENTIETH','TWENTY FIRST','TWENTY SECOND','TWENTY THIRD','TWENTY FOURTH','TWENTY FIFTH','TWENTY SIXTH','TWENTY SEVENTH','TWENTY EIFHTH','TWENTY NINTH','Thirtieth','THIRTY FIRST']
mm = ['','JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER']

# for college LC Generate
def admission_collcgenerate(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        remarkData = LCRemark.objects.all()
        if request.method == 'POST':
            try:
                stud_id=[]
                studid=request.POST['studid'].split(",")
                for x in range(0,len(studid)):
                    stud_id.append(int(studid[x]))
                    colData = CollegeAdm.objects.get(pk=studid[x])
                    userData = User.objects.get(pk=studid[x])
                    userData.is_active=False
                    userData.save()
                    date=request.POST['lcdateofleaving'].split('-')
                    doleave=date[2]+'-'+date[1]+'-'+date[0]
                    print(doleave)
                    colData.lcdateofleaving=doleave
                    colData.lcyearofleaving=date[0]
                    if request.POST['lcdateofissue'] !="":
                        date=request.POST['lcdateofissue'].split('-')
                        doissue=date[2]+'-'+date[1]+'-'+date[0]
                        print(doissue)
                        colData.lcissuedate=doissue
                    else:
                        colData.lcissuedate=None

                    date=colData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    print(dobirth)
                    colData.lcdob=dobirth

                    # for dob in words
                    yy=p.number_to_words(y).capitalize()
                    yy=yy.replace(" and",'')
                    print(dd[d],mm[m],yy.upper())
                    colData.lcdobinwords=dd[d]+' '+mm[m]+' '+yy.upper()

                    date=colData.admdate.split('-')
                    print("ADM Date",colData.admdate)
                    admdate=date[2]+'-'+date[1]+'-'+date[0]
                    print(admdate)
                    colData.lcadmdate=admdate

                    colsrnoData = ColLCSrNo()
                    colsrnoData.srnotext="a"
                    colsrnoData.save()
                    colData.lcgenerated=True
                    colData.lcsrno=colsrnoData.id
                    colData.lcprogress=request.POST['lcprogress']
                    colData.lcconduct=request.POST['lcconduct']
                    colData.lcreason=request.POST['lcreason']
                    colData.lcremarks=request.POST['lcremarks']
                    colData.lctongue=str(colData.tongue)
                    colData.lcreligion=str(colData.religion)
                    colData.lccaste=str(colData.cast)
                    colData.lcstudyinginclass=request.POST['lcstudyinginclass'].upper()
                    colData.lcprintcount=1
                    colData.save()
                if request.POST.get('submit_print'):
                    colData=CollegeAdm.objects.all()
                    print(colData)
                    context = {
                        'colData':colData,
                        'stud_id':stud_id,
                        }
                    print(stud_id)
                    return render(request,'schoolviews/lcgenerate/collegeleavingcertificate.html',context)
                elif request.POST.get('submit_pdf'):
                    colData=CollegeAdm.objects.all()
                    print(colData)
                    context = {
                        'colData':colData,
                        'stud_id':stud_id,
                        }
                    print(stud_id)
                    return render(request,'schoolviews/lcgenerate/collegeleavingcertificate_view.html',context)
            except:
                messages.error(request,"Invalid header found in LC Generated form... Try again")
                return redirect('admission_collcgenerate')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Certificate /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "remarkData":remarkData,
            "page_path":"College LC Generate ",
            "menu_icon":"nav-icon fas fa-university",
            }
        return render(request,'schoolviews/lcgenerate/collegelcgenerate.html',context) 
    else:
        return redirect('login')


# for College terminate LC Generate
def admission_colterlcgenerate(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        remarkData = LCRemark.objects.all()
        if request.method == 'POST':
            try:
                stud_id=[]
                stud_id.append(int(user_id))
                colData = CollegeAdm.objects.get(pk=user_id)
                date=request.POST['lcdateofleaving'].split('-')
                doleave=date[2]+'-'+date[1]+'-'+date[0]
                print(doleave)
                colData.lcdateofleaving=doleave
                colData.lcyearofleaving=date[0]
                if request.POST['lcdateofissue'] !="":
                    date=request.POST['lcdateofissue'].split('-')
                    doissue=date[2]+'-'+date[1]+'-'+date[0]
                    print(doissue)
                    colData.lcissuedate=doissue
                else:
                    colData.lcissuedate=None

                date=colData.dob.split('-')
                dobirth=date[2]+'-'+date[1]+'-'+date[0]
                d=int(date[2])
                m=int(date[1])
                y=int(date[0])
                print(dobirth)
                colData.lcdob=dobirth

                # for dob in words
                yy=p.number_to_words(y).capitalize()
                yy=yy.replace(" and",'')
                print(dd[d],mm[m],yy.upper())
                colData.lcdobinwords=dd[d]+' '+mm[m]+' '+yy.upper()

                date=colData.admdate.split('-')
                print("ADM Date",colData.admdate)
                admdate=date[2]+'-'+date[1]+'-'+date[0]
                print(admdate)
                colData.lcadmdate=admdate

                colsrnoData = ColLCSrNo()
                colsrnoData.srnotext="a"
                colsrnoData.save()
                colData.lcgenerated=True
                colData.terminatebyprincipal=True
                colData.lcsrno=colsrnoData.id
                colData.lcprogress=request.POST['lcprogress']
                colData.lcconduct=request.POST['lcconduct']
                colData.lcreason=request.POST['lcreason']
                colData.lcremarks=request.POST['lcremarks']
                colData.lctongue=str(colData.tongue)
                colData.lcreligion=str(colData.religion)
                colData.lccaste=str(colData.cast)
                colData.lcstudyinginclass=request.POST['lcstudyinginclass'].upper()
                colData.lcprintcount=1
                colData.save()
                colData=CollegeAdm.objects.all()
                context = {
                    'colData':colData,
                    'stud_id':stud_id,
                    }
                return render(request,'schoolviews/lcgenerate/collegeleavingcertificate.html',context)
            except:
                messages.error(request,"Invalid header found in LC Generated form... Try again")
                return redirect('academic_colterminatedeclist')
    else:
        return redirect('login')        



# for college  LC 
def load_colstudentslc(request):
    class1 = int(request.GET.get('class1'))
    year = request.GET.get('year')
    div = request.GET.get('div')
    stream = request.GET.get('stream')
    if class1 == 11:
        students = CollegeAdm.objects.filter(updateclass11=class1,updateyear11=year,updatedivision11=div,updatestream11=stream,updateclass12=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 12:
        students = CollegeAdm.objects.filter(updateclass12=class1,updateyear12=year,updatedivision12=div,updatestream12=stream,lcgenerated=0,terminatebyprincipal=0)
    print(students)
    return render(request,'schoolviews/lcgenerate/studentslc.html',{"students":students})


# for college lc list 
def admission_collclist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    colAdmData=CollegeAdm.objects.filter(lcyearofleaving=cy,lcgenerated=True)
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Certificate /",
                    'fname':fname,
                    "page_path":" Leaving Certificate / College Leaving Certificate",
                    "menu_icon":"nav-icon fa fa-certificate",
                    "colAdmData":colAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy
                     }    
                    return render(request, 'schoolviews/lcgenerate/college_lclist.html',context) 
                except:
                    messages.error(request,"Invalid header found in College Student List form... Try again")
                    return redirect('admission_collclist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            colAdmData=CollegeAdm.objects.filter(lcyearofleaving=cy,lcgenerated=True)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Certificate /",
            'fname':fname,
            "page_path":" Leaving Certificate / College Leaving Certificate",
            "menu_icon":"nav-icon fa fa-certificate",
            "colAdmData":colAdmData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/lcgenerate/college_lclist.html',context) 
    else:
        return redirect('login') 



# for college lc View 
def admission_collcview(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        stud_id=[]
        stud_id.append(int(user_id))
        colData=CollegeAdm.objects.filter(pk=user_id)
        context = {
            "colData":colData,
            "stud_id":stud_id,
            "schnameabove":schnameabove,
            "schname":schname,
            "schnamebelow":schnamebelow,
            "schUDISEno":schUDISEno,
            "schboard":schboard,
            "schreg":schreg,
            }
        return render(request, 'schoolviews/lcgenerate/collegeleavingcertificate_view.html',context) 
    else:
        return redirect('login')




# for college lc Delete 
def admission_collcdelete(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            colData=CollegeAdm.objects.get(pk=user_id)
            colData.terminatebyprincipal=False
            colData.terminatebyteacher=False
            colData.treason=None
            colData.tyear=None
            colData.tdate=None
            colData.tclass=None
            colData.lcgenerated=False
            srno=int(colData.lcsrno)
            colsrnoData = ColLCSrNo.objects.get(pk=srno)
            colsrnoData.delete()
            colData.lcsrno=None
            colData.lcprogress=None
            colData.lcconduct=None
            colData.lcdateofleaving=None
            colData.lcyearofleaving=None
            colData.lcreason=None
            colData.lcremarks=None
            colData.lctongue=None
            colData.lcreligion=None
            colData.lccaste=None
            colData.lcstudyinginclass=None
            colData.lcadmdate=None
            colData.lcdobinwords=None
            colData.lcissuedate=None
            colData.lcdob=None
            colData.lcprintcount=0
            colData.save()
            messages.success(request,'LC Deleted Sucessfully!')
            return redirect('admission_collclist')
        except:
            messages.error(request,"Invalid header found in LC Generated form... Try again")
            return redirect('admission_collclist')    
    else:
        return redirect('login') 



# for secondary lc Original Print 
def admission_collcorigprint(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            stud_id=[]
            colData1=CollegeAdm.objects.get(pk=user_id)
            pc=int(colData1.lcprintcount)
            colData1.lcprintcount=pc+1
            colData1.save()
            colData=CollegeAdm.objects.filter(pk=user_id)
            stud_id.append(user_id)
            context = {
                'colData':colData,
                'stud_id':stud_id,
                }
            print(stud_id,colData)
            return render(request,'schoolviews/lcgenerate/collegeleavingcertificate.html',context)
        except:
            messages.error(request,"Invalid header found in LC Bonafide form... Try again")
            return redirect('admission_collclist')
    else:
        return redirect('login')



# college LC Export View
def admission_collcexport(request,cy):
    print("export",cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=CollegeLCList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('CollegeLCList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["LC Sr No","Registration Number","Saral ID","Aadhar","Last Name","First Name","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","Last attended school","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Stream","Division","Progress","Conduct"," Date of leaving school(DD-MM-YYYY)","Standard in which studying and since when","Reason of leaving school","Remarks","Date of Issue"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = CollegeAdm.objects.filter(lcyearofleaving=cy).values_list('lcsrno','prn','saral_id','aadhar','lname','fname','faname','moname','nationality','lctongue','lcreligion','lccaste','subcast','pob','lcdob','last_school','lcadmdate','adm_class','admission_faculty','division','lcprogress','lcconduct','lcdateofleaving','lcstudyinginclass','lcreason','lcremarks','lcissuedate')
    for row in rows:
        # row[12]-subcast,row[15]-last_school,row[18]-division
        row=list(row)

        if row[12]!=None:
            sc=SubCast.objects.get(id=row[12])
            row[12]=sc.subCastName

        if row[15]!=None:
            os=OtherSch.objects.get(id=row[15])
            row[15]=os.schName

        if row[19]!=None:
            d=Division.objects.get(id=row[19])
            row[19]=d.division
            
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response