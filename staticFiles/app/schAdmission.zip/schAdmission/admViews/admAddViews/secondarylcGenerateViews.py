from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,PriLCSrNo,SecLCSrNo,ColLCSrNo,Form1710LCSrNo,Form1712LCSrNo
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue,LCRemark
from schAdmission.admForms.admissionForms import GetAdmYearForm
from seedData.models import Year
import inflect
import datetime
import xlwt
from xlwt.Formatting import Borders
p=inflect.engine()
        
#Secondary LC Generate Views
#Secondary 8th pass Certificate View

sname=conf_set.SCHOOL_NAME 
schnameabove=conf_set.SCHNAME_ABOVE
schname=conf_set.SCHNAME
schemail=conf_set.SCHNAME_EMAIL
schnamebelow=conf_set.SCHNAME_BELOW
schUDISEno=conf_set.SCH_UDISE_NO
schboard=conf_set.SCH_BOARD
schreg=conf_set.SCH_REG


dd = ['','FIRST','SECOND','THIRD','FOURTH','FIFTH','SIXTH','SEVENTH','EIGHTH','NINTH','TENTH','ELEVENTH','TWELVETH','THIRTEENTH','FOURTEENTH','FIFTEENTH','SIXTEENTH','SEVENTEENTH','EIGHTEENTH','NINETEENTH','TWENTIETH','TWENTY FIRST','TWENTY SECOND','TWENTY THIRD','TWENTY FOURTH','TWENTY FIFTH','TWENTY SIXTH','TWENTY SEVENTH','TWENTY EIGHTH','TWENTY NINTH','THIRTIETH','THIRTY FIRST']
mm = ['','JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER']

# for secondary LC Generate
def admission_seclcgenerate(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        remarkData = LCRemark.objects.all()
        if request.method == 'POST':
            try:
                stud_id=[]
                studid=request.POST['studid'].split(",")
                for x in range(0,len(studid)):
                    stud_id.append(int(studid[x]))
                    secData = SecondAdm.objects.get(pk=studid[x])
                    userData = User.objects.get(pk=studid[x])
                    userData.is_active=False
                    userData.save()
                    date=request.POST['lcdateofleaving'].split('-')
                    doleave=date[2]+'-'+date[1]+'-'+date[0]
                    print(doleave)
                    secData.lcdateofleaving=doleave
                    secData.lcyearofleaving=date[0]
                    if request.POST['lcdateofissue'] !="":
                        date=request.POST['lcdateofissue'].split('-')
                        doissue=date[2]+'-'+date[1]+'-'+date[0]
                        print(doissue)
                        secData.lcissuedate=doissue
                    else:
                        secData.lcissuedate=None

                    date=secData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    print(dobirth)
                    secData.lcdob=dobirth

                    # for dob in words
                    yy=p.number_to_words(y).capitalize()
                    yy=yy.replace(" and",'')
                    print(dd[d],mm[m],yy.upper())
                    secData.lcdobinwords=dd[d]+' '+mm[m]+' '+yy.upper()

                    date=secData.admdate.split('-')
                    print("ADM Date",secData.admdate)
                    admdate=date[2]+'-'+date[1]+'-'+date[0]
                    print(admdate)
                    secData.lcadmdate=admdate


                    secsrnoData = SecLCSrNo()
                    secsrnoData.srnotext="a"
                    secsrnoData.save()
                    secData.lcgenerated=True
                    secData.lcsrno=secsrnoData.id
                    secData.lcprogress=request.POST['lcprogress']
                    secData.lcconduct=request.POST['lcconduct']
                    secData.lcreason=request.POST['lcreason']
                    secData.lcremarks=request.POST['lcremarks']
                    secData.lctongue=str(secData.tongue)
                    secData.lcreligion=str(secData.religion)
                    secData.lccaste=str(secData.cast)
                    secData.lcstudyinginclass=request.POST['lcstudyinginclass'].upper()
                    secData.lcprintcount=1
                    secData.save()
                if request.POST.get('submit_print'):
                    secData=SecondAdm.objects.all()
                    print(secData)
                    context = {
                        'secData':secData,
                        'stud_id':stud_id,
                        }
                    print(stud_id)
                    return render(request,'schoolviews/lcgenerate/secondaryleavingcertificate.html',context)
                elif request.POST.get('submit_pdf'):
                    secData=SecondAdm.objects.all()
                    print(secData)
                    context = {
                        'secData':secData,
                        'stud_id':stud_id,
                        }
                    print(stud_id)
                    return render(request,'schoolviews/lcgenerate/secondaryleavingcertificate_view.html',context)
            except:
                messages.error(request,"Invalid header found in LC Generated form... Try again")
                return redirect('admission_seclcgenerate')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Certificate /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "remarkData":remarkData,
            "page_path":"Secondary LC Generate ",
            "menu_icon":"nav-icon fas fa-university",
            }
        return render(request,'schoolviews/lcgenerate/secondarylcgenerate.html',context) 
    else:
        return redirect('login')



# for Secondary terminate LC Generate
def admission_secterlcgenerate(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        remarkData = LCRemark.objects.all()
        if request.method == 'POST':
            try:
                stud_id=[]
                stud_id.append(int(user_id))
                secData = SecondAdm.objects.get(pk=user_id)
                date=request.POST['lcdateofleaving'].split('-')
                doleave=date[2]+'-'+date[1]+'-'+date[0]
                print(doleave)
                secData.lcdateofleaving=doleave
                secData.lcyearofleaving=date[0]
                if request.POST['lcdateofissue'] !="":
                    date=request.POST['lcdateofissue'].split('-')
                    doissue=date[2]+'-'+date[1]+'-'+date[0]
                    print(doissue)
                    secData.lcissuedate=doissue
                else:
                    secData.lcissuedate=None

                date=secData.dob.split('-')
                dobirth=date[2]+'-'+date[1]+'-'+date[0]
                d=int(date[2])
                m=int(date[1])
                y=int(date[0])
                print(dobirth)
                secData.lcdob=dobirth

                # for dob in words
                yy=p.number_to_words(y).capitalize()
                yy=yy.replace(" and",'')
                print(dd[d],mm[m],yy.upper())
                secData.lcdobinwords=dd[d]+' '+mm[m]+' '+yy.upper()

                date=secData.admdate.split('-')
                print("ADM Date",secData.admdate)
                admdate=date[2]+'-'+date[1]+'-'+date[0]
                print(admdate)
                secData.lcadmdate=admdate


                secsrnoData = SecLCSrNo()
                secsrnoData.srnotext="a"
                secsrnoData.save()
                secData.lcgenerated=True
                secData.terminatebyprincipal=True
                secData.lcsrno=secsrnoData.id
                secData.lcprogress=request.POST['lcprogress']
                secData.lcconduct=request.POST['lcconduct']
                secData.lcreason=request.POST['lcreason']
                secData.lcremarks=request.POST['lcremarks']
                secData.lctongue=str(secData.tongue)
                secData.lcreligion=str(secData.religion)
                secData.lccaste=str(secData.cast)
                secData.lcstudyinginclass=request.POST['lcstudyinginclass'].upper()
                secData.lcprintcount=1
                secData.save()
                secData=SecondAdm.objects.all()
                context = {
                    'secData':secData,
                    'stud_id':stud_id,
                    }
                return render(request,'schoolviews/lcgenerate/secondaryleavingcertificate.html',context)
            except:
                messages.error(request,"Invalid header found in LC Generated form... Try again")
                return redirect('academic_secterminatedeclist')
    else:
        return redirect('login')


# for Secondary  LC 
def load_secstudentslc(request):
    class1 = int(request.GET.get('class1'))
    year = request.GET.get('year')
    div = request.GET.get('div')
    if class1 == 5:
        students = SecondAdm.objects.filter(updateclass5=class1,updateyear5=year,updatedivision5=div,updateclass6=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 6:
        students = SecondAdm.objects.filter(updateclass6=class1,updateyear6=year,updatedivision6=div,updateclass7=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 7:
        students = SecondAdm.objects.filter(updateclass7=class1,updateyear7=year,updatedivision7=div,updateclass8=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 8:
        students = SecondAdm.objects.filter(updateclass8=class1,updateyear8=year,updatedivision8=div,updateclass9=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 9:
        students = SecondAdm.objects.filter(updateclass9=class1,updateyear9=year,updatedivision9=div,updateclass10=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 10:
        students = SecondAdm.objects.filter(updateclass10=class1,updateyear10=year,updatedivision10=div,lcgenerated=0,terminatebyprincipal=0)
    print(students)
    return render(request,'schoolviews/lcgenerate/studentslc.html',{"students":students})


# for secondary lc list 
def admission_seclclist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    secAdmData=SecondAdm.objects.filter(lcyearofleaving=cy,lcgenerated=True)
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Certificate /",
                    'fname':fname,
                    "page_path":" Leaving Certificate / Secondary Leaving Certificate",
                    "menu_icon":"nav-icon fa fa-certificate",
                    "secAdmData":secAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy
                     }    
                    return render(request, 'schoolviews/lcgenerate/secondary_lclist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Secondary Student List form... Try again")
                    return redirect('admission_seclclist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            secAdmData=SecondAdm.objects.filter(lcyearofleaving=cy,lcgenerated=True)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Certificate /",
            'fname':fname,
            "page_path":" Leaving Certificate / Secondary Leaving Certificate",
            "menu_icon":"nav-icon fa fa-certificate",
            "secAdmData":secAdmData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/lcgenerate/secondary_lclist.html',context) 
    else:
        return redirect('login') 



# for secondary lc View 
def admission_seclcview(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        stud_id=[]
        stud_id.append(int(user_id))
        secData=SecondAdm.objects.filter(pk=user_id)
        context = {
            "secData":secData,
            "stud_id":stud_id,
            "schnameabove":schnameabove,
            "schname":schname,
            "schemail":schemail,
            "schnamebelow":schnamebelow,
            "schUDISEno":schUDISEno,
            "schboard":schboard,
            "schreg":schreg,
            }
        return render(request, 'schoolviews/lcgenerate/secondaryleavingcertificate_view.html',context) 
    else:
        return redirect('login')




# for secondary lc Delete 
def admission_seclcdelete(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            secData=SecondAdm.objects.get(pk=user_id)
            secData.terminatebyprincipal=False
            secData.terminatebyteacher=False
            secData.treason=None
            secData.tyear=None
            secData.tdate=None
            secData.tclass=None
            secData.lcgenerated=False
            srno=int(secData.lcsrno)
            secsrnoData = SecLCSrNo.objects.get(pk=srno)
            secsrnoData.delete()
            secData.lcsrno=None
            secData.lcprogress=None
            secData.lcconduct=None
            secData.lcdateofleaving=None
            secData.lcyearofleaving=None
            secData.lcreason=None
            secData.lcremarks=None
            secData.lctongue=None
            secData.lcreligion=None
            secData.lccaste=None
            secData.lcstudyinginclass=None
            secData.lcadmdate=None
            secData.lcdobinwords=None
            secData.lcissuedate=None
            secData.lcdob=None
            secData.lcprintcount=0
            secData.save()
            messages.success(request,'LC Deleted Sucessfully!')
            return redirect('admission_seclclist')
        except:
            messages.error(request,"Invalid header found in LC Generated form... Try again")
            return redirect('admission_seclclist')    
    else:
        return redirect('login') 



# for secondary lc Original Print 
def admission_seclcorigprint(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            stud_id=[]
            secData1=SecondAdm.objects.get(pk=user_id)
            pc=int(secData1.lcprintcount)
            secData1.lcprintcount=pc+1
            secData1.save()
            secData=SecondAdm.objects.filter(pk=user_id)
            stud_id.append(user_id)
            context = {
                'secData':secData,
                'stud_id':stud_id,
                }
            print(stud_id,secData)
            return render(request,'schoolviews/lcgenerate/secondaryleavingcertificate.html',context)
        except:
            messages.error(request,"Invalid header found in LC Bonafide form... Try again")
            return redirect('admission_seclclist')    
    else:
        return redirect('login')



# secondary LC Export View
def admission_seclcexport(request,cy):
    print("export",cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=SecondaryLCList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('SecondaryLCList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["LC Sr No","Registration Number","Saral ID","Aadhar","Last Name","First Name","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","Last attended school","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Progress","Conduct","Date of leaving school(DD-MM-YYYY)","Standard in which studying and since when","Reason of leaving school","Remarks","Date of Issue"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = SecondAdm.objects.filter(lcyearofleaving=cy).values_list('lcsrno','prn','saral_id','aadhar','lname','fname','faname','moname','nationality','lctongue','lcreligion','lccaste','subcast','pob','lcdob','last_school','lcadmdate','adm_class','division','lcprogress','lcconduct','lcdateofleaving','lcstudyinginclass','lcreason','lcremarks','lcissuedate')
    for row in rows:
        # row[12]-subcast,row[15]-last_school,row[18]-division
        row=list(row)

        if row[12]!=None:
            sc=SubCast.objects.get(id=row[12])
            row[12]=sc.subCastName

        if row[15]!=None:
            os=OtherSch.objects.get(id=row[15])
            row[15]=os.schName

        if row[18]!=None:
            d=Division.objects.get(id=row[18])
            row[18]=d.division
            
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response



#8th pass Certificate Add
def admission_sec8passcertigen(request):
    if request.session.has_key('username'):
        lname=request.user.last_name
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        if request.method == 'POST':
            try:
                stud_id=[]
                studid=request.POST['studid'].split(",")
                passdate=request.POST['sec8passdate'].split('-')
                date=passdate[2]+'-'+passdate[1]+'-'+passdate[0]
                for x in range(0,len(studid)):
                    stud_id.append(int(studid[x]))
                    secData = SecondAdm.objects.get(pk=studid[x])
                    print(studid[x])
                    secData.sec8pass=True
                    secData.sec8passdate=date
                    secData.sec8passyear=passdate[0]
                    secData.save()
                secData=SecondAdm.objects.all()
                context = {
                    'secData':secData,
                    'stud_id':stud_id,
                    }
                print(stud_id)
                return render(request,'schoolviews/8thpasscertificate/secondary8thpasscerti.html',context)
            except:
                messages.error(request,"Invalid header found in Secondary 8th Pass Certificate form... Try again")
                return redirect('admission_sec8passcertigen')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Certificate /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "page_path":" 8th Passed Certificate",
            "menu_icon":"nav-icon fas fa-university",
            }    
        return render(request,'schoolviews/8thpasscertificate/secondary8thpasscertigenerate.html',context) 
    else:
        return redirect('login')




# for Secondary  8th pass ajax
def load_sec8passstudents(request):
    class1 = int(request.GET.get('class1'))
    year = request.GET.get('year')
    div = request.GET.get('div')
    if class1 == 9:
        students = SecondAdm.objects.filter(updateclass9=class1,updateyear9=year,updatedivision9=div,sec8pass=False,updateclass10=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 10:
        students = SecondAdm.objects.filter(updateclass10=class1,updateyear10=year,updatedivision10=div,sec8pass=False,lcgenerated=0,terminatebyprincipal=0)
    print(students)
    return render(request,'schoolviews/lcgenerate/studentslc.html',{"students":students})



# 8th pass Certificate List
def admission_sec8passcertilist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    secAdmData=SecondAdm.objects.filter(sec8passyear=cy,sec8pass=True)
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Certificate /",
                    'fname':fname,
                    "page_path":" 8th Passed Certificate List",
                    "menu_icon":"nav-icon fa fa-certificate",
                    "secAdmData":secAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy
                     }    
                    return render(request, 'schoolviews/8thpasscertificate/secondary8thpasscertilist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Secondary Student List form... Try again")
                    return redirect('admission_sec8passcertilist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            secAdmData=SecondAdm.objects.filter(sec8passyear=cy,sec8pass=True)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Certificate /",
            'fname':fname,
            "page_path":" 8th Passed Certificate List",
            "menu_icon":"nav-icon fa fa-certificate",
            "secAdmData":secAdmData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/8thpasscertificate/secondary8thpasscertilist.html',context) 
    else:
        return redirect('login') 




# 8th pass Certificate View
def admission_sec8passcertiview(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        stud_id=[]
        stud_id.append(int(user_id))
        secData=SecondAdm.objects.filter(pk=user_id)
        context = {
            "secData":secData,
            "stud_id":stud_id,
            }
        return render(request, 'schoolviews/8thpasscertificate/secondary8thpasscerti.html',context) 
    else:
        return redirect('login')    




# 8th pass Certificate delete 
def admission_sec8passcertidelete(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            secData=SecondAdm.objects.get(pk=user_id)
            secData.sec8pass=False
            secData.sec8passdate=None
            secData.sec8passyear=None
            
            secData.save()
            messages.success(request,'Certificate Sucessfully!')
            return redirect('admission_sec8passcertilist')
        except:
            messages.error(request,"Invalid header found in LC Generated form... Try again")
            return redirect('admission_sec8passcertilist')    
    else:
        return redirect('login') 




# 8th pass certificate Export View
def admission_sec8passcertiexport(request,cy):
    print("export",cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=Secondary8thPassCertificateList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Secondary8thPassCertificateList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Registration Number","Last Name","First Name","Father Name","Date of Issue"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = SecondAdm.objects.filter(sec8passyear=cy).values_list('prn','lname','fname','faname','sec8passdate')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response