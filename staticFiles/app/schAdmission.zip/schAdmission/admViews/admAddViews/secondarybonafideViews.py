from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm
from schAdmission.admModels.academicModels import PrimBonafide,SecBonafide,ColBonafide
from schSetup.setupModels.setup_models import Division
from schAdmission.admForms.admissionForms import GetAdmYearForm
from seedData.models import Year
import inflect
import datetime
import xlwt
from xlwt.Formatting import Borders
  
p=inflect.engine()
sname=conf_set.SCHOOL_NAME
schnameabove=conf_set.SCHNAME_ABOVE
schname=conf_set.SCHNAME
schnamebelow=conf_set.SCHNAME_BELOW
schUDISEno=conf_set.SCH_UDISE_NO


# Secondary Bonafide views   

dd = ['','FIRST','SECOND','THIRD','FOURTH','FIFTH','SIXTH','SEVENTH','EIGHTH','NINTH','TENTH','ELEVENTH','TWELVETH','THIRTEENTH','FOURTEENTH','FIFTEENTH','SIXTEENTH','SEVENTEENTH','EIGHTEENTH','NINETEENTH','TWENTIETH','TWENTY FIRST','TWENTY SECOND','TWENTY THIRD','TWENTY FOURTH','TWENTY FIFTH','TWENTY SIXTH','TWENTY SEVENTH','TWENTY EIFHTH','TWENTY NINTH','Thirtieth','THIRTY FIRST']
mm = ['','JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER']


# for Secondary Student 
def admission_secbonafide(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        if request.method == 'POST':
            try:
                studid=request.POST['studid'].split(",")
                class1 = int(request.POST['secbonaclass'])
                year = int(request.POST['secbonayear'])
                for x in range(0,len(studid)):
                    secData=SecondAdm.objects.get(pk=studid[x])
                    secbona=SecBonafide()
                    secbona.prn=secData.prn
                    secbona.lname=secData.lname
                    secbona.fname=secData.fname
                    secbona.faname=secData.faname
                    secbona.breligion=secData.religion
                    secbona.bcast=secData.cast
                    secbona.sec_academic=secData
                    secbona.bona_class=class1

                    # from adm to bonafide
                    date=secData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    print(dobirth)
                    secbona.dob=dobirth

                     # for dob in words
                    yy=p.number_to_words(y).capitalize()
                    yy=yy.replace(" and",'')
                    print(dd[d],mm[m],yy.upper())
                    secbona.dobinwords=dd[d]+' '+mm[m]+' '+yy.upper()

                    secbona.bona_year=str(year)

                    # for issuedate
                    date=request.POST['dateofissue'].split('-')
                    doissue=date[2]+'-'+date[1]+'-'+date[0]
                    print(doissue)
                    secbona.issuedate=doissue

                    secbona.save()
                messages.success(request,'Bonafide issued Successfully!')
                return redirect('admission_secbonafide')
            except:
                messages.error(request,"Invalid header found in Student Bonafide form... Try again")
                return redirect('admission_secbonafide')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Bonafide /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "page_path":"Secondary Bonafide Issue",
            "menu_icon":"far fa-address-card nav-icon",
            }    
        return render(request,'schoolviews/bonafide/secondarybonafidegenerate.html',context) 
    else:
        return redirect('login')


# for Secondary Student  
def load_secstudentsbona(request):
    class1 = int(request.GET.get('class1'))
    year = request.GET.get('year')
    div = request.GET.get('div')
    if class1 == 5:
        students = SecondAdm.objects.filter(updateclass5=class1,updateyear5=year,updatedivision5=div,updateclass6=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 6:
        students = SecondAdm.objects.filter(updateclass6=class1,updateyear6=year,updatedivision6=div,updateclass7=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 7:
        students = SecondAdm.objects.filter(updateclass7=class1,updateyear7=year,updatedivision7=div,updateclass8=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 8:
        students = SecondAdm.objects.filter(updateclass8=class1,updateyear8=year,updatedivision8=div,updateclass9=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 9:
        students = SecondAdm.objects.filter(updateclass9=class1,updateyear9=year,updatedivision9=div,updateclass10=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 10:
        students = SecondAdm.objects.filter(updateclass10=class1,updateyear10=year,updatedivision10=div,lcgenerated=0,terminatebyprincipal=0)
    print(students)
    return render(request,'schoolviews/bonafide/studentsbona.html',{"students":students})




# for Secondary bonafide  list 
def admission_secbonafidelist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    secbonaData=SecBonafide.objects.filter(bona_year=cy)
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Bonafide /",
                    'fname':fname,
                    "page_path":" Secondary Bonafide List",
                    "menu_icon":"far fa-address-card nav-icon",
                    "secbonaData":secbonaData,
                    "getAdmDate":getAdmDate,
                    "cy": cy
                     }    
                    return render(request, 'schoolviews/bonafide/secondary_bonafidelist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Secondary Student List form... Try again")
                    return redirect('admission_secbonafidelist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            secbonaData=SecBonafide.objects.filter(bona_year=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Bonafide /",
            'fname':fname,
            "page_path":" Secondary Bonafide List",
            "menu_icon":"nav-icon far fa-address-card",
            "secbonaData":secbonaData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request,'schoolviews/bonafide/secondary_bonafidelist.html',context) 
    else:
        return redirect('login')




# for Secondary bonafide  View 
def admission_secbonafideview(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        secbonaData=SecBonafide.objects.get(pk=id)
        secData=SecondAdm.objects.get(prn=secbonaData.prn)
        acad_year=int(secbonaData.bona_year)
        acad_year+=1
        context = {
            "secData":secData,
            "secbonaData":secbonaData,
            "acad_year":acad_year,
            "schnameabove":schnameabove,
            "schname":schname,
            "schnamebelow":schnamebelow,
            "schUDISEno":schUDISEno,
            }
        return render(request, 'schoolviews/bonafide/secondarybonafide_view.html',context)
    else:
        return redirect('login')



# for Secondary bonafide Delete 
def admission_secbonafidedelete(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            secbona=SecBonafide.objects.get(pk=id)
            secbona.delete()
            messages.success(request,'Bonafide Deleted Sucessfully!')
            return redirect('admission_secbonafidelist')
        except:
            messages.error(request,"Invalid header found in Bonafide form... Try again")
            return redirect('admission_secbonafidelist')    
    else:
        return redirect('login') 