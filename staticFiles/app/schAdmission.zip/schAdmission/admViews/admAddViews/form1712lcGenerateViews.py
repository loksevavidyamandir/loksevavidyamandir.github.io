from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,PriLCSrNo,SecLCSrNo,ColLCSrNo,Form1710LCSrNo,Form1712LCSrNo
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue,LCRemark
from schAdmission.admForms.admissionForms import GetAdmYearForm
from seedData.models import Year
import inflect
import datetime
import xlwt
from xlwt.Formatting import Borders
p=inflect.engine()
        
  

sname=conf_set.SCHOOL_NAME 
schnameabovemar=conf_set.SCHNAME_ABOVEMAR
schnamemar=conf_set.SCHNAMEMAR
schemail=conf_set.SCHNAME_EMAIL
schnamebelowmar=conf_set.SCHNAME_BELOWMAR
schUDISEno=conf_set.SCH_UDISE_NO
schboard=conf_set.SCH_BOARD
schreg=conf_set.SCH_REG


dd = ['','FIRST','SECOND','THIRD','FOURTH','FIFTH','SIXTH','SEVENTH','EIGHTH','NINTH','TENTH','ELEVENTH','TWELVETH','THIRTEENTH','FOURTEENTH','FIFTEENTH','SIXTEENTH','SEVENTEENTH','EIGHTEENTH','NINETEENTH','TWENTIETH','TWENTY FIRST','TWENTY SECOND','TWENTY THIRD','TWENTY FOURTH','TWENTY FIFTH','TWENTY SIXTH','TWENTY SEVENTH','TWENTY EIGHTH','TWENTY NINTH','THIRTIETH','THIRTY FIRST']
mm = ['','JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER']

# for form1712 LC Generate
def admission_form1712lcgenerate(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        remarkData = LCRemark.objects.all()
        if request.method == 'POST':
            try:
                studid=request.POST['studid']
                form1712Data = Form1712Adm.objects.get(pk=int(studid))
                userData = User.objects.get(pk=studid)
                userData.is_active=False
                userData.save()
                form1712Data.seatnoandyear=request.POST['seatnoandyear'].upper()
                date=request.POST['lcdateofpass'].split('-')
                doleave=date[2]+'-'+date[1]+'-'+date[0]
                print(doleave)
                form1712Data.lcdateofpassing=doleave
                form1712Data.lcyearofpassing=date[0]
                if request.POST['lcdateofissue'] !="":
                    date=request.POST['lcdateofissue'].split('-')
                    doissue=date[2]+'-'+date[1]+'-'+date[0]
                    print(doissue)
                    form1712Data.lcissuedate=doissue
                else:
                    form1712Data.lcissuedate=None

                date=form1712Data.dob.split('-')
                dobirth=date[2]+'-'+date[1]+'-'+date[0]
                d=int(date[2])
                m=int(date[1])
                y=int(date[0])
                print(dobirth)
                form1712Data.lcdob=dobirth

                # for dob in words
                yy=p.number_to_words(y).capitalize()
                yy=yy.replace(" and",'')
                print(dd[d],mm[m],yy.upper())
                form1712Data.lcdobinwords=dd[d]+' '+mm[m]+' '+yy.upper()

                date=form1712Data.admdate.split('-')
                print("ADM Date",form1712Data.admdate)
                admdate=date[2]+'-'+date[1]+'-'+date[0]
                print(admdate)

                form1712Data.lcadmdate=admdate
                form1712srnoData = Form1712LCSrNo()
                form1712srnoData.srnotext="a"
                form1712srnoData.save()
                form1712Data.lcgenerated=True
                form1712Data.lcsrno=form1712srnoData.id
                form1712Data.lctongue=str(form1712Data.tongue)
                form1712Data.lcreligion=str(form1712Data.religion)
                form1712Data.lccaste=str(form1712Data.cast)
                form1712Data.lcprintcount=1
                form1712Data.save()
                lc = Form1712Adm.objects.get(pk=int(studid))
                context = {
                        'lc':lc,
                        "schnameabovemar":schnameabovemar,
                        "schnamemar":schnamemar,
                        "schemail":schemail,
                        "schnamebelowmar":schnamebelowmar,
                        "schUDISEno":schUDISEno,
                        "schboard":schboard,
                        "schreg":schreg,
                        }
                return render(request,'schoolviews/lcgenerate/form1712leavingcertificate.html',context)
            except:
                messages.error(request,"Invalid header found in LC Generated form... Try again")
                return redirect('admission_form1712lcgenerate')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Certificate /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "remarkData":remarkData,
            "page_path":"Form-17 HSC  LC Generate ",
            "menu_icon":"nav-icon fas fa-university",
            }
        return render(request,'schoolviews/lcgenerate/form1712lcgenerate.html',context) 
    else:
        return redirect('login')



# for form1712  LC 
def load_form1712studentslc(request):
    year = request.GET.get('year')
    stream = request.GET.get('stream')
    students = Form1712Adm.objects.filter(admyear=year,admission_faculty=stream,lcgenerated=0)
    print(students)
    return render(request,'schoolviews/lcgenerate/studentsform17lc.html',{"students":students})



# for form1712 lc list
def admission_form1712lclist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    form1712AdmData=Form1712Adm.objects.filter(lcyearofpassing=cy,lcgenerated=True)
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Certificate /",
                    'fname':fname,
                    "page_path":" Leaving Certificate / Form-17 HSC Leaving Certificate",
                    "menu_icon":"nav-icon fa fa-certificate",
                    "form1712AdmData":form1712AdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy,
                     }    
                    return render(request, 'schoolviews/lcgenerate/form1710_lclist.html',context) 
                except:
                    messages.error(request,"Invalid header found in College Student List form... Try again")
                    return redirect('admission_form1710lclist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            form1712AdmData=Form1712Adm.objects.filter(lcyearofpassing=cy,lcgenerated=True)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Certificate /",
            'fname':fname,
            "page_path":" Leaving Certificate / Form-17 HSC Leaving Certificate",
            "menu_icon":"nav-icon fa fa-certificate",
            "form1712AdmData":form1712AdmData,
            "getAdmDate":getAdmDate,
            "cy" : cy,
            }    
        return render(request, 'schoolviews/lcgenerate/form1712_lclist.html',context) 
    else:
        return redirect('login') 



# for form1712 lc View 
def admission_form1712lcview(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        lc = Form1712Adm.objects.get(pk=user_id)
        pc=int(lc.lcprintcount)
        lc.lcprintcount=pc+1
        lc.save()
        context = {
            "lc":lc,
            "schnameabovemar":schnameabovemar,
            "schnamemar":schnamemar,
            "schemail":schemail,
            "schnamebelowmar":schnamebelowmar,
            "schUDISEno":schUDISEno,
            "schboard":schboard,
            "schreg":schreg,
            }
        return render(request, 'schoolviews/lcgenerate/form1712leavingcertificate.html',context) 
    else:
        return redirect('login')




# for form1712 lc Delete 
def admission_form1712lcdelete(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            form1712=Form1712Adm.objects.get(pk=user_id)
            form1712.lcgenerated=False
            srno=int(form1712.lcsrno)
            form1712srnoData = Form1712LCSrNo.objects.get(pk=srno)
            form1712srnoData.delete()
            form1712.lcsrno=None
            form1712.lcdateofpassing=None
            form1712.lcyearofpassing=None
            form1712.lctongue=None
            form1712.lcreligion=None
            form1712.lccaste=None
            form1712.seatnoandyear=None
            form1712.lcadmdate=None
            form1712.lcdobinwords=None
            form1712.lcissuedate=None
            form1712.lcdob=None
            form1712.lcprintcount=0
            form1712.save()
            messages.success(request,'LC Deleted Sucessfully!')
            return redirect('admission_form1712lclist')
        except:
            messages.error(request,"Invalid header found in LC Bonafide form... Try again")
            return redirect('admission_form1712lclist')    
    else:
        return redirect('login') 



# form1712 LC Export View
def admission_form1712lcexport(request,cy):
    print("export",cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=Form17HSCLCList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Form17HSCLCList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["LC Sr No","Registration Number","Saral ID","Aadhar","Last Name","First Name","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","Last attended school","Previous LC Sr No","Previous Registration No","Admission Date(DD-MM-YYYY)","Admission Faculty"," Date of Passing Std X.(DD-MM-YYYY)","Seat No. & Year of Passing Std X.","Date of Issue"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = Form1712Adm.objects.filter(lcyearofpassing=cy).values_list('lcsrno','prn','saral_id','aadhar','lname','fname','faname','moname','nationality','lctongue','lcreligion','lccaste','subcast','pob','lcdob','last_school','prevlcsrno','prevprn','lcadmdate','admission_faculty','lcdateofpassing','lcdateofpassing','seatnoandyear','lcissuedate')
    for row in rows:
        # row[12]-subcast,row[15]-last_school,row[18]-division
        row=list(row)

        if row[12]!=None:
            sc=SubCast.objects.get(id=row[12])
            row[12]=sc.subCastName

        if row[15]!=None:
            os=OtherSch.objects.get(id=row[15])
            row[15]=os.schName
            
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response