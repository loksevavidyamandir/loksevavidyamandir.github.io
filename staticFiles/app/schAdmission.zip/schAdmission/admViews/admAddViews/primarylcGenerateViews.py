from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,PriLCSrNo
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue,LCRemark
from schAdmission.admForms.admissionForms import GetAdmYearForm
from seedData.models import Year
import inflect
import datetime
import xlwt
from xlwt.Formatting import Borders
p=inflect.engine()
        
  

sname=conf_set.SCHOOL_NAME
schnameabove=conf_set.SCHNAME_ABOVE
schname=conf_set.SCHNAME
schemail=conf_set.SCHNAME_EMAIL
schnamebelow=conf_set.SCHNAME_BELOW
schUDISEno=conf_set.SCH_UDISE_NO
schboard=conf_set.SCH_BOARD
schreg=conf_set.SCH_REG


dd = ['','FIRST','SECOND','THIRD','FOURTH','FIFTH','SIXTH','SEVENTH','EIGHTH','NINTH','TENTH','ELEVENTH','TWELVETH','THIRTEENTH','FOURTEENTH','FIFTEENTH','SIXTEENTH','SEVENTEENTH','EIGHTEENTH','NINETEENTH','TWENTIETH','TWENTY FIRST','TWENTY SECOND','TWENTY THIRD','TWENTY FOURTH','TWENTY FIFTH','TWENTY SIXTH','TWENTY SEVENTH','TWENTY EIGHTH','TWENTY NINTH','THIRTIETH','THIRTY FIRST']
mm = ['','JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER']

# for primary LC Generate
def admission_prilcgenerate(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        remarkData = LCRemark.objects.all()
        if request.method == 'POST':
            try:
                stud_id=[]
                studid=request.POST['studid'].split(",")
                for x in range(0,len(studid)):
                    stud_id.append(int(studid[x]))
                    priData = PrimAdm.objects.get(pk=studid[x])
                    userData = User.objects.get(pk=studid[x])
                    userData.is_active=False
                    userData.save()
                    date=request.POST['lcdateofleaving'].split('-')
                    doleave=date[2]+'-'+date[1]+'-'+date[0]
                    print(doleave)
                    priData.lcdateofleaving=doleave
                    priData.lcyearofleaving=date[0]
                    if request.POST['lcdateofissue'] !="":
                        date=request.POST['lcdateofissue'].split('-')
                        doissue=date[2]+'-'+date[1]+'-'+date[0]
                        print(doissue)
                        priData.lcissuedate=doissue
                    else:
                        priData.lcissuedate=None

                    date=priData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    print(dobirth)
                    priData.lcdob=dobirth

                    # for dob in words
                    yy=p.number_to_words(y).capitalize()
                    yy=yy.replace(" and",'')
                    print(dd[d],mm[m],yy.upper())
                    priData.lcdobinwords=dd[d]+' '+mm[m]+' '+yy.upper()

                    date=priData.admdate.split('-')
                    print("ADM Date",priData.admdate)
                    admdate=date[2]+'-'+date[1]+'-'+date[0]
                    print(admdate)
                    priData.lcadmdate=admdate


                    prisrnoData = PriLCSrNo()
                    prisrnoData.srnotext="a"
                    prisrnoData.save()
                    priData.lcgenerated=True
                    priData.lcsrno=prisrnoData.id
                    priData.lcprogress=request.POST['lcprogress']
                    priData.lcconduct=request.POST['lcconduct']
                    priData.lcreason=request.POST['lcreason'].upper()
                    priData.lcremarks=request.POST['lcremarks']
                    priData.lctongue=str(priData.tongue)
                    priData.lcreligion=str(priData.religion)
                    priData.lccaste=str(priData.cast)
                    priData.lcstudyinginclass=request.POST['lcstudyinginclass'].upper()
                    priData.lcprintcount=1
                    priData.save()
                    print(priData.tongue)
                if request.POST.get('submit_print'):
                    priData=PrimAdm.objects.all()
                    print(priData)
                    context = {
                        'priData':priData,
                        'stud_id':stud_id,
                        }
                    print(stud_id)
                    return render(request,'schoolviews/lcgenerate/primaryleavingcertificate.html',context)
                elif request.POST.get('submit_pdf'):
                    for x in range(0,len(studid)):
                        priData = PrimAdm.objects.get(pk=studid[x])
                        priData.lcprintcount=0
                        priData.save()
                    priData=PrimAdm.objects.all()
                    print(priData)
                    context = {
                        'priData':priData,
                        'stud_id':stud_id,
                        }
                    print(stud_id)
                    return render(request,'schoolviews/lcgenerate/primaryleavingcertificate_view.html',context)
                print(1)
            except:
                messages.error(request,"Invalid header found in LC Generated form... Try again")
                return redirect('admission_prilcgenerate')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Certificate /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "remarkData":remarkData,
            "page_path":"Primary LC Generate ",
            "menu_icon":"nav-icon fas fa-university",
            }
        return render(request,'schoolviews/lcgenerate/primarylcgenerate.html',context) 
    else:
        return redirect('login')



# for primary terminate LC Generate
def admission_priterlcgenerate(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        remarkData = LCRemark.objects.all()
        if request.method == 'POST':
            try:
                stud_id=[]
                stud_id.append(int(user_id))
                priData = PrimAdm.objects.get(pk=user_id)
                date=request.POST['lcdateofleaving'].split('-')
                doleave=date[2]+'-'+date[1]+'-'+date[0]
                print(doleave)
                priData.lcdateofleaving=doleave
                priData.lcyearofleaving=date[0]
                if request.POST['lcdateofissue'] !="":
                    date=request.POST['lcdateofissue'].split('-')
                    doissue=date[2]+'-'+date[1]+'-'+date[0]
                    print(doissue)
                    priData.lcissuedate=doissue
                else:
                    priData.lcissuedate=None

                date=priData.dob.split('-')
                dobirth=date[2]+'-'+date[1]+'-'+date[0]
                d=int(date[2])
                m=int(date[1])
                y=int(date[0])
                print(dobirth)
                priData.lcdob=dobirth

                # for dob in words
                yy=p.number_to_words(y).capitalize()
                yy=yy.replace(" and",'')
                print(dd[d],mm[m],yy.upper())
                priData.lcdobinwords=dd[d]+' '+mm[m]+' '+yy.upper()

                date=priData.admdate.split('-')
                print("ADM Date",priData.admdate)
                admdate=date[2]+'-'+date[1]+'-'+date[0]
                print(admdate)
                priData.lcadmdate=admdate

                prisrnoData = PriLCSrNo()
                prisrnoData.srnotext="a"
                prisrnoData.save()
                priData.lcgenerated=True
                priData.terminatebyprincipal=True
                priData.lcsrno=prisrnoData.id
                priData.lcprogress=request.POST['lcprogress']
                priData.lcconduct=request.POST['lcconduct']
                priData.lcreason=request.POST['lcreason']
                priData.lcremarks=request.POST['lcremarks']
                priData.lctongue=str(priData.tongue)
                priData.lcreligion=str(priData.religion)
                priData.lccaste=str(priData.cast)
                priData.lcstudyinginclass=request.POST['lcstudyinginclass'].upper()
                priData.lcprintcount=1
                priData.save()
                priData=PrimAdm.objects.all()
                print(priData)
                context = {
                    'priData':priData,
                    'stud_id':stud_id,
                    }
                return render(request,'schoolviews/lcgenerate/primaryleavingcertificate.html',context)
            except:
                messages.error(request,"Invalid header found in LC Generated form... Try again")
                return redirect('academic_priterminatedeclist')
    else:
        return redirect('login')



# for primary LC 
def load_pristudentslc(request):
    class1 = int(request.GET.get('class1'))
    year = request.GET.get('year')
    div = request.GET.get('div')
    if class1 == 1:
        students = PrimAdm.objects.filter(updateclass1=class1,updateyear1=year[0:4],updatedivision1=div,updateclass2=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 2:
        students = PrimAdm.objects.filter(updateclass2=class1,updateyear2=year[0:4],updatedivision2=div,updateclass3=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 3:
        students = PrimAdm.objects.filter(updateclass3=class1,updateyear3=year[0:4],updatedivision3=div,updateclass4=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 4:
        students = PrimAdm.objects.filter(updateclass4=class1,updateyear4=year[0:4],updatedivision4=div,lcgenerated=0,terminatebyprincipal=0)
    print(students)
    return render(request,'schoolviews/lcgenerate/studentslc.html',{"students":students})


# for primary lc list 
def admission_prilclist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy[0:4])
                    priAdmData=PrimAdm.objects.filter(lcyearofleaving=cy[0:4],lcgenerated=True)
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Certificate /",
                    'fname':fname,
                    "page_path":" Leaving Certificate / Primary Leaving Certificate",
                    "menu_icon":"nav-icon fa fa-certificate",
                    "priAdmData":priAdmData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                    }    
                    return render(request, 'schoolviews/lcgenerate/primary_lclist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Primary Student List form... Try again")
                    return redirect('admission_prilclist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            priAdmData=PrimAdm.objects.filter(lcyearofleaving=cy,lcgenerated=True)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Certificate /",
            'fname':fname,
            "page_path":" Leaving Certificate / Primary Leaving Certificate",
            "menu_icon":"nav-icon fa fa-certificate",
            "priAdmData":priAdmData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/lcgenerate/primary_lclist.html',context) 
    else:
        return redirect('login') 



# for primary lc View 
def admission_prilcview(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        stud_id=[]
        stud_id.append(int(user_id))
        priData=PrimAdm.objects.filter(pk=user_id)
        print(priData)
        context = {
            'priData':priData,
            'stud_id':stud_id,
            "schnameabove":schnameabove,
            "schname":schname,
            "schemail":schemail,
            "schnamebelow":schnamebelow,
            "schUDISEno":schUDISEno,
            "schboard":schboard,
            "schreg":schreg,
            }
        return render(request, 'schoolviews/lcgenerate/primaryleavingcertificate_view.html',context) 
    else:
        return redirect('login') 




# for primary lc Delete 
def admission_prilcdelete(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            priData=PrimAdm.objects.get(pk=user_id)
            priData.terminatebyprincipal=False
            priData.terminatebyteacher=False
            priData.treason=None
            priData.tyear=None
            priData.tdate=None
            priData.tclass=None
            priData.lcgenerated=False
            srno=int(priData.lcsrno)
            prisrnoData = PriLCSrNo.objects.get(pk=srno)
            prisrnoData.delete()
            priData.lcsrno=None
            priData.lcprogress=None
            priData.lcconduct=None
            priData.lcdateofleaving=None
            priData.lcyearofleaving=None
            priData.lcreason=None
            priData.lcremarks=None
            priData.lctongue=None
            priData.lcreligion=None
            priData.lccaste=None
            priData.lcstudyinginclass=None
            priData.lcadmdate=None
            priData.lcdobinwords=None
            priData.lcissuedate=None
            priData.lcdob=None
            priData.lcprintcount=0
            priData.save()
            messages.success(request,'LC Deleted Sucessfully!')
            return redirect('admission_prilclist')
        except:
            messages.error(request,"Invalid header found in LC Bonafide form... Try again")
            return redirect('admission_prilclist')    
    else:
        return redirect('login') 



# for primary lc Original Print 
def admission_prilcorigprint(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            stud_id=[]
            priData1=PrimAdm.objects.get(pk=user_id)
            pc=int(priData1.lcprintcount)
            priData1.lcprintcount=pc+1
            priData1.save()
            priData=PrimAdm.objects.filter(pk=user_id)
            stud_id.append(user_id)
            context = {
                'priData':priData,
                'stud_id':stud_id,
                }
            print(stud_id,priData)
            return render(request,'schoolviews/lcgenerate/primaryleavingcertificate.html',context)
        except:
            messages.error(request,"Invalid header found in LC Generated form... Try again")
            return redirect('admission_prilclist')    
    else:
        return redirect('login')



# Primary LC Export View
def admission_prilcexport(request,cy):
    print("export",cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=PrimaryLCList'+cy+'.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('PrimaryLCList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["LC Sr No","Registration Number","Saral ID","Aadhar","Last Name","First Name","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","Last attended school","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Progress","Conduct","Date of leaving school(DD-MM-YYYY)","Standard in which studying and since when","Reason of leaving school","Remarks","Date of Issue"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = PrimAdm.objects.filter(lcyearofleaving=cy).values_list('lcsrno','prn','saral_id','aadhar','lname','fname','faname','moname','nationality','lctongue','lcreligion','lccaste','subcast','pob','lcdob','last_school','lcadmdate','adm_class','division','lcprogress','lcconduct','lcdateofleaving','lcstudyinginclass','lcreason','lcremarks','lcissuedate')
    print(rows)
    for row in rows:
        # row[12]-subcast,row[15]-last_school,row[18]-division
        row=list(row)

        if row[12]!=None:
            sc=SubCast.objects.get(id=row[12])
            row[12]=sc.subCastName

        if row[15]!=None:
            os=OtherSch.objects.get(id=row[15])
            row[15]=os.schName

        if row[18]!=None:
            d=Division.objects.get(id=row[18])
            row[18]=d.division
            
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response