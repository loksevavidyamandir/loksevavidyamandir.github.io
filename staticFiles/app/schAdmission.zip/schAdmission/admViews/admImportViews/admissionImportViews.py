from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import  Division,MTongue,OtherSch,ImportData
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schSetup.setupForms.setup_forms import ImportDataForm
from seedData.models import Year
import re

import xlwt
from xlwt.Formatting import Borders
import xlrd
import os

basedir=conf_set.BASE_DIR
sname=conf_set.SCHOOL_NAME



yearData=Year.objects.all()

#primary Import
def admission_prim_import(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        yearData=Year.objects.all()
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    admyear=str(request.POST['year'])
                    print(admyear[0:4])
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr) # 1
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):

                                try:
                                    prn=str(int(inputWorksheet.cell_value(y,0)))
                                except:
                                    messages.error(request,"Register Number should contain only numbers")
                                    return redirect('admission_primimport')

                                try:
                                    aadhar=str(int(inputWorksheet.cell_value(y,6)))
                                except:
                                    messages.error(request,"Aadhar Number should contain only numbers")
                                    return redirect('admission_primimport')

                                if PrimAdm.objects.filter(prn__iexact=prn).exists():
                                    messages.error(request,"Register Number Already Exists")
                                    return redirect('admission_primimport')
                                elif PrimAdm.objects.filter(aadhar__iexact=aadhar).exists():
                                    messages.error(request,"Aadhar Number Already Exists")
                                    return redirect('admission_primimport')
                                elif PrimAdm.objects.filter(email__iexact=str(inputWorksheet.cell_value(y,31))).exists():
                                    messages.error(request,"Email Id Already Exists")
                                    return redirect('admission_primimport')
                                else:
                                    priAdmModule=PrimAdm()
                                    #for prn validation
                                    priAdmModule.prn=prn
                                    if inputWorksheet.cell_value(y,1) == "":
                                        messages.error(request,"Student Last Name required")
                                        return redirect('admission_primimport')
                                    priAdmModule.lname=str(inputWorksheet.cell_value(y,1)).upper()
                                    # for first name    
                                    if inputWorksheet.cell_value(y,2) == "":
                                        messages.error(request,"Student First Name required")
                                        return redirect('admission_primimport')
                                    priAdmModule.fname=str(inputWorksheet.cell_value(y,2)).upper()
                                    # for Father name  
                                    if inputWorksheet.cell_value(y,3) == "":
                                        messages.error(request,"Student Father Name required")
                                        return redirect('admission_primimport')  
                                    priAdmModule.faname=str(inputWorksheet.cell_value(y,3)).upper()
                                    # for Mother name    
                                    if inputWorksheet.cell_value(y,4) == "":
                                        messages.error(request,"Student Mother Name required")
                                        return redirect('admission_primimport')
                                    priAdmModule.moname=str(inputWorksheet.cell_value(y,4)).upper()
                                    priAdmModule.mrname=str(inputWorksheet.cell_value(y,5))
                                    #for aadhar validation
                                    print(aadhar)
                                    leng=len(aadhar)
                                    print(leng)
                                    if leng == 12 or leng == 13:
                                        priAdmModule.aadhar=aadhar
                                    else:
                                        messages.error(request,"Aadhar Number is 12 or 13 digits")
                                        return redirect('admission_primimport')
                                        
                                    priAdmModule.saral_id=str(inputWorksheet.cell_value(y,7))
                                    natlist=['INDIAN','AFGHAN','BANGLADESHI','NEPALESE']
                                    n=str(inputWorksheet.cell_value(y,8)).upper()
                                    if n in natlist:
                                        print(n)
                                        priAdmModule.nationality=n
                                    else:
                                        messages.error(request,"Nationality Does not exists : "+n)
                                        return redirect('admission_primimport')
                                    tong=str(inputWorksheet.cell_value(y,9)).upper()
                                    # For Mother Tongue
                                    if MTongue.objects.filter(m_tongue=tong).exists():
                                        priAdmModule.tongue=MTongue.objects.get(m_tongue=tong)
                                    else:
                                        messages.error(request,"Mother Tongue Does not exists "+tong)
                                        return redirect('admission_primimport')
                                    # For Religion
                                    rel=str(inputWorksheet.cell_value(y,10)).upper()
                                    if Religion.objects.filter(religionName=rel).exists():
                                        priAdmModule.religion=Religion.objects.get(religionName=rel)
                                    else:
                                        messages.error(request,"Religion Does not exists "+rel)
                                        return redirect('admission_primimport')
                                    # For Caste
                                    cast=str(inputWorksheet.cell_value(y,11)).upper()
                                    if Cast.objects.filter(castName=cast).exists():
                                        priAdmModule.cast=Cast.objects.get(castName=cast)
                                    else:
                                        messages.error(request,"Caste Does not exists "+cast)
                                        return redirect('admission_primimport')
                                    # For SubCaste
                                    scast=str(inputWorksheet.cell_value(y,13)).upper()
                                    if SubCast.objects.filter(subCastName=scast).exists():
                                        priAdmModule.subcast=SubCast.objects.get(subCastName=scast)
                                    elif scast=="":
                                        pass
                                    else:
                                        messages.error(request,"SubCaste Does not exists "+scast)
                                        return redirect('admission_primimport')
                                    minlist=['YES','NO']
                                    mino = str(inputWorksheet.cell_value(y,14)).upper()
                                    if mino in minlist:
                                        print(mino)
                                        priAdmModule.minority=mino
                                    else:
                                        messages.error(request,"Minority Does not exists : "+mino)
                                        return redirect('admission_primimport')
                                    print(1)
                                    if inputWorksheet.cell_value(y,15) == "":
                                        messages.error(request,"Place of Birth is Required")
                                        return redirect('admission_primimport')
                                    priAdmModule.pob=str(inputWorksheet.cell_value(y,15)).upper()
                                    dob=str(inputWorksheet.cell_value(y,16))
                                    leng=len(dob)
                                    if leng==10:
                                        if dob[4]=='-' and dob[7]=='-':
                                            priAdmModule.dob=dob
                                        else:
                                            messages.error(request,"Invalid Date Of Birth "+dob)
                                            return redirect('admission_primimport')
                                    else:
                                        messages.error(request,"Invalid Date Of Birth "+dob)
                                        return redirect('admission_primimport')
                                    print(2)
                                    # priAdmModule.dob=inputWorksheet.cell_value(y,16)
                                    # For Last attended school
                                    last_s=str(inputWorksheet.cell_value(y,17)).upper()
                                    if last_s=="":
                                        pass
                                    elif OtherSch.objects.filter(schName=last_s).exists():
                                        priAdmModule.last_school=OtherSch.objects.get(schName=last_s)
                                    else:
                                        messages.error(request,"School Name Does not exists "+last_s)
                                        return redirect('admission_primimport')
                                    print(3)
                                    
                                    # for last class
                                    if inputWorksheet.cell_value(y,18)!="":
                                        try:
                                            last_class=str(int(inputWorksheet.cell_value(y,18)))
                                        except:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_primimport')
                                        last_classlist=['1','2','3']
                                        if last_class=="":
                                            pass
                                        elif last_class in last_classlist:
                                            priAdmModule.last_class=last_class
                                        else:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_primimport')
                                    print(4)
                                    try:
                                        if inputWorksheet.cell_value(y,19) == "":
                                            pass
                                        else:
                                            priAdmModule.prevlcsrno=str(int(inputWorksheet.cell_value(y,19)))
                                    except:
                                        messages.error(request,"Invalid Previous LC Sr No")
                                        return redirect('admission_primimport')
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,20) == "":
                                            pass
                                        else:
                                            priAdmModule.prevprn=str(int(inputWorksheet.cell_value(y,20)))
                                    except:
                                        messages.error(request,"Invalid Pervious Registration Number")
                                        return redirect('admission_primimport')
                                    admdate=str(inputWorksheet.cell_value(y,21))
                                    leng=len(admdate)
                                    if leng==10:
                                        if admdate[4]=='-' and admdate[7]=='-':
                                            priAdmModule.admdate=admdate
                                        else:
                                            messages.error(request,"Invalid Admission Date "+admdate)
                                            return redirect('admission_primimport')
                                    else:
                                        messages.error(request,"Invalid Admission Date "+admdate)
                                        return redirect('admission_primimport')
                                    priAdmModule.admyear=admyear[0:4]
                                    # for Adm class
                                    try:
                                        adm_class=str(int(inputWorksheet.cell_value(y,22)))
                                    except:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_primimport')
                                    adm_classlist=['1','2','3','4']
                                    if adm_class in adm_classlist:
                                        priAdmModule.adm_class=adm_class
                                    else:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_primimport')
                                    # For Division
                                    div=str(inputWorksheet.cell_value(y,23)).upper()
                                    if div == "":
                                        pass
                                    elif Division.objects.filter(division=div).exists():
                                        priAdmModule.division=Division.objects.get(division=div)
                                    else:
                                        messages.error(request,"Division Does not exists "+div)
                                        return redirect('admission_primimport')

                                    try:
                                        if inputWorksheet.cell_value(y,24)=="":
                                            pass
                                        else:
                                            priAdmModule.rollno=str(int(inputWorksheet.cell_value(y,24)))
                                            rollno=str(int(inputWorksheet.cell_value(y,24)))
                                    except:
                                        messages.error(request,"Invalid Roll Number")
                                        return redirect('admission_primimport')
                                    # for late Adm 
                                    lateadm=str(inputWorksheet.cell_value(y,25)).upper()
                                    lateadmlist=['YES','NO']
                                    if lateadm in lateadmlist:
                                        priAdmModule.lateadm=lateadm
                                    else:
                                        messages.error(request,"Invalid Late Admission ")
                                        return redirect('admission_primimport')
                                    # for adm type
                                    admtype=str(inputWorksheet.cell_value(y,26)).upper()
                                    admtypelist=['FRESHER','REPETER','ONE TIME FAILED']
                                    if admtype in admtypelist:
                                        priAdmModule.admtype=admtype
                                    else:
                                        messages.error(request,"Invalid Admission Type")
                                        return redirect('admission_primimport')
                                    # for hostel
                                    hostel=str(inputWorksheet.cell_value(y,27)).upper()
                                    hostellist=['YES','NO']
                                    if hostel in hostellist:
                                        priAdmModule.hostel=hostel
                                    else:
                                        messages.error(request,"Invalid Hostel")
                                        return redirect('admission_primimport')
                                    # for Gender
                                    sex=str(inputWorksheet.cell_value(y,28)).upper()
                                    sexlist=['MALE','FEMALE','OTHER']
                                    if sex in sexlist:
                                        priAdmModule.sex=sex
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_primimport')
                                    priAdmModule.pwd=str(inputWorksheet.cell_value(y,29)).upper()
                                    priAdmModule.bgroup=str(inputWorksheet.cell_value(y,30)).upper()
                                    #for Email validation
                                    email=str(inputWorksheet.cell_value(y,31))
                                    regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'
                                    if(re.search(regex, email)):
                                        priAdmModule.email=str(email)
                                    else:
                                        messages.error(request,"Invalid Email Id")
                                        return redirect('admission_primimport')

                                    # for Gender
                                    areaType=str(inputWorksheet.cell_value(y,32)).upper()
                                    areaTypelist=['RURAL','URBAN']
                                    if areaType in areaTypelist:
                                        priAdmModule.areaType=areaType
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_primimport')
                                    priAdmModule.caddress=str(inputWorksheet.cell_value(y,33)).upper()
                                    # for current address == permanent adderss
                                    if inputWorksheet.cell_value(y,33).upper()==inputWorksheet.cell_value(y,34).upper():
                                        priAdmModule.ca_is_pa_addr="YES"
                                        priAdmModule.paddress=str(inputWorksheet.cell_value(y,33)).upper()
                                    else:
                                        priAdmModule.ca_is_pa_addr="NO"
                                        priAdmModule.paddress=str(inputWorksheet.cell_value(y,34)).upper()

                                    #for father mobile no
                                    try:
                                        fa_mob=str(inputWorksheet.cell_value(y,35))
                                        if fa_mob=="":
                                            pass
                                        else:
                                            fa_mob=str(int(inputWorksheet.cell_value(y,35)))
                                    except:
                                        messages.error(request,"Father Mobile Number should contain only numbers")
                                        return redirect('admission_primimport')
                                    print(fa_mob)
                                    leng=len(fa_mob)
                                    if fa_mob =="":
                                        priAdmModule.fa_mob=fa_mob
                                    elif leng == 10:
                                        priAdmModule.fa_mob=fa_mob
                                    else:
                                        messages.error(request,"Father Mobile Number should be 10 digits")
                                        return redirect('admission_primimport')
                                    print(fa_mob)
                                    
                                    #for mother mobile no
                                    try:
                                        mo_mob=str(inputWorksheet.cell_value(y,36))
                                        if mo_mob=="":
                                            pass
                                        else:
                                            mo_mob=str(int(inputWorksheet.cell_value(y,36)))
                                    except:
                                        messages.error(request,"Mother Mobile Number should contain only numbers")
                                        return redirect('admission_primimport')
                                    leng=len(mo_mob)
                                    if mo_mob =="":
                                        priAdmModule.mo_mob=mo_mob
                                    elif leng == 10:
                                        priAdmModule.mo_mob=mo_mob
                                    else:
                                        messages.error(request,"Mother Mobile Number should be 10 digits")
                                        return redirect('admission_primimport')
                                    
                                    priAdmModule.fa_occu=str(inputWorksheet.cell_value(y,37)).upper()
                                    priAdmModule.mo_occu=str(inputWorksheet.cell_value(y,38)).upper()
                                    priAdmModule.fam_income=str(inputWorksheet.cell_value(y,39))
                                    # for bpl
                                    bpl=str(inputWorksheet.cell_value(y,40)).upper()
                                    bpllist=['YES','NO']
                                    if bpl in bpllist:
                                        priAdmModule.bpl=bpl
                                    else:
                                        messages.error(request,"Invalid BPL")
                                        return redirect('admission_primimport')
                                    #for Guardian is
                                    gis=str(inputWorksheet.cell_value(y,41)).upper()
                                    glist=['FATHER','MOTHER','OTHER']
                                    if gis in glist:
                                        priAdmModule.gis=gis
                                    else:
                                        messages.error(request,"Invalid Guardian Is")
                                        return redirect('admission_primimport')
                                    priAdmModule.ganame=str(inputWorksheet.cell_value(y,42)).upper()
                                    try:
                                        ga_mob=str(inputWorksheet.cell_value(y,43))
                                        if ga_mob=="":
                                            pass
                                        else:
                                            ga_mob=str(int(inputWorksheet.cell_value(y,43)))
                                    except:
                                        messages.error(request,"Guardian Mobile Number should contain only numbers")
                                        return redirect('admission_primimport')
                                    leng=len(ga_mob)
                                    if ga_mob =="":
                                        priAdmModule.ga_mob=ga_mob
                                    elif leng == 10:
                                        priAdmModule.ga_mob=ga_mob
                                    else:
                                        messages.error(request,"Guardian Mobile Number should be 10 digits")
                                        return redirect('admission_primimport')
                                    priAdmModule.ga_occu=str(inputWorksheet.cell_value(y,44)).upper()
                                    priAdmModule.gaddress=str(inputWorksheet.cell_value(y,45)).upper()
                                    priAdmModule.ga_relation=str(inputWorksheet.cell_value(y,46)).upper()

                                    try:
                                        if inputWorksheet.cell_value(y,47)=="":
                                            pass
                                        else:
                                            priAdmModule.baccount=str(int(inputWorksheet.cell_value(y,47)))
                                    except:
                                        messages.error(request,"Invalid Bank Account Number")
                                        return redirect('admission_primimport')

                                    priAdmModule.bankname=str(inputWorksheet.cell_value(y,48)).upper()
                                    priAdmModule.ifsc=str(inputWorksheet.cell_value(y,49))
                                    priAdmModule.branch=str(inputWorksheet.cell_value(y,50)).upper()
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,51)=="":
                                            pass
                                        else:
                                            priAdmModule.micr=str(int(inputWorksheet.cell_value(y,51)))
                                    except:
                                        messages.error(request,"Invalid MICR Code")
                                        return redirect('admission_primimport')

                                    priAdmModule.note=str(inputWorksheet.cell_value(y,52))

                                    # Create User for Student
                                    print(5)
                                    user=User.objects.create_user(username=aadhar,email=str(inputWorksheet.cell_value(y,31)),password="Admin@123",first_name=str(inputWorksheet.cell_value(y,2)).upper(),last_name=str(inputWorksheet.cell_value(y,1)).upper())
                                    print(6)
                                    user.save()
                                    # create student id for rejoin
                                    # studid=StudID()
                                    # studid.stud_id="a"
                                    # studid.save()
                                    priAdmModule.stud_id="p"+str(user.id)+""+prn
                                    my_group=Group.objects.get(name='student')
                                    user.groups.add(my_group)
                                    priAdmModule.user=user

                                    #for Academics
                                    no=int(adm_class)
                                    print(no)
                                    if no==1:
                                        print(7)
                                        priAdmModule.updateclass1 = adm_class
                                        priAdmModule.updateyear1 = admyear[0:4]
                                        priAdmModule.updatedivision1 = div
                                        priAdmModule.updaterollno1 = str(inputWorksheet.cell_value(y,24))
                                        print(8)
                                    elif no==2:
                                        priAdmModule.updateclass2 = adm_class
                                        priAdmModule.updateyear2 = admyear[0:4]
                                        priAdmModule.updatedivision2 = div
                                        priAdmModule.updaterollno2 = str(inputWorksheet.cell_value(y,24))
                                    elif no==3:
                                        priAdmModule.updateclass3 = adm_class
                                        priAdmModule.updateyear3 = admyear[0:4]
                                        priAdmModule.updatedivision3 = div
                                        priAdmModule.updaterollno3 = str(inputWorksheet.cell_value(y,24))
                                    elif no==4:
                                        priAdmModule.updateclass4 = adm_class
                                        priAdmModule.updateyear4 = admyear[0:4]
                                        priAdmModule.updatedivision4 = div
                                        priAdmModule.updaterollno4 = str(inputWorksheet.cell_value(y,24))
                                    
                                    print(fr)
                                    priAdmModule.save()
                                    print(fr)
                        messages.success(request, "File Imported Successfully")
                        return redirect('admission_primlist')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('admission_primimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Primary Admission /",
            'fname':fname,
            'yearData':yearData,
            "page_path":"  Import-Primary Admission",
            "menu_icon":"nav-icon fas fa-address-card",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)
    else:
        return redirect('login')





#Secondary Import
def admission_sec_import(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    admyear=request.POST['year']
                    print(admyear[0:4])
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr) # 1
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):

                                try:
                                    prn=str(int(inputWorksheet.cell_value(y,0)))
                                except:
                                    messages.error(request,"Register Number should contain only numbers")
                                    return redirect('admission_secimport')

                                try:
                                    aadhar=str(int(inputWorksheet.cell_value(y,6)))
                                except:
                                    messages.error(request,"Aadhar Number should contain only numbers")
                                    return redirect('admission_secimport')

                                if SecondAdm.objects.filter(prn__iexact=prn).exists():
                                    messages.error(request,"Register Number Already Exists")
                                    return redirect('admission_secimport')
                                elif SecondAdm.objects.filter(aadhar__iexact=aadhar).exists():
                                    messages.error(request,"Aadhar Number Already Exists")
                                    return redirect('admission_secimport')
                                elif SecondAdm.objects.filter(email__iexact=str(inputWorksheet.cell_value(y,31))).exists():
                                    messages.error(request,"Email Id Already Exists")
                                    return redirect('admission_secimport')
                                else:
                                    secAdmModule=SecondAdm()
                                    #for prn validation
                                    secAdmModule.prn=prn
                                    if inputWorksheet.cell_value(y,1) == "":
                                        messages.error(request,"Student Last Name required")
                                        return redirect('admission_secimport')
                                    secAdmModule.lname=str(inputWorksheet.cell_value(y,1)).upper()
                                    # for first name    
                                    if inputWorksheet.cell_value(y,2) == "":
                                        messages.error(request,"Student First Name required")
                                        return redirect('admission_secimport')
                                    secAdmModule.fname=str(inputWorksheet.cell_value(y,2)).upper()
                                    # for Father name  
                                    if inputWorksheet.cell_value(y,3) == "":
                                        messages.error(request,"Student Father Name required")
                                        return redirect('admission_secimport')  
                                    secAdmModule.faname=str(inputWorksheet.cell_value(y,3)).upper()
                                    # for Mother name    
                                    if inputWorksheet.cell_value(y,4) == "":
                                        messages.error(request,"Student Mother Name required")
                                        return redirect('admission_secimport')
                                    secAdmModule.moname=str(inputWorksheet.cell_value(y,4)).upper()
                                    secAdmModule.mrname=str(inputWorksheet.cell_value(y,5))
                                    #for aadhar validation
                                    print(aadhar)
                                    leng=len(aadhar)
                                    print(leng)
                                    if leng == 12 or leng == 13:
                                        secAdmModule.aadhar=aadhar
                                    else:
                                        messages.error(request,"Aadhar Number is 12 or 13 digits")
                                        return redirect('admission_secimport')
                                        
                                    secAdmModule.saral_id=str(inputWorksheet.cell_value(y,7))
                                    natlist=['INDIAN','AFGHAN','BANGLADESHI','NEPALESE']
                                    n=str(inputWorksheet.cell_value(y,8)).upper()
                                    if n in natlist:
                                        print(n)
                                        secAdmModule.nationality=n
                                    else:
                                        messages.error(request,"Nationality Does not exists : "+n)
                                        return redirect('admission_secimport')
                                    tong=str(inputWorksheet.cell_value(y,9)).upper()
                                    # For Mother Tongue
                                    if MTongue.objects.filter(m_tongue=tong).exists():
                                        secAdmModule.tongue=MTongue.objects.get(m_tongue=tong)
                                    else:
                                        messages.error(request,"Mother Tongue Does not exists "+tong)
                                        return redirect('admission_secimport')
                                    #for Religion
                                    rel=str(inputWorksheet.cell_value(y,10)).upper()
                                    if Religion.objects.filter(religionName=rel).exists():
                                        secAdmModule.religion=Religion.objects.get(religionName=rel)
                                    else:
                                        messages.error(request,"Religion Does not exists "+rel)
                                        return redirect('admission_secimport')
                                    # For Caste
                                    cast=str(inputWorksheet.cell_value(y,11)).upper()
                                    if Cast.objects.filter(castName=cast).exists():
                                        secAdmModule.cast=Cast.objects.get(castName=cast)
                                    else:
                                        messages.error(request,"Caste Does not exists "+cast)
                                        return redirect('admission_secimport')
                                    # For SubCaste
                                    scast=str(inputWorksheet.cell_value(y,13)).upper()
                                    if SubCast.objects.filter(subCastName=scast).exists():
                                        secAdmModule.subcast=SubCast.objects.get(subCastName=scast)
                                    elif scast=="":
                                        pass
                                    else:
                                        messages.error(request,"SubCaste Does not exists "+scast)
                                        return redirect('admission_secimport')
                                    minlist=['YES','NO']
                                    mino = str(inputWorksheet.cell_value(y,14)).upper()
                                    if mino in minlist:
                                        print(mino)
                                        secAdmModule.minority=mino
                                    else:
                                        messages.error(request,"Minority Does not exists : "+mino)
                                        return redirect('admission_secimport')
                                    if inputWorksheet.cell_value(y,15) == "":
                                        messages.error(request,"Place of Birth is Required")
                                        return redirect('admission_secimport')
                                    secAdmModule.pob=str(inputWorksheet.cell_value(y,15)).upper()
                                    dob=str(inputWorksheet.cell_value(y,16))
                                    leng=len(dob)
                                    if leng==10:
                                        if dob[4]=='-' and dob[7]=='-':
                                            secAdmModule.dob=dob
                                        else:
                                            messages.error(request,"Invalid Date Of Birth "+dob)
                                            return redirect('admission_secimport')
                                    else:
                                        messages.error(request,"Invalid Date Of Birth "+dob)
                                        return redirect('admission_secimport')
                                    # secAdmModule.dob=inputWorksheet.cell_value(y,16)
                                    # For Last attended school
                                    last_s=str(inputWorksheet.cell_value(y,17)).upper()
                                    if last_s=="":
                                        pass
                                    elif OtherSch.objects.filter(schName=last_s).exists():
                                        secAdmModule.last_school=OtherSch.objects.get(schName=last_s)
                                    else:
                                        messages.error(request,"School Name Does not exists "+last_s)
                                        return redirect('admission_secimport')

                                    # for Last class
                                    if inputWorksheet.cell_value(y,18)!="":
                                        try:
                                            last_class=str(int(inputWorksheet.cell_value(y,18)))
                                        except:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_secimport')
                                        last_classlist=['4','5','6','7','8','9']
                                        if last_class=="":
                                            pass
                                        elif last_class in last_classlist:
                                            secAdmModule.last_class=last_class
                                        else:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_secimport')

                                    try:
                                        if inputWorksheet.cell_value(y,19) == "":
                                            pass
                                        else:
                                            secAdmModule.prevlcsrno=str(int(inputWorksheet.cell_value(y,19)))
                                    except:
                                        messages.error(request,"Invalid Previous LC Sr No")
                                        return redirect('admission_secimport')
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,20) == "":
                                            pass
                                        else:
                                            secAdmModule.prevprn=str(int(inputWorksheet.cell_value(y,20)))
                                    except:
                                        messages.error(request,"Invalid Pervious Registration Number")
                                        return redirect('admission_secimport')
                                    
                                    admdate=str(inputWorksheet.cell_value(y,21))
                                    leng=len(admdate)
                                    if leng==10:
                                        if admdate[4]=='-' and admdate[7]=='-':
                                            secAdmModule.admdate=admdate
                                        else:
                                            messages.error(request,"Invalid Admission Date "+admdate)
                                            return redirect('admission_secimport')
                                    else:
                                        messages.error(request,"Invalid Admission Date "+admdate)
                                        return redirect('admission_secimport')
                                    secAdmModule.admyear=admyear[0:4]
                                    # for Adm class
                                    try:
                                        adm_class=str(int(inputWorksheet.cell_value(y,22)))
                                    except:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_secimport')
                                    adm_classlist=['5','6','7','8','9','10']
                                    if adm_class in adm_classlist:
                                        secAdmModule.adm_class=adm_class
                                    else:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_secimport')
                                    # For Division
                                    div=str(inputWorksheet.cell_value(y,23)).upper()
                                    if div == "":
                                        pass
                                    elif Division.objects.filter(division=div).exists():
                                        secAdmModule.division=Division.objects.get(division=div)
                                    else:
                                        messages.error(request,"Division Does not exists "+div)
                                        return redirect('admission_secimport')

                                    try:
                                        if inputWorksheet.cell_value(y,24)=="":
                                            pass
                                        else:
                                            secAdmModule.rollno=str(int(inputWorksheet.cell_value(y,24)))
                                    except:
                                        messages.error(request,"Invalid Roll Number")
                                        return redirect('admission_secimport')
                                    # for late Adm 
                                    lateadm=str(inputWorksheet.cell_value(y,25)).upper()
                                    lateadmlist=['YES','NO']
                                    if lateadm in lateadmlist:
                                        secAdmModule.lateadm=lateadm
                                    else:
                                        messages.error(request,"Invalid Late Admission ")
                                        return redirect('admission_secimport')
                                    # for adm type
                                    admtype=str(inputWorksheet.cell_value(y,26)).upper()
                                    admtypelist=['FRESHER','REPETER','ONE TIME FAILED']
                                    if admtype in admtypelist:
                                        secAdmModule.admtype=admtype
                                    else:
                                        messages.error(request,"Invalid Admission Type")
                                        return redirect('admission_secimport')
                                    # for hostel
                                    hostel=str(inputWorksheet.cell_value(y,27)).upper()
                                    hostellist=['YES','NO']
                                    if hostel in hostellist:
                                        secAdmModule.hostel=hostel
                                    else:
                                        messages.error(request,"Invalid Hostel")
                                        return redirect('admission_secimport')
                                    # for Gender
                                    sex=str(inputWorksheet.cell_value(y,28)).upper()
                                    sexlist=['MALE','FEMALE','OTHER']
                                    if sex in sexlist:
                                        secAdmModule.sex=sex
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_secimport')
                                    secAdmModule.pwd=str(inputWorksheet.cell_value(y,29)).upper()
                                    secAdmModule.bgroup=str(inputWorksheet.cell_value(y,30)).upper()
                                    #for Email validation
                                    email=str(inputWorksheet.cell_value(y,31))
                                    regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'
                                    if(re.search(regex, email)):
                                        secAdmModule.email=str(email)
                                    else:
                                        messages.error(request,"Invalid Email Id")
                                        return redirect('admission_secimport')

                                    # for Gender
                                    areaType=str(inputWorksheet.cell_value(y,32)).upper()
                                    areaTypelist=['RURAL','URBAN']
                                    if areaType in areaTypelist:
                                        secAdmModule.areaType=areaType
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_secimport')
                                    secAdmModule.caddress=str(inputWorksheet.cell_value(y,33)).upper()
                                    # for current address == permanent adderss
                                    if inputWorksheet.cell_value(y,33).upper()==inputWorksheet.cell_value(y,34).upper():
                                        secAdmModule.ca_is_pa_addr="YES"
                                        secAdmModule.paddress=str(inputWorksheet.cell_value(y,33)).upper()
                                    else:
                                        secAdmModule.ca_is_pa_addr="NO"
                                        secAdmModule.paddress=str(inputWorksheet.cell_value(y,34)).upper()

                                    #for father mobile no
                                    try:
                                        fa_mob=str(inputWorksheet.cell_value(y,35))
                                        if fa_mob=="":
                                            pass
                                        else:
                                            fa_mob=str(int(inputWorksheet.cell_value(y,35)))
                                    except:
                                        messages.error(request,"Father Mobile Number should contain only numbers")
                                        return redirect('admission_secimport')
                                    print(fa_mob)
                                    leng=len(fa_mob)
                                    if fa_mob =="":
                                        secAdmModule.fa_mob=fa_mob
                                    elif leng == 10:
                                        secAdmModule.fa_mob=fa_mob
                                    else:
                                        messages.error(request,"Father Mobile Number should be 10 digits")
                                        return redirect('admission_secimport')
                                    print(fa_mob)
                                    
                                    #for mother mobile no
                                    try:
                                        mo_mob=str(inputWorksheet.cell_value(y,36))
                                        if mo_mob=="":
                                            pass
                                        else:
                                            mo_mob=str(int(inputWorksheet.cell_value(y,36)))
                                    except:
                                        messages.error(request,"Mother Mobile Number should contain only numbers")
                                        return redirect('admission_secimport')
                                    leng=len(mo_mob)
                                    if mo_mob =="":
                                        secAdmModule.mo_mob=mo_mob
                                    elif leng == 10:
                                        secAdmModule.mo_mob=mo_mob
                                    else:
                                        messages.error(request,"Mother Mobile Number should be 10 digits")
                                        return redirect('admission_secimport')
                                    
                                    secAdmModule.fa_occu=str(inputWorksheet.cell_value(y,37)).upper()
                                    secAdmModule.mo_occu=str(inputWorksheet.cell_value(y,38)).upper()
                                    secAdmModule.fam_income=str(inputWorksheet.cell_value(y,39))
                                    # for bpl
                                    bpl=str(inputWorksheet.cell_value(y,40)).upper()
                                    bpllist=['YES','NO']
                                    if bpl in bpllist:
                                        secAdmModule.bpl=bpl
                                    else:
                                        messages.error(request,"Invalid BPL")
                                        return redirect('admission_secimport')
                                    #for Guardian is
                                    gis=str(inputWorksheet.cell_value(y,41)).upper()
                                    glist=['FATHER','MOTHER','OTHER']
                                    if gis in glist:
                                        secAdmModule.gis=gis
                                    else:
                                        messages.error(request,"Invalid Guardian Is")
                                        return redirect('admission_secimport')
                                    secAdmModule.ganame=str(inputWorksheet.cell_value(y,42)).upper()
                                    try:
                                        ga_mob=str(inputWorksheet.cell_value(y,43))
                                        if ga_mob=="":
                                            pass
                                        else:
                                            ga_mob=str(int(inputWorksheet.cell_value(y,43)))
                                    except:
                                        messages.error(request,"Guardian Mobile Number should contain only numbers")
                                        return redirect('admission_secimport')
                                    leng=len(ga_mob)
                                    if ga_mob =="":
                                        secAdmModule.ga_mob=ga_mob
                                    elif leng == 10:
                                        secAdmModule.ga_mob=ga_mob
                                    else:
                                        messages.error(request,"Guardian Mobile Number should be 10 digits")
                                        return redirect('admission_secimport')
                                    secAdmModule.ga_occu=str(inputWorksheet.cell_value(y,44)).upper()
                                    secAdmModule.gaddress=str(inputWorksheet.cell_value(y,45)).upper()
                                    secAdmModule.ga_relation=str(inputWorksheet.cell_value(y,46)).upper()

                                    try:
                                        if inputWorksheet.cell_value(y,47)=="":
                                            pass
                                        else:
                                            secAdmModule.baccount=str(int(inputWorksheet.cell_value(y,47)))
                                    except:
                                        messages.error(request,"Invalid Bank Account Number")
                                        return redirect('admission_secimport')

                                    secAdmModule.bankname=str(inputWorksheet.cell_value(y,48)).upper()
                                    secAdmModule.ifsc=str(inputWorksheet.cell_value(y,49))
                                    secAdmModule.branch=str(inputWorksheet.cell_value(y,50)).upper()
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,51)=="":
                                            pass
                                        else:
                                            secAdmModule.micr=str(int(inputWorksheet.cell_value(y,51)))
                                    except:
                                        messages.error(request,"Invalid MICR Code")
                                        return redirect('admission_secimport')
                                    secAdmModule.note=str(inputWorksheet.cell_value(y,52))

                                    # Create User for Student
                                    user=User.objects.create_user(username=aadhar,email=str(inputWorksheet.cell_value(y,31)),password="Admin@123",first_name=str(inputWorksheet.cell_value(y,2)).upper(),last_name=str(inputWorksheet.cell_value(y,1)).upper())
                                    user.save()
                                    # create student id for rejoin
                                    # studid=StudID()
                                    # studid.stud_id="a"
                                    # studid.save()
                                    secAdmModule.stud_id="s"+str(user.id)+""+prn
                                    my_group=Group.objects.get(name='student')
                                    user.groups.add(my_group)
                                    secAdmModule.user=user
                                    #for Academics
                                    no=int(adm_class)
                                    print(no)
                                    if no==5:
                                        secAdmModule.updateclass5 = adm_class
                                        secAdmModule.updateyear5 = admyear[0:4]
                                        secAdmModule.updatedivision5 = div
                                        secAdmModule.updaterollno5 = str(inputWorksheet.cell_value(y,24))
                                    elif no==6:
                                        secAdmModule.updateclass6 = adm_class
                                        secAdmModule.updateyear6 = admyear[0:4]
                                        secAdmModule.updatedivision6 = div
                                        secAdmModule.updaterollno6 = str(inputWorksheet.cell_value(y,24))
                                    elif no==7:
                                        secAdmModule.updateclass7 = adm_class
                                        secAdmModule.updateyear7 = admyear[0:4]
                                        secAdmModule.updatedivision7 = div
                                        secAdmModule.updaterollno7 = str(inputWorksheet.cell_value(y,24))
                                    elif no==8:
                                        secAdmModule.updateclass8 = adm_class
                                        secAdmModule.updateyear8 = admyear[0:4]
                                        secAdmModule.updatedivision8 = div
                                        secAdmModule.updaterollno8 = str(inputWorksheet.cell_value(y,24))
                                    elif no==9:
                                        secAdmModule.updateclass9 = adm_class
                                        secAdmModule.updateyear9 = admyear[0:4]
                                        secAdmModule.updatedivision9 = div
                                        secAdmModule.updaterollno9 = str(inputWorksheet.cell_value(y,24))
                                    elif no==10:
                                        secAdmModule.updateclass10 = adm_class
                                        secAdmModule.updateyear10 = admyear[0:4]
                                        secAdmModule.updatedivision10 = div
                                        secAdmModule.updaterollno10 = str(inputWorksheet.cell_value(y,24))   
                                    print(fr)
                                    secAdmModule.save()
                                    print(fr)
                        messages.success(request, "File Imported Successfully")
                        return redirect('admission_seclist')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('admission_secimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Secondary Admission /",
            'fname':fname,
            'yearData':yearData,
            "page_path":"Import-Secondary Admission",
            "menu_icon":"nav-icon fas fa-address-card",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)
    else:
        return redirect('login')




# College Import
def admission_clg_import(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    admyear=request.POST['year']
                    print(admyear[0:4])
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr) # 1
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):

                                try:
                                    prn=str(int(inputWorksheet.cell_value(y,0)))
                                except:
                                    messages.error(request,"Register Number should contain only numbers")
                                    return redirect('admission_clgimport')

                                try:
                                    aadhar=str(int(inputWorksheet.cell_value(y,6)))
                                except:
                                    messages.error(request,"Aadhar Number should contain only numbers")
                                    return redirect('admission_clgimport')

                                if CollegeAdm.objects.filter(prn__iexact=prn).exists():
                                    messages.error(request,"Register Number Already Exists")
                                    return redirect('admission_clgimport')
                                elif CollegeAdm.objects.filter(aadhar__iexact=aadhar).exists():
                                    messages.error(request,"Aadhar Number Already Exists")
                                    return redirect('admission_clgimport')
                                elif CollegeAdm.objects.filter(email__iexact=str(inputWorksheet.cell_value(y,32))).exists():
                                    messages.error(request,"Email Id Already Exists")
                                    return redirect('admission_clgimport')
                                else:
                                    clgAdmModule=CollegeAdm()
                                    #for prn validation
                                    clgAdmModule.prn=prn
                                    if inputWorksheet.cell_value(y,1) == "":
                                        messages.error(request,"Student Last Name required")
                                        return redirect('admission_clgimport')
                                    clgAdmModule.lname=str(inputWorksheet.cell_value(y,1)).upper()
                                    # for first name    
                                    if inputWorksheet.cell_value(y,2) == "":
                                        messages.error(request,"Student First Name required")
                                        return redirect('admission_clgimport')
                                    clgAdmModule.fname=str(inputWorksheet.cell_value(y,2)).upper()
                                    # for Father name  
                                    if inputWorksheet.cell_value(y,3) == "":
                                        messages.error(request,"Student Father Name required")
                                        return redirect('admission_clgimport')  
                                    clgAdmModule.faname=str(inputWorksheet.cell_value(y,3)).upper()
                                    # for Mother name    
                                    if inputWorksheet.cell_value(y,4) == "":
                                        messages.error(request,"Student Mother Name required")
                                        return redirect('admission_clgimport')   
                                    clgAdmModule.moname=str(inputWorksheet.cell_value(y,4)).upper()
                                    clgAdmModule.mrname=str(inputWorksheet.cell_value(y,5))
                                    #for aadhar validation
                                    print(aadhar)
                                    leng=len(aadhar)
                                    print(leng)
                                    if leng == 12 or leng == 13:
                                        clgAdmModule.aadhar=aadhar
                                    else:
                                        messages.error(request,"Aadhar Number is 12 or 13 digits")
                                        return redirect('admission_clgimport')
                                        
                                    clgAdmModule.saral_id=str(inputWorksheet.cell_value(y,7))
                                    natlist=['INDIAN','AFGHAN','BANGLADESHI','NEPALESE']
                                    n=str(inputWorksheet.cell_value(y,8)).upper()
                                    if n in natlist:
                                        print(n)
                                        clgAdmModule.nationality=n
                                    else:
                                        messages.error(request,"Nationality Does not exists : "+n)
                                        return redirect('admission_clgimport')
                                    tong=str(inputWorksheet.cell_value(y,9)).upper()
                                    # For Mother Tongue
                                    if MTongue.objects.filter(m_tongue=tong).exists():
                                        clgAdmModule.tongue=MTongue.objects.get(m_tongue=tong)
                                    else:
                                        messages.error(request,"Mother Tongue Does not exists "+tong)
                                        return redirect('admission_clgimport')
                                    #for Religion
                                    rel=str(inputWorksheet.cell_value(y,10)).upper()
                                    if Religion.objects.filter(religionName=rel).exists():
                                        clgAdmModule.religion=Religion.objects.get(religionName=rel)
                                    else:
                                        messages.error(request,"Religion Does not exists "+rel)
                                        return redirect('admission_clgimport')
                                    # For Caste
                                    cast=str(inputWorksheet.cell_value(y,11)).upper()
                                    if Cast.objects.filter(castName=cast).exists():
                                        clgAdmModule.cast=Cast.objects.get(castName=cast)
                                    else:
                                        messages.error(request,"Caste Does not exists "+cast)
                                        return redirect('admission_clgimport')
                                    # For SubCaste
                                    scast=str(inputWorksheet.cell_value(y,13)).upper()
                                    if SubCast.objects.filter(subCastName=scast).exists():
                                        clgAdmModule.subcast=SubCast.objects.get(subCastName=scast)
                                    elif scast=="":
                                        pass
                                    else:
                                        messages.error(request,"SubCaste Does not exists "+scast)
                                        return redirect('admission_clgimport')
                                    minlist=['YES','NO']
                                    mino = str(inputWorksheet.cell_value(y,14)).upper()
                                    if mino in minlist:
                                        print(mino)
                                        clgAdmModule.minority=mino
                                    else:
                                        messages.error(request,"Minority Does not exists : "+mino)
                                        return redirect('admission_clgimport')
                                    if inputWorksheet.cell_value(y,15) == "":
                                        messages.error(request,"Place of Birth is required")
                                        return redirect('admission_clgimport')
                                    clgAdmModule.pob=str(inputWorksheet.cell_value(y,15)).upper()
                                    dob=str(inputWorksheet.cell_value(y,16))
                                    leng=len(dob)
                                    if leng==10:
                                        if dob[4]=='-' and dob[7]=='-':
                                            clgAdmModule.dob=dob
                                        else:
                                            messages.error(request,"Invalid Date Of Birth "+dob)
                                            return redirect('admission_clgimport')
                                    else:
                                        messages.error(request,"Invalid Date Of Birth "+dob)
                                        return redirect('admission_clgimport')
                                    # clgAdmModule.dob=inputWorksheet.cell_value(y,16)
                                    # For Last attended school
                                    last_s=str(inputWorksheet.cell_value(y,17)).upper()
                                    if last_s=="":
                                        pass
                                    elif OtherSch.objects.filter(schName=last_s).exists():
                                        clgAdmModule.last_school=OtherSch.objects.get(schName=last_s)
                                    else:
                                        messages.error(request,"School Name Does not exists "+last_s)
                                        return redirect('admission_clgimport')
                                    
                                    # for Last class
                                    if inputWorksheet.cell_value(y,18)!="":
                                        try:
                                            last_class=str(int(inputWorksheet.cell_value(y,18)))
                                        except:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_clgimport')
                                        last_classlist=['10','11']
                                        if last_class=="":
                                            pass
                                        elif last_class in last_classlist:
                                            clgAdmModule.last_class=last_class
                                        else:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_clgimport')
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,19) == "":
                                            pass
                                        else:
                                            clgAdmModule.prevlcsrno=str(int(inputWorksheet.cell_value(y,19)))
                                    except:
                                        messages.error(request,"Invalid Previous LC Sr No")
                                        return redirect('admission_clgimport')
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,20) == "":
                                            pass
                                        else:
                                            clgAdmModule.prevprn=str(int(inputWorksheet.cell_value(y,20)))
                                    except:
                                        messages.error(request,"Invalid Pervious Registration Number")
                                        return redirect('admission_clgimport')

                                    admdate=str(inputWorksheet.cell_value(y,21))
                                    leng=len(admdate)
                                    if leng==10:
                                        if admdate[4]=='-' and admdate[7]=='-':
                                            clgAdmModule.admdate=admdate
                                        else:
                                            messages.error(request,"Invalid Admission Date "+admdate)
                                            return redirect('admission_clgimport')
                                    else:
                                        messages.error(request,"Invalid Admission Date "+admdate)
                                        return redirect('admission_clgimport')
                                    clgAdmModule.admyear=admyear[0:4]
                                    # for Adm class
                                    try:
                                        adm_class=str(int(inputWorksheet.cell_value(y,22)))
                                    except:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_clgimport')
                                    adm_classlist=['11','12']
                                    if adm_class in adm_classlist:
                                        clgAdmModule.adm_class=adm_class
                                    else:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_clgimport')
                                    
                                    adm_facultylist=['SCIENCE','COMMERCE','ARTS','VOCATIONAL']
                                    admission_faculty=str(inputWorksheet.cell_value(y,23))
                                    if admission_faculty in adm_facultylist:
                                        clgAdmModule.admission_faculty=admission_faculty
                                    else:
                                        messages.error(request,"Invalid Admission Faculty")
                                        return redirect('admission_clgimport')

                                    # For Division
                                    div=str(inputWorksheet.cell_value(y,24)).upper()
                                    if div == "":
                                        pass
                                    elif Division.objects.filter(division=div).exists():
                                        clgAdmModule.division=Division.objects.get(division=div)
                                    else:
                                        messages.error(request,"Division Does not exists "+div)
                                        return redirect('admission_clgimport')

                                    try:
                                        if inputWorksheet.cell_value(y,25)=="":
                                            pass
                                        else:
                                            clgAdmModule.rollno=str(int(inputWorksheet.cell_value(y,25)))
                                    except:
                                        messages.error(request,"Invalid Roll Number")
                                        return redirect('admission_clgimport')
                                    # for late Adm 
                                    lateadm=str(inputWorksheet.cell_value(y,26)).upper()
                                    lateadmlist=['YES','NO']
                                    if lateadm in lateadmlist:
                                        clgAdmModule.lateadm=lateadm
                                    else:
                                        messages.error(request,"Invalid Late Admission ")
                                        return redirect('admission_clgimport')
                                    # for adm type
                                    admtype=str(inputWorksheet.cell_value(y,27)).upper()
                                    admtypelist=['FRESHER','REPETER','ONE TIME FAILED']
                                    if admtype in admtypelist:
                                        clgAdmModule.admtype=admtype
                                    else:
                                        messages.error(request,"Invalid Admission Type")
                                        return redirect('admission_clgimport')
                                    # for hostel
                                    hostel=str(inputWorksheet.cell_value(y,28)).upper()
                                    hostellist=['YES','NO']
                                    if hostel in hostellist:
                                        clgAdmModule.hostel=hostel
                                    else:
                                        messages.error(request,"Invalid Hostel")
                                        return redirect('admission_clgimport')
                                    # for Gender
                                    sex=str(inputWorksheet.cell_value(y,29)).upper()
                                    sexlist=['MALE','FEMALE','OTHER']
                                    if sex in sexlist:
                                        clgAdmModule.sex=sex
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_clgimport')
                                    clgAdmModule.pwd=str(inputWorksheet.cell_value(y,30)).upper()
                                    clgAdmModule.bgroup=str(inputWorksheet.cell_value(y,31)).upper()
                                    #for Email validation
                                    email=str(inputWorksheet.cell_value(y,32))
                                    regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'
                                    if(re.search(regex, email)):
                                        clgAdmModule.email=str(email)
                                    else:
                                        messages.error(request,"Invalid Email Id")
                                        return redirect('admission_clgimport')

                                    # for Gender
                                    areaType=str(inputWorksheet.cell_value(y,33)).upper()
                                    areaTypelist=['RURAL','URBAN']
                                    if areaType in areaTypelist:
                                        clgAdmModule.areaType=areaType
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_clgimport')
                                    clgAdmModule.caddress=str(inputWorksheet.cell_value(y,34)).upper()
                                    # for current address == permanent adderss
                                    if inputWorksheet.cell_value(y,34).upper()==inputWorksheet.cell_value(y,35).upper():
                                        clgAdmModule.ca_is_pa_addr="YES"
                                        clgAdmModule.paddress=str(inputWorksheet.cell_value(y,34)).upper()
                                    else:
                                        clgAdmModule.ca_is_pa_addr="NO"
                                        clgAdmModule.paddress=str(inputWorksheet.cell_value(y,35)).upper()

                                    #for father mobile no
                                    try:
                                        fa_mob=str(inputWorksheet.cell_value(y,36))
                                        if fa_mob=="":
                                            pass
                                        else:
                                            fa_mob=str(int(inputWorksheet.cell_value(y,36)))
                                    except:
                                        messages.error(request,"Father Mobile Number should contain only numbers")
                                        return redirect('admission_clgimport')
                                    print(fa_mob)
                                    leng=len(fa_mob)
                                    if fa_mob =="":
                                        clgAdmModule.fa_mob=fa_mob
                                    elif leng == 10:
                                        clgAdmModule.fa_mob=fa_mob
                                    else:
                                        messages.error(request,"Father Mobile Number should be 10 digits")
                                        return redirect('admission_clgimport')
                                    print(fa_mob)
                                    
                                    #for mother mobile no
                                    try:
                                        mo_mob=str(inputWorksheet.cell_value(y,37))
                                        if mo_mob=="":
                                            pass
                                        else:
                                            mo_mob=str(int(inputWorksheet.cell_value(y,37)))
                                    except:
                                        messages.error(request,"Mother Mobile Number should contain only numbers")
                                        return redirect('admission_clgimport')
                                    leng=len(mo_mob)
                                    if mo_mob =="":
                                        clgAdmModule.mo_mob=mo_mob
                                    elif leng == 10:
                                        clgAdmModule.mo_mob=mo_mob
                                    else:
                                        messages.error(request,"Mother Mobile Number should be 10 digits")
                                        return redirect('admission_clgimport')
                                    
                                    clgAdmModule.fa_occu=str(inputWorksheet.cell_value(y,38)).upper()
                                    clgAdmModule.mo_occu=str(inputWorksheet.cell_value(y,39)).upper()
                                    clgAdmModule.fam_income=str(inputWorksheet.cell_value(y,40))
                                    # for bpl
                                    bpl=str(inputWorksheet.cell_value(y,41)).upper()
                                    bpllist=['YES','NO']
                                    if bpl in bpllist:
                                        clgAdmModule.bpl=bpl
                                    else:
                                        messages.error(request,"Invalid BPL")
                                        return redirect('admission_clgimport')
                                    #for Guardian is
                                    gis=str(inputWorksheet.cell_value(y,42)).upper()
                                    glist=['FATHER','MOTHER','OTHER']
                                    if gis in glist:
                                        clgAdmModule.gis=gis
                                    else:
                                        messages.error(request,"Invalid Guardian Is")
                                        return redirect('admission_clgimport')
                                    clgAdmModule.ganame=str(inputWorksheet.cell_value(y,43)).upper()
                                    try:
                                        ga_mob=str(inputWorksheet.cell_value(y,44))
                                        if ga_mob=="":
                                            pass
                                        else:
                                            ga_mob=str(int(inputWorksheet.cell_value(y,44)))
                                    except:
                                        messages.error(request,"Guardian Mobile Number should contain only numbers")
                                        return redirect('admission_clgimport')
                                    leng=len(ga_mob)
                                    if ga_mob =="":
                                        clgAdmModule.ga_mob=ga_mob
                                    elif leng == 10:
                                        clgAdmModule.ga_mob=ga_mob
                                    else:
                                        messages.error(request,"Guardian Mobile Number should be 10 digits")
                                        return redirect('admission_clgimport')
                                    clgAdmModule.ga_occu=str(inputWorksheet.cell_value(y,45)).upper()
                                    clgAdmModule.gaddress=str(inputWorksheet.cell_value(y,46)).upper()
                                    clgAdmModule.ga_relation=str(inputWorksheet.cell_value(y,47)).upper()

                                    try:
                                        if inputWorksheet.cell_value(y,48)=="":
                                            pass
                                        else:
                                            clgAdmModule.baccount=str(int(inputWorksheet.cell_value(y,48)))
                                    except:
                                        messages.error(request,"Invalid Bank Account Number")
                                        return redirect('admission_clgimport')

                                    clgAdmModule.bankname=str(inputWorksheet.cell_value(y,49)).upper()
                                    clgAdmModule.ifsc=str(inputWorksheet.cell_value(y,50))
                                    clgAdmModule.branch=str(inputWorksheet.cell_value(y,51)).upper()
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,52)=="":
                                            pass
                                        else:
                                            clgAdmModule.micr=str(int(inputWorksheet.cell_value(y,52)))
                                    except:
                                        messages.error(request,"Invalid MICR Code")
                                        return redirect('admission_clgimport')

                                    clgAdmModule.note=str(inputWorksheet.cell_value(y,53))
                                    
                                    # Create User for Student
                                    user=User.objects.create_user(username=aadhar,email=str(inputWorksheet.cell_value(y,32)),password="Admin@123",first_name=str(inputWorksheet.cell_value(y,2)).upper(),last_name=str(inputWorksheet.cell_value(y,1)).upper())
                                    user.save()
                                    # create student id for rejoin
                                    # studid=StudID()
                                    # studid.stud_id="a"
                                    # studid.save()
                                    clgAdmModule.stud_id="c"+str(user.id)+""+prn
                                    my_group=Group.objects.get(name='student')
                                    user.groups.add(my_group)
                                    #for Academics
                                    no=int(adm_class)
                                    print(no)
                                    if no==11:
                                        clgAdmModule.updateclass11 = adm_class
                                        clgAdmModule.updatestream11 = admission_faculty
                                        clgAdmModule.updateyear11 = admyear[0:4]
                                        clgAdmModule.updatedivision11 = div
                                        clgAdmModule.updaterollno11 = str(inputWorksheet.cell_value(y,25))
                                    elif no==12:
                                        clgAdmModule.updateclass12 = adm_class
                                        clgAdmModule.updatestream12 = admission_faculty
                                        clgAdmModule.updateyear12 = admyear[0:4]
                                        clgAdmModule.updatedivision12 = div
                                        clgAdmModule.updaterollno12 = str(inputWorksheet.cell_value(y,25))
                                    clgAdmModule.user=user
                                    clgAdmModule.save()
                                    print(fr)
                        messages.success(request, "File Imported Successfully")
                        return redirect('admission_collist')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('admission_clgimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" College Admission /",
            'yearData':yearData,
            'fname':fname,
            "page_path":"Import-College Admission",
            "menu_icon":"nav-icon fas fa-address-card",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)
    else:
        return redirect('login')




# 11-ATKT Import
def admission_atkt11_import(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    admyear=request.POST['year']
                    print(admyear[0:4])
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr) # 1
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):

                                
                                prn=str(inputWorksheet.cell_value(y,0))

                                try:
                                    aadhar=str(int(inputWorksheet.cell_value(y,6)))
                                except:
                                    messages.error(request,"Aadhar Number should contain only numbers")
                                    return redirect('admission_atkt11import')

                                if ATKT11Adm.objects.filter(prn__iexact=prn).exists():
                                    messages.error(request,"Register Number Already Exists")
                                    return redirect('admission_atkt11import')
                                elif ATKT11Adm.objects.filter(aadhar__iexact=aadhar).exists():
                                    messages.error(request,"Aadhar Number Already Exists")
                                    return redirect('admission_atkt11import')
                                elif ATKT11Adm.objects.filter(email__iexact=str(inputWorksheet.cell_value(y,32))).exists():
                                    messages.error(request,"Email Id Already Exists")
                                    return redirect('admission_atkt11import')
                                else:
                                    atkt11AdmModule=ATKT11Adm()
                                    #for prn validation
                                    atkt11AdmModule.prn=prn
                                    if inputWorksheet.cell_value(y,1) == "":
                                        messages.error(request,"Student Last Name required")
                                        return redirect('admission_atkt11import')
                                    atkt11AdmModule.lname=str(inputWorksheet.cell_value(y,1)).upper()
                                    # for first name    
                                    if inputWorksheet.cell_value(y,2) == "":
                                        messages.error(request,"Student First Name required")
                                        return redirect('admission_atkt11import')
                                    atkt11AdmModule.fname=str(inputWorksheet.cell_value(y,2)).upper()
                                    # for Father name  
                                    if inputWorksheet.cell_value(y,3) == "":
                                        messages.error(request,"Student Father Name required")
                                        return redirect('admission_atkt11import')  
                                    atkt11AdmModule.faname=str(inputWorksheet.cell_value(y,3)).upper()
                                    # for Mother name    
                                    if inputWorksheet.cell_value(y,4) == "":
                                        messages.error(request,"Student Mother Name required")
                                        return redirect('admission_atkt11import')
                                    atkt11AdmModule.moname=str(inputWorksheet.cell_value(y,4)).upper()
                                    atkt11AdmModule.mrname=str(inputWorksheet.cell_value(y,5))
                                    #for aadhar validation
                                    leng=len(aadhar)
                                    if leng == 12 or leng == 13:
                                        atkt11AdmModule.aadhar=aadhar
                                    else:
                                        messages.error(request,"Aadhar Number is 12 or 13 digits")
                                        return redirect('admission_atkt11import')
                                        
                                    atkt11AdmModule.saral_id=str(inputWorksheet.cell_value(y,7))
                                    natlist=['INDIAN','AFGHAN','BANGLADESHI','NEPALESE']
                                    n=str(inputWorksheet.cell_value(y,8)).upper()
                                    if n in natlist:
                                        print(n)
                                        atkt11AdmModule.nationality=n
                                    else:
                                        messages.error(request,"Nationality Does not exists : "+n)
                                        return redirect('admission_atkt11import')
                                    tong=str(inputWorksheet.cell_value(y,9)).upper()
                                    # For Mother Tongue
                                    if MTongue.objects.filter(m_tongue=tong).exists():
                                        atkt11AdmModule.tongue=MTongue.objects.get(m_tongue=tong)
                                    else:
                                        messages.error(request,"Mother Tongue Does not exists "+tong)
                                        return redirect('admission_atkt11import')
                                    #for Religion
                                    rel=str(inputWorksheet.cell_value(y,10)).upper()
                                    if Religion.objects.filter(religionName=rel).exists():
                                        atkt11AdmModule.religion=Religion.objects.get(religionName=rel)
                                    else:
                                        messages.error(request,"Religion Does not exists "+rel)
                                        return redirect('admission_atkt11import')
                                    # For Caste
                                    cast=str(inputWorksheet.cell_value(y,11)).upper()
                                    if Cast.objects.filter(castName=cast).exists():
                                        atkt11AdmModule.cast=Cast.objects.get(castName=cast)
                                    else:
                                        messages.error(request,"Caste Does not exists "+cast)
                                        return redirect('admission_atkt11import')
                                    # For SubCaste
                                    scast=str(inputWorksheet.cell_value(y,13)).upper()
                                    if SubCast.objects.filter(subCastName=scast).exists():
                                        atkt11AdmModule.subcast=SubCast.objects.get(subCastName=scast)
                                    elif scast=="":
                                        pass
                                    else:
                                        messages.error(request,"SubCaste Does not exists "+scast)
                                        return redirect('admission_atkt11import')
                                    minlist=['YES','NO']
                                    mino = str(inputWorksheet.cell_value(y,14)).upper()
                                    if mino in minlist:
                                        print(mino)
                                        atkt11AdmModule.minority=mino
                                    else:
                                        messages.error(request,"Minority Does not exists : "+mino)
                                        return redirect('admission_atkt11import')
                                    if inputWorksheet.cell_value(y,15) == "":
                                        messages.error(request,"Place of Birth is required")
                                        return redirect('admission_atkt11import')
                                    atkt11AdmModule.pob=str(inputWorksheet.cell_value(y,15)).upper()
                                    dob=str(inputWorksheet.cell_value(y,16))
                                    leng=len(dob)
                                    if leng==10:
                                        if dob[4]=='-' and dob[7]=='-':
                                            atkt11AdmModule.dob=dob
                                        else:
                                            messages.error(request,"Invalid Date Of Birth "+dob)
                                            return redirect('admission_atkt11import')
                                    else:
                                        messages.error(request,"Invalid Date Of Birth "+dob)
                                        return redirect('admission_atkt11import')
                                    # atkt11AdmModule.dob=inputWorksheet.cell_value(y,16)
                                    # For Last attended school
                                    last_s=str(inputWorksheet.cell_value(y,17)).upper()
                                    if last_s=="":
                                        pass
                                    elif OtherSch.objects.filter(schName=last_s).exists():
                                        atkt11AdmModule.last_school=OtherSch.objects.get(schName=last_s)
                                    else:
                                        messages.error(request,"School Name Does not exists "+last_s)
                                        return redirect('admission_atkt11import')

                                    # for Last class
                                    if inputWorksheet.cell_value(y,18)!="":
                                        try:
                                            last_class=str(int(inputWorksheet.cell_value(y,18)))
                                        except:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_atkt11import')
                                        last_classlist=['10']
                                        if last_class=="":
                                            pass
                                        elif last_class in last_classlist:
                                            atkt11AdmModule.last_class=last_class
                                        else:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_atkt11import')

                                    try:
                                        if inputWorksheet.cell_value(y,19) == "":
                                            pass
                                        else:
                                            atkt11AdmModule.prevlcsrno=str(int(inputWorksheet.cell_value(y,19)))
                                    except:
                                        messages.error(request,"Invalid Previous LC Sr No")
                                        return redirect('admission_atkt11import')
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,20) == "":
                                            pass
                                        else:
                                            atkt11AdmModule.prevprn=str(int(inputWorksheet.cell_value(y,20)))
                                    except:
                                        messages.error(request,"Invalid Pervious Registration Number")
                                        return redirect('admission_atkt11import')

                                    admdate=str(inputWorksheet.cell_value(y,21))
                                    leng=len(admdate)
                                    if leng==10:
                                        if admdate[4]=='-' and admdate[7]=='-':
                                            atkt11AdmModule.admdate=admdate
                                        else:
                                            messages.error(request,"Invalid Admission Date "+admdate)
                                            return redirect('admission_atkt11import')
                                    else:
                                        messages.error(request,"Invalid Admission Date "+admdate)
                                        return redirect('admission_atkt11import')
                                    atkt11AdmModule.admyear=admyear[0:4]
                                    # for Adm class
                                    
                                    atkt11AdmModule.adm_class="11"
                                    
                                    adm_facultylist=['SCIENCE','COMMERCE','ARTS','VOCATIONAL']
                                    admission_faculty=str(inputWorksheet.cell_value(y,23)).upper()
                                    if admission_faculty in adm_facultylist:
                                        atkt11AdmModule.admission_faculty=admission_faculty
                                    else:
                                        messages.error(request,"Invalid Admission Faculty")
                                        return redirect('admission_atkt11import')

                                    # For Division
                                    div=str(inputWorksheet.cell_value(y,24)).upper()
                                    if div == "":
                                        pass
                                    elif Division.objects.filter(division=div).exists():
                                        atkt11AdmModule.division=Division.objects.get(division=div)
                                    else:
                                        messages.error(request,"Division Does not exists "+div)
                                        return redirect('admission_atkt11import')

                                    try:
                                        if inputWorksheet.cell_value(y,25)=="":
                                            pass
                                        else:
                                            atkt11AdmModule.rollno=str(int(inputWorksheet.cell_value(y,25)))
                                    except:
                                        messages.error(request,"Invalid Roll Number")
                                        return redirect('admission_atkt11import')
                                    # for late Adm 
                                    lateadm=str(inputWorksheet.cell_value(y,26)).upper()
                                    lateadmlist=['YES','NO']
                                    if lateadm in lateadmlist:
                                        atkt11AdmModule.lateadm=lateadm
                                    else:
                                        messages.error(request,"Invalid Late Admission ")
                                        return redirect('admission_atkt11import')
                                    # for adm type
                                    admtype=str(inputWorksheet.cell_value(y,27)).upper()
                                    admtypelist=['FRESHER','REPETER','ONE TIME FAILED']
                                    if admtype in admtypelist:
                                        atkt11AdmModule.admtype=admtype
                                    else:
                                        messages.error(request,"Invalid Admission Type")
                                        return redirect('admission_atkt11import')
                                    # for hostel
                                    hostel=str(inputWorksheet.cell_value(y,28)).upper()
                                    hostellist=['YES','NO']
                                    if hostel in hostellist:
                                        atkt11AdmModule.hostel=hostel
                                    else:
                                        messages.error(request,"Invalid Hostel")
                                        return redirect('admission_atkt11import')
                                    # for Gender
                                    sex=str(inputWorksheet.cell_value(y,29)).upper()
                                    sexlist=['MALE','FEMALE','OTHER']
                                    if sex in sexlist:
                                        atkt11AdmModule.sex=sex
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_atkt11import')
                                    atkt11AdmModule.pwd=str(inputWorksheet.cell_value(y,30)).upper()
                                    atkt11AdmModule.bgroup=str(inputWorksheet.cell_value(y,31)).upper()
                                    #for Email validation
                                    email=str(inputWorksheet.cell_value(y,32))
                                    regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'
                                    if(re.search(regex, email)):
                                        atkt11AdmModule.email=str(email)
                                    else:
                                        messages.error(request,"Invalid Email Id")
                                        return redirect('admission_atkt11import')

                                    # for Gender
                                    areaType=str(inputWorksheet.cell_value(y,33)).upper()
                                    areaTypelist=['RURAL','URBAN']
                                    if areaType in areaTypelist:
                                        atkt11AdmModule.areaType=areaType
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_atkt11import')
                                    atkt11AdmModule.caddress=str(inputWorksheet.cell_value(y,34)).upper()
                                    # for current address == permanent adderss
                                    if inputWorksheet.cell_value(y,34).upper()==inputWorksheet.cell_value(y,35).upper():
                                        atkt11AdmModule.ca_is_pa_addr="YES"
                                        atkt11AdmModule.paddress=str(inputWorksheet.cell_value(y,34)).upper()
                                    else:
                                        atkt11AdmModule.ca_is_pa_addr="NO"
                                        atkt11AdmModule.paddress=str(inputWorksheet.cell_value(y,35)).upper()

                                    #for father mobile no
                                    try:
                                        fa_mob=str(inputWorksheet.cell_value(y,36))
                                        if fa_mob=="":
                                            pass
                                        else:
                                            fa_mob=str(int(inputWorksheet.cell_value(y,36)))
                                    except:
                                        messages.error(request,"Father Mobile Number should contain only numbers")
                                        return redirect('admission_atkt11import')
                                    print(fa_mob)
                                    leng=len(fa_mob)
                                    if fa_mob =="":
                                        atkt11AdmModule.fa_mob=fa_mob
                                    elif leng == 10:
                                        atkt11AdmModule.fa_mob=fa_mob
                                    else:
                                        messages.error(request,"Father Mobile Number should be 10 digits")
                                        return redirect('admission_atkt11import')
                                    print(fa_mob)
                                    
                                    #for mother mobile no
                                    try:
                                        mo_mob=str(inputWorksheet.cell_value(y,37))
                                        if mo_mob=="":
                                            pass
                                        else:
                                            mo_mob=str(int(inputWorksheet.cell_value(y,37)))
                                    except:
                                        messages.error(request,"Mother Mobile Number should contain only numbers")
                                        return redirect('admission_atkt11import')
                                    leng=len(mo_mob)
                                    if mo_mob =="":
                                        atkt11AdmModule.mo_mob=mo_mob
                                    elif leng == 10:
                                        atkt11AdmModule.mo_mob=mo_mob
                                    else:
                                        messages.error(request,"Mother Mobile Number should be 10 digits")
                                        return redirect('admission_atkt11import')
                                    
                                    atkt11AdmModule.fa_occu=str(inputWorksheet.cell_value(y,38)).upper()
                                    atkt11AdmModule.mo_occu=str(inputWorksheet.cell_value(y,39)).upper()
                                    atkt11AdmModule.fam_income=str(inputWorksheet.cell_value(y,40))
                                    # for bpl
                                    bpl=str(inputWorksheet.cell_value(y,41)).upper()
                                    bpllist=['YES','NO']
                                    if bpl in bpllist:
                                        atkt11AdmModule.bpl=bpl
                                    else:
                                        messages.error(request,"Invalid BPL")
                                        return redirect('admission_atkt11import')
                                    #for Guardian is
                                    gis=str(inputWorksheet.cell_value(y,42)).upper()
                                    glist=['FATHER','MOTHER','OTHER']
                                    if gis in glist:
                                        atkt11AdmModule.gis=gis
                                    else:
                                        messages.error(request,"Invalid Guardian Is")
                                        return redirect('admission_atkt11import')
                                    atkt11AdmModule.ganame=str(inputWorksheet.cell_value(y,43)).upper()
                                    try:
                                        ga_mob=str(inputWorksheet.cell_value(y,44))
                                        if ga_mob=="":
                                            pass
                                        else:
                                            ga_mob=str(int(inputWorksheet.cell_value(y,44)))
                                    except:
                                        messages.error(request,"Guardian Mobile Number should contain only numbers")
                                        return redirect('admission_atkt11import')
                                    leng=len(ga_mob)
                                    if ga_mob =="":
                                        atkt11AdmModule.ga_mob=ga_mob
                                    elif leng == 10:
                                        atkt11AdmModule.ga_mob=ga_mob
                                    else:
                                        messages.error(request,"Guardian Mobile Number should be 10 digits")
                                        return redirect('admission_atkt11import')
                                    atkt11AdmModule.ga_occu=str(inputWorksheet.cell_value(y,45)).upper()
                                    atkt11AdmModule.gaddress=str(inputWorksheet.cell_value(y,46)).upper()
                                    atkt11AdmModule.ga_relation=str(inputWorksheet.cell_value(y,47)).upper()

                                    atkt11AdmModule.bonaissuedate=str(inputWorksheet.cell_value(y,48))
                                    atkt11AdmModule.bonasrno=str(inputWorksheet.cell_value(y,49)).upper()

                                    try:
                                        if inputWorksheet.cell_value(y,50)=="":
                                            pass
                                        else:
                                            atkt11AdmModule.baccount=str(int(inputWorksheet.cell_value(y,50)))
                                    except:
                                        messages.error(request,"Invalid Bank Account Number")
                                        return redirect('admission_atkt11import')

                                    

                                    atkt11AdmModule.bankname=str(inputWorksheet.cell_value(y,51)).upper()
                                    atkt11AdmModule.ifsc=str(inputWorksheet.cell_value(y,52))
                                    atkt11AdmModule.branch=str(inputWorksheet.cell_value(y,53)).upper()
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,54)=="":
                                            pass
                                        else:
                                            atkt11AdmModule.micr=str(int(inputWorksheet.cell_value(y,54)))
                                    except:
                                        messages.error(request,"Invalid MICR Code")
                                        return redirect('admission_atkt11import')
                                    
                                    atkt11AdmModule.note=str(inputWorksheet.cell_value(y,55))

                                    

                                    # Create User for Student
                                    user=User.objects.create_user(username=aadhar,email=str(inputWorksheet.cell_value(y,32)),password="Admin@123",first_name=str(inputWorksheet.cell_value(y,2)).upper(),last_name=str(inputWorksheet.cell_value(y,1)).upper())
                                    user.save()
                                    # create student id for rejoin
                                    # studid=StudID()
                                    # studid.stud_id="a"
                                    # studid.save()
                                    atkt11AdmModule.stud_id="f12"+str(user.id)+""+prn
                                    my_group=Group.objects.get(name='student')
                                    user.groups.add(my_group)
                                    atkt11AdmModule.user=user
                                    atkt11AdmModule.save()
                                    print(fr)
                        messages.success(request, "File Imported Successfully")
                        return redirect('admission_atkt11list')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('admission_atkt11import')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" 11-ATKT Admission /",
            'yearData':yearData,
            'fname':fname,
            "page_path":"Import-11-ATKT Admission",
            "menu_icon":"nav-icon fas fa-address-card",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)
    else:
        return redirect('login')





# Form1710 Import
def admission_f1710_import(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    admyear=request.POST['year']
                    print(admyear[0:4])
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr) # 1
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):

                                try:
                                    prn=str(int(inputWorksheet.cell_value(y,0)))
                                except:
                                    messages.error(request,"Register Number should contain only numbers")
                                    return redirect('admission_f1710import')

                                try:
                                    aadhar=str(int(inputWorksheet.cell_value(y,6)))
                                except:
                                    messages.error(request,"Aadhar Number should contain only numbers")
                                    return redirect('admission_f1710import')

                                if Form1710Adm.objects.filter(prn__iexact=prn).exists():
                                    messages.error(request,"Register Number Already Exists")
                                    return redirect('admission_f1710import')
                                elif Form1710Adm.objects.filter(aadhar__iexact=aadhar).exists():
                                    messages.error(request,"Aadhar Number Already Exists")
                                    return redirect('admission_f1710import')
                                elif Form1710Adm.objects.filter(email__iexact=str(inputWorksheet.cell_value(y,30))).exists():
                                    messages.error(request,"Email Id Already Exists")
                                    return redirect('admission_f1710import')
                                else:
                                    f1710AdmModule=Form1710Adm()
                                    f1710AdmModule.prn=prn
                                    if inputWorksheet.cell_value(y,1) == "":
                                        messages.error(request,"Student Last Name required")
                                        return redirect('admission_f1710import')
                                    f1710AdmModule.lname=str(inputWorksheet.cell_value(y,1)).upper()
                                    # for first name    
                                    if inputWorksheet.cell_value(y,2) == "":
                                        messages.error(request,"Student First Name required")
                                        return redirect('admission_f1710import')
                                    f1710AdmModule.fname=str(inputWorksheet.cell_value(y,2)).upper()
                                    # for Father name  
                                    if inputWorksheet.cell_value(y,3) == "":
                                        messages.error(request,"Student Father Name required")
                                        return redirect('admission_f1710import')  
                                    f1710AdmModule.faname=str(inputWorksheet.cell_value(y,3)).upper()
                                    # for Mother name    
                                    if inputWorksheet.cell_value(y,4) == "":
                                        messages.error(request,"Student Mother Name required")
                                        return redirect('admission_f1710import')
                                    f1710AdmModule.moname=str(inputWorksheet.cell_value(y,4)).upper()
                                    f1710AdmModule.mrname=inputWorksheet.cell_value(y,5)
                                    #for aadhar validation
                                    print(aadhar)
                                    leng=len(aadhar)
                                    print(leng)
                                    if leng == 12 or leng == 13:
                                        f1710AdmModule.aadhar=aadhar
                                    else:
                                        messages.error(request,"Aadhar Number is 12 or 13 digits")
                                        return redirect('admission_f1710import')
                                        
                                    f1710AdmModule.saral_id=str(inputWorksheet.cell_value(y,7))
                                    natlist=['INDIAN','AFGHAN','BANGLADESHI','NEPALESE']
                                    n=str(inputWorksheet.cell_value(y,8)).upper()
                                    if n in natlist:
                                        print(n)
                                        f1710AdmModule.nationality=n
                                    else:
                                        messages.error(request,"Nationality Does not exists : "+n)
                                        return redirect('admission_f1710import')
                                    tong=str(inputWorksheet.cell_value(y,9)).upper()
                                    # For Mother Tongue
                                    if MTongue.objects.filter(m_tongue=tong).exists():
                                        f1710AdmModule.tongue=MTongue.objects.get(m_tongue=tong)
                                    else:
                                        messages.error(request,"Mother Tongue Does not exists "+tong)
                                        return redirect('admission_f1710import')
                                    #for Religion
                                    rel=str(inputWorksheet.cell_value(y,10)).upper()
                                    if Religion.objects.filter(religionName=rel).exists():
                                        f1710AdmModule.religion=Religion.objects.get(religionName=rel)
                                    else:
                                        messages.error(request,"Religion Does not exists "+rel)
                                        return redirect('admission_f1710import')
                                    # For Caste
                                    cast=str(inputWorksheet.cell_value(y,11)).upper()
                                    if Cast.objects.filter(castName=cast).exists():
                                        f1710AdmModule.cast=Cast.objects.get(castName=cast)
                                    else:
                                        messages.error(request,"Caste Does not exists "+cast)
                                        return redirect('admission_f1710import')
                                    # For SubCaste
                                    scast=str(inputWorksheet.cell_value(y,13)).upper()
                                    if SubCast.objects.filter(subCastName=scast).exists():
                                        f1710AdmModule.subcast=SubCast.objects.get(subCastName=scast)
                                    elif scast=="":
                                        pass
                                    else:
                                        messages.error(request,"SubCaste Does not exists "+scast)
                                        return redirect('admission_f1710import')
                                    minlist=['YES','NO']
                                    mino = str(inputWorksheet.cell_value(y,14)).upper()
                                    if mino in minlist:
                                        print(mino)
                                        f1710AdmModule.minority=mino
                                    else:
                                        messages.error(request,"Minority Does not exists : "+mino)
                                        return redirect('admission_f1710import')
                                    if inputWorksheet.cell_value(y,15) == "":
                                        messages.error(request,"Place of Birth is required")
                                        return redirect('admission_f1710import')
                                    f1710AdmModule.pob=str(inputWorksheet.cell_value(y,15)).upper()
                                    dob=str(inputWorksheet.cell_value(y,16))
                                    leng=len(dob)
                                    if leng==10:
                                        if dob[4]=='-' and dob[7]=='-':
                                            f1710AdmModule.dob=dob
                                        else:
                                            messages.error(request,"Invalid Date Of Birth "+dob)
                                            return redirect('admission_f1710import')
                                    else:
                                        messages.error(request,"Invalid Date Of Birth "+dob)
                                        return redirect('admission_f1710import')
                                    # f1710AdmModule.dob=inputWorksheet.cell_value(y,16)
                                    # For Last attended school
                                    last_s=str(inputWorksheet.cell_value(y,17)).upper()
                                    if last_s=="":
                                        pass
                                    elif OtherSch.objects.filter(schName=last_s).exists():
                                        f1710AdmModule.last_school=OtherSch.objects.get(schName=last_s)
                                    else:
                                        messages.error(request,"School Name Does not exists "+last_s)
                                        return redirect('admission_f1710import')
                                    
                                    # for Last class
                                    if inputWorksheet.cell_value(y,18)!="":
                                        try:
                                            last_class=str(int(inputWorksheet.cell_value(y,18)))
                                        except:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_f1710import')
                                        last_classlist=['5','6','7','8','9','10']
                                        if last_class=="":
                                            pass
                                        elif last_class in last_classlist:
                                            f1710AdmModule.last_class=last_class
                                        else:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_f1710import')

                                    try:
                                        if inputWorksheet.cell_value(y,19) == "":
                                            pass
                                        else:
                                            f1710AdmModule.prevlcsrno=str(int(inputWorksheet.cell_value(y,19)))
                                    except:
                                        messages.error(request,"Invalid Previous LC Sr No")
                                        return redirect('admission_clgimport')
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,20) == "":
                                            pass
                                        else:
                                            f1710AdmModule.prevprn=str(int(inputWorksheet.cell_value(y,20)))
                                    except:
                                        messages.error(request,"Invalid Pervious Registration Number")
                                        return redirect('admission_clgimport')        

                                    admdate=str(inputWorksheet.cell_value(y,21))
                                    leng=len(admdate)
                                    if leng==10:
                                        if admdate[4]=='-' and admdate[7]=='-':
                                            f1710AdmModule.admdate=admdate
                                        else:
                                            messages.error(request,"Invalid Admission Date "+admdate)
                                            return redirect('admission_f1710import')
                                    else:
                                        messages.error(request,"Invalid Admission Date "+admdate)
                                        return redirect('admission_f1710import')
                                    f1710AdmModule.admyear=admyear[0:4]
                                    # for Adm class
                                    try:
                                        adm_class=str(int(inputWorksheet.cell_value(y,22)))
                                    except:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_f1710import')
                                    adm_classlist=['10']
                                    if adm_class in adm_classlist:
                                        f1710AdmModule.adm_class=adm_class
                                    else:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_f1710import')

                                    try:
                                        if inputWorksheet.cell_value(y,23)=="":
                                            pass
                                        else:
                                            f1710AdmModule.rollno=str(int(inputWorksheet.cell_value(y,23)))
                                    except:
                                        messages.error(request,"Invalid Roll Number")
                                        return redirect('admission_f1710import')
                                    # for late Adm 
                                    lateadm=str(inputWorksheet.cell_value(y,24)).upper()
                                    lateadmlist=['YES','NO']
                                    if lateadm in lateadmlist:
                                        f1710AdmModule.lateadm=lateadm
                                    else:
                                        messages.error(request,"Invalid Late Admission ")
                                        return redirect('admission_f1710import')
                                    # for adm type
                                    admtype=str(inputWorksheet.cell_value(y,25)).upper()
                                    admtypelist=['FRESHER','REPETER','ONE TIME FAILED']
                                    if admtype in admtypelist:
                                        f1710AdmModule.admtype=admtype
                                    else:
                                        messages.error(request,"Invalid Admission Type")
                                        return redirect('admission_f1710import')
                                    # for hostel
                                    hostel=str(inputWorksheet.cell_value(y,26)).upper()
                                    hostellist=['YES','NO']
                                    if hostel in hostellist:
                                        f1710AdmModule.hostel=hostel
                                    else:
                                        messages.error(request,"Invalid Hostel")
                                        return redirect('admission_f1710import')
                                    # for Gender
                                    sex=str(inputWorksheet.cell_value(y,27)).upper()
                                    sexlist=['MALE','FEMALE','OTHER']
                                    if sex in sexlist:
                                        f1710AdmModule.sex=sex
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_f1710import')
                                    f1710AdmModule.pwd=str(inputWorksheet.cell_value(y,28)).upper()
                                    f1710AdmModule.bgroup=str(inputWorksheet.cell_value(y,29)).upper()
                                    #for Email validation
                                    email=str(inputWorksheet.cell_value(y,30))
                                    regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'
                                    if(re.search(regex, email)):
                                        f1710AdmModule.email=str(email)
                                    else:
                                        messages.error(request,"Invalid Email Id")
                                        return redirect('admission_f1710import')

                                    # for Gender
                                    areaType=str(inputWorksheet.cell_value(y,31)).upper()
                                    areaTypelist=['RURAL','URBAN']
                                    if areaType in areaTypelist:
                                        f1710AdmModule.areaType=areaType
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_f1710import')
                                    f1710AdmModule.caddress=str(inputWorksheet.cell_value(y,32)).upper()
                                    # for current address == permanent adderss
                                    if inputWorksheet.cell_value(y,32).upper()==inputWorksheet.cell_value(y,33).upper():
                                        f1710AdmModule.ca_is_pa_addr="YES"
                                        f1710AdmModule.paddress=str(inputWorksheet.cell_value(y,32)).upper()
                                    else:
                                        f1710AdmModule.ca_is_pa_addr="NO"
                                        f1710AdmModule.paddress=str(inputWorksheet.cell_value(y,33)).upper()

                                    #for father mobile no
                                    try:
                                        fa_mob=str(inputWorksheet.cell_value(y,34))
                                        if fa_mob=="":
                                            pass
                                        else:
                                            fa_mob=str(int(inputWorksheet.cell_value(y,34)))
                                    except:
                                        messages.error(request,"Father Mobile Number should contain only numbers")
                                        return redirect('admission_f1710import')
                                    print(fa_mob)
                                    leng=len(fa_mob)
                                    if fa_mob =="":
                                        f1710AdmModule.fa_mob=fa_mob
                                    elif leng == 10:
                                        f1710AdmModule.fa_mob=fa_mob
                                    else:
                                        messages.error(request,"Father Mobile Number should be 10 digits")
                                        return redirect('admission_f1710import')
                                    print(fa_mob)
                                    
                                    #for mother mobile no
                                    try:
                                        mo_mob=str(inputWorksheet.cell_value(y,35))
                                        if mo_mob=="":
                                            pass
                                        else:
                                            mo_mob=str(int(inputWorksheet.cell_value(y,35)))
                                    except:
                                        messages.error(request,"Mother Mobile Number should contain only numbers")
                                        return redirect('admission_f1710import')
                                    leng=len(mo_mob)
                                    if mo_mob =="":
                                        f1710AdmModule.mo_mob=mo_mob
                                    elif leng == 10:
                                        f1710AdmModule.mo_mob=mo_mob
                                    else:
                                        messages.error(request,"Mother Mobile Number should be 10 digits")
                                        return redirect('admission_f1710import')
                                    
                                    f1710AdmModule.fa_occu=str(inputWorksheet.cell_value(y,36)).upper()
                                    f1710AdmModule.mo_occu=str(inputWorksheet.cell_value(y,37)).upper()
                                    f1710AdmModule.fam_income=str(inputWorksheet.cell_value(y,38))
                                    # for bpl
                                    bpl=str(inputWorksheet.cell_value(y,39)).upper()
                                    bpllist=['YES','NO']
                                    if bpl in bpllist:
                                        f1710AdmModule.bpl=bpl
                                    else:
                                        messages.error(request,"Invalid BPL")
                                        return redirect('admission_f1710import')
                                    #for Guardian is
                                    gis=str(inputWorksheet.cell_value(y,40)).upper()
                                    glist=['FATHER','MOTHER','OTHER']
                                    if gis in glist:
                                        f1710AdmModule.gis=gis
                                    else:
                                        messages.error(request,"Invalid Guardian Is")
                                        return redirect('admission_f1710import')
                                    f1710AdmModule.ganame=str(inputWorksheet.cell_value(y,41)).upper()
                                    try:
                                        ga_mob=str(inputWorksheet.cell_value(y,42))
                                        if ga_mob=="":
                                            pass
                                        else:
                                            ga_mob=str(int(inputWorksheet.cell_value(y,42)))
                                    except:
                                        messages.error(request,"Guardian Mobile Number should contain only numbers")
                                        return redirect('admission_f1710import')
                                    leng=len(ga_mob)
                                    if ga_mob =="":
                                        f1710AdmModule.ga_mob=ga_mob
                                    elif leng == 10:
                                        f1710AdmModule.ga_mob=ga_mob
                                    else:
                                        messages.error(request,"Guardian Mobile Number should be 10 digits")
                                        return redirect('admission_f1710import')
                                    f1710AdmModule.ga_occu=str(inputWorksheet.cell_value(y,43)).upper()
                                    f1710AdmModule.gaddress=str(inputWorksheet.cell_value(y,44)).upper()
                                    f1710AdmModule.ga_relation=str(inputWorksheet.cell_value(y,45)).upper()

                                    try:
                                        if inputWorksheet.cell_value(y,46)=="":
                                            pass
                                        else:
                                            f1710AdmModule.baccount=str(int(inputWorksheet.cell_value(y,46)))
                                    except:
                                        messages.error(request,"Invalid Bank Account Number")
                                        return redirect('admission_f1710import')

                                    f1710AdmModule.bankname=str(inputWorksheet.cell_value(y,47)).upper()
                                    f1710AdmModule.ifsc=str(inputWorksheet.cell_value(y,48))
                                    f1710AdmModule.branch=str(inputWorksheet.cell_value(y,49)).upper()
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,50)=="":
                                            pass
                                        else:
                                            f1710AdmModule.micr=str(int(inputWorksheet.cell_value(y,50)))
                                    except:
                                        messages.error(request,"Invalid MICR Code")
                                        return redirect('admission_f1710import')
                                    
                                    f1710AdmModule.note=str(inputWorksheet.cell_value(y,51))


                                    # Create User for Student
                                    user=User.objects.create_user(username=aadhar,email=str(inputWorksheet.cell_value(y,30)),password="Admin@123",first_name=str(inputWorksheet.cell_value(y,2)).upper(),last_name=str(inputWorksheet.cell_value(y,1)).upper())
                                    user.save()
                                    # create student id for rejoin
                                    # studid=StudID()
                                    # studid.stud_id="a"
                                    # studid.save()
                                    f1710AdmModule.stud_id="f10"+str(user.id)+""+prn
                                    my_group=Group.objects.get(name='student')
                                    user.groups.add(my_group)
                                    f1710AdmModule.user=user
                                    f1710AdmModule.save()
                                    print(fr)
                        messages.success(request, "File Imported Successfully")
                        return redirect('admission_form1710list')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('admission_f1710import')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Form1710 Admission /",
            'yearData':yearData,
            'fname':fname,
            "page_path":"Import-Form1710 Admission",
            "menu_icon":"nav-icon fas fa-address-card",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)
    else:
        return redirect('login')





# Form1712 Import
def admission_f1712_import(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    admyear=request.POST['year']
                    print(admyear[0:4])
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr) # 1
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):

                                try:
                                    prn=str(int(inputWorksheet.cell_value(y,0)))
                                except:
                                    messages.error(request,"Register Number should contain only numbers")
                                    return redirect('admission_f1712import')

                                try:
                                    aadhar=str(int(inputWorksheet.cell_value(y,6)))
                                except:
                                    messages.error(request,"Aadhar Number should contain only numbers")
                                    return redirect('admission_f1712import')

                                if Form1712Adm.objects.filter(prn__iexact=prn).exists():
                                    messages.error(request,"Register Number Already Exists")
                                    return redirect('admission_f1712import')
                                elif Form1712Adm.objects.filter(aadhar__iexact=aadhar).exists():
                                    messages.error(request,"Aadhar Number Already Exists")
                                    return redirect('admission_f1712import')
                                elif Form1712Adm.objects.filter(email__iexact=str(inputWorksheet.cell_value(y,31))).exists():
                                    messages.error(request,"Email Id Already Exists")
                                    return redirect('admission_f1712import')
                                else:
                                    f1712AdmModule=Form1712Adm()
                                    #for prn validation
                                    f1712AdmModule.prn=prn
                                    if inputWorksheet.cell_value(y,1) == "":
                                        messages.error(request,"Student Last Name required")
                                        return redirect('admission_f1712import')
                                    f1712AdmModule.lname=str(inputWorksheet.cell_value(y,1)).upper()
                                    # for first name    
                                    if inputWorksheet.cell_value(y,2) == "":
                                        messages.error(request,"Student First Name required")
                                        return redirect('admission_f1712import')
                                    f1712AdmModule.fname=str(inputWorksheet.cell_value(y,2)).upper()
                                    # for Father name  
                                    if inputWorksheet.cell_value(y,3) == "":
                                        messages.error(request,"Student Father Name required")
                                        return redirect('admission_f1712import')  
                                    f1712AdmModule.faname=str(inputWorksheet.cell_value(y,3)).upper()
                                    # for Mother name    
                                    if inputWorksheet.cell_value(y,4) == "":
                                        messages.error(request,"Student Mother Name required")
                                        return redirect('admission_f1712import')
                                    f1712AdmModule.moname=str(inputWorksheet.cell_value(y,4)).upper()
                                    f1712AdmModule.mrname=str(inputWorksheet.cell_value(y,5))
                                    #for aadhar validation
                                    leng=len(aadhar)
                                    if leng == 12 or leng == 13:
                                        f1712AdmModule.aadhar=aadhar
                                    else:
                                        messages.error(request,"Aadhar Number is 12 or 13 digits")
                                        return redirect('admission_f1712import')
                                        
                                    f1712AdmModule.saral_id=str(inputWorksheet.cell_value(y,7))
                                    natlist=['INDIAN','AFGHAN','BANGLADESHI','NEPALESE']
                                    n=str(inputWorksheet.cell_value(y,8)).upper()
                                    if n in natlist:
                                        print(n)
                                        f1712AdmModule.nationality=n
                                    else:
                                        messages.error(request,"Nationality Does not exists : "+n)
                                        return redirect('admission_f1712import')
                                    tong=str(inputWorksheet.cell_value(y,9)).upper()
                                    # For Mother Tongue
                                    if MTongue.objects.filter(m_tongue=tong).exists():
                                        f1712AdmModule.tongue=MTongue.objects.get(m_tongue=tong)
                                    else:
                                        messages.error(request,"Mother Tongue Does not exists "+tong)
                                        return redirect('admission_f1712import')
                                    #for Religion
                                    rel=str(inputWorksheet.cell_value(y,10)).upper()
                                    if Religion.objects.filter(religionName=rel).exists():
                                        f1712AdmModule.religion=Religion.objects.get(religionName=rel)
                                    else:
                                        messages.error(request,"Religion Does not exists "+rel)
                                        return redirect('admission_f1712import')
                                    # For Caste
                                    cast=str(inputWorksheet.cell_value(y,11)).upper()
                                    if Cast.objects.filter(castName=cast).exists():
                                        f1712AdmModule.cast=Cast.objects.get(castName=cast)
                                    else:
                                        messages.error(request,"Caste Does not exists "+cast)
                                        return redirect('admission_f1712import')
                                    # For SubCaste
                                    scast=str(inputWorksheet.cell_value(y,13)).upper()
                                    if SubCast.objects.filter(subCastName=scast).exists():
                                        f1712AdmModule.subcast=SubCast.objects.get(subCastName=scast)
                                    elif scast=="":
                                        pass
                                    else:
                                        messages.error(request,"SubCaste Does not exists "+scast)
                                        return redirect('admission_f1712import')
                                    minlist=['YES','NO']
                                    mino = str(inputWorksheet.cell_value(y,14)).upper()
                                    if mino in minlist:
                                        print(mino)
                                        f1712AdmModule.minority=mino
                                    else:
                                        messages.error(request,"Minority Does not exists : "+mino)
                                        return redirect('admission_f1712import')
                                    if inputWorksheet.cell_value(y,15) == "":
                                        messages.error(request,"Place of Birth is required")
                                        return redirect('admission_f1712import')
                                    f1712AdmModule.pob=str(inputWorksheet.cell_value(y,15)).upper()
                                    dob=str(inputWorksheet.cell_value(y,16))
                                    leng=len(dob)
                                    if leng==10:
                                        if dob[4]=='-' and dob[7]=='-':
                                            f1712AdmModule.dob=dob
                                        else:
                                            messages.error(request,"Invalid Date Of Birth "+dob)
                                            return redirect('admission_f1712import')
                                    else:
                                        messages.error(request,"Invalid Date Of Birth "+dob)
                                        return redirect('admission_f1712import')
                                    # f1712AdmModule.dob=inputWorksheet.cell_value(y,16)
                                    # For Last attended school
                                    last_s=str(inputWorksheet.cell_value(y,17)).upper()
                                    if last_s=="":
                                        pass
                                    elif OtherSch.objects.filter(schName=last_s).exists():
                                        f1712AdmModule.last_school=OtherSch.objects.get(schName=last_s)
                                    else:
                                        messages.error(request,"School Name Does not exists "+last_s)
                                        return redirect('admission_f1712import')

                                    # for Last class
                                    if inputWorksheet.cell_value(y,18)!="":
                                        try:
                                            last_class=str(int(inputWorksheet.cell_value(y,18)))
                                        except:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_f1712import')
                                        last_classlist=['10','11','12']
                                        if last_class=="":
                                            pass
                                        elif last_class in last_classlist:
                                            f1712AdmModule.last_class=last_class
                                        else:
                                            messages.error(request,"Invalid Last Attended Class")
                                            return redirect('admission_f1712import')

                                    try:
                                        if inputWorksheet.cell_value(y,19) == "":
                                            pass
                                        else:
                                            f1712AdmModule.prevlcsrno=str(int(inputWorksheet.cell_value(y,19)))
                                    except:
                                        messages.error(request,"Invalid Previous LC Sr No")
                                        return redirect('admission_f1712import')
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,20) == "":
                                            pass
                                        else:
                                            f1712AdmModule.prevprn=str(int(inputWorksheet.cell_value(y,20)))
                                    except:
                                        messages.error(request,"Invalid Pervious Registration Number")
                                        return redirect('admission_f1712import')

                                    admdate=str(inputWorksheet.cell_value(y,21))
                                    leng=len(admdate)
                                    if leng==10:
                                        if admdate[4]=='-' and admdate[7]=='-':
                                            f1712AdmModule.admdate=admdate
                                        else:
                                            messages.error(request,"Invalid Admission Date "+admdate)
                                            return redirect('admission_f1712import')
                                    else:
                                        messages.error(request,"Invalid Admission Date "+admdate)
                                        return redirect('admission_f1712import')
                                    f1712AdmModule.admyear=admyear[0:4]
                                    # for Adm class
                                    try:
                                        adm_class=str(int(inputWorksheet.cell_value(y,22)))
                                    except:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_f1712import')
                                    adm_classlist=['12']
                                    if adm_class in adm_classlist:
                                        f1712AdmModule.adm_class=adm_class
                                    else:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_f1712import')
                                    
                                    adm_facultylist=['SCIENCE','COMMERCE','ARTS','VOCATIONAL']
                                    admission_faculty=str(inputWorksheet.cell_value(y,23))
                                    if admission_faculty in adm_facultylist:
                                        f1712AdmModule.admission_faculty=admission_faculty
                                    else:
                                        messages.error(request,"Invalid Admission Faculty")
                                        return redirect('admission_f1712import')

                                    try:
                                        if inputWorksheet.cell_value(y,24)=="":
                                            pass
                                        else:
                                            f1712AdmModule.rollno=str(int(inputWorksheet.cell_value(y,24)))
                                    except:
                                        messages.error(request,"Invalid Roll Number")
                                        return redirect('admission_f1712import')
                                    # for late Adm 
                                    lateadm=str(inputWorksheet.cell_value(y,25)).upper()
                                    lateadmlist=['YES','NO']
                                    if lateadm in lateadmlist:
                                        f1712AdmModule.lateadm=lateadm
                                    else:
                                        messages.error(request,"Invalid Late Admission ")
                                        return redirect('admission_f1712import')
                                    # for adm type
                                    admtype=str(inputWorksheet.cell_value(y,26)).upper()
                                    admtypelist=['FRESHER','REPETER','ONE TIME FAILED']
                                    if admtype in admtypelist:
                                        f1712AdmModule.admtype=admtype
                                    else:
                                        messages.error(request,"Invalid Admission Type")
                                        return redirect('admission_f1712import')
                                    # for hostel
                                    hostel=str(inputWorksheet.cell_value(y,27)).upper()
                                    hostellist=['YES','NO']
                                    if hostel in hostellist:
                                        f1712AdmModule.hostel=hostel
                                    else:
                                        messages.error(request,"Invalid Hostel")
                                        return redirect('admission_f1712import')
                                    # for Gender
                                    sex=str(inputWorksheet.cell_value(y,28)).upper()
                                    sexlist=['MALE','FEMALE','OTHER']
                                    if sex in sexlist:
                                        f1712AdmModule.sex=sex
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_f1712import')
                                    f1712AdmModule.pwd=str(inputWorksheet.cell_value(y,29)).upper()
                                    f1712AdmModule.bgroup=str(inputWorksheet.cell_value(y,30)).upper()
                                    #for Email validation
                                    email=str(inputWorksheet.cell_value(y,31))
                                    regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'
                                    if(re.search(regex, email)):
                                        f1712AdmModule.email=str(email)
                                    else:
                                        messages.error(request,"Invalid Email Id")
                                        return redirect('admission_f1712import')

                                    # for Gender
                                    areaType=str(inputWorksheet.cell_value(y,32)).upper()
                                    areaTypelist=['RURAL','URBAN']
                                    if areaType in areaTypelist:
                                        f1712AdmModule.areaType=areaType
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_f1712import')
                                    f1712AdmModule.caddress=str(inputWorksheet.cell_value(y,33)).upper()
                                    # for current address == permanent adderss
                                    if inputWorksheet.cell_value(y,33).upper()==inputWorksheet.cell_value(y,34).upper():
                                        f1712AdmModule.ca_is_pa_addr="YES"
                                        f1712AdmModule.paddress=str(inputWorksheet.cell_value(y,33)).upper()
                                    else:
                                        f1712AdmModule.ca_is_pa_addr="NO"
                                        f1712AdmModule.paddress=str(inputWorksheet.cell_value(y,34)).upper()

                                    #for father mobile no
                                    try:
                                        fa_mob=str(inputWorksheet.cell_value(y,35))
                                        if fa_mob=="":
                                            pass
                                        else:
                                            fa_mob=str(int(inputWorksheet.cell_value(y,35)))
                                    except:
                                        messages.error(request,"Father Mobile Number should contain only numbers")
                                        return redirect('admission_f1712import')
                                    print(fa_mob)
                                    leng=len(fa_mob)
                                    if fa_mob =="":
                                        f1712AdmModule.fa_mob=fa_mob
                                    elif leng == 10:
                                        f1712AdmModule.fa_mob=fa_mob
                                    else:
                                        messages.error(request,"Father Mobile Number should be 10 digits")
                                        return redirect('admission_f1712import')
                                    print(fa_mob)
                                    
                                    #for mother mobile no
                                    try:
                                        mo_mob=str(inputWorksheet.cell_value(y,36))
                                        if mo_mob=="":
                                            pass
                                        else:
                                            mo_mob=str(int(inputWorksheet.cell_value(y,36)))
                                    except:
                                        messages.error(request,"Mother Mobile Number should contain only numbers")
                                        return redirect('admission_f1712import')
                                    leng=len(mo_mob)
                                    if mo_mob =="":
                                        f1712AdmModule.mo_mob=mo_mob
                                    elif leng == 10:
                                        f1712AdmModule.mo_mob=mo_mob
                                    else:
                                        messages.error(request,"Mother Mobile Number should be 10 digits")
                                        return redirect('admission_f1712import')
                                    
                                    f1712AdmModule.fa_occu=str(inputWorksheet.cell_value(y,37)).upper()
                                    f1712AdmModule.mo_occu=str(inputWorksheet.cell_value(y,38)).upper()
                                    f1712AdmModule.fam_income=str(inputWorksheet.cell_value(y,39))
                                    # for bpl
                                    bpl=str(inputWorksheet.cell_value(y,40)).upper()
                                    bpllist=['YES','NO']
                                    if bpl in bpllist:
                                        f1712AdmModule.bpl=bpl
                                    else:
                                        messages.error(request,"Invalid BPL")
                                        return redirect('admission_f1712import')
                                    #for Guardian is
                                    gis=str(inputWorksheet.cell_value(y,41)).upper()
                                    glist=['FATHER','MOTHER','OTHER']
                                    if gis in glist:
                                        f1712AdmModule.gis=gis
                                    else:
                                        messages.error(request,"Invalid Guardian Is")
                                        return redirect('admission_f1712import')
                                    f1712AdmModule.ganame=str(inputWorksheet.cell_value(y,42)).upper()
                                    try:
                                        ga_mob=str(inputWorksheet.cell_value(y,43))
                                        if ga_mob=="":
                                            pass
                                        else:
                                            ga_mob=str(int(inputWorksheet.cell_value(y,43)))
                                    except:
                                        messages.error(request,"Guardian Mobile Number should contain only numbers")
                                        return redirect('admission_f1712import')
                                    leng=len(ga_mob)
                                    if ga_mob =="":
                                        f1712AdmModule.ga_mob=ga_mob
                                    elif leng == 10:
                                        f1712AdmModule.ga_mob=ga_mob
                                    else:
                                        messages.error(request,"Guardian Mobile Number should be 10 digits")
                                        return redirect('admission_f1712import')
                                    f1712AdmModule.ga_occu=str(inputWorksheet.cell_value(y,44)).upper()
                                    f1712AdmModule.gaddress=str(inputWorksheet.cell_value(y,45)).upper()
                                    f1712AdmModule.ga_relation=str(inputWorksheet.cell_value(y,46)).upper()

                                    try:
                                        if inputWorksheet.cell_value(y,47)=="":
                                            pass
                                        else:
                                            f1712AdmModule.baccount=str(int(inputWorksheet.cell_value(y,47)))
                                    except:
                                        messages.error(request,"Invalid Bank Account Number")
                                        return redirect('admission_f1712import')

                                    f1712AdmModule.bankname=str(inputWorksheet.cell_value(y,48)).upper()
                                    f1712AdmModule.ifsc=str(inputWorksheet.cell_value(y,49))
                                    f1712AdmModule.branch=str(inputWorksheet.cell_value(y,50)).upper()
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,51)=="":
                                            pass
                                        else:
                                            f1712AdmModule.micr=str(int(inputWorksheet.cell_value(y,51)))
                                    except:
                                        messages.error(request,"Invalid MICR Code")
                                        return redirect('admission_f1712import')
                                    
                                    f1712AdmModule.note=str(inputWorksheet.cell_value(y,52))

                                    

                                    # Create User for Student
                                    user=User.objects.create_user(username=aadhar,email=str(inputWorksheet.cell_value(y,31)),password="Admin@123",first_name=str(inputWorksheet.cell_value(y,2)).upper(),last_name=str(inputWorksheet.cell_value(y,1)).upper())
                                    user.save()
                                    # create student id for rejoin
                                    # studid=StudID()
                                    # studid.stud_id="a"
                                    # studid.save()
                                    f1712AdmModule.stud_id="f12"+str(user.id)+""+prn
                                    my_group=Group.objects.get(name='student')
                                    user.groups.add(my_group)
                                    f1712AdmModule.user=user
                                    f1712AdmModule.save()
                                    print(fr)
                        messages.success(request, "File Imported Successfully")
                        return redirect('admission_form1712list')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('admission_f1712import')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Form1712 Admission /",
            'yearData':yearData,
            'fname':fname,
            "page_path":"Import-Form1712 Admission",
            "menu_icon":"nav-icon fas fa-address-card",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)
    else:
        return redirect('login')