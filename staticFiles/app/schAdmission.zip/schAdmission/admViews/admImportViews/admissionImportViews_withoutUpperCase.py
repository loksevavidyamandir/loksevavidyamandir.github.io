from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import  Division,MTongue,OtherSch,ImportData
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm
from schSetup.setupForms.setup_forms import ImportDataForm
import re

import xlwt
from xlwt.Formatting import Borders
import xlrd
import os

basedir=conf_set.BASE_DIR
sname=conf_set.SCHOOL_NAME




#primary Import
def admission_prim_import(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr) # 1
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):

                                try:
                                    prn=str(int(inputWorksheet.cell_value(y,0)))
                                except:
                                    messages.error(request,"Register Number should contain only numbers")
                                    return redirect('admission_primimport')

                                try:
                                    aadhar=str(int(inputWorksheet.cell_value(y,6)))
                                except:
                                    messages.error(request,"Aadhar Number should contain only numbers")
                                    return redirect('admission_primimport')

                                if PrimAdm.objects.filter(prn__iexact=prn).exists():
                                    messages.error(request,"Register Number Already Exists")
                                    return redirect('admission_primimport')
                                elif PrimAdm.objects.filter(aadhar__iexact=aadhar).exists():
                                    messages.error(request,"Aadhar Number Already Exists")
                                    return redirect('admission_primimport')
                                elif PrimAdm.objects.filter(email__iexact=str(inputWorksheet.cell_value(y,28))).exists():
                                    messages.error(request,"Email Id Already Exists")
                                    return redirect('admission_primimport')
                                else:
                                    priAdmModule=PrimAdm()
                                    #for prn validation
                                    priAdmModule.prn=prn
                                    priAdmModule.lname=str(inputWorksheet.cell_value(y,1))
                                    # for first name    
                                    priAdmModule.fname=str(inputWorksheet.cell_value(y,2))
                                    # for Father name    
                                    priAdmModule.faname=str(inputWorksheet.cell_value(y,3))
                                    # for Mother name    
                                    priAdmModule.moname=str(inputWorksheet.cell_value(y,4))
                                    priAdmModule.mrname=str(inputWorksheet.cell_value(y,5))
                                    #for aadhar validation
                                    print(aadhar)
                                    leng=len(aadhar)
                                    print(leng)
                                    if leng == 12 or leng == 13:
                                        priAdmModule.aadhar=aadhar
                                    else:
                                        messages.error(request,"Aadhar Number is 12 or 13 digits")
                                        return redirect('admission_primimport')
                                        
                                    priAdmModule.saral_id=str(inputWorksheet.cell_value(y,7))
                                    natlist=['INDIAN','AFGHAN','BANGLADESHI','NEPALESE']
                                    n=str(inputWorksheet.cell_value(y,8)).upper()
                                    if n in natlist:
                                        print(n)
                                        priAdmModule.nationality=n
                                    else:
                                        messages.error(request,"Nationality Does not exists : "+n)
                                        return redirect('admission_primimport')
                                    tong=str(inputWorksheet.cell_value(y,9)).upper()
                                    # For Mother Tongue
                                    if MTongue.objects.filter(m_tongue=tong).exists():
                                        priAdmModule.tongue=MTongue.objects.get(m_tongue=tong)
                                    else:
                                        messages.error(request,"Mother Tongue Does not exists "+tong)
                                        return redirect('admission_primimport')
                                    #for Religion
                                    rel=str(inputWorksheet.cell_value(y,10)).upper()
                                    if Religion.objects.filter(religionName=rel).exists():
                                        priAdmModule.religion=Religion.objects.get(religionName=rel)
                                    else:
                                        messages.error(request,"Religion Does not exists "+rel)
                                        return redirect('admission_primimport')
                                    # For Caste
                                    cast=str(inputWorksheet.cell_value(y,11)).upper()
                                    if Cast.objects.filter(castName=cast).exists():
                                        priAdmModule.cast=Cast.objects.get(castName=cast)
                                    else:
                                        messages.error(request,"Caste Does not exists "+cast)
                                        return redirect('admission_primimport')
                                    # For Caste Category
                                    castcat=str(inputWorksheet.cell_value(y,12)).upper()
                                    if CastCategory.objects.filter(castCategoryName=castcat).exists():
                                        priAdmModule.category=CastCategory.objects.get(castCategoryName=castcat)
                                    else:
                                        messages.error(request,"Caste Category Does not exists "+castcat)
                                        return redirect('admission_primimport')
                                    # For SubCaste
                                    scast=str(inputWorksheet.cell_value(y,13)).upper()
                                    if SubCast.objects.filter(subCastName=scast).exists():
                                        priAdmModule.subcast=SubCast.objects.get(subCastName=scast)
                                    elif scast=="":
                                        pass
                                    else:
                                        messages.error(request,"SubCaste Does not exists "+scast)
                                        return redirect('admission_primimport')
                                    minlist=['YES','NO']
                                    mino = str(inputWorksheet.cell_value(y,14)).upper()
                                    if mino in minlist:
                                        print(mino)
                                        priAdmModule.minority=mino
                                    else:
                                        messages.error(request,"Minority Does not exists : "+mino)
                                        return redirect('admission_primimport')
                                    priAdmModule.pob=str(inputWorksheet.cell_value(y,15))
                                    dob=str(inputWorksheet.cell_value(y,16))
                                    leng=len(dob)
                                    if leng==10:
                                        if dob[4]=='-' and dob[7]=='-':
                                            priAdmModule.dob=dob
                                        else:
                                            messages.error(request,"Invalid Date Of Birth "+dob)
                                            return redirect('admission_primimport')
                                    else:
                                        messages.error(request,"Invalid Date Of Birth "+dob)
                                        return redirect('admission_primimport')
                                    # priAdmModule.dob=inputWorksheet.cell_value(y,16)
                                    # For Last attended school
                                    last_s=str(inputWorksheet.cell_value(y,17)).upper()
                                    if last_s=="":
                                        pass
                                    elif OtherSch.objects.filter(schName=last_s).exists():
                                        priAdmModule.last_school=OtherSch.objects.get(schName=last_s)
                                    else:
                                        messages.error(request,"School Name Does not exists "+last_s)
                                        return redirect('admission_primimport')

                                    admdate=str(inputWorksheet.cell_value(y,18))
                                    leng=len(admdate)
                                    if leng==10:
                                        if admdate[4]=='-' and admdate[7]=='-':
                                            priAdmModule.admdate=admdate
                                        else:
                                            messages.error(request,"Invalid Admission Date "+admdate)
                                            return redirect('admission_primimport')
                                    else:
                                        messages.error(request,"Invalid Admission Date "+admdate)
                                        return redirect('admission_primimport')
                                    year=str(inputWorksheet.cell_value(y,18))
                                    print(year) #9
                                    priAdmModule.admyear=year[0:4]
                                    # for Adm class
                                    try:
                                        adm_class=str(int(inputWorksheet.cell_value(y,19)))
                                    except:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_primimport')
                                    adm_classlist=['1','2','3','4']
                                    if adm_class in adm_classlist:
                                        priAdmModule.adm_class=adm_class
                                    else:
                                        messages.error(request,"Invalid Admission Standard")
                                        return redirect('admission_primimport')
                                    # For Division
                                    div=str(inputWorksheet.cell_value(y,20)).upper()
                                    if div == "":
                                        pass
                                    elif Division.objects.filter(division=div).exists():
                                        priAdmModule.division=Division.objects.get(division=div)
                                    else:
                                        messages.error(request,"Division Does not exists "+div)
                                        return redirect('admission_primimport')

                                    priAdmModule.rollno=str(inputWorksheet.cell_value(y,21))
                                    # for late Adm 
                                    lateadm=str(inputWorksheet.cell_value(y,22)).upper()
                                    lateadmlist=['YES','NO']
                                    if lateadm in lateadmlist:
                                        priAdmModule.lateadm=lateadm
                                    else:
                                        messages.error(request,"Invalid Late Admission ")
                                        return redirect('admission_primimport')
                                    # for adm type
                                    admtype=str(inputWorksheet.cell_value(y,23)).upper()
                                    admtypelist=['FRESHER','REPETER','ONE TIME FAILED']
                                    if admtype in admtypelist:
                                        priAdmModule.admtype=admtype
                                    else:
                                        messages.error(request,"Invalid Admission Type")
                                        return redirect('admission_primimport')
                                    # for hostel
                                    hostel=str(inputWorksheet.cell_value(y,24)).upper()
                                    hostellist=['YES','NO']
                                    if hostel in hostellist:
                                        priAdmModule.hostel=hostel
                                    else:
                                        messages.error(request,"Invalid Hostel")
                                        return redirect('admission_primimport')
                                    # for Gender
                                    sex=str(inputWorksheet.cell_value(y,25)).upper()
                                    sexlist=['MALE','FEMALE','OTHER']
                                    if sex in sexlist:
                                        priAdmModule.sex=sex
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_primimport')
                                    priAdmModule.pwd=str(inputWorksheet.cell_value(y,26))
                                    priAdmModule.bgroup=str(inputWorksheet.cell_value(y,27))
                                    #for Email validation
                                    email=str(inputWorksheet.cell_value(y,28))
                                    regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'
                                    if(re.search(regex, email)):
                                        priAdmModule.email=str(email)
                                    else:
                                        messages.error(request,"Invalid Email Id")
                                        return redirect('admission_primimport')

                                    # for Gender
                                    areaType=str(inputWorksheet.cell_value(y,29)).upper()
                                    areaTypelist=['RURAL','URBAN']
                                    if areaType in areaTypelist:
                                        priAdmModule.areaType=areaType
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('admission_primimport')
                                    priAdmModule.caddress=str(inputWorksheet.cell_value(y,30))
                                    # for current address == permanent adderss
                                    if inputWorksheet.cell_value(y,30).upper()==inputWorksheet.cell_value(y,31).upper():
                                        priAdmModule.ca_is_pa_addr="YES"
                                    else:
                                        priAdmModule.ca_is_pa_addr="NO"
                                        priAdmModule.paddress=str(inputWorksheet.cell_value(y,31))

                                    #for father mobile no
                                    try:
                                        fa_mob=str(inputWorksheet.cell_value(y,32))
                                        if fa_mob=="":
                                            pass
                                        else:
                                            fa_mob=str(int(inputWorksheet.cell_value(y,32)))
                                    except:
                                        messages.error(request,"Father Mobile Number should contain only numbers")
                                        return redirect('admission_primimport')
                                    print(fa_mob)
                                    leng=len(fa_mob)
                                    if fa_mob =="":
                                        priAdmModule.fa_mob=fa_mob
                                    elif leng == 10:
                                        priAdmModule.fa_mob=fa_mob
                                    else:
                                        messages.error(request,"Father Mobile Number should be 10 digits")
                                        return redirect('admission_primimport')
                                    print(fa_mob)
                                    
                                    #for mother mobile no
                                    try:
                                        mo_mob=str(inputWorksheet.cell_value(y,33))
                                        if mo_mob=="":
                                            pass
                                        else:
                                            mo_mob=str(int(inputWorksheet.cell_value(y,33)))
                                    except:
                                        messages.error(request,"Mother Mobile Number should contain only numbers")
                                        return redirect('admission_primimport')
                                    leng=len(mo_mob)
                                    if mo_mob =="":
                                        priAdmModule.mo_mob=mo_mob
                                    elif leng == 10:
                                        priAdmModule.mo_mob=mo_mob
                                    else:
                                        messages.error(request,"Mother Mobile Number should be 10 digits")
                                        return redirect('admission_primimport')
                                    
                                    priAdmModule.fa_occu=str(inputWorksheet.cell_value(y,34))
                                    priAdmModule.mo_occu=str(inputWorksheet.cell_value(y,35))
                                    priAdmModule.fam_income=str(inputWorksheet.cell_value(y,36))
                                    # for bpl
                                    bpl=str(inputWorksheet.cell_value(y,37)).upper()
                                    bpllist=['YES','NO']
                                    if bpl in bpllist:
                                        priAdmModule.bpl=bpl
                                    else:
                                        messages.error(request,"Invalid BPL")
                                        return redirect('admission_primimport')
                                    #for Guardian is
                                    gis=str(inputWorksheet.cell_value(y,38)).upper()
                                    glist=['FATHER','MOTHER','OTHER']
                                    if gis in glist:
                                        priAdmModule.gis=gis
                                    else:
                                        messages.error(request,"Invalid Guardian Is")
                                        return redirect('admission_primimport')
                                    priAdmModule.ganame=str(inputWorksheet.cell_value(y,39))
                                    try:
                                        ga_mob=str(inputWorksheet.cell_value(y,40))
                                        if ga_mob=="":
                                            pass
                                        else:
                                            ga_mob=str(int(inputWorksheet.cell_value(y,40)))
                                    except:
                                        messages.error(request,"Guardian Mobile Number should contain only numbers")
                                        return redirect('admission_primimport')
                                    leng=len(ga_mob)
                                    if ga_mob =="":
                                        priAdmModule.ga_mob=ga_mob
                                    elif leng == 10:
                                        priAdmModule.ga_mob=ga_mob
                                    else:
                                        messages.error(request,"Guardian Mobile Number should be 10 digits")
                                        return redirect('admission_primimport')
                                    priAdmModule.ga_occu=str(inputWorksheet.cell_value(y,41))
                                    priAdmModule.gaddress=str(inputWorksheet.cell_value(y,42))
                                    priAdmModule.ga_relation=str(inputWorksheet.cell_value(y,43))
                                    priAdmModule.baccount=str(inputWorksheet.cell_value(y,44))
                                    priAdmModule.bankname=str(inputWorksheet.cell_value(y,45))
                                    priAdmModule.ifsc=str(inputWorksheet.cell_value(y,46))
                                    priAdmModule.branch=str(inputWorksheet.cell_value(y,47))
                                    priAdmModule.micr=str(inputWorksheet.cell_value(y,48))
                                    # Create User for Student
                                    user=User.objects.create_user(username=aadhar,email=str(inputWorksheet.cell_value(y,28)),password="Admin@123",first_name=str(inputWorksheet.cell_value(y,2)),last_name=str(inputWorksheet.cell_value(y,1)))
                                    user.save()
                                    # create student id for rejoin
                                    # studid=StudID()
                                    # studid.stud_id="a"
                                    # studid.save()
                                    priAdmModule.stud_id="stu458did"
                                    my_group=Group.objects.get(name='student')
                                    user.groups.add(my_group)
                                    priAdmModule.user=user
                                    priAdmModule.save()
                                    print(fr)
                        messages.success(request, "File Imported Successfully")
                        return redirect('admission_primlist')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('admission_primlist')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Primary Admission /",
            'fname':fname,
            "page_path":"  Import-Primary Admission",
            "menu_icon":"nav-icon fas fa-address-card",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)
    else:
        return redirect('login')