from django.db import models
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm



class PrimBonafide(models.Model):
    prim_academic=models.ForeignKey(PrimAdm,on_delete=models.CASCADE)
    prn=models.CharField(max_length=50)
    lname=models.CharField(max_length=100)
    fname=models.CharField(max_length=100)
    faname=models.CharField(max_length=100)
    breligion=models.CharField(max_length=100)
    bcast=models.CharField(max_length=100)
    dob=models.CharField(max_length=10)
    dobinwords=models.CharField(max_length=100)
    bona_class=models.CharField(max_length=2)
    bona_year=models.CharField(max_length=10)
    issuedate=models.CharField(max_length=10,null=True)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"primbonafide"





class SecBonafide(models.Model):
    sec_academic=models.ForeignKey(SecondAdm,on_delete=models.CASCADE)
    prn=models.CharField(max_length=50)
    lname=models.CharField(max_length=100)
    fname=models.CharField(max_length=100)
    faname=models.CharField(max_length=100)
    breligion=models.CharField(max_length=100)
    bcast=models.CharField(max_length=100)
    dob=models.CharField(max_length=10)
    dobinwords=models.CharField(max_length=100)
    bona_class=models.CharField(max_length=2)
    bona_year=models.CharField(max_length=10)
    issuedate=models.CharField(max_length=10,null=True)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"secbonafide"





class ColBonafide(models.Model):
    col_academic=models.ForeignKey(CollegeAdm,on_delete=models.CASCADE)
    prn=models.CharField(max_length=50)
    lname=models.CharField(max_length=100)
    fname=models.CharField(max_length=100)
    faname=models.CharField(max_length=100)
    breligion=models.CharField(max_length=100)
    bcast=models.CharField(max_length=100)
    dob=models.CharField(max_length=10)
    dobinwords=models.CharField(max_length=100)
    bona_class=models.CharField(max_length=2)
    bona_stream=models.CharField(max_length=15)
    bona_year=models.CharField(max_length=10)
    issuedate=models.CharField(max_length=10,null=True)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"colbonafide"



class ATKT11Bonafide(models.Model):
    atkt11_academic=models.ForeignKey(ATKT11Adm,on_delete=models.CASCADE)
    prn=models.CharField(max_length=50)
    lname=models.CharField(max_length=100)
    fname=models.CharField(max_length=100)
    faname=models.CharField(max_length=100)
    breligion=models.CharField(max_length=100)
    bcast=models.CharField(max_length=100)
    dob=models.CharField(max_length=10)
    dobinwords=models.CharField(max_length=100)
    bona_class=models.CharField(max_length=2)
    bona_stream=models.CharField(max_length=15)
    bona_year=models.CharField(max_length=10)
    issuedate=models.CharField(max_length=10,null=True)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"atkt11bonafide"




class Form17SSCBonafide(models.Model):
    f17ssc_academic=models.ForeignKey(Form1710Adm,on_delete=models.CASCADE)
    prn=models.CharField(max_length=50)
    lname=models.CharField(max_length=100)
    fname=models.CharField(max_length=100)
    faname=models.CharField(max_length=100)
    breligion=models.CharField(max_length=100)
    bcast=models.CharField(max_length=100)
    dob=models.CharField(max_length=10)
    dobinwords=models.CharField(max_length=100)
    bona_class=models.CharField(max_length=2)
    bona_year=models.CharField(max_length=10)
    issuedate=models.CharField(max_length=10,null=True)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"form17sscbonafide"




class Form17HSCBonafide(models.Model):
    f17hsc_academic=models.ForeignKey(Form1712Adm,on_delete=models.CASCADE)
    prn=models.CharField(max_length=50)
    lname=models.CharField(max_length=100)
    fname=models.CharField(max_length=100)
    faname=models.CharField(max_length=100)
    breligion=models.CharField(max_length=100)
    bcast=models.CharField(max_length=100)
    dob=models.CharField(max_length=10)
    dobinwords=models.CharField(max_length=100)
    bona_class=models.CharField(max_length=2)
    bona_stream=models.CharField(max_length=15)
    bona_year=models.CharField(max_length=10)
    issuedate=models.CharField(max_length=10,null=True)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"form17hscbonafide"