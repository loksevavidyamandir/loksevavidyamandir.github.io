from django.shortcuts import redirect,render
from django.http import HttpResponse, HttpResponseRedirect
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue
from django.contrib import messages
import xlwt
from xlwt.Formatting import Borders
from django.conf import settings as conf_set
from seedData.models import Year


# Create your views here.

sname=conf_set.SCHOOL_NAME
schname=conf_set.SCHNAME




def report_studentAcademic(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        yearData = Year.objects.all()
        divData = Division.objects.all()
        male=0
        female=0
        if request.method=='POST':
            try:
                students=""
                section=request.POST['acad_section']
                year=request.POST['acad_year']
                if request.POST.get('search') == "search":
                    if request.POST['acad_section'] == "Jr.College":
                        class1=int(request.POST['acad_class'])
                        div=request.POST['acad_div']
                        stream=request.POST['acad_faculty']
                        if class1 == 11:
                            data = CollegeAdm.objects.filter(updateclass11=class1,updateyear11=year[0:4],updatedivision11=div,updatestream11=stream)
                        elif class1 == 12:
                            data = CollegeAdm.objects.filter(updateclass12=class1,updateyear12=year[0:4],updatedivision12=div,updatestream11=stream)
                        else:
                            messages.error(request,"Selected Class is Invalid")
                            return redirect('report_studentAcademic')
                        context = {
                        'sname':sname,
                        'lname':lname,
                        'page_title':" Reports /",
                        'fname':fname,
                        'update':True,
                        'pri':False,
                        'sec':False,
                        'col':True,
                        'atkt':False,
                        'f1710':False,
                        'f1712':False,
                        'section':section,
                        'year':year,
                        'div':div,
                        'class1':class1,
                        'faculty':stream,
                        'data':data,
                        'yearData':yearData,
                        'divData':divData,
                        "page_path":"Academic Report",
                        "menu_icon":"nav-icon fas fa-university",
                        }
                        return render(request,'schoolviews/reports/academicsreport.html',context) 
                    
                    elif request.POST['acad_section'] == "Primary":
                        class1=int(request.POST['acad_class'])
                        div=request.POST['acad_div']
                        if class1 == 1:
                            data = PrimAdm.objects.filter(updateclass1=class1,updateyear1=year[0:4],updatedivision1=div)
                        elif class1 == 2:
                            data = PrimAdm.objects.filter(updateclass2=class1,updateyear2=year[0:4],updatedivision2=div)
                        elif class1 == 3:
                            data = PrimAdm.objects.filter(updateclass3=class1,updateyear3=year[0:4],updatedivision3=div)
                        elif class1 == 4:
                            data = PrimAdm.objects.filter(updateclass4=class1,updateyear4=year[0:4],updatedivision4=div)
                        else:
                            messages.error(request,"Selected Class is Invalid")
                            return redirect('report_studentAcademic')
                        context = {
                        'sname':sname,
                        'lname':lname,
                        'page_title':" Reports /",
                        'fname':fname,
                        'update':True,
                        'pri':True,
                        'sec':False,
                        'col':False,
                        'atkt':False,
                        'f1710':False,
                        'f1712':False,
                        'section':section,
                        'year':year,
                        'div':div,
                        'class1':class1,
                        'data':data,
                        'yearData':yearData,
                        'divData':divData,
                        "page_path":"Academic Report",
                        "menu_icon":"nav-icon fas fa-university",
                        }
                        return render(request,'schoolviews/reports/academicsreport.html',context)

                    elif request.POST['acad_section'] == "Secondary":
                        div=request.POST['acad_div']
                        class1=int(request.POST['acad_class'])
                        if class1 == 5:
                            data = SecondAdm.objects.filter(updateclass5=class1,updateyear5=year[0:4],updatedivision5=div)
                        elif class1 == 6:
                            data = SecondAdm.objects.filter(updateclass6=class1,updateyear6=year[0:4],updatedivision6=div)
                        elif class1 == 7:
                            data = SecondAdm.objects.filter(updateclass7=class1,updateyear7=year[0:4],updatedivision7=div)
                        elif class1 == 8:
                            data = SecondAdm.objects.filter(updateclass8=class1,updateyear8=year[0:4],updatedivision8=div)
                        elif class1 == 9:
                            data = SecondAdm.objects.filter(updateclass9=class1,updateyear9=year[0:4],updatedivision9=div)
                        elif class1 == 10:
                            data = SecondAdm.objects.filter(updateclass10=class1,updateyear10=year[0:4],updatedivision10=div)
                        else:
                            messages.error(request,"Selected Class is Invalid")
                            return redirect('report_studentAcademic')
                        context = {
                        'sname':sname,
                        'lname':lname,
                        'page_title':" Reports /",
                        'fname':fname,
                        'update':True,
                        'pri':False,
                        'sec':True,
                        'col':False,
                        'atkt':False,
                        'f1710':False,
                        'f1712':False,
                        'section':section,
                        'year':year,
                        'div':div,
                        'class1':class1,
                        'data':data,
                        'yearData':yearData,
                        'divData':divData,
                        "page_path":"Academic Report",
                        "menu_icon":"nav-icon fas fa-university",
                        }
                        return render(request,'schoolviews/reports/academicsreport.html',context)
                    
                    elif request.POST['acad_section'] == "11-ATKT":
                        stream=request.POST['acad_faculty']
                        div=request.POST['acad_div']
                        divData1 = Division.objects.get(division=div)
                        data = ATKT11Adm.objects.filter(admyear=year[0:4],division=divData1,admission_faculty=stream)
                        context = {
                        'sname':sname,
                        'lname':lname,
                        'page_title':" Reports /",
                        'fname':fname,
                        'update':True,
                        'pri':False,
                        'sec':False,
                        'col':False,
                        'atkt':True,
                        'f1710':False,
                        'f1712':False,
                        'section':section,
                        'year':year,
                        'div':div,
                        'faculty':stream,
                        'data':data,
                        'yearData':yearData,
                        'divData':divData,
                        "page_path":"Academic Report",
                        "menu_icon":"nav-icon fas fa-university",
                        }
                        return render(request,'schoolviews/reports/academicsreport.html',context) 

                    elif request.POST['acad_section'] == "Form17-HSC":
                        stream=request.POST['acad_faculty']
                        data = Form1712Adm.objects.filter(admyear=year[0:4],admission_faculty=stream)
                        context = {
                        'sname':sname,
                        'lname':lname,
                        'page_title':" Reports /",
                        'fname':fname,
                        'update':True,
                        'pri':False,
                        'sec':False,
                        'col':False,
                        'atkt':False,
                        'f1710':False,
                        'f1712':True,
                        'section':section,
                        'year':year,
                        'faculty':stream,
                        'data':data,
                        'yearData':yearData,
                        'divData':divData,
                        "page_path":"Academic Report",
                        "menu_icon":"nav-icon fas fa-university",
                        }
                        return render(request,'schoolviews/reports/academicsreport.html',context)
                    
                    elif request.POST['acad_section'] == "Form17-SSC":
                        data = Form1710Adm.objects.filter(admyear=year[0:4])
                        context = {
                        'sname':sname,
                        'lname':lname,
                        'page_title':" Reports /",
                        'fname':fname,
                        'update':True,
                        'pri':False,
                        'sec':False,
                        'col':False,
                        'atkt':False,
                        'f1710':True,
                        'f1712':False,
                        'section':section,
                        'year':year,
                        'data':data,
                        'yearData':yearData,
                        'divData':divData,
                        "page_path":"Academic Report",
                        "menu_icon":"nav-icon fas fa-university",
                        }
                        return render(request,'schoolviews/reports/academicsreport.html',context)
                    
                    

                elif request.POST.get('report') == "report":
                    students=""
                    section=request.POST['acad_section']
                    year=request.POST['acad_year']
                    if section == "Primary":
                        class1=int(request.POST['acad_class'])
                        div=request.POST['acad_div']
                        response = HttpResponse(content_type='application/ms-excel')
                        response['Content-Disposition'] = 'attachment; filename=Primary_AcademicReport'+year+'.xls'
                        wb = xlwt.Workbook(encoding='utf-8')
                        ws = wb.add_sheet('Primary')
                        format0 = xlwt.easyxf(
                            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format1 = xlwt.easyxf(
                            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format2 = xlwt.easyxf(
                            'font:height 300,bold True;pattern: pattern solid, fore_colour white;')
                        # Sheet header, first row
                        row_num = 5
                        excel_style = xlwt.XFStyle()
                        ws.write_merge(0, 0, 0, 17, schname,format0)
                        ws.write_merge(1, 3, 0, 17, 'Primary Academics Report - '+year,format1)
                        excel_style.font.bold = True
                        borders = xlwt.Borders()
                        borders.left = 1
                        borders.right = 1
                        borders.top = 1
                        borders.bottom = 1
                        excel_style.borders = borders
                        columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar Number","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste Category","SubCaste","Minority","Place of Birth","Date of Birth","DOB in Words","Last attended School","Last attended Class","Previous LC Sr No","Previous Registration No","Admission Date","Admission Class","Division","Roll No","Late Admission","Admission Type","Hostel Required","Gender","Persion with Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Father Occupation","Mother Mobile","Mother Occupation","Annual Income","BPL","Guardian Is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","Branch Name","IFSC Code","MICR Code","Standard 1st Year","Standard 1st","Standard 1st Division","Standard 1st Roll No","Standard 2nd Year","Standard 2nd","Standard 2nd Division","Standard 2nd Roll No","Standard 3rd Year","Standard 1rd","Standard 3rd Division","Standard 3rd Roll No","Standard 4th Year","Standard 4th","Standard 4th Division","Standard 4th Roll No","Terminate Class","Terminate Date","Terminate Reason","LC Serial No.","LC Progress","LC Conduct","LC Remark","LC Reason of Leaving","Standard in Studying and since when","School Leaving Date","LC Issue Date"]
                        for col_num in range(len(columns)):
                            ws.write(row_num, col_num, columns[col_num], excel_style)
                        # Sheet body, remaining rows
                        excel_style = xlwt.XFStyle()
                        excel_style.borders = borders
                        if class1 == 1:
                            rows = PrimAdm.objects.filter(updateclass1=class1,updateyear1=year[0:4],updatedivision1=div).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear1','updateclass1','updatedivision1','updaterollno1','updateyear2','updateclass2','updatedivision2','updaterollno2','updateyear3','updateclass3','updatedivision3','updaterollno3','updateyear4','updateclass4','updatedivision4','updaterollno4','tclass','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        elif class1 == 2:
                            rows = PrimAdm.objects.filter(updateclass2=class1,updateyear2=year[0:4],updatedivision2=div).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear1','updateclass1','updatedivision1','updaterollno1','updateyear2','updateclass2','updatedivision2','updaterollno2','updateyear3','updateclass3','updatedivision3','updaterollno3','updateyear4','updateclass4','updatedivision4','updaterollno4','tclass','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        elif class1 == 3:
                            rows = PrimAdm.objects.filter(updateclass3=class1,updateyear3=year[0:4],updatedivision3=div).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear1','updateclass1','updatedivision1','updaterollno1','updateyear2','updateclass2','updatedivision2','updaterollno2','updateyear3','updateclass3','updatedivision3','updaterollno3','updateyear4','updateclass4','updatedivision4','updaterollno4','tclass','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        elif class1 == 4:
                            rows = PrimAdm.objects.filter(updateclass4=class1,updateyear4=year[0:4],updatedivision4=div).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear1','updateclass1','updatedivision1','updaterollno1','updateyear2','updateclass2','updatedivision2','updaterollno2','updateyear3','updateclass3','updatedivision3','updaterollno3','updateyear4','updateclass4','updatedivision4','updaterollno4','tclass','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        else:
                            messages.error(request,"Selected Class is Invalid")
                            return redirect('report_studentAcademic')
                        for row in rows:
                            if row[29] == "MALE":
                                male=male+1
                            elif row[29] == "FEMALE":
                                female=female+1
                            # row[9]-tongue,row[10]-religion,row[11]-cast,
                            # row[12]- category,row[13]-subcast,row[18]-last_school,row[24]-division
                            row=list(row)
                            t=MTongue.objects.get(id=row[9])
                            row[9]=t.m_tongue

                            r=Religion.objects.get(id=row[10])
                            row[10]=r.religionName

                            c=Cast.objects.get(id=row[11])
                            row[11]=c.castName
                            row[12]=c.castCat.castCategoryName

                            if row[13]!=None:
                                sc=SubCast.objects.get(id=row[13])
                                row[13]=sc.subCastName

                            dob=date=row[16].split('-')
                            dob=date[2]+'-'+date[1]+'-'+date[0]
                            row[16]=dob

                            admdate=date=row[22].split('-')
                            admdate=date[2]+'-'+date[1]+'-'+date[0]
                            row[22]=admdate

                            if row[18]!=None:
                                os=OtherSch.objects.get(id=row[18])
                                row[18]=os.schName

                            if row[24]!=None:
                                d=Division.objects.get(id=row[24])
                                row[24]=d.division
                                
                            row=tuple(row)
                            row_num += 1
                            for col_num in range(len(row)):
                                ws.write(row_num, col_num, row[col_num], excel_style)
                        ws.write(4, 5,"Class : "+str(class1)+", Division : "+str(div)+", Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        wb.save(response)
                        return response
                    elif section == "Secondary":
                        class1=int(request.POST['acad_class'])
                        div=request.POST['acad_div']
                        response = HttpResponse(content_type='application/ms-excel')
                        response['Content-Disposition'] = 'attachment; filename=Secondary_AcademicReport'+year+'.xls'
                        wb = xlwt.Workbook(encoding='utf-8')
                        ws = wb.add_sheet('Secondary')
                        format0 = xlwt.easyxf(
                            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format1 = xlwt.easyxf(
                            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format2 = xlwt.easyxf(
                            'font:height 300,bold True;pattern: pattern solid, fore_colour white;')
                        # Sheet header, first row
                        row_num = 5
                        excel_style = xlwt.XFStyle()
                        ws.write_merge(0, 0, 0, 17, schname,format0)
                        ws.write_merge(1, 3, 0, 17, 'Secondary Academics Report - '+year,format1)
                        excel_style.font.bold = True
                        borders = xlwt.Borders()
                        borders.left = 1
                        borders.right = 1
                        borders.top = 1
                        borders.bottom = 1
                        excel_style.borders = borders
                        columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar Number","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste Category","SubCaste","Minority","Place of Birth","Date of Birth","DOB in Words","Last attended School","Last attended Class","Previous LC Sr No","Previous Registration No","Admission Date","Admission Class","Division","Roll No","Late Admission","Admission Type","Hostel Required","Gender","Persion with Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Father Occupation","Mother Mobile","Mother Occupation","Annual Income","BPL","Guardian Is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","Branch Name","IFSC Code","MICR Code","Standard 5th Year","Standard 5th","Standard 5th Division","Standard 5th Roll No","Standard 6th Year","Standard 6th","Standard 6th Division","Standard 6th Roll No","Standard 7th Year","Standard 7th","Standard 7th Division","Standard 7th Roll No","Standard 8th Year","Standard 8th","Standard 8th Division","Standard 8th Roll No","Standard 9th Year","Standard 9th","Standard 9th Division","Standard 9th Roll No","Standard 10th Year","Standard 10th","Standard 10th Division","Standard 10th Roll No","Terminate Class","Terminate Date","Terminate Reason","LC Serial No.","LC Progress","LC Conduct","LC Remark","LC Reason of Leaving","Standard in Studying and since when","School Leaving Date","LC Issue Date"]
                        for col_num in range(len(columns)):
                            ws.write(row_num, col_num, columns[col_num], excel_style)
                        # Sheet body, remaining rows
                        excel_style = xlwt.XFStyle()
                        excel_style.borders = borders
                        if class1 == 5:
                            rows = SecondAdm.objects.filter(updateclass5=class1,updateyear5=year[0:4],updatedivision5=div).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear5','updateclass5','updatedivision5','updaterollno5','updateyear6','updateclass6','updatedivision6','updaterollno6','updateyear7','updateclass7','updatedivision7','updaterollno7','updateyear8','updateclass8','updatedivision8','updaterollno8','updateyear9','updateclass9','updatedivision9','updaterollno9','updateyear10','updateclass10','updatedivision10','updaterollno10','tclass','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        elif class1 == 6:
                            rows = SecondAdm.objects.filter(updateclass6=class1,updateyear6=year[0:4],updatedivision6=div).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear5','updateclass5','updatedivision5','updaterollno5','updateyear6','updateclass6','updatedivision6','updaterollno6','updateyear7','updateclass7','updatedivision7','updaterollno7','updateyear8','updateclass8','updatedivision8','updaterollno8','updateyear9','updateclass9','updatedivision9','updaterollno9','updateyear10','updateclass10','updatedivision10','updaterollno10','tclass','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        elif class1 == 7:
                            rows = SecondAdm.objects.filter(updateclass7=class1,updateyear7=year[0:4],updatedivision7=div).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear5','updateclass5','updatedivision5','updaterollno5','updateyear6','updateclass6','updatedivision6','updaterollno6','updateyear7','updateclass7','updatedivision7','updaterollno7','updateyear8','updateclass8','updatedivision8','updaterollno8','updateyear9','updateclass9','updatedivision9','updaterollno9','updateyear10','updateclass10','updatedivision10','updaterollno10','tclass','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        elif class1 == 8:
                            rows = SecondAdm.objects.filter(updateclass8=class1,updateyear8=year[0:4],updatedivision8=div).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear5','updateclass5','updatedivision5','updaterollno5','updateyear6','updateclass6','updatedivision6','updaterollno6','updateyear7','updateclass7','updatedivision7','updaterollno7','updateyear8','updateclass8','updatedivision8','updaterollno8','updateyear9','updateclass9','updatedivision9','updaterollno9','updateyear10','updateclass10','updatedivision10','updaterollno10','tclass','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        elif class1 == 9:
                            rows = SecondAdm.objects.filter(updateclass9=class1,updateyear9=year[0:4],updatedivision9=div).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear5','updateclass5','updatedivision5','updaterollno5','updateyear6','updateclass6','updatedivision6','updaterollno6','updateyear7','updateclass7','updatedivision7','updaterollno7','updateyear8','updateclass8','updatedivision8','updaterollno8','updateyear9','updateclass9','updatedivision9','updaterollno9','updateyear10','updateclass10','updatedivision10','updaterollno10','tclass','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        elif class1 == 10:
                            rows = SecondAdm.objects.filter(updateclass10=class1,updateyear10=year[0:4],updatedivision10=div).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear5','updateclass5','updatedivision5','updaterollno5','updateyear6','updateclass6','updatedivision6','updaterollno6','updateyear7','updateclass7','updatedivision7','updaterollno7','updateyear8','updateclass8','updatedivision8','updaterollno8','updateyear9','updateclass9','updatedivision9','updaterollno9','updateyear10','updateclass10','updatedivision10','updaterollno10','tclass','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        else:
                            messages.error(request,"Selected Class is Invalid")
                            return redirect('report_studentAcademic')
                        for row in rows:
                            if row[29] == "MALE":
                                male=male+1
                            elif row[29] == "FEMALE":
                                female=female+1
                            # row[9]-tongue,row[10]-religion,row[11]-cast,
                            # row[12]- category,row[13]-subcast,row[18]-last_school,row[24]-division
                            row=list(row)
                            t=MTongue.objects.get(id=row[9])
                            row[9]=t.m_tongue

                            r=Religion.objects.get(id=row[10])
                            row[10]=r.religionName

                            c=Cast.objects.get(id=row[11])
                            row[11]=c.castName
                            row[12]=c.castCat.castCategoryName

                            if row[13]!=None:
                                sc=SubCast.objects.get(id=row[13])
                                row[13]=sc.subCastName

                            dob=date=row[16].split('-')
                            dob=date[2]+'-'+date[1]+'-'+date[0]
                            row[16]=dob

                            admdate=date=row[22].split('-')
                            admdate=date[2]+'-'+date[1]+'-'+date[0]
                            row[22]=admdate

                            if row[18]!=None:
                                os=OtherSch.objects.get(id=row[18])
                                row[18]=os.schName

                            if row[24]!=None:
                                d=Division.objects.get(id=row[24])
                                row[24]=d.division
                                
                            row=tuple(row)
                            row_num += 1
                            for col_num in range(len(row)):
                                ws.write(row_num, col_num, row[col_num], excel_style)
                        ws.write(4, 5,"Class : "+str(class1)+", Division : "+str(div)+", Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        wb.save(response)
                        return response
                    elif section == "Jr.College":
                        class1=int(request.POST['acad_class'])
                        div=request.POST['acad_div']
                        stream=request.POST['acad_faculty']
                        response = HttpResponse(content_type='application/ms-excel')
                        response['Content-Disposition'] = 'attachment; filename=Jr.College_AcademicReport'+year+'.xls'
                        wb = xlwt.Workbook(encoding='utf-8')
                        ws = wb.add_sheet('Jr.College')
                        format0 = xlwt.easyxf(
                            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format1 = xlwt.easyxf(
                            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format2 = xlwt.easyxf(
                            'font:height 300,bold True;pattern: pattern solid, fore_colour white;')
                        # Sheet header, first row
                        row_num = 5
                        excel_style = xlwt.XFStyle()
                        ws.write_merge(0, 0, 0, 17, schname,format0)
                        ws.write_merge(1, 3, 0, 17, 'Jr.College Academics Report - '+year,format1)
                        excel_style.font.bold = True
                        borders = xlwt.Borders()
                        borders.left = 1
                        borders.right = 1
                        borders.top = 1
                        borders.bottom = 1
                        excel_style.borders = borders
                        columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar Number","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste Category","SubCaste","Minority","Place of Birth","Date of Birth","DOB in Words","Last attended School","Last attended Class","Previous LC Sr No","Previous Registration No","Admission Date","Admission Class","Admission Faculty","Division","Roll No","Late Admission","Admission Type","Hostel Required","Gender","Persion with Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Father Occupation","Mother Mobile","Mother Occupation","Annual Income","BPL","Guardian Is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","Branch Name","IFSC Code","MICR Code","Standard 11th Year","Standard 11th","Standard 11th Faculty","Standard 11th Division","Standard 11th Roll","Standard 12th Year","Standard 12th","Standard 12th Faculty","Standard 12th Division","Standard 12th Roll","Repeater Year","Repeater Standard","Repeater Faculty","Repeater Division","Repeater Roll No","Repeater Year","Repeater Standard","Repeater Faculty","Repeater Division","Repeater Roll No","Repeater Year","Repeater Standard","Repeater Faculty","Repeater Division","Repeater Roll No","Terminate Class","Terminate Faculty","Terminate Date","Terminate Reason","LC Serial No.","LC Progress","LC Conduct","LC Remark","LC Reason of Leaving","Standard in Studying and since when","School Leaving Date","LC Issue Date"]
                        for col_num in range(len(columns)):
                            ws.write(row_num, col_num, columns[col_num], excel_style)
                        # Sheet body, remaining rows
                        excel_style = xlwt.XFStyle()
                        excel_style.borders = borders
                        if class1 == 11:
                            rows = CollegeAdm.objects.filter(updateclass11=class1,updateyear11=year[0:4],updatedivision11=div,updatestream11=stream).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear11','updateclass11','updatestream11','updatedivision11','updaterollno11','updateyear12','updateclass12','updatestream12','updatedivision12','updaterollno12','updateyearrep1','updateclassrep1','updatestreamrep1','updatedivisionrep1','updaterollnorep1','updateyearrep2','updateclassrep2','updatestreamrep2','updatedivisionrep2','updaterollnorep2','updateyearrep3','updateclassrep3','updatestreamrep3','updatedivisionrep3','updaterollnorep3','tclass','tstream','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        elif class1 == 12:
                            rows = CollegeAdm.objects.filter(updateclass12=class1,updateyear12=year[0:4],updatedivision12=div,updatestream11=stream).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','updateyear11','updateclass11','updatestream11','updatedivision11','updaterollno11','updateyear12','updateclass12','updatestream12','updatedivision12','updaterollno12','updateyearrep1','updateclassrep1','updatestreamrep1','updatedivisionrep1','updaterollnorep1','updateyearrep2','updateclassrep2','updatestreamrep2','updatedivisionrep2','updaterollnorep2','updateyearrep3','updateclassrep3','updatestreamrep3','updatedivisionrep3','updaterollnorep3','tclass','tstream','tdate','treason','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        else:
                            messages.error(request,"Selected Class is Invalid")
                            return redirect('report_studentAcademic')
                        for row in rows:
                            if row[30] == "MALE":
                                male=male+1
                            elif row[30] == "FEMALE":
                                female=female+1
                            # row[9]-tongue,row[10]-religion,row[11]-cast,
                            # row[12]- category,row[13]-subcast,row[18]-last_school,row[25]-division
                            row=list(row)
                            t=MTongue.objects.get(id=row[9])
                            row[9]=t.m_tongue

                            r=Religion.objects.get(id=row[10])
                            row[10]=r.religionName

                            c=Cast.objects.get(id=row[11])
                            row[11]=c.castName
                            row[12]=c.castCat.castCategoryName

                            if row[13]!=None:
                                sc=SubCast.objects.get(id=row[13])
                                row[13]=sc.subCastName

                            dob=date=row[16].split('-')
                            dob=date[2]+'-'+date[1]+'-'+date[0]
                            row[16]=dob

                            admdate=date=row[22].split('-')
                            admdate=date[2]+'-'+date[1]+'-'+date[0]
                            row[22]=admdate

                            if row[18]!=None:
                                os=OtherSch.objects.get(id=row[18])
                                row[18]=os.schName

                            if row[25]!=None:
                                d=Division.objects.get(id=row[25])
                                row[25]=d.division
                                
                            row=tuple(row)
                            row_num += 1
                            for col_num in range(len(row)):
                                ws.write(row_num, col_num, row[col_num], excel_style)
                        ws.write(4, 5,"Class : "+str(class1)+", Division : "+str(div)+", Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        wb.save(response)
                        return response
                    elif section == "11-ATKT":
                        div=request.POST['acad_div']
                        stream=request.POST['acad_faculty']
                        response = HttpResponse(content_type='application/ms-excel')
                        response['Content-Disposition'] = 'attachment; filename=11ATKT_AcademicReport'+year+'.xls'
                        wb = xlwt.Workbook(encoding='utf-8')
                        ws = wb.add_sheet('11-ATKT')
                        format0 = xlwt.easyxf(
                            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format1 = xlwt.easyxf(
                            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format2 = xlwt.easyxf(
                            'font:height 300,bold True;pattern: pattern solid, fore_colour white;')
                        # Sheet header, first row
                        row_num = 5
                        excel_style = xlwt.XFStyle()
                        ws.write_merge(0, 0, 0, 17, schname,format0)
                        ws.write_merge(1, 3, 0, 17, '11-ATKT Academics Report - '+year,format1)
                        excel_style.font.bold = True
                        borders = xlwt.Borders()
                        borders.left = 1
                        borders.right = 1
                        borders.top = 1
                        borders.bottom = 1
                        excel_style.borders = borders
                        columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar Number","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste Category","SubCaste","Minority","Place of Birth","Date of Birth","DOB in Words","Last attended School","Last attended Class","Previous LC Sr No","Previous Registration No","Admission Date","Admission Class","Admission Faculty","Division","Roll No","Late Admission","Admission Type","Hostel Required","Gender","Persion with Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Father Occupation","Mother Mobile","Mother Occupation","Annual Income","BPL","Guardian Is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","Branch Name","IFSC Code","MICR Code","Bonafide Serial No","Bonafide Issued Date","LC Serial No.","LC Progress","LC Conduct","LC Remark","LC Reason of Leaving","Standard in Studying and since when","School Leaving Date","LC Issue Date"]
                        for col_num in range(len(columns)):
                            ws.write(row_num, col_num, columns[col_num], excel_style)
                        # Sheet body, remaining rows
                        excel_style = xlwt.XFStyle()
                        excel_style.borders = borders
                        divData = Division.objects.get(division=div)
                        rows = ATKT11Adm.objects.filter(admyear=year[0:4],division=divData,admission_faculty=stream).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','division','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','bonasrno','bonaissuedate','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcstudyinginclass','lcdateofleaving','lcissuedate')
                        print(1)
                        for row in rows:
                            if row[30] == "MALE":
                                male=male+1
                            elif row[30] == "FEMALE":
                                female=female+1
                            # row[9]-tongue,row[10]-religion,row[11]-cast,
                            # row[12]- category,row[13]-subcast,row[18]-last_school,row[25]-division
                            row=list(row)
                            t=MTongue.objects.get(id=row[9])
                            row[9]=t.m_tongue

                            r=Religion.objects.get(id=row[10])
                            row[10]=r.religionName

                            c=Cast.objects.get(id=row[11])
                            row[11]=c.castName
                            row[12]=c.castCat.castCategoryName

                            if row[13]!=None:
                                sc=SubCast.objects.get(id=row[13])
                                row[13]=sc.subCastName

                            dob=date=row[16].split('-')
                            dob=date[2]+'-'+date[1]+'-'+date[0]
                            row[16]=dob

                            admdate=date=row[22].split('-')
                            admdate=date[2]+'-'+date[1]+'-'+date[0]
                            row[22]=admdate

                            if row[18]!=None:
                                os=OtherSch.objects.get(id=row[18])
                                row[18]=os.schName

                            if row[25]!=None:
                                d=Division.objects.get(id=row[25])
                                row[25]=d.division
                                
                            row=tuple(row)
                            row_num += 1
                            for col_num in range(len(row)):
                                ws.write(row_num, col_num, row[col_num], excel_style)
                        ws.write(4, 5,"Class : 11, Division : "+str(div)+", Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        wb.save(response)
                        return response
                    elif section == "Form17-SSC":
                        response = HttpResponse(content_type='application/ms-excel')
                        response['Content-Disposition'] = 'attachment; filename=Form17_SSC_AcademicReport'+year+'.xls'
                        wb = xlwt.Workbook(encoding='utf-8')
                        ws = wb.add_sheet('Form17-SSC')
                        format0 = xlwt.easyxf(
                            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format1 = xlwt.easyxf(
                            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format2 = xlwt.easyxf(
                            'font:height 300,bold True;pattern: pattern solid, fore_colour white;')
                        # Sheet header, first row
                        row_num = 5
                        excel_style = xlwt.XFStyle()
                        ws.write_merge(0, 0, 0, 17, schname,format0)
                        ws.write_merge(1, 3, 0, 17, 'Form17-SSC Academics Report - '+year,format1)
                        excel_style.font.bold = True
                        borders = xlwt.Borders()
                        borders.left = 1
                        borders.right = 1
                        borders.top = 1
                        borders.bottom = 1
                        excel_style.borders = borders
                        columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar Number","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste Category","SubCaste","Minority","Place of Birth","Date of Birth","DOB in Words","Last attended School","Last attended Class","Previous LC Sr No","Previous Registration No","Admission Date","Admission Class","Roll No","Late Admission","Admission Type","Hostel Required","Gender","Persion with Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Father Occupation","Mother Mobile","Mother Occupation","Annual Income","BPL","Guardian Is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","Branch Name","IFSC Code","MICR Code","LC Serial No.","Seat No & Year of Passing Std. X","Date of passing X","LC Issue Date"]
                        for col_num in range(len(columns)):
                            ws.write(row_num, col_num, columns[col_num], excel_style)
                        # Sheet body, remaining rows
                        excel_style = xlwt.XFStyle()
                        excel_style.borders = borders
                        rows = Form1710Adm.objects.filter(admyear=year[0:4]).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','lcsrno','seatnoandyear','lcdateofpassing','lcissuedate')
                        for row in rows:
                            if row[28] == "MALE":
                                male=male+1
                            elif row[28] == "FEMALE":
                                female=female+1
                            # row[9]-tongue,row[10]-religion,row[11]-cast,
                            # row[12]- category,row[13]-subcast,row[18]-last_school,row[25]-division
                            row=list(row)
                            t=MTongue.objects.get(id=row[9])
                            row[9]=t.m_tongue

                            r=Religion.objects.get(id=row[10])
                            row[10]=r.religionName

                            c=Cast.objects.get(id=row[11])
                            row[11]=c.castName
                            row[12]=c.castCat.castCategoryName

                            if row[13]!=None:
                                sc=SubCast.objects.get(id=row[13])
                                row[13]=sc.subCastName

                            dob=date=row[16].split('-')
                            dob=date[2]+'-'+date[1]+'-'+date[0]
                            row[16]=dob

                            admdate=date=row[22].split('-')
                            admdate=date[2]+'-'+date[1]+'-'+date[0]
                            row[22]=admdate

                            if row[18]!=None:
                                os=OtherSch.objects.get(id=row[18])
                                row[18]=os.schName

                            row=tuple(row)
                            row_num += 1
                            for col_num in range(len(row)):
                                ws.write(row_num, col_num, row[col_num], excel_style)
                        ws.write(4, 5,"Class : 10, Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        wb.save(response)
                        return response
                    elif section == "Form17-HSC":
                        stream = request.POST["acad_faculty"]
                        response = HttpResponse(content_type='application/ms-excel')
                        response['Content-Disposition'] = 'attachment; filename=Form17_HSC_AcademicReport'+year+'.xls'
                        wb = xlwt.Workbook(encoding='utf-8')
                        ws = wb.add_sheet('Form17-HSC')
                        format0 = xlwt.easyxf(
                            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format1 = xlwt.easyxf(
                            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format2 = xlwt.easyxf(
                            'font:height 300,bold True;pattern: pattern solid, fore_colour white;')
                        # Sheet header, first row
                        row_num = 5
                        excel_style = xlwt.XFStyle()
                        ws.write_merge(0, 0, 0, 17, schname,format0)
                        ws.write_merge(1, 3, 0, 17, 'Form17-HSC Academics Report - '+year,format1)
                        excel_style.font.bold = True
                        borders = xlwt.Borders()
                        borders.left = 1
                        borders.right = 1
                        borders.top = 1
                        borders.bottom = 1
                        excel_style.borders = borders
                        columns = ["Registration Number","Last Name","First Name","Father Name","Mother Name","Student Name in Devnagari","Aadhar Number","Saral ID","Nationality","Mother Tongue","Religion","Caste","Caste Category","SubCaste","Minority","Place of Birth","Date of Birth","DOB in Words","Last attended School","Last attended Class","Previous LC Sr No","Previous Registration No","Admission Date","Admission Class","Admission Faculty","Roll No","Late Admission","Admission Type","Hostel Required","Gender","Persion with Disability","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Father Mobile","Father Occupation","Mother Mobile","Mother Occupation","Annual Income","BPL","Guardian Is","Guardian Name","Guardian Mobile","Guardian Occupation","Guardian Address","Guardian Relation","Bank Account Number","Bank Name","Branch Name","IFSC Code","MICR Code","LC Serial No.","Seat No & Year of Passing Std. XII","Date of passing XII","LC Issue Date"]
                        for col_num in range(len(columns)):
                            ws.write(row_num, col_num, columns[col_num], excel_style)
                        # Sheet body, remaining rows
                        excel_style = xlwt.XFStyle()
                        excel_style.borders = borders
                        rows = Form1712Adm.objects.filter(admyear=year[0:4],admission_faculty=stream).values_list('prn','lname','fname','faname','moname','mrname','aadhar','saral_id','nationality','tongue','religion','cast','cast','subcast','minority','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','rollno','lateadm','admtype','hostel','sex','pwd','bgroup','email','areaType','caddress','paddress','fa_mob','fa_occu','mo_mob','mo_occu','fam_income','bpl','gis','ganame','ga_mob','ga_occu','gaddress','ga_relation','baccount','bankname','branch','ifsc','micr','lcsrno','seatnoandyear','lcdateofpassing','lcissuedate')
                        for row in rows:
                            if row[29] == "MALE":
                                male=male+1
                            elif row[29] == "FEMALE":
                                female=female+1
                            # row[9]-tongue,row[10]-religion,row[11]-cast,
                            # row[12]- category,row[13]-subcast,row[18]-last_school,row[25]-division
                            row=list(row)
                            t=MTongue.objects.get(id=row[9])
                            row[9]=t.m_tongue

                            r=Religion.objects.get(id=row[10])
                            row[10]=r.religionName

                            c=Cast.objects.get(id=row[11])
                            row[11]=c.castName
                            row[12]=c.castCat.castCategoryName

                            if row[13]!=None:
                                sc=SubCast.objects.get(id=row[13])
                                row[13]=sc.subCastName

                            dob=date=row[16].split('-')
                            dob=date[2]+'-'+date[1]+'-'+date[0]
                            row[16]=dob

                            admdate=date=row[22].split('-')
                            admdate=date[2]+'-'+date[1]+'-'+date[0]
                            row[22]=admdate

                            if row[18]!=None:
                                os=OtherSch.objects.get(id=row[18])
                                row[18]=os.schName

                            row=tuple(row)
                            row_num += 1
                            for col_num in range(len(row)):
                                ws.write(row_num, col_num, row[col_num], excel_style)
                        ws.write(4, 5,"Class : 12, Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        wb.save(response)
                        return response
            except:
                messages.error(request,"Invalid header found in Academic Report form... Try again")
                return redirect('report_studentAcademic')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Reports /",
            'fname':fname,
            'yearData':yearData,
            'divData':divData,
            "page_path":"Academic Report",
            "menu_icon":"nav-icon fas fa-university",
            }
        return render(request,'schoolviews/reports/academicsreport.html',context) 
    else:
        return redirect('login')