from django.apps import AppConfig


class SchreportsConfig(AppConfig):
    name = 'schReports'
