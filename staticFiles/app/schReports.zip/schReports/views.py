from django.shortcuts import redirect,render
from django.http import HttpResponse, HttpResponseRedirect
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue
from django.contrib import messages
import xlwt
from xlwt.Formatting import Borders
from django.conf import settings as conf_set
from seedData.models import Year


# Create your views here.

sname=conf_set.SCHOOL_NAME
schname=conf_set.SCHNAME

def report_studentadmission(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        yearData = Year.objects.all()
        if request.method=='POST':
            try:
                year=request.POST['year']
                faculty=request.POST['faculty']

                if faculty=="Primary":
                    response = HttpResponse(content_type='application/ms-excel')
                    response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Primary'+year+'.xls'
                    wb = xlwt.Workbook(encoding='utf-8')
                    ws = wb.add_sheet('Primary')
                    format0 = xlwt.easyxf(
                        'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    format1 = xlwt.easyxf(
                        'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    # Sheet header, first row
                    row_num = 4
                    excel_style = xlwt.XFStyle()
                    ws.write_merge(0, 0, 0, 39, schname,format0)
                    ws.write_merge(1, 3, 0, 39, 'Primary General Register Report - '+year,format1)
                    excel_style.font.bold = True
                    borders = xlwt.Borders()
                    borders.left = 1
                    borders.right = 1
                    borders.top = 1
                    borders.bottom = 1
                    excel_style.borders = borders
                    columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Gender","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Standard in Studying and since when","LC Serial No","Progress","Conduct","Remarks","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                    for col_num in range(len(columns)):
                        ws.write(row_num, col_num, columns[col_num], excel_style)
                    # Sheet body, remaining rows
                    excel_style = xlwt.XFStyle()
                    excel_style.borders = borders
                    rows = PrimAdm.objects.filter(admyear=year).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','sex','bgroup','email','areaType','caddress','paddress','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcdateofleaving','lcissuedate')
                    for row in rows:
                        print(1)
                        # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                        # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                        row=list(row)
                        t=MTongue.objects.get(id=row[8])
                        row[8]=t.m_tongue

                        r=Religion.objects.get(id=row[9])
                        row[9]=r.religionName

                        c=Cast.objects.get(id=row[10])
                        row[10]=c.castName
                        row[11]=c.castCat.castCategoryName

                        if row[12]!=None:
                            sc=SubCast.objects.get(id=row[12])
                            row[12]=sc.subCastName

                        dobdate=date=row[14].split('-')
                        dobdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[14]=dobdate

                        admdate=date=row[20].split('-')
                        admdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[20]=admdate

                        if row[16]!=None:
                            os=OtherSch.objects.get(id=row[16])
                            row[16]=os.schName

                        if row[22]!=None:
                            d=Division.objects.get(id=row[22])
                            row[22]=d.division
                            
                        row=tuple(row)
                        row_num += 1
                        for col_num in range(len(row)):
                            ws.write(row_num, col_num, row[col_num], excel_style)
                    wb.save(response)
                    return response
                elif faculty=="Secondary":
                    response = HttpResponse(content_type='application/ms-excel')
                    response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Secondary'+year+'.xls'
                    wb = xlwt.Workbook(encoding='utf-8')
                    ws = wb.add_sheet('Secondary')
                    format0 = xlwt.easyxf(
                        'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    format1 = xlwt.easyxf(
                        'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    # Sheet header, first row
                    row_num = 4
                    excel_style = xlwt.XFStyle()
                    ws.write_merge(0, 0, 0, 39, schname,format0)
                    ws.write_merge(1, 3, 0, 39, 'Secondary General Register Report - '+year,format1)
                    excel_style.font.bold = True
                    borders = xlwt.Borders()
                    borders.left = 1
                    borders.right = 1
                    borders.top = 1
                    borders.bottom = 1
                    excel_style.borders = borders
                    columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Gender","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Standard in Studying and since when","LC Serial No","Progress","Conduct","Remarks","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                    for col_num in range(len(columns)):
                        ws.write(row_num, col_num, columns[col_num], excel_style)
                    # Sheet body, remaining rows
                    excel_style = xlwt.XFStyle()
                    excel_style.borders = borders
                    rows = SecondAdm.objects.filter(admyear=year).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','sex','bgroup','email','areaType','caddress','paddress','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcdateofleaving','lcissuedate')
                    for row in rows:
                        # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                        # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                        row=list(row)
                        t=MTongue.objects.get(id=row[8])
                        row[8]=t.m_tongue

                        r=Religion.objects.get(id=row[9])
                        row[9]=r.religionName

                        c=Cast.objects.get(id=row[10])
                        row[10]=c.castName
                        row[11]=c.castCat.castCategoryName


                        if row[12]!=None:
                            sc=SubCast.objects.get(id=row[12])
                            row[12]=sc.subCastName

                        dobdate=date=row[14].split('-')
                        dobdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[14]=dobdate

                        admdate=date=row[20].split('-')
                        admdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[20]=admdate

                        if row[16]!=None:
                            os=OtherSch.objects.get(id=row[16])
                            row[16]=os.schName

                        if row[22]!=None:
                            d=Division.objects.get(id=row[22])
                            row[22]=d.division
                            
                        row=tuple(row)
                        row_num += 1
                        for col_num in range(len(row)):
                            ws.write(row_num, col_num, row[col_num], excel_style)
                    wb.save(response)
                    return response
                elif faculty=="Jr.College":
                    response = HttpResponse(content_type='application/ms-excel')
                    response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Jr.College'+year+'.xls'
                    wb = xlwt.Workbook(encoding='utf-8')
                    ws = wb.add_sheet('Jr.College')
                    format0 = xlwt.easyxf(
                        'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    format1 = xlwt.easyxf(
                        'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    # Sheet header, first row
                    row_num = 4
                    excel_style = xlwt.XFStyle()
                    ws.write_merge(0, 0, 0, 40, schname,format0)
                    ws.write_merge(1, 3, 0, 40, 'Jr.College General Register Report - '+year,format1)
                    excel_style.font.bold = True
                    borders = xlwt.Borders()
                    borders.left = 1
                    borders.right = 1
                    borders.top = 1
                    borders.bottom = 1
                    excel_style.borders = borders
                    columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Division","Gender","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Standard in Studying and since when","LC Serial No","Progress","Conduct","Remarks","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                    for col_num in range(len(columns)):
                        ws.write(row_num, col_num, columns[col_num], excel_style)
                    # Sheet body, remaining rows
                    excel_style = xlwt.XFStyle()
                    excel_style.borders = borders
                    rows = CollegeAdm.objects.filter(admyear=year).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','division','sex','bgroup','email','areaType','caddress','paddress','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcdateofleaving','lcissuedate')
                    for row in rows:
                        # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                        # row[11]- category,row[12]-subcast,row[16]-last_school,row[23]-division
                        row=list(row)
                        t=MTongue.objects.get(id=row[8])
                        row[8]=t.m_tongue

                        r=Religion.objects.get(id=row[9])
                        row[9]=r.religionName

                        c=Cast.objects.get(id=row[10])
                        row[10]=c.castName
                        row[11]=c.castCat.castCategoryName

                        if row[12]!=None:
                            sc=SubCast.objects.get(id=row[12])
                            row[12]=sc.subCastName

                        dobdate=date=row[14].split('-')
                        dobdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[14]=dobdate

                        admdate=date=row[20].split('-')
                        admdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[20]=admdate

                        if row[16]!=None:
                            os=OtherSch.objects.get(id=row[16])
                            row[16]=os.schName

                        if row[23]!=None:
                            d=Division.objects.get(id=row[23])
                            row[23]=d.division
                            
                        row=tuple(row)
                        row_num += 1
                        for col_num in range(len(row)):
                            ws.write(row_num, col_num, row[col_num], excel_style)
                    wb.save(response)
                    return response
                elif faculty=="11-ATKT":
                    response = HttpResponse(content_type='application/ms-excel')
                    response['Content-Disposition'] = 'attachment; filename=GeneralRegister_11-ATKT'+year+'.xls'
                    wb = xlwt.Workbook(encoding='utf-8')
                    ws = wb.add_sheet('11-ATKT')
                    format0 = xlwt.easyxf(
                        'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    format1 = xlwt.easyxf(
                        'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    # Sheet header, first row
                    row_num = 4
                    excel_style = xlwt.XFStyle()
                    ws.write_merge(0, 0, 0, 42, schname,format0)
                    ws.write_merge(1, 3, 0, 42, '11-ATKT General Register Report - '+year,format1)
                    excel_style.font.bold = True
                    borders = xlwt.Borders()
                    borders.left = 1
                    borders.right = 1
                    borders.top = 1
                    borders.bottom = 1
                    excel_style.borders = borders
                    columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Division","Gender","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Bonafide Issue Date","Bonafide Serial No","Standard in Studying and since when","LC Serial No","Progress","Conduct","Remarks","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                    for col_num in range(len(columns)):
                        ws.write(row_num, col_num, columns[col_num], excel_style)
                    # Sheet body, remaining rows
                    excel_style = xlwt.XFStyle()
                    excel_style.borders = borders
                    rows = ATKT11Adm.objects.filter(admyear=year).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','division','sex','bgroup','email','areaType','caddress','paddress','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcdateofleaving','lcissuedate')
                    for row in rows:
                        # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                        # row[11]- category,row[12]-subcast,row[16]-last_school,row[23]-division
                        row=list(row)
                        t=MTongue.objects.get(id=row[8])
                        row[8]=t.m_tongue

                        r=Religion.objects.get(id=row[9])
                        row[9]=r.religionName

                        c=Cast.objects.get(id=row[10])
                        row[10]=c.castName
                        row[11]=c.castCat.castCategoryName

                        if row[12]!=None:
                            sc=SubCast.objects.get(id=row[12])
                            row[12]=sc.subCastName

                        bonadate=date=row[30].split('-')
                        bonadate=date[2]+'-'+date[1]+'-'+date[0]
                        row[30]=bonadate

                        dobdate=date=row[14].split('-')
                        dobdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[14]=dobdate

                        admdate=date=row[20].split('-')
                        admdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[20]=admdate

                        if row[16]!=None:
                            os=OtherSch.objects.get(id=row[16])
                            row[16]=os.schName

                        if row[23]!=None:
                            d=Division.objects.get(id=row[23])
                            row[23]=d.division
                            
                        row=tuple(row)
                        row_num += 1
                        for col_num in range(len(row)):
                            ws.write(row_num, col_num, row[col_num], excel_style)
                    wb.save(response)
                    return response
                elif faculty=="Form17-SSC":
                    response = HttpResponse(content_type='application/ms-excel')
                    response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Form17-SSC'+year+'.xls'
                    wb = xlwt.Workbook(encoding='utf-8')
                    ws = wb.add_sheet('Form17-SSC')
                    format0 = xlwt.easyxf(
                        'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    format1 = xlwt.easyxf(
                        'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    # Sheet header, first row
                    row_num = 4
                    excel_style = xlwt.XFStyle()
                    ws.write_merge(0, 0, 0, 34, schname,format0)
                    ws.write_merge(1, 3, 0, 34, 'Form17-SSC General Register Report - '+year,format1)
                    excel_style.font.bold = True
                    borders = xlwt.Borders()
                    borders.left = 1
                    borders.right = 1
                    borders.top = 1
                    borders.bottom = 1
                    excel_style.borders = borders
                    columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Gender","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Seat No & Year of Passing Std.X ","LC Serial No","Date of Passing Std.X","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                    for col_num in range(len(columns)):
                        ws.write(row_num, col_num, columns[col_num], excel_style)
                    # Sheet body, remaining rows
                    excel_style = xlwt.XFStyle()
                    excel_style.borders = borders
                    rows = Form1710Adm.objects.filter(admyear=year).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','sex','bgroup','email','areaType','caddress','paddress','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                    for row in rows:
                        # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                        # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                        row=list(row)
                        t=MTongue.objects.get(id=row[8])
                        row[8]=t.m_tongue

                        r=Religion.objects.get(id=row[9])
                        row[9]=r.religionName

                        c=Cast.objects.get(id=row[10])
                        row[10]=c.castName
                        row[11]=c.castCat.castCategoryName


                        if row[12]!=None:
                            sc=SubCast.objects.get(id=row[12])
                            row[12]=sc.subCastName

                        dobdate=date=row[14].split('-')
                        dobdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[14]=dobdate

                        admdate=date=row[20].split('-')
                        admdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[20]=admdate

                        if row[16]!=None:
                            os=OtherSch.objects.get(id=row[16])
                            row[16]=os.schName
                            
                        row=tuple(row)
                        row_num += 1
                        for col_num in range(len(row)):
                            ws.write(row_num, col_num, row[col_num], excel_style)
                    wb.save(response)
                    return response
                elif faculty=="Form17-HSC":
                    response = HttpResponse(content_type='application/ms-excel')
                    response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Form17-HSC'+year+'.xls'
                    wb = xlwt.Workbook(encoding='utf-8')
                    ws = wb.add_sheet('Form17-HSC')
                    format0 = xlwt.easyxf(
                        'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    format1 = xlwt.easyxf(
                        'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                            left thin, right thin, top thin, bottom thin;')
                    # Sheet header, first row
                    row_num = 4
                    excel_style = xlwt.XFStyle()
                    ws.write_merge(0, 0, 0, 35, schname,format0)
                    ws.write_merge(1, 3, 0, 35, 'Form17-HSC General Register Report - '+year,format1)
                    excel_style.font.bold = True
                    borders = xlwt.Borders()
                    borders.left = 1
                    borders.right = 1
                    borders.top = 1
                    borders.bottom = 1
                    excel_style.borders = borders
                    columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Gender","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Seat No & Year of Passing Std.XII ","LC Serial No","Date of Passing Std.XII","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                    for col_num in range(len(columns)):
                        ws.write(row_num, col_num, columns[col_num], excel_style)
                    # Sheet body, remaining rows
                    excel_style = xlwt.XFStyle()
                    excel_style.borders = borders
                    rows = Form1712Adm.objects.filter(admyear=year).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','sex','bgroup','email','areaType','caddress','paddress','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                    for row in rows:
                        # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                        # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                        row=list(row)
                        t=MTongue.objects.get(id=row[8])
                        row[8]=t.m_tongue

                        r=Religion.objects.get(id=row[9])
                        row[9]=r.religionName

                        c=Cast.objects.get(id=row[10])
                        row[10]=c.castName
                        row[11]=c.castCat.castCategoryName


                        if row[12]!=None:
                            sc=SubCast.objects.get(id=row[12])
                            row[12]=sc.subCastName

                        dobdate=date=row[14].split('-')
                        dobdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[14]=dobdate

                        admdate=date=row[20].split('-')
                        admdate=date[2]+'-'+date[1]+'-'+date[0]
                        row[20]=admdate

                        if row[16]!=None:
                            os=OtherSch.objects.get(id=row[16])
                            row[16]=os.schName
                            
                        row=tuple(row)
                        row_num += 1
                        for col_num in range(len(row)):
                            ws.write(row_num, col_num, row[col_num], excel_style)
                    wb.save(response)
                    return response


            except:
                messages.error(request,"Invalid header found in Report form... Try again")
                return redirect('report_studentadmission')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Reports /",
            'fname':fname,
            'yearData':yearData,
            "page_path":" General Register Reports ",
            "menu_icon":"nav-icon fas fa-university",
            }
        return render(request,'schoolviews/reports/studentreport.html',context) 
    else:
        return redirect('login')

# def pri_report(request,cy):
#     response = HttpResponse(content_type='application/ms-excel')
#     response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Primary'+cy+'.xls'
#     wb = xlwt.Workbook(encoding='utf-8')
#     ws = wb.add_sheet('Primary')
#     format0 = xlwt.easyxf(
#            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
#             left thin, right thin, top thin, bottom thin;')
#     format1 = xlwt.easyxf(
#            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
#             left thin, right thin, top thin, bottom thin;')
#     # Sheet header, first row
#     row_num = 4
#     excel_style = xlwt.XFStyle()
#     ws.write_merge(0, 0, 0, 38, schname,format0)
#     ws.write_merge(1, 3, 0, 38, 'Primary General Register Report - '+cy,format1)
#     excel_style.font.bold = True
#     borders = xlwt.Borders()
#     borders.left = 1
#     borders.right = 1
#     borders.top = 1
#     borders.bottom = 1
#     excel_style.borders = borders
#     columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Gender","Blood Group","Email","Rural/Urban","Current Address","Permanent Address","Standard in Studying and since when","LC Serial No","Progress","Conduct","Remarks","Reason of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
#     for col_num in range(len(columns)):
#         ws.write(row_num, col_num, columns[col_num], excel_style)
#     # Sheet body, remaining rows
#     excel_style = xlwt.XFStyle()
#     excel_style.borders = borders
#     rows = PrimAdm.objects.filter(admyear=cy).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','category','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','division','sex','bgroup','email','areaType','caddress','paddress','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcremarks','lcreason','lcissuedate')
#     for row in rows:
#         # row[8]-m_tongue,row[9]-religion,row[10]-cast,
#         # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
#         row=list(row)
#         t=MTongue.objects.get(id=row[8])
#         row[8]=t.m_tongue

#         r=Religion.objects.get(id=row[9])
#         row[9]=r.religionName

#         c=Cast.objects.get(id=row[10])
#         row[10]=c.castName

#         cc=CastCategory.objects.get(id=row[11])
#         row[11]=cc.castCategoryName

#         if row[12]!=None:
#             sc=SubCast.objects.get(id=row[12])
#             row[12]=sc.subCastName

#         dobdate=date=row[14].split('-')
#         dobdate=date[2]+'-'+date[1]+'-'+date[0]
#         print(dobdate)
#         row[14]=dobdate

#         admdate=date=row[20].split('-')
#         admdate=date[2]+'-'+date[1]+'-'+date[0]
#         print(admdate)
#         row[20]=admdate

#         if row[16]!=None:
#             os=OtherSch.objects.get(id=row[16])
#             row[16]=os.schName

#         if row[22]!=None:
#             d=Division.objects.get(id=row[22])
#             row[22]=d.division
            
#         row=tuple(row)
#         row_num += 1
#         for col_num in range(len(row)):
#             ws.write(row_num, col_num, row[col_num], excel_style)
#     wb.save(response)
#     return response