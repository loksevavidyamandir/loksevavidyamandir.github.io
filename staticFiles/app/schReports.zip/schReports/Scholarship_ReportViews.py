from django.shortcuts import redirect,render
from django.http import HttpResponse, HttpResponseRedirect
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue
from schScholarship.models import AddScholarship,PrimaryScholarship,SecondaryScholarship,CollegeScholarship,ATKT11Scholarship
from django.contrib import messages
import xlwt
from xlwt.Formatting import Borders
from django.conf import settings as conf_set
from seedData.models import Year
from schScholarship.models import AddScholarship


# Create your views here.

sname=conf_set.SCHOOL_NAME
schname=conf_set.SCHNAME


def report_studentScholarship(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        yearData = Year.objects.all()
        divData = Division.objects.all()
        shipData = AddScholarship.objects.all()
        male=0
        female=0
        gtotal=0
        if request.method=='POST':
            # try:
                s_name=request.POST['ship_name']
                section=request.POST['ship_section']
                year=request.POST['ship_year']
                scholarData = AddScholarship.objects.get(s_name=s_name)
                if request.POST.get('search') == "search":
                    if section == "Primary":
                        class1=request.POST['ship_class']
                        if request.POST['ship_div']:
                            data = PrimaryScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1,s_div=request.POST['ship_div'])
                        else:
                            data = PrimaryScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1)
                        context = {
                        'sname':sname,
                        'lname':lname,
                        'page_title':" Reports /",
                        'fname':fname,
                        'update':True,
                        'col':False,
                        'atkt':False,
                        's_name':s_name,
                        'section':section,
                        'year':year,
                        'div':request.POST['ship_div'],
                        'class1':class1,
                        'data':data,
                        'yearData':yearData,
                        'divData':divData,
                        'shipData':shipData,
                        "page_path":"Scholarship Report",
                        "menu_icon":"nav-icon fa fa-graduation-cap",
                        }
                        return render(request,'schoolviews/reports/scholarshipreport.html',context) 
                    elif section == "Secondary":
                        class1=request.POST['ship_class']
                        if request.POST['ship_div']:
                            data = SecondaryScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1,s_div=request.POST['ship_div'])
                        else:
                            data = SecondaryScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1)
                        context = {
                        'sname':sname,
                        'lname':lname,
                        'page_title':" Reports /",
                        'fname':fname,
                        'update':True,
                        'col':False,
                        'atkt':False,
                        's_name':s_name,
                        'section':section,
                        'year':year,
                        'div':request.POST['ship_div'],
                        'class1':class1,
                        'data':data,
                        'yearData':yearData,
                        'divData':divData,
                        'shipData':shipData,
                        "page_path":"Scholarship Report",
                        "menu_icon":"nav-icon fa fa-graduation-cap",
                        }
                        return render(request,'schoolviews/reports/scholarshipreport.html',context) 
                    elif section == "Jr.College":
                        faculty=request.POST['ship_faculty']
                        class1=request.POST['ship_class']
                        if request.POST['ship_div']:
                            data = CollegeScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1,faculty=faculty,s_div=request.POST['ship_div'])
                        else:
                            data = CollegeScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1,faculty=faculty)
                        context = {
                        'sname':sname,
                        'lname':lname,
                        'page_title':" Reports /",
                        'fname':fname,
                        'update':True,
                        'col':True,
                        'atkt':False,
                        's_name':s_name,
                        'section':section,
                        'year':year,
                        'div':request.POST['ship_div'],
                        'class1':class1,
                        'faculty':request.POST['ship_faculty'],
                        'data':data,
                        'yearData':yearData,
                        'divData':divData,
                        'shipData':shipData,
                        "page_path":"Scholarship Report",
                        "menu_icon":"nav-icon fa fa-graduation-cap",
                        }
                        return render(request,'schoolviews/reports/scholarshipreport.html',context) 
                    elif section == "11-ATKT":
                        faculty=request.POST['ship_faculty']
                        data = ATKT11Scholarship.objects.filter(s_name=scholarData,year=year[0:4],faculty=faculty)
                        context = {
                        'sname':sname,
                        'lname':lname,
                        'page_title':" Reports /",
                        'fname':fname,
                        'update':True,
                        'col':False,
                        'atkt':True,
                        's_name':s_name,
                        'section':section,
                        'year':year,
                        'faculty':request.POST['ship_faculty'],
                        'data':data,
                        'yearData':yearData,
                        'divData':divData,
                        'shipData':shipData,
                        "page_path":"Scholarship Report",
                        "menu_icon":"nav-icon fa fa-graduation-cap",
                        }
                        return render(request,'schoolviews/reports/scholarshipreport.html',context) 
                elif request.POST.get('report') == "report":
                    if section == "Primary":
                        class1=int(request.POST['ship_class'])
                        response = HttpResponse(content_type='application/ms-excel')
                        response['Content-Disposition'] = 'attachment; filename=Primary_ScholarshipReport'+year+'.xls'
                        wb = xlwt.Workbook(encoding='utf-8')
                        ws = wb.add_sheet('Primary')
                        format0 = xlwt.easyxf(
                            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format1 = xlwt.easyxf(
                            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format2 = xlwt.easyxf(
                            'font:height 300,bold True;pattern: pattern solid, fore_colour white;')
                        # Sheet header, first row
                        row_num = 5
                        excel_style = xlwt.XFStyle()
                        ws.write_merge(0, 0, 0, 13, schname,format0)
                        ws.write_merge(1, 3, 0, 13, s_name+' Scholarship Report - '+year,format1)
                        excel_style.font.bold = True
                        borders = xlwt.Borders()
                        borders.left = 1
                        borders.right = 1
                        borders.top = 1
                        borders.bottom = 1
                        excel_style.borders = borders
                        columns = ["Scholarship Name","Registration Number","Last Name","First Name","Father Name","Religion","Caste","Caste Category","Class","Division","Amount","No of Month","Total"]
                        for col_num in range(len(columns)):
                            ws.write(row_num, col_num, columns[col_num], excel_style)
                        # Sheet body, remaining rows
                        excel_style = xlwt.XFStyle()
                        excel_style.borders = borders
                        if request.POST['ship_div']:
                            rows = PrimaryScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1,s_div=request.POST['ship_div']).values_list('s_name','stud','stud','stud','stud','stud','stud','stud','s_class','s_div','amount','no_of_month','total')
                        else:
                            rows = PrimaryScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1).values_list('s_name','stud','stud','stud','stud','stud','stud','stud','s_class','s_div','amount','no_of_month','total')
                        for row in rows:
                            pridata = PrimAdm.objects.get(pk=row[1])
                            if pridata.sex == "MALE":
                                male=male+1
                            elif pridata.sex == "FEMALE":
                                female=female+1
                            row=list(row)
                            row[0]=scholarData.s_name
                            row[1]=pridata.prn
                            row[2]=pridata.lname
                            row[3]=pridata.fname
                            row[4]=pridata.faname
                            row[5]=pridata.religion.religionName
                            row[6]=pridata.cast.castName
                            row[7]=pridata.cast.castCat.castCategoryName
                            row=tuple(row)
                            gtotal=gtotal+int(row[12])
                            row_num += 1
                            for col_num in range(len(row)):
                                ws.write(row_num, col_num, row[col_num], excel_style)
                        ws.write(row_num+1, 11,"Total :",format2)
                        ws.write(row_num+1, 12,gtotal,format2)
                        if request.POST['ship_div']:
                            ws.write(4, 3,"Class : "+str(class1)+", Division : "+str(request.POST['ship_div'])+", Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        else:
                            ws.write(4, 3,"Class : "+str(class1)+", Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        wb.save(response)
                        return response
                    elif section == "Secondary":
                        class1=request.POST['ship_class']
                        response = HttpResponse(content_type='application/ms-excel')
                        response['Content-Disposition'] = 'attachment; filename=Secondary_ScholarshipReport'+year+'.xls'
                        wb = xlwt.Workbook(encoding='utf-8')
                        ws = wb.add_sheet('Secondary')
                        format0 = xlwt.easyxf(
                            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format1 = xlwt.easyxf(
                            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format2 = xlwt.easyxf(
                            'font:height 300,bold True;pattern: pattern solid, fore_colour white;')
                        # Sheet header, first row
                        row_num = 5
                        excel_style = xlwt.XFStyle()
                        ws.write_merge(0, 0, 0, 13, schname,format0)
                        ws.write_merge(1, 3, 0, 13, s_name+' Scholarship Report - '+year,format1)
                        excel_style.font.bold = True
                        borders = xlwt.Borders()
                        borders.left = 1
                        borders.right = 1
                        borders.top = 1
                        borders.bottom = 1
                        excel_style.borders = borders
                        columns = ["Scholarship Name","Registration Number","Last Name","First Name","Father Name","Religion","Caste","Caste Category","Class","Division","Amount","No of Month","Total"]
                        for col_num in range(len(columns)):
                            ws.write(row_num, col_num, columns[col_num], excel_style)
                        # Sheet body, remaining rows
                        excel_style = xlwt.XFStyle()
                        excel_style.borders = borders
                        if request.POST['ship_div']:
                            rows = SecondaryScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1,s_div=request.POST['ship_div']).values_list('s_name','stud','stud','stud','stud','stud','stud','stud','s_class','s_div','amount','no_of_month','total')
                        else:
                            rows = SecondaryScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1).values_list('s_name','stud','stud','stud','stud','stud','stud','stud','s_class','s_div','amount','no_of_month','total')
                        for row in rows:
                            secdata = SecondAdm.objects.get(pk=row[1])
                            if secdata.sex == "MALE":
                                male=male+1
                            elif secdata.sex == "FEMALE":
                                female=female+1
                            row=list(row)
                            row[0]=scholarData.s_name
                            row[1]=secdata.prn
                            row[2]=secdata.lname
                            row[3]=secdata.fname
                            row[4]=secdata.faname
                            row[5]=secdata.religion.religionName
                            row[6]=secdata.cast.castName
                            row[7]=secdata.cast.castCat.castCategoryName
                            row=tuple(row)
                            gtotal=gtotal+int(row[12])
                            row_num += 1
                            for col_num in range(len(row)):
                                ws.write(row_num, col_num, row[col_num], excel_style)
                        ws.write(row_num+1, 11,"Total :",format2)
                        ws.write(row_num+1, 12,gtotal,format2)
                        if request.POST['ship_div']:
                            ws.write(4, 3,"Class : "+str(class1)+", Division : "+str(request.POST['ship_div'])+", Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        else:
                            ws.write(4, 3,"Class : "+str(class1)+", Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        wb.save(response)
                        return response
                    elif section == "Jr.College":
                        faculty=request.POST['ship_faculty']
                        class1=request.POST['ship_class']
                        response = HttpResponse(content_type='application/ms-excel')
                        response['Content-Disposition'] = 'attachment; filename=College_ScholarshipReport'+year+'.xls'
                        wb = xlwt.Workbook(encoding='utf-8')
                        ws = wb.add_sheet('College')
                        format0 = xlwt.easyxf(
                            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format1 = xlwt.easyxf(
                            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format2 = xlwt.easyxf(
                            'font:height 300,bold True;pattern: pattern solid, fore_colour white;')
                        # Sheet header, first row
                        row_num = 5
                        excel_style = xlwt.XFStyle()
                        ws.write_merge(0, 0, 0, 13, schname,format0)
                        ws.write_merge(1, 3, 0, 13, s_name+' Scholarship Report - '+year,format1)
                        excel_style.font.bold = True
                        borders = xlwt.Borders()
                        borders.left = 1
                        borders.right = 1
                        borders.top = 1
                        borders.bottom = 1
                        excel_style.borders = borders
                        columns = ["Scholarship Name","Registration Number","Last Name","First Name","Father Name","Religion","Caste","Caste Category","Class","Faculty","Division","Amount","No of Month","Total"]
                        for col_num in range(len(columns)):
                            ws.write(row_num, col_num, columns[col_num], excel_style)
                        # Sheet body, remaining rows
                        excel_style = xlwt.XFStyle()
                        excel_style.borders = borders
                        if request.POST['ship_div']:
                            rows = CollegeScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1,s_div=request.POST['ship_div']).values_list('s_name','stud','stud','stud','stud','stud','stud','stud','s_class','faculty','s_div','amount','no_of_month','total')
                        else:
                            rows = CollegeScholarship.objects.filter(s_name=scholarData,year=year[0:4],s_class=class1).values_list('s_name','stud','stud','stud','stud','stud','stud','stud','s_class','faculty','s_div','amount','no_of_month','total')
                        for row in rows:
                            colData = CollegeAdm.objects.get(pk=row[1])
                            if colData.sex == "MALE":
                                male=male+1
                            elif colData.sex == "FEMALE":
                                female=female+1
                            row=list(row)
                            row[0]=scholarData.s_name
                            row[1]=colData.prn
                            row[2]=colData.lname
                            row[3]=colData.fname
                            row[4]=colData.faname
                            row[5]=colData.religion.religionName
                            row[6]=colData.cast.castName
                            row[7]=colData.cast.castCat.castCategoryName
                            row=tuple(row)
                            gtotal=gtotal+int(row[13])
                            row_num += 1
                            for col_num in range(len(row)):
                                ws.write(row_num, col_num, row[col_num], excel_style)
                        ws.write(row_num+1, 12,"Total :",format2)
                        ws.write(row_num+1, 13,gtotal,format2)
                        if request.POST['ship_div']:
                            ws.write(4, 3,"Class : "+str(class1)+", Division : "+str(request.POST['ship_div'])+", Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        else:
                            ws.write(4, 3,"Class : "+str(class1)+", Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        wb.save(response)
                        return response
                    elif section == "11-ATKT":
                        faculty=request.POST['ship_faculty']
                        response = HttpResponse(content_type='application/ms-excel')
                        response['Content-Disposition'] = 'attachment; filename=ATKT11_ScholarshipReport'+year+'.xls'
                        wb = xlwt.Workbook(encoding='utf-8')
                        ws = wb.add_sheet('ATKT11')
                        format0 = xlwt.easyxf(
                            'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format1 = xlwt.easyxf(
                            'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                        left thin, right thin, top thin, bottom thin;')
                        format2 = xlwt.easyxf(
                            'font:height 300,bold True;pattern: pattern solid, fore_colour white;')
                        # Sheet header, first row
                        row_num = 5
                        excel_style = xlwt.XFStyle()
                        ws.write_merge(0, 0, 0, 13, schname,format0)
                        ws.write_merge(1, 3, 0, 13, s_name+' Scholarship Report - '+year,format1)
                        excel_style.font.bold = True
                        borders = xlwt.Borders()
                        borders.left = 1
                        borders.right = 1
                        borders.top = 1
                        borders.bottom = 1
                        excel_style.borders = borders
                        columns = ["Scholarship Name","Registration Number","Last Name","First Name","Father Name","Religion","Caste","Caste Category","Faculty","Amount","No of Month","Total"]
                        for col_num in range(len(columns)):
                            ws.write(row_num, col_num, columns[col_num], excel_style)
                        # Sheet body, remaining rows
                        excel_style = xlwt.XFStyle()
                        excel_style.borders = borders
                        rows = ATKT11Scholarship.objects.filter(s_name=scholarData,year=year[0:4]).values_list('s_name','stud','stud','stud','stud','stud','stud','stud','faculty','amount','no_of_month','total')
                        for row in rows:
                            atktData = ATKT11Adm.objects.get(pk=row[1])
                            if atktData.sex == "MALE":
                                male=male+1
                            elif atktData.sex == "FEMALE":
                                female=female+1
                            row=list(row)
                            row[0]=scholarData.s_name
                            row[1]=atktData.prn
                            row[2]=atktData.lname
                            row[3]=atktData.fname
                            row[4]=atktData.faname
                            row[5]=atktData.religion.religionName
                            row[6]=atktData.cast.castName
                            row[7]=atktData.cast.castCat.castCategoryName
                            row=tuple(row)
                            gtotal=gtotal+int(row[11])
                            row_num += 1
                            for col_num in range(len(row)):
                                ws.write(row_num, col_num, row[col_num], excel_style)
                        ws.write(row_num+1, 10,"Total :",format2)
                        ws.write(row_num+1, 11,gtotal,format2)
                        ws.write(4, 3,"Male : "+str(male)+", Female : "+str(female)+", Total : "+str(male+female),format2)
                        wb.save(response)
                        return response
                
            # except:
            #     messages.error(request,"Invalid header found in Academic Report form... Try again")
            #     return redirect('report_studentScholarship')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Reports /",
            'fname':fname,
            'yearData':yearData,
            'divData':divData,
            'shipData':shipData,
            "page_path":"Scholarship Report",
            "menu_icon":"nav-icon fa fa-graduation-cap",
            }
        return render(request,'schoolviews/reports/scholarshipreport.html',context) 
    else:
        return redirect('login')