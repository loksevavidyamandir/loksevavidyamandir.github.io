from django.shortcuts import redirect,render
from django.http import HttpResponse, HttpResponseRedirect
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue
from django.contrib import messages
import xlwt
from xlwt.Formatting import Borders
from django.conf import settings as conf_set
from seedData.models import Year


# Create your views here.

sname=conf_set.SCHOOL_NAME
schname=conf_set.SCHNAME


def report_studentCategory(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        yearData = Year.objects.all()
        if request.method=='POST':
            try:
                section=request.POST['section']
                year=request.POST['year']
                month=request.POST['month']
                if section == "Primary":
                    pass
                elif section == "Secondary":
                    pass
                elif section == "Jr.College":
                    pass
                elif section == "11-ATKT":
                    pass
                elif section == "Form17-SSC":
                    pass
                elif section == "Form17-HSC":
                    pass
            except:
                messages.error(request,"Invalid header found in Category Report form... Try again")
                return redirect('report_studentadmission')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Reports /",
            'fname':fname,
            'yearData':yearData,
            "page_path":"Category Report",
            "menu_icon":"nav-icon fas fa-university",
            }
        return render(request,'schoolviews/reports/categoryreport.html',context) 
    else:
        return redirect('login')