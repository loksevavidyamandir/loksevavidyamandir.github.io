from django.urls import path,include
from schReports import GR_ReportViews as views1
from schReports import Category_ReportViews as views2
from schReports import Academics_ReportViews as views3
from schReports import Scholarship_ReportViews as views4



urlpatterns = [
    path('reportstudentadmission',views1.report_studentadmission,name='report_studentadmission'),
    path('reportstudentCategory',views2.report_studentCategory,name='report_studentCategory'),
    path('reportstudentAcademic',views3.report_studentAcademic,name='report_studentAcademic'),
    path('reportstudentScholarship',views4.report_studentScholarship,name='report_studentScholarship'),
    path('loadreports',views1.load_reports,name='load_reports'),
]