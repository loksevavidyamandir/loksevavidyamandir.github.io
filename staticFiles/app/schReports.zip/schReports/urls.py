from django.urls import path,include
from schReports import views1



urlpatterns = [
    path('reportstudentadmission',views1.report_studentadmission,name='report_studentadmission'),
    path('loadreports',views1.load_reports,name='load_reports'),
]