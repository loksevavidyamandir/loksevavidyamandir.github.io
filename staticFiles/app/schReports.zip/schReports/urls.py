from django.urls import path,include
from schReports import views 



urlpatterns = [
    path('reportstudentadmission',views.report_studentadmission,name='report_studentadmission'),
]