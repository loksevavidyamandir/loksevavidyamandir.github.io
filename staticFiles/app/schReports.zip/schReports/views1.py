from django.shortcuts import redirect,render
from django.http import HttpResponse, HttpResponseRedirect
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Division,OtherSch,MTongue
from django.contrib import messages
import xlwt
from xlwt.Formatting import Borders
from django.conf import settings as conf_set
from seedData.models import Year


# Create your views here.

sname=conf_set.SCHOOL_NAME
schname=conf_set.SCHNAME


def load_reports(request):
    students=""
    section = request.GET.get('section')
    searchcat = request.GET.get('searchcat')
    year = request.GET.get('year')
    if searchcat == "prn":
        if section == "Primary" and year:
            students = PrimAdm.objects.filter(admyear=year[0:4])
        elif section == "Primary":
            students = PrimAdm.objects.all()
        elif section == "Secondary" and year:
            students = SecondAdm.objects.filter(admyear=year[0:4])
        elif section == "Secondary":
            students = SecondAdm.objects.all()
        elif section == "11-ATKT" and year:
            students = ATKT11Adm.objects.filter(admyear=year[0:4])
        elif section == "11-ATKT":
            students = ATKT11Adm.objects.all()
        elif section == "Jr.College" and year:
            students = CollegeAdm.objects.filter(admyear=year[0:4])
        elif section == "Jr.College":
            students = CollegeAdm.objects.all()
        elif section == "Form17-SSC" and year:
            students = Form1710Adm.objects.filter(admyear=year[0:4])
        elif section == "Form17-SSC":
            students = Form1710Adm.objects.all()
        elif section == "Form17-HSC" and year:
            students = Form1712Adm.objects.filter(admyear=year[0:4])
        elif section == "Form17-HSC":
            students = Form1712Adm.objects.all()
        return render(request,'schoolviews/reports/studreportprn.html',{"students":students})
    elif searchcat == "aadhar":
        if section == "Primary" and year:
            students = PrimAdm.objects.filter(admyear=year[0:4])
        elif section == "Primary":
            students = PrimAdm.objects.all()
        elif section == "Secondary" and year:
            students = SecondAdm.objects.filter(admyear=year[0:4])
        elif section == "Secondary":
            students = SecondAdm.objects.all()
        elif section == "11-ATKT" and year:
            students = ATKT11Adm.objects.filter(admyear=year[0:4])
        elif section == "11-ATKT":
            students = ATKT11Adm.objects.all()
        elif section == "Jr.College" and year:
            students = CollegeAdm.objects.filter(admyear=year[0:4])
        elif section == "Jr.College":
            students = CollegeAdm.objects.all()
        elif section == "Form17-SSC" and year:
            students = Form1710Adm.objects.filter(admyear=year[0:4])
        elif section == "Form17-SSC":
            students = Form1710Adm.objects.all()
        elif section == "Form17-HSC" and year:
            students = Form1712Adm.objects.filter(admyear=year[0:4])
        elif section == "Form17-HSC":
            students = Form1712Adm.objects.all()
        return render(request,'schoolviews/reports/studreportaadhar.html',{"students":students})
    elif searchcat == "fname":
        if section == "Primary" and year:
            students = PrimAdm.objects.filter(admyear=year[0:4])
        elif section == "Primary":
            students = PrimAdm.objects.all()
        elif section == "Secondary" and year:
            students = SecondAdm.objects.filter(admyear=year[0:4])
        elif section == "Secondary":
            students = SecondAdm.objects.all()
        elif section == "11-ATKT" and year:
            students = ATKT11Adm.objects.filter(admyear=year[0:4])
        elif section == "11-ATKT":
            students = ATKT11Adm.objects.all()
        elif section == "Jr.College" and year:
            students = CollegeAdm.objects.filter(admyear=year[0:4])
        elif section == "Jr.College":
            students = CollegeAdm.objects.all()
        elif section == "Form17-SSC" and year:
            students = Form1710Adm.objects.filter(admyear=year[0:4])
        elif section == "Form17-SSC":
            students = Form1710Adm.objects.all()
        elif section == "Form17-HSC" and year:
            students = Form1712Adm.objects.filter(admyear=year[0:4])
        elif section == "Form17-HSC":
            students = Form1712Adm.objects.all()
        return render(request,'schoolviews/reports/studreportfname.html',{"students":students})
    elif searchcat == "faname":
        if section == "Primary" and year:
            students = PrimAdm.objects.filter(admyear=year[0:4])
        elif section == "Primary":
            students = PrimAdm.objects.all()
        elif section == "Secondary" and year:
            students = SecondAdm.objects.filter(admyear=year[0:4])
        elif section == "Secondary":
            students = SecondAdm.objects.all()
        elif section == "11-ATKT" and year:
            students = ATKT11Adm.objects.filter(admyear=year[0:4])
        elif section == "11-ATKT":
            students = ATKT11Adm.objects.all()
        elif section == "Jr.College" and year:
            students = CollegeAdm.objects.filter(admyear=year[0:4])
        elif section == "Jr.College":
            students = CollegeAdm.objects.all()
        elif section == "Form17-SSC" and year:
            students = Form1710Adm.objects.filter(admyear=year[0:4])
        elif section == "Form17-SSC":
            students = Form1710Adm.objects.all()
        elif section == "Form17-HSC" and year:
            students = Form1712Adm.objects.filter(admyear=year[0:4])
        elif section == "Form17-HSC":
            students = Form1712Adm.objects.all()
        return render(request,'schoolviews/reports/studreportfaname.html',{"students":students})
    elif searchcat == "lname":
        if section == "Primary" and year:
            students = PrimAdm.objects.filter(admyear=year[0:4])
        elif section == "Primary":
            students = PrimAdm.objects.all()
        elif section == "Secondary" and year:
            students = SecondAdm.objects.filter(admyear=year[0:4])
        elif section == "Secondary":
            students = SecondAdm.objects.all()
        elif section == "11-ATKT" and year:
            students = ATKT11Adm.objects.filter(admyear=year[0:4])
        elif section == "11-ATKT":
            students = ATKT11Adm.objects.all()
        elif section == "Jr.College" and year:
            students = CollegeAdm.objects.filter(admyear=year[0:4])
        elif section == "Jr.College":
            students = CollegeAdm.objects.all()
        elif section == "Form17-SSC" and year:
            students = Form1710Adm.objects.filter(admyear=year[0:4])
        elif section == "Form17-SSC":
            students = Form1710Adm.objects.all()
        elif section == "Form17-HSC" and year:
            students = Form1712Adm.objects.filter(admyear=year[0:4])
        elif section == "Form17-HSC":
            students = Form1712Adm.objects.all()
        return render(request,'schoolviews/reports/studreportlname.html',{"students":students})

def report_studentadmission(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        yearData = Year.objects.all()
        casteData = Cast.objects.all()
        subcasteData = SubCast.objects.all()
        relData = Religion.objects.all()
        if request.method=='POST':
            try:
                section=request.POST['section']
                year=request.POST['year']
                searchcat=request.POST['searchcat']
                if request.POST.get('search') == "search":
                    if request.POST['year'] and request.POST['section'] and request.POST['searchcat']:
                        if section == "Primary" and request.POST['year']:
                            if searchcat=="prn":
                                print("prn")
                                data = PrimAdm.objects.filter(admyear=year[0:4],prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = PrimAdm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = PrimAdm.objects.filter(admyear=year[0:4],fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = PrimAdm.objects.filter(admyear=year[0:4],faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = PrimAdm.objects.filter(admyear=year[0:4],lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = PrimAdm.objects.filter(admyear=year[0:4],sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = PrimAdm.objects.filter(admyear=year[0:4],religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = PrimAdm.objects.filter(admyear=year[0:4],cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = PrimAdm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = PrimAdm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = PrimAdm.objects.filter(admyear=year[0:4],pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Primary section has no field Faculty")
                                return redirect('report_studentadmission')
                            college=False
                            atkt=False
                            f1712=False
                            f1710=False
                        elif section == "Secondary" and request.POST['year']:
                            if searchcat=="prn":
                                print("prn")
                                data = SecondAdm.objects.filter(admyear=year[0:4],prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = SecondAdm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = SecondAdm.objects.filter(admyear=year[0:4],fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = SecondAdm.objects.filter(admyear=year[0:4],faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = SecondAdm.objects.filter(admyear=year[0:4],lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = SecondAdm.objects.filter(admyear=year[0:4],sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = SecondAdm.objects.filter(admyear=year[0:4],religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = SecondAdm.objects.filter(admyear=year[0:4],cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = SecondAdm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = SecondAdm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = SecondAdm.objects.filter(admyear=year[0:4],pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Secondary section has no field Faculty")
                                return redirect('report_studentadmission')
                            college=False
                            atkt=False
                            f1712=False
                            f1710=False
                        elif section == "Jr.College" and request.POST['year']:
                            if searchcat=="prn":
                                print("prn")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                data = CollegeAdm.objects.filter(admyear=year[0:4],admission_faculty=request.POST['faculty'])
                            college=True
                            atkt=False
                            f1712=False
                            f1710=False
                        elif section == "11-ATKT" and request.POST['year']:
                            if searchcat=="prn":
                                print("prn")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                data = ATKT11Adm.objects.filter(admyear=year[0:4],admission_faculty=request.POST['faculty'])
                            college=False
                            atkt=True
                            f1712=False
                            f1710=False
                        elif section == "Form17-SSC" and request.POST['year']:
                            if searchcat=="prn":
                                print("prn")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = Form1710Adm.objects.filter(admyear=year[0:4],pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Form17-SSC section has no field Faculty")
                                return redirect('report_studentadmission')
                            college=False
                            atkt=False
                            f1712=False
                            f1710=True
                        elif section == "Form17-HSC" and request.POST['year']:
                            if searchcat=="prn":
                                print("prn")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                data = Form1712Adm.objects.filter(admyear=year[0:4],admission_faculty=request.POST['faculty'])
                            college=False
                            atkt=False
                            f1712=True
                            f1710=False
                        context = {
                                'sname':sname,
                                'lname':lname,
                                'page_title':" Reports /",
                                'fname':fname,
                                'yearData':yearData,
                                'relData':relData,
                                'casteData':casteData,
                                'subcasteData':subcasteData,
                                'update':True,
                                'college':college,
                                'atkt':atkt,
                                'f1712':f1712,
                                'f1710':f1710,
                                'section':section,
                                'data':data,
                                'year':year,
                                'searchcat':searchcat,
                                's':request.POST[""+searchcat],
                                "page_path":"General Register Report",
                                "menu_icon":"nav-icon fas fa-university",
                                }
                        return render(request,'schoolviews/reports/studentreport.html',context) 
                    elif request.POST['section'] and request.POST['searchcat']:
                        if section == "Primary":
                            if searchcat=="prn":
                                print("prn")
                                data = PrimAdm.objects.filter(prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = PrimAdm.objects.filter(aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = PrimAdm.objects.filter(fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = PrimAdm.objects.filter(faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = PrimAdm.objects.filter(lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = PrimAdm.objects.filter(sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = PrimAdm.objects.filter(religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = PrimAdm.objects.filter(cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = PrimAdm.objects.filter(subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = PrimAdm.objects.filter(bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = PrimAdm.objects.filter(pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Primary section has no field Faculty")
                                return redirect('report_studentadmission')
                            college=False
                            atkt=False
                            f1712=False
                            f1710=False
                        elif section == "Secondary":
                            if searchcat=="prn":
                                print("prn")
                                data = SecondAdm.objects.filter(prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = SecondAdm.objects.filter(aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = SecondAdm.objects.filter(fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = SecondAdm.objects.filter(faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = SecondAdm.objects.filter(lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = SecondAdm.objects.filter(sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = SecondAdm.objects.filter(religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = SecondAdm.objects.filter(cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = SecondAdm.objects.filter(subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = SecondAdm.objects.filter(bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = SecondAdm.objects.filter(pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Secondary section has no field Faculty")
                                return redirect('report_studentadmission')
                            college=False
                            atkt=False
                            f1712=False
                            f1710=False
                        elif section == "Jr.College":
                            if searchcat=="prn":
                                print("prn")
                                data = CollegeAdm.objects.filter(prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = CollegeAdm.objects.filter(aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = CollegeAdm.objects.filter(fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = CollegeAdm.objects.filter(faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = CollegeAdm.objects.filter(lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = CollegeAdm.objects.filter(sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = CollegeAdm.objects.filter(religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = CollegeAdm.objects.filter(cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = CollegeAdm.objects.filter(subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = CollegeAdm.objects.filter(bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = CollegeAdm.objects.filter(pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                data = CollegeAdm.objects.filter(admission_faculty=request.POST['faculty'])
                            college=True
                            atkt=False
                            f1712=False
                            f1710=False
                        elif section == "11-ATKT":
                            if searchcat=="prn":
                                print("prn")
                                data = ATKT11Adm.objects.filter(prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = ATKT11Adm.objects.filter(aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = ATKT11Adm.objects.filter(fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = ATKT11Adm.objects.filter(faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = ATKT11Adm.objects.filter(lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = ATKT11Adm.objects.filter(sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = ATKT11Adm.objects.filter(religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = ATKT11Adm.objects.filter(cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = ATKT11Adm.objects.filter(subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = ATKT11Adm.objects.filter(bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = ATKT11Adm.objects.filter(pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                data = ATKT11Adm.objects.filter(admission_faculty=request.POST['faculty'])
                            college=False
                            atkt=True
                            f1712=False
                            f1710=False
                        elif section == "Form17-SSC":
                            if searchcat=="prn":
                                print("prn")
                                data = Form1710Adm.objects.filter(prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = Form1710Adm.objects.filter(aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = Form1710Adm.objects.filter(fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = Form1710Adm.objects.filter(faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = Form1710Adm.objects.filter(lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = Form1710Adm.objects.filter(sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = Form1710Adm.objects.filter(religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = Form1710Adm.objects.filter(cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = Form1710Adm.objects.filter(subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = Form1710Adm.objects.filter(bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = Form1710Adm.objects.filter(pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Form17-SSC section has no field Faculty")
                                return redirect('report_studentadmission')
                            college=False
                            atkt=False
                            f1712=False
                            f1710=True
                        elif section == "Form17-HSC":
                            if searchcat=="prn":
                                print("prn")
                                data = Form1712Adm.objects.filter(prn=request.POST['prn'])
                            elif searchcat=="aadhar":
                                print("aadhar")
                                data = Form1712Adm.objects.filter(aadhar=request.POST['aadhar'])
                            elif searchcat=="fname":
                                print("fname")
                                data = Form1712Adm.objects.filter(fname=request.POST['fname'])
                            elif searchcat=="faname":
                                print("faname")
                                data = Form1712Adm.objects.filter(faname=request.POST['faname'])
                            elif searchcat=="lname":
                                print("lname")
                                data = Form1712Adm.objects.filter(lname=request.POST['lname'])
                            elif searchcat=="gender":
                                print("gender")
                                data = Form1712Adm.objects.filter(sex=request.POST['gender'])
                            elif searchcat=="religion":
                                print("religion")
                                data = Form1712Adm.objects.filter(religion=request.POST['religion'])
                            elif searchcat=="caste":
                                print("caste")
                                data = Form1712Adm.objects.filter(cast=request.POST['caste'])
                            elif searchcat=="subcaste":
                                print("subcaste")
                                data = Form1712Adm.objects.filter(subcast=request.POST['subcaste'])
                            elif searchcat=="bpl":
                                print("bpl")
                                data = Form1712Adm.objects.filter(bpl=request.POST['bpl'])
                            elif searchcat=="disability":
                                print("disability")
                                data = Form1712Adm.objects.filter(pwd=request.POST['disability'])
                            elif searchcat == "faculty":
                                print("faculty")
                                data = Form1712Adm.objects.filter(admission_faculty=request.POST['faculty'])
                            college=False
                            atkt=False
                            f1712=True
                            f1710=False
                        context = {
                                'sname':sname,
                                'lname':lname,
                                'page_title':" Reports /",
                                'fname':fname,
                                'yearData':yearData,
                                'relData':relData,
                                'casteData':casteData,
                                'subcasteData':subcasteData,
                                'update':True,
                                'college':college,
                                'atkt':atkt,
                                'f1712':f1712,
                                'f1710':f1710,
                                'section':section,
                                'data':data,
                                'searchcat':searchcat,
                                's':request.POST[""+searchcat],
                                "page_path":"General Register Report",
                                "menu_icon":"nav-icon fas fa-university",
                                }
                        return render(request,'schoolviews/reports/studentreport.html',context) 
                    elif request.POST['section'] and request.POST['year']:
                        if section == "Primary":
                            data = PrimAdm.objects.filter(admyear=year[0:4])
                            college=False
                            atkt=False
                            f1712=False
                            f1710=False
                        elif section == "Secondary":
                            data = SecondAdm.objects.filter(admyear=year[0:4])
                            college=False
                            atkt=False
                            f1712=False
                            f1710=False
                        elif section == "Jr.College":
                            data = CollegeAdm.objects.filter(admyear=year[0:4])
                            college=True
                            atkt=False
                            f1712=False
                            f1710=False                       
                        elif section == "11-ATKT":
                            data = ATKT11Adm.objects.filter(admyear=year[0:4])
                            college=False
                            atkt=True
                            f1712=False
                            f1710=False 
                        elif section == "Form17-SSC":
                            data = Form1710Adm.objects.filter(admyear=year[0:4])
                            college=False
                            atkt=False
                            f1712=False
                            f1710=True 
                        elif section == "Form17-HSC":
                            data = Form1712Adm.objects.filter(admyear=year[0:4])
                            college=False
                            atkt=False
                            f1712=True
                            f1710=False 
                        context = {
                                'sname':sname,
                                'lname':lname,
                                'page_title':" Reports /",
                                'fname':fname,
                                'yearData':yearData,
                                'relData':relData,
                                'casteData':casteData,
                                'subcasteData':subcasteData,
                                'update':True,
                                'college':college,
                                'atkt':atkt,
                                'f1712':f1712,
                                'f1710':f1710,
                                'data':data,
                                'section':section,
                                'year':year,
                                "page_path":"General Register Report",
                                "menu_icon":"nav-icon fas fa-university",
                                }
                        return render(request,'schoolviews/reports/studentreport.html',context) 
                    elif request.POST['section']:
                        if section == "Primary":
                            data = PrimAdm.objects.all()
                            college=False
                            atkt=False
                            f1712=False
                            f1710=False
                        elif section == "Secondary":
                            data = SecondAdm.objects.all()
                            college=False
                            atkt=False
                            f1712=False
                            f1710=False
                        elif section == "Jr.College":
                            data = CollegeAdm.objects.all()
                            college=True
                            atkt=False
                            f1712=False
                            f1710=False                       
                        elif section == "11-ATKT":
                            data = ATKT11Adm.objects.all()
                            college=False
                            atkt=True
                            f1712=False
                            f1710=False 
                        elif section == "Form17-SSC":
                            data = Form1710Adm.objects.all()
                            college=False
                            atkt=False
                            f1712=False
                            f1710=True 
                        elif section == "Form17-HSC":
                            data = Form1712Adm.objects.all()
                            college=False
                            atkt=False
                            f1712=True
                            f1710=False 
                        context = {
                                'sname':sname,
                                'lname':lname,
                                'page_title':" Reports /",
                                'fname':fname,
                                'yearData':yearData,
                                'relData':relData,
                                'casteData':casteData,
                                'subcasteData':subcasteData,
                                'update':True,
                                'college':college,
                                'atkt':atkt,
                                'f1712':f1712,
                                'f1710':f1710,
                                'section':section,
                                'data':data,
                                "page_path":"General Register Report",
                                "menu_icon":"nav-icon fas fa-university",
                                }
                        return render(request,'schoolviews/reports/studentreport.html',context) 

                

                elif request.POST.get('report') == "report":
                    if request.POST['year'] and request.POST['section'] and request.POST['searchcat']:
                        if section == "Primary" and request.POST['year']:
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Primary'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Primary')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 30, schname,format0)
                            ws.write_merge(1, 3, 0, 30, 'Primary General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat=="prn":
                                print("prn")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="aadhar":
                                print("aadhar")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="fname":
                                print("fname")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="faname":
                                print("faname")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="lname":
                                print("lname")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="gender":
                                print("gender")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="religion":
                                print("religion")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="caste":
                                print("caste")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="subcaste":
                                print("subcaste")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="bpl":
                                print("bpl")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="disability":
                                print("disability")
                                rows = PrimAdm.objects.filter(admyear=year[0:4],pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Primary section has no field Faculty")
                                return redirect('report_studentadmission')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,row[14]-dobdate,row[18]-admdate
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[20]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[20]!=None:
                                    d=Division.objects.get(id=row[20])
                                    row[20]=d.division
                                
                                row.append("")
                                row.append("")
                                row.append("")
                                
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Secondary" and request.POST['year']:
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Secondary'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Secondary')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 30, schname,format0)
                            ws.write_merge(1, 3, 0, 30, 'Secondary General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat=="prn":
                                print("prn")
                                rows = SecondAdm.objects.filter(admyear=year[0:4],prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="aadhar":
                                print("aadhar")
                                rows = SecondAdm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="fname":
                                print("fname")
                                rows = SecondAdm.objects.filter(admyear=year[0:4],fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="faname":
                                print("faname")
                                rows = SecondAdm.objects.filter(admyear=year[0:4],faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="lname":
                                print("lname")
                                rows = SecondAdm.objects.filter(admyear=year[0:4],lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="gender":
                                print("gender")
                                rows = SecondAdm.objects.filter(admyear=year[0:4],sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="religion":
                                print("religion")
                                rows = SecondAdm.objects.filter(admyear=year[0:4],religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="caste":
                                print("caste")
                                rows = SecondAdm.objects.filter(admyear=year,cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="subcaste":
                                print("subcaste")
                                rows = SecondAdm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="bpl":
                                print("bpl")
                                rows = SecondAdm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="disability":
                                print("disability")
                                rows = SecondAdm.objects.filter(admyear=year[0:4],pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Secondary section has no field Faculty")
                                return redirect('report_studentadmission')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[20]!=None:
                                    d=Division.objects.get(id=row[20])
                                    row[20]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Jr.College" and request.POST['year']:
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Jr.College'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Jr.College')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 31, schname,format0)
                            ws.write_merge(1, 3, 0, 31, 'Jr.College General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat == "prn":
                                print("prn")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "aadhar":
                                print("aadhar")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "fname":
                                print("fname")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faname":
                                print("faname")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "lname":
                                print("lname")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "gender":
                                print("gender")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "religion":
                                print("religion")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "caste":
                                print("caste")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "subcaste":
                                print("subcaste")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],admission_faculty=request.POST['faculty']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "bpl":
                                print("bpl")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "disability":
                                print("disability")
                                rows = CollegeAdm.objects.filter(admyear=year[0:4],pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[23]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[21]!=None:
                                    d=Division.objects.get(id=row[23])
                                    row[21]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="11-ATKT" and request.POST['year']:
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_11-ATKT'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('11-ATKT')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 33, schname,format0)
                            ws.write_merge(1, 3, 0, 33, '11-ATKT General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Division","Bonafide Issue Date","Bonafide Serial No","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat == "prn":
                                print("prn")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "aadhar":
                                print("aadhar")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "fname":
                                print("fname")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faname":
                                print("faname")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "lname":
                                print("lname")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "gender":
                                print("gender")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "religion":
                                print("religion")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "caste":
                                print("caste")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "subcaste":
                                print("subcaste")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],admission_faculty=request.POST['faculty']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "bpl":
                                print("bpl")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "disability":
                                print("disability")
                                rows = ATKT11Adm.objects.filter(admyear=year[0:4],pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[23]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                bonadate=date=row[22].split('-')
                                bonadate=date[2]+'-'+date[1]+'-'+date[0]
                                row[22]=bonadate

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[21]!=None:
                                    d=Division.objects.get(id=row[23])
                                    row[21]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Form17-SSC" and request.POST['year']:
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Form17-SSC'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Form17-SSC')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 28, schname,format0)
                            ws.write_merge(1, 3, 0, 28, 'Form17-SSC General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Seat No & Year of Passing Std.X ","LC Serial No","Date of Passing Std.X","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat == "prn":
                                print("prn")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "aadhar":
                                print("aadhar")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "fname":
                                print("fname")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "faname":
                                print("faname")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "lname":
                                print("lname")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "gender":
                                print("gender")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "religion":
                                print("religion")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "caste":
                                print("caste")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "subcaste":
                                print("subcaste")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "bpl":
                                print("bpl")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "disability":
                                print("disability")
                                rows = Form1710Adm.objects.filter(admyear=year[0:4],pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Form 17-SSC section has no field Faculty")
                                return redirect('report_studentadmission')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[20].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[20]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Form17-HSC" and request.POST['year']:
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Form17-HSC'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Form17-HSC')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 29, schname,format0)
                            ws.write_merge(1, 3, 0, 29, 'Form17-HSC General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Seat No & Year of Passing Std.XII ","LC Serial No","Date of Passing Std.XII","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat == "prn":
                                print("prn")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "aadhar":
                                print("aadhar")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "fname":
                                print("fname")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "faname":
                                print("faname")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "lname":
                                print("lname")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "gender":
                                print("gender")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "religion":
                                print("religion")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "caste":
                                print("caste")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "subcaste":
                                print("subcaste")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],admission_faculty=request.POST['faculty']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "bpl":
                                print("bpl")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "disability":
                                print("disability")
                                rows = Form1712Adm.objects.filter(admyear=year[0:4],pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[20].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[20]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response



                    elif request.POST['section'] and request.POST['searchcat']:
                        if section == "Primary":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Primary.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Primary')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 30, schname,format0)
                            ws.write_merge(1, 3, 0, 30, 'Primary General Register Report ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat=="prn":
                                print("prn")
                                rows = PrimAdm.objects.filter(prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="aadhar":
                                print("aadhar")
                                rows = PrimAdm.objects.filter(aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="fname":
                                print("fname")
                                rows = PrimAdm.objects.filter(fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="faname":
                                print("faname")
                                rows = PrimAdm.objects.filter(faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="lname":
                                print("lname")
                                rows = PrimAdm.objects.filter(lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="gender":
                                print("gender")
                                rows = PrimAdm.objects.filter(sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="religion":
                                print("religion")
                                rows = PrimAdm.objects.filter(religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="caste":
                                print("caste")
                                rows = PrimAdm.objects.filter(cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="subcaste":
                                print("subcaste")
                                rows = PrimAdm.objects.filter(subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="bpl":
                                print("bpl")
                                rows = PrimAdm.objects.filter(bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="disability":
                                print("disability")
                                rows = PrimAdm.objects.filter(pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Primary section has no field Faculty")
                                return redirect('report_studentadmission')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[20]!=None:
                                    d=Division.objects.get(id=row[20])
                                    row[20]=d.division
                                
                                row.append("")
                                row.append("")
                                row.append("")
                                
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Secondary":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Secondary.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Secondary')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 30, schname,format0)
                            ws.write_merge(1, 3, 0, 30, 'Secondary General Register Report ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat=="prn":
                                print("prn")
                                rows = SecondAdm.objects.filter(prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="aadhar":
                                print("aadhar")
                                rows = SecondAdm.objects.filter(aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="fname":
                                print("fname")
                                rows = SecondAdm.objects.filter(fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="faname":
                                print("faname")
                                rows = SecondAdm.objects.filter(faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="lname":
                                print("lname")
                                rows = SecondAdm.objects.filter(lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="gender":
                                print("gender")
                                rows = SecondAdm.objects.filter(sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="religion":
                                print("religion")
                                rows = SecondAdm.objects.filter(religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="caste":
                                print("caste")
                                rows = SecondAdm.objects.filter(cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="subcaste":
                                print("subcaste")
                                rows = SecondAdm.objects.filter(subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="bpl":
                                print("bpl")
                                rows = SecondAdm.objects.filter(bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat=="disability":
                                print("disability")
                                rows = SecondAdm.objects.filter(pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Secondary section has no field Faculty")
                                return redirect('report_studentadmission')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[20]!=None:
                                    d=Division.objects.get(id=row[20])
                                    row[20]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Jr.College":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Jr.College.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Jr.College')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 31, schname,format0)
                            ws.write_merge(1, 3, 0, 31, 'Jr.College General Register Report ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat == "prn":
                                print("prn")
                                rows = CollegeAdm.objects.filter(prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "aadhar":
                                print("aadhar")
                                rows = CollegeAdm.objects.filter(aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "fname":
                                print("fname")
                                rows = CollegeAdm.objects.filter(fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faname":
                                print("faname")
                                rows = CollegeAdm.objects.filter(faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "lname":
                                print("lname")
                                rows = CollegeAdm.objects.filter(lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "gender":
                                print("gender")
                                rows = CollegeAdm.objects.filter(sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "religion":
                                print("religion")
                                rows = CollegeAdm.objects.filter(religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "caste":
                                print("caste")
                                rows = CollegeAdm.objects.filter(cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "subcaste":
                                print("subcaste")
                                rows = CollegeAdm.objects.filter(subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                rows = CollegeAdm.objects.filter(admission_faculty=request.POST['faculty']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "bpl":
                                print("bpl")
                                rows = CollegeAdm.objects.filter(bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "disability":
                                print("disability")
                                rows = CollegeAdm.objects.filter(pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[23]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[21]!=None:
                                    d=Division.objects.get(id=row[23])
                                    row[21]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="11-ATKT":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_11-ATKT.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('11-ATKT')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 33, schname,format0)
                            ws.write_merge(1, 3, 0, 33, '11-ATKT General Register Report ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Division","Bonafide Issue Date","Bonafide Serial No","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat == "prn":
                                print("prn")
                                rows = ATKT11Adm.objects.filter(prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "aadhar":
                                print("aadhar")
                                rows = ATKT11Adm.objects.filter(aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "fname":
                                print("fname")
                                rows = ATKT11Adm.objects.filter(fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faname":
                                print("faname")
                                rows = ATKT11Adm.objects.filter(faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "lname":
                                print("lname")
                                rows = ATKT11Adm.objects.filter(lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "gender":
                                print("gender")
                                rows = ATKT11Adm.objects.filter(sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "religion":
                                print("religion")
                                rows = ATKT11Adm.objects.filter(religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "caste":
                                print("caste")
                                rows = ATKT11Adm.objects.filter(cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "subcaste":
                                print("subcaste")
                                rows = ATKT11Adm.objects.filter(subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                rows = ATKT11Adm.objects.filter(admission_faculty=request.POST['faculty']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "bpl":
                                print("bpl")
                                rows = ATKT11Adm.objects.filter(bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            elif searchcat == "disability":
                                print("disability")
                                rows = ATKT11Adm.objects.filter(pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[23]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                bonadate=date=row[22].split('-')
                                bonadate=date[2]+'-'+date[1]+'-'+date[0]
                                row[22]=bonadate

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[21]!=None:
                                    d=Division.objects.get(id=row[23])
                                    row[21]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Form17-SSC":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Form17-SSC.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Form17-SSC')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 28, schname,format0)
                            ws.write_merge(1, 3, 0, 28, 'Form17-SSC General Register Report ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Seat No & Year of Passing Std.X ","LC Serial No","Date of Passing Std.X","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat == "prn":
                                print("prn")
                                rows = Form1710Adm.objects.filter(prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "aadhar":
                                print("aadhar")
                                rows = Form1710Adm.objects.filter(aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "fname":
                                print("fname")
                                rows = Form1710Adm.objects.filter(fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "faname":
                                print("faname")
                                rows = Form1710Adm.objects.filter(faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "lname":
                                print("lname")
                                rows = Form1710Adm.objects.filter(lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "gender":
                                print("gender")
                                rows = Form1710Adm.objects.filter(sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "religion":
                                print("religion")
                                rows = Form1710Adm.objects.filter(religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "caste":
                                print("caste")
                                rows = Form1710Adm.objects.filter(cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "subcaste":
                                print("subcaste")
                                rows = Form1710Adm.objects.filter(subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "bpl":
                                print("bpl")
                                rows = Form1710Adm.objects.filter(bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "disability":
                                print("disability")
                                rows = Form1710Adm.objects.filter(pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                messages.error(request,"Form 17-SSC section has no field Faculty")
                                return redirect('report_studentadmission')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[20].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[20]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Form17-HSC":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Form17-HSC.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Form17-HSC')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 29, schname,format0)
                            ws.write_merge(1, 3, 0, 29, 'Form17-HSC General Register Report ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Seat No & Year of Passing Std.XII ","LC Serial No","Date of Passing Std.XII","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            if searchcat == "prn":
                                print("prn")
                                rows = Form1712Adm.objects.filter(prn=request.POST['prn']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "aadhar":
                                print("aadhar")
                                rows = Form1712Adm.objects.filter(aadhar=request.POST['aadhar']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "fname":
                                print("fname")
                                rows = Form1712Adm.objects.filter(fname=request.POST['fname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "faname":
                                print("faname")
                                rows = Form1712Adm.objects.filter(faname=request.POST['faname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "lname":
                                print("lname")
                                rows = Form1712Adm.objects.filter(lname=request.POST['lname']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "gender":
                                print("gender")
                                rows = Form1712Adm.objects.filter(sex=request.POST['gender']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "religion":
                                print("religion")
                                rows = Form1712Adm.objects.filter(religion=request.POST['religion']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "caste":
                                print("caste")
                                rows = Form1712Adm.objects.filter(cast=request.POST['caste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "subcaste":
                                print("subcaste")
                                rows = Form1712Adm.objects.filter(subcast=request.POST['subcaste']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "faculty":
                                print("faculty")
                                rows = Form1712Adm.objects.filter(admission_faculty=request.POST['faculty']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "bpl":
                                print("bpl")
                                rows = Form1712Adm.objects.filter(bpl=request.POST['bpl']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            elif searchcat == "disability":
                                print("disability")
                                rows = Form1712Adm.objects.filter(pwd=request.POST['disability']).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[20].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[20]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response


                    elif request.POST['year'] and request.POST['section']:
                        if section=="Primary":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Primary'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Primary')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 30, schname,format0)
                            ws.write_merge(1, 3, 0, 30, 'Primary General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = PrimAdm.objects.filter(admyear=year[0:4]).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                print(1)
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[20]!=None:
                                    d=Division.objects.get(id=row[20])
                                    row[20]=d.division
                                
                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Secondary":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Secondary'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Secondary')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 30, schname,format0)
                            ws.write_merge(1, 3, 0, 30, 'Secondary General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = SecondAdm.objects.filter(admyear=year[0:4]).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[20]!=None:
                                    d=Division.objects.get(id=row[20])
                                    row[20]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Jr.College":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Jr.College'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Jr.College')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 31, schname,format0)
                            ws.write_merge(1, 3, 0, 31, 'Jr.College General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = CollegeAdm.objects.filter(admyear=year[0:4]).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[23]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[21]!=None:
                                    d=Division.objects.get(id=row[23])
                                    row[21]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="11-ATKT":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_11-ATKT'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('11-ATKT')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 33, schname,format0)
                            ws.write_merge(1, 3, 0, 33, '11-ATKT General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Division","Bonafide Issue Date","Bonafide Serial No","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = ATKT11Adm.objects.filter(admyear=year[0:4]).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[23]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                bonadate=date=row[22].split('-')
                                bonadate=date[2]+'-'+date[1]+'-'+date[0]
                                row[22]=bonadate

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[21]!=None:
                                    d=Division.objects.get(id=row[23])
                                    row[21]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Form17-SSC":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Form17-SSC'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Form17-SSC')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 28, schname,format0)
                            ws.write_merge(1, 3, 0, 28, 'Form17-SSC General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Seat No & Year of Passing Std.X ","LC Serial No","Date of Passing Std.X","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = Form1710Adm.objects.filter(admyear=year[0:4]).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[20].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[20]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Form17-HSC":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Form17-HSC'+year+'.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Form17-HSC')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 29, schname,format0)
                            ws.write_merge(1, 3, 0, 29, 'Form17-HSC General Register Report - '+year,format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Seat No & Year of Passing Std.XII ","LC Serial No","Date of Passing Std.XII","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = Form1712Adm.objects.filter(admyear=year[0:4]).values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[20].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[20]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response


                    elif request.POST['section']:
                        if section=="Primary":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_PrimaryAll.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Primary')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 30, schname,format0)
                            ws.write_merge(1, 3, 0, 30, 'Primary General Register Report ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = PrimAdm.objects.all().values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[20]!=None:
                                    d=Division.objects.get(id=row[20])
                                    row[20]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Secondary":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_SecondaryAll.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Secondary')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 30, schname,format0)
                            ws.write_merge(1, 3, 0, 30, 'Secondary General Register Report ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = SecondAdm.objects.all().values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[20]!=None:
                                    d=Division.objects.get(id=row[20])
                                    row[20]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Jr.College":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Jr.CollegeAll.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Jr.College')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 310,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 31, schname,format0)
                            ws.write_merge(1, 3, 0, 40, 'Jr.College General Register Report ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Division","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = CollegeAdm.objects.all().values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[23]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[21]!=None:
                                    d=Division.objects.get(id=row[23])
                                    row[21]=d.division
                                
                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="11-ATKT":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_11-ATKTAll.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('11-ATKT')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 33, schname,format0)
                            ws.write_merge(1, 3, 0, 33, '11-ATKT General Register Report  ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Division","Bonafide Issue Date","Bonafide Serial No","Standard in Studying and since when","LC Serial No","Progress","Conduct","Reason of Leaving","Date of Leaving","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = ATKT11Adm.objects.all().values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','admdate','adm_class','admission_faculty','division','bonaissuedate','bonasrno','lcstudyinginclass','lcsrno','lcprogress','lcconduct','lcreason','lcdateofleaving','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[23]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName

                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                bonadate=date=row[22].split('-')
                                bonadate=date[2]+'-'+date[1]+'-'+date[0]
                                row[22]=bonadate

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[18].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[18]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName

                                if row[21]!=None:
                                    d=Division.objects.get(id=row[23])
                                    row[21]=d.division

                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Form17-SSC":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Form17-SSCAll.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Form17-SSC')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 28, schname,format0)
                            ws.write_merge(1, 3, 0, 28, 'Form17-SSC General Register Report  ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Seat No & Year of Passing Std.X ","LC Serial No","Date of Passing Std.X","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = Form1710Adm.objects.all().values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[20].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[20]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName
                                
                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response
                        elif section=="Form17-HSC":
                            response = HttpResponse(content_type='application/ms-excel')
                            response['Content-Disposition'] = 'attachment; filename=GeneralRegister_Form17-HSCAll.xls'
                            wb = xlwt.Workbook(encoding='utf-8')
                            ws = wb.add_sheet('Form17-HSC')
                            format0 = xlwt.easyxf(
                                'font:height 300;pattern: pattern solid, fore_colour white;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,left thin, right thin, top thin, bottom thin;')
                            format1 = xlwt.easyxf(
                                'font:height 400,bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,left thin, right thin, top thin, bottom thin;')
                            # Sheet header, first row
                            row_num = 4
                            excel_style = xlwt.XFStyle()
                            ws.write_merge(0, 0, 0, 29, schname,format0)
                            ws.write_merge(1, 3, 0, 29, 'Form17-HSC General Register Report ',format1)
                            excel_style.font.bold = True
                            borders = xlwt.Borders()
                            borders.left = 1
                            borders.right = 1
                            borders.top = 1
                            borders.bottom = 1
                            excel_style.borders = borders
                            columns = ["Registration Number","Saral ID","Aadhar","Surname","Pupils","Father Name","Mother Name","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Place of Birth","Date of Birth(DD-MM-YYYY)","DOB in Words","Last attended school","Last attended class","Previous LC Sr No","Previous Registration Number","Admission Date(DD-MM-YYYY)","Admission Standard","Admission Faculty","Seat No & Year of Passing Std.XII ","LC Serial No","Date of Passing Std.XII","Date of Issue","Transfer Certificate recived date & Parent Sign","Please Confirm the following information is correct - Sign of Guardian","Remarks"]
                            for col_num in range(len(columns)):
                                ws.write(row_num, col_num, columns[col_num], excel_style)
                            # Sheet body, remaining rows
                            excel_style = xlwt.XFStyle()
                            excel_style.borders = borders
                            rows = Form1712Adm.objects.all().values_list('prn','saral_id','aadhar','lname','fname','faname','moname','nationality','tongue','religion','cast','cast','subcast','pob','dob','lcdobinwords','last_school','last_class','prevlcsrno','prevprn','admdate','adm_class','admission_faculty','seatnoandyear','lcsrno','lcdateofpassing','lcissuedate')
                            for row in rows:
                                # row[8]-m_tongue,row[9]-religion,row[10]-cast,
                                # row[11]- category,row[12]-subcast,row[16]-last_school,row[22]-division
                                row=list(row)
                                t=MTongue.objects.get(id=row[8])
                                row[8]=t.m_tongue

                                r=Religion.objects.get(id=row[9])
                                row[9]=r.religionName

                                c=Cast.objects.get(id=row[10])
                                row[10]=c.castName
                                row[11]=c.castCat.castCategoryName


                                if row[12]!=None:
                                    sc=SubCast.objects.get(id=row[12])
                                    row[12]=sc.subCastName

                                dobdate=date=row[14].split('-')
                                dobdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[14]=dobdate

                                admdate=date=row[20].split('-')
                                admdate=date[2]+'-'+date[1]+'-'+date[0]
                                row[20]=admdate

                                if row[16]!=None:
                                    os=OtherSch.objects.get(id=row[16])
                                    row[16]=os.schName
                                
                                row.append("")
                                row.append("")
                                row.append("")
                                    
                                row=tuple(row)
                                row_num += 1
                                for col_num in range(len(row)):
                                    ws.write(row_num, col_num, row[col_num], excel_style)
                            wb.save(response)
                            return response


            except:
                messages.error(request,"Invalid header found in Report form... Try again")
                return redirect('report_studentadmission')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Reports /",
            'fname':fname,
            'yearData':yearData,
            'relData':relData,
            'casteData':casteData,
            'subcasteData':subcasteData,
            "page_path":"General Register Report",
            "menu_icon":"nav-icon fas fa-university",
            }
        return render(request,'schoolviews/reports/studentreport.html',context) 
    else:
        return redirect('login')