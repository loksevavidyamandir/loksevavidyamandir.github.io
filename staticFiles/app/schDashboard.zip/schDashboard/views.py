from django.shortcuts import redirect,render
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import cache_control
from django.contrib import messages
from django.conf import settings as conf_set
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm
from schAdmission.admModels.academicModels import PrimBonafide,SecBonafide,ColBonafide,Form17SSCBonafide,Form17HSCBonafide,ATKT11Bonafide
import datetime

# Create your views here.

sname=conf_set.SCHOOL_NAME


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required(login_url='login')
def dashboard_dash(request):
    if request.session.has_key('username'):
        lname=request.user.first_name 
        fname=request.user.first_name
        now = datetime.datetime.now()
        cy=str(now.year)
        cy1=now.year+1
        # start_date=cy+"-06-01"
        # end_date=str(cy1)+"-05-31"
        # print(start_date)
        # print(end_date)

# for 8th Pass Secondary Certificate current year
        s8thcount=0
        # for secondary
        secData=SecondAdm.objects.filter(sec8passyear=cy,sec8pass=True)
        for s in secData:
            s8thcount+=1


#for Admission count for current year
        padmcount=sadmcount=cadmcount=atktadmcount=f10admcount=f12admcount=0
        c_Sciadmc=c_Artsadmc=c_Comadmc=c_Vocadmc=0
        atkt_Sciadmc=atkt_Artsadmc=atkt_Comadmc=atkt_Vocadmc=0
        f12_Sciadmc=f12_Artsadmc=f12_Comadmc=f12_Vocadmc=0
        tnoadmc=0

        # for primary
        priData=PrimAdm.objects.filter(admyear=cy)
        for p in priData:
            padmcount+=1

        # for secondary
        secData=SecondAdm.objects.filter(admyear=cy)
        for s in secData:
            sadmcount+=1


        # for College
        colData=CollegeAdm.objects.filter(admyear=cy)
        for c in colData:
            cadmcount+=1
        colData=CollegeAdm.objects.filter(admyear=cy,admission_faculty="ARTS")

        for c in colData:
            c_Artsadmc+=1
        colData=CollegeAdm.objects.filter(admyear=cy,admission_faculty="SCIENCE")
        for c in colData:
            c_Sciadmc+=1
        colData=CollegeAdm.objects.filter(admyear=cy,admission_faculty="COMMERCE")
        for c in colData:
            c_Comadmc+=1
        colData=CollegeAdm.objects.filter(admyear=cy,admission_faculty="VOCATIONAL")
        for c in colData:
            c_Vocadmc+=1
        

        # for College
        atkt11Data=ATKT11Adm.objects.filter(admyear=cy)
        for c in atkt11Data:
            atktadmcount+=1
        atkt11Data=ATKT11Adm.objects.filter(admyear=cy,admission_faculty="ARTS")

        for c in atkt11Data:
            atkt_Artsadmc+=1
        atkt11Data=ATKT11Adm.objects.filter(admyear=cy,admission_faculty="SCIENCE")
        for c in atkt11Data:
            atkt_Sciadmc+=1
        atkt11Data=ATKT11Adm.objects.filter(admyear=cy,admission_faculty="COMMERCE")
        for c in atkt11Data:
            atkt_Comadmc+=1
        atkt11Data=ATKT11Adm.objects.filter(admyear=cy,admission_faculty="VOCATIONAL")
        for c in atkt11Data:
            atkt_Vocadmc+=1
            
        # for Form17-SSC
        f1710Data=Form1710Adm.objects.filter(admyear=cy)
        for f in f1710Data:
            f10admcount+=1

        # for Form17-HSC
        f1712Data=Form1712Adm.objects.filter(admyear=cy)
        for f in f1712Data:
            f12admcount+=1
        f1712Data=Form1712Adm.objects.filter(admyear=cy,admission_faculty="ARTS")

        for f in f1712Data:
            f12_Artsadmc+=1
        f1712Data=Form1712Adm.objects.filter(admyear=cy,admission_faculty="SCIENCE")
        for f in f1712Data:
            f12_Sciadmc+=1
        f1712Data=Form1712Adm.objects.filter(admyear=cy,admission_faculty="COMMERCE")
        for f in f1712Data:
            f12_Comadmc+=1
        f1712Data=Form1712Adm.objects.filter(admyear=cy,admission_faculty="VOCATIONAL")
        for f in f1712Data:
            f12_Vocadmc+=1
        tnoadmc=padmcount+sadmcount+cadmcount+atktadmcount+f10admcount+f12admcount



#for Students count for current year
        #for primary
        pstud1=pstud2=pstud3=pstud4=0
        priData=PrimAdm.objects.filter(updateyear1=cy,lcgenerated=False)
        for p in priData:
            pstud1+=1
        priData=PrimAdm.objects.filter(updateyear2=cy,lcgenerated=False)
        for p in priData:
            pstud2+=1
        priData=PrimAdm.objects.filter(updateyear3=cy,lcgenerated=False)
        for p in priData:
            pstud3+=1
        priData=PrimAdm.objects.filter(updateyear4=cy,lcgenerated=False)
        for p in priData:
            pstud4+=1
        pstudcount=pstud1+pstud2+pstud3+pstud4

        #for Secondary
        sstud5=sstud6=sstud7=sstud8=sstud9=sstud10=0
        secData=SecondAdm.objects.filter(updateyear5=cy,lcgenerated=False)
        for s in secData:
            sstud5+=1
        secData=SecondAdm.objects.filter(updateyear6=cy,lcgenerated=False)
        for s in secData:
            sstud6+=1
        secData=SecondAdm.objects.filter(updateyear7=cy,lcgenerated=False)
        for s in secData:
            sstud7+=1
        secData=SecondAdm.objects.filter(updateyear8=cy,lcgenerated=False)
        for s in secData:
            sstud8+=1
        secData=SecondAdm.objects.filter(updateyear9=cy,lcgenerated=False)
        for s in secData:
            sstud9+=1
        secData=SecondAdm.objects.filter(updateyear10=cy,lcgenerated=False)
        for s in secData:
            sstud10+=1
        sstudcount=sstud5+sstud6+sstud7+sstud8+sstud9+sstud10

        # for College
        sstud11=sstud12=0
        colData=CollegeAdm.objects.filter(updateyear11=cy,lcgenerated=False)
        for c in colData:
            sstud11+=1
        colData=CollegeAdm.objects.filter(updateyear12=cy,lcgenerated=False)
        for c in colData:
            sstud12+=1
        cstudcount=sstud11+sstud12

        # for College for Science
        sstudSci11=sstudSci12=0
        colData=CollegeAdm.objects.filter(updateyear11=cy,updatestream11="SCIENCE",lcgenerated=False)
        for c in colData:
            sstudSci11+=1
        colData=CollegeAdm.objects.filter(updateyear12=cy,updatestream12="SCIENCE",lcgenerated=False)
        for c in colData:
            sstudSci12+=1
        sstudScicount=sstudSci11+sstudSci12

        # for College for Commerce
        sstudCom11=sstudCom12=0
        colData=CollegeAdm.objects.filter(updateyear11=cy,updatestream11="COMMERCE",lcgenerated=False)
        for c in colData:
            sstudCom11+=1
        colData=CollegeAdm.objects.filter(updateyear12=cy,updatestream12="COMMERCE",lcgenerated=False)
        for c in colData:
            sstudCom12+=1
        sstudComcount=sstudCom11+sstudCom12

        # for College for Arts
        sstudArts11=sstudArts12=0
        colData=CollegeAdm.objects.filter(updateyear11=cy,updatestream11="ARTS",lcgenerated=False)
        for c in colData:
            sstudArts11+=1
        colData=CollegeAdm.objects.filter(updateyear12=cy,updatestream12="ARTS",lcgenerated=False)
        for c in colData:
            sstudArts12+=1
        sstudArtscount=sstudArts11+sstudArts12

        # for College for Vocational
        sstudVoc11=sstudVoc12=0
        colData=CollegeAdm.objects.filter(updateyear11=cy,updatestream11="VOCATIONAL",lcgenerated=False)
        for c in colData:
            sstudVoc11+=1
        colData=CollegeAdm.objects.filter(updateyear12=cy,updatestream12="VOCATIONAL",lcgenerated=False)
        for c in colData:
            sstudVoc12+=1
        sstudVoccount=sstudVoc11+sstudVoc12

        tstudcount=pstudcount+sstudcount+cstudcount+atktadmcount+f10admcount+f12admcount

#for Students LC Issued count for current year
        plccount=slccount=clccount=atktlccount=f10lccount=f12lccount=0
        clcScicount=clcComcount=clcArtscount=clcVoccount=0
        atktlcScicount=atktlcComcount=atktlcArtscount=atktlcVoccount=0
        f12lcScicount=f12lcComcount=f12lcArtscount=f12lcVoccount=0
        # For primary
        priData=PrimAdm.objects.filter(lcyearofleaving=cy,lcgenerated=True)
        for p in priData:
            plccount+=1

        #for Secondary
        secData=SecondAdm.objects.filter(lcyearofleaving=cy,lcgenerated=True)
        for s in secData:
            slccount+=1

        # For College
        colData=CollegeAdm.objects.filter(lcyearofleaving=cy,lcgenerated=True)
        for c in colData:
            clccount+=1
        #for Science
        colData=CollegeAdm.objects.filter(lcyearofleaving=cy,admission_faculty="SCIENCE",lcgenerated=True)
        for c in colData:
            clcScicount+=1
        #for Commerce
        colData=CollegeAdm.objects.filter(lcyearofleaving=cy,admission_faculty="COMMERCE",lcgenerated=True)
        for c in colData:
            clcComcount+=1
        #for Arts
        colData=CollegeAdm.objects.filter(lcyearofleaving=cy,admission_faculty="ARTS",lcgenerated=True)
        for c in colData:
            clcArtscount+=1
        #for Vocational
        colData=CollegeAdm.objects.filter(lcyearofleaving=cy,admission_faculty="VOCATIONAL",lcgenerated=True)
        for c in colData:
            clcVoccount+=1

        
        # For 11-ATKT
        atkt11Data=ATKT11Adm.objects.filter(lcyearofleaving=cy,lcgenerated=True)
        for c in atkt11Data:
            atktlccount+=1
        #for Science
        atkt11Data=ATKT11Adm.objects.filter(lcyearofleaving=cy,admission_faculty="SCIENCE",lcgenerated=True)
        for c in atkt11Data:
            atktlcScicount+=1
        #for Commerce
        atkt11Data=ATKT11Adm.objects.filter(lcyearofleaving=cy,admission_faculty="COMMERCE",lcgenerated=True)
        for c in atkt11Data:
            atktlcComcount+=1
        #for Arts
        atkt11Data=ATKT11Adm.objects.filter(lcyearofleaving=cy,admission_faculty="ARTS",lcgenerated=True)
        for c in atkt11Data:
            atktlcArtscount+=1
        #for Vocational
        atkt11Data=ATKT11Adm.objects.filter(lcyearofleaving=cy,admission_faculty="VOCATIONAL",lcgenerated=True)
        for c in atkt11Data:
            atktlcVoccount+=1
        

        # For Form17-SSC
        f1710Data=Form1710Adm.objects.filter(lcyearofpassing=cy,lcgenerated=True)
        for c in f1710Data:
            f10lccount+=1

        # For Form17-HSC
        f1712Data=Form1712Adm.objects.filter(lcyearofpassing=cy,lcgenerated=True)
        for c in f1712Data:
            f12lccount+=1
        #for Science
        f1712Data=Form1712Adm.objects.filter(lcyearofpassing=cy,admission_faculty="SCIENCE",lcgenerated=True)
        for c in f1712Data:
            f12lcScicount+=1
        #for Commerce
        f1712Data=Form1712Adm.objects.filter(lcyearofpassing=cy,admission_faculty="COMMERCE",lcgenerated=True)
        for c in f1712Data:
            f12lcComcount+=1
        #for Arts
        f1712Data=Form1712Adm.objects.filter(lcyearofpassing=cy,admission_faculty="ARTS",lcgenerated=True)
        for c in f1712Data:
            f12lcArtscount+=1
        #for Vocational
        f1712Data=Form1712Adm.objects.filter(lcyearofpassing=cy,admission_faculty="VOCATIONAL",lcgenerated=True)
        for c in f1712Data:
            f12lcVoccount+=1

        totallccount=plccount+slccount+clccount+atktlccount+f10lccount+f12lccount



#for Students Bonafide Issued count for current year
        pbocount=sbocount=cbocount=atktbocount=f10bocount=f12bocount=0
        cboScicount=cboComcount=cboArtscount=cboVoccount=0
        atktboScicount=atktboComcount=atktboArtscount=atktboVoccount=0
        f12boScicount=f12boComcount=f12boArtscount=f12boVoccount=0
        # For primary
        priBona=PrimBonafide.objects.filter(bona_year=cy)
        for p in priBona:
            pbocount+=1

        # For Secondary
        secBona=SecBonafide.objects.filter(bona_year=cy)
        for p in secBona:
            sbocount+=1

        # For College
        colBona=ColBonafide.objects.filter(bona_year=cy)
        for p in colBona:
            cbocount+=1
        #for Science
        colBona=ColBonafide.objects.filter(bona_year=cy,bona_stream="SCIENCE")
        for c in colBona:
            cboScicount+=1
        #for Commerce
        colBona=ColBonafide.objects.filter(bona_year=cy,bona_stream="COMMERCE")
        for c in colBona:
            cboComcount+=1
        #for Arts
        colBona=ColBonafide.objects.filter(bona_year=cy,bona_stream="ARTS")
        for c in colBona:
            cboArtscount+=1
        #for Vocational
        colBona=ColBonafide.objects.filter(bona_year=cy,bona_stream="VOCATIONAL")
        for c in colBona:
            cboVoccount+=1

        # For 11-ATKT
        atkt11Bona=ATKT11Bonafide.objects.filter(bona_year=cy)
        for p in atkt11Bona:
            atktbocount+=1
        #for Science
        atkt11Bona=ATKT11Bonafide.objects.filter(bona_year=cy,bona_stream="SCIENCE")
        for c in atkt11Bona:
            atktboScicount+=1
        #for Commerce
        atkt11Bona=ATKT11Bonafide.objects.filter(bona_year=cy,bona_stream="COMMERCE")
        for c in atkt11Bona:
            atktboComcount+=1
        #for Arts
        atkt11Bona=ATKT11Bonafide.objects.filter(bona_year=cy,bona_stream="ARTS")
        for c in atkt11Bona:
            atktboArtscount+=1
        #for Vocational
        atkt11Bona=ATKT11Bonafide.objects.filter(bona_year=cy,bona_stream="VOCATIONAL")
        for c in atkt11Bona:
            atktboVoccount+=1

        # For Form17-SSC
        f10Bona=Form17SSCBonafide.objects.filter(bona_year=cy)
        for c in f10Bona:
            f10bocount+=1

        # For Form17-SSC
        f12Bona=Form17HSCBonafide.objects.filter(bona_year=cy)
        for c in f12Bona:
            f12bocount+=1
        #for Science
        f12Bona=Form17HSCBonafide.objects.filter(bona_year=cy,bona_stream="SCIENCE")
        for c in f12Bona:
            f12boScicount+=1
        #for Commerce
        f12Bona=Form17HSCBonafide.objects.filter(bona_year=cy,bona_stream="COMMERCE")
        for c in f12Bona:
            f12boComcount+=1
        #for Arts
        f12Bona=Form17HSCBonafide.objects.filter(bona_year=cy,bona_stream="ARTS")
        for c in f12Bona:
            f12boArtscount+=1
        #for Vocational
        f12Bona=Form17HSCBonafide.objects.filter(bona_year=cy,bona_stream="VOCATIONAL")
        for c in f12Bona:
            f12boVoccount+=1

        totalbonacount=pbocount+sbocount+cbocount+atktbocount+f10bocount+f12bocount



        context = {
            'sname':sname,
            'lname':lname,
            'fname':fname,
            'cy':cy,
            'cy1':cy1,

            's8thcount':s8thcount,

            'c_Scic':c_Sciadmc,
            'c_Artsc':c_Artsadmc,
            'c_Comc':c_Comadmc,
            'c_Vocc':c_Vocadmc,
            'atkt_Scic':atkt_Sciadmc,
            'atkt_Artsc':atkt_Artsadmc,
            'atkt_Comc':atkt_Comadmc,
            'atkt_Vocc':atkt_Vocadmc,
            'f12_Scic':f12_Sciadmc,
            'f12_Artsc':f12_Artsadmc,
            'f12_Comc':f12_Comadmc,
            'f12_Vocc':f12_Vocadmc,
            'padmcount':padmcount,
            'sadmcount':sadmcount,
            'cadmcount':cadmcount,
            'atktadmcount':atktadmcount,
            'f10admcount':f10admcount,
            'f12admcount':f12admcount,
            'tnoadmc':tnoadmc,

            'pstudcount':pstudcount,
            'sstudcount':sstudcount,
            'cstudcount':cstudcount,
            'sstudScicount':sstudScicount,
            'sstudComcount':sstudComcount,
            'sstudArtscount':sstudArtscount,
            'sstudVoccount':sstudVoccount,
            'tstudcount':tstudcount,

            'plccount':plccount,
            'slccount':slccount,
            'clccount':clccount,
            'clcScicount':clcScicount,
            'clcComcount':clcComcount,
            'clcArtscount':clcArtscount,
            'clcVoccount':clcVoccount,
            'atktlccount':atktlccount,
            'atktlcScicount':atktlcScicount,
            'atktlcComcount':atktlcComcount,
            'atktlcArtscount':atktlcArtscount,
            'atktlcVoccount':atktlcVoccount,
            'f10lccount':f10lccount,
            'f12lccount':f12lccount,
            'f12lcScicount':f12lcScicount,
            'f12lcComcount':f12lcComcount,
            'f12lcArtscount':f12lcArtscount,
            'f12lcVoccount':f12lcVoccount,
            'totallccount':totallccount,

            'pbocount':pbocount,
            'sbocount':sbocount,
            'cbocount':cbocount,
            'cboScicount':cboScicount,
            'cboComcount':cboComcount,
            'cboArtscount':cboArtscount,
            'cboVoccount':cboVoccount,
            'atktbocount':atktbocount,
            'atktboScicount':atktboScicount,
            'atktboComcount':atktboComcount,
            'atktboArtscount':atktboArtscount,
            'atktboVoccount':atktboVoccount,
            'f10bocount':f10bocount,
            'f12bocount':f12bocount,
            'f12boScicount':f12boScicount,
            'f12boComcount':f12boComcount,
            'f12boArtscount':f12boArtscount,
            'f12boVoccount':f12boVoccount,
            'totalbonacount':totalbonacount,
            'page_title':" Dashboard / ",
            "dashboard_page": "active",
            "page_path":"Dashboard",
            "menu_icon":"nav-icon fas fa-tachometer-alt"}
        return render(request,"schoolviews/dashboard/dashboard.html",context) 
    else:
        return redirect('login') 




    