from django.apps import AppConfig


class SchdashboardConfig(AppConfig):
    name = 'schDashboard'
