from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schAdmission.admForms.admissionForms import PriAdmForm,SecondAdmForm,CollegeAdmForm,RejoinForm,Form1710AdmForm,Form1712AdmForm
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm
from schAdmission.admModels.academicModels import PrimBonafide,SecBonafide,ColBonafide
from schSetup.setupModels.setup_models import Division
from schAdmission.admForms.admissionForms import GetAdmYearForm
from seedData.models import Year
import inflect
import datetime
import xlwt
from xlwt.Formatting import Borders
  
p=inflect.engine()
sname=conf_set.SCHOOL_NAME
schnameabove=conf_set.SCHNAME_ABOVE
schname=conf_set.SCHNAME
schnamebelow=conf_set.SCHNAME_BELOW
schUDISEno=conf_set.SCH_UDISE_NO


# College Bonafide views   

dd = ['','FIRST','SECOND','THIRD','FOURTH','FIFTH','SIXTH','SEVENTH','EIGHTH','NINTH','TENTH','ELEVENTH','TWELVETH','THIRTEENTH','FOURTEENTH','FIFTEENTH','SIXTEENTH','SEVENTEENTH','EIGHTEENTH','NINETEENTH','TWENTIETH','TWENTY FIRST','TWENTY SECOND','TWENTY THIRD','TWENTY FOURTH','TWENTY FIFTH','TWENTY SIXTH','TWENTY SEVENTH','TWENTY EIGHTH','TWENTY NINTH','THIRTIETH','THIRTY FIRST']
mm = ['','JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER']

# for College Student 
def admission_colbonafide(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divData = Division.objects.all()
        yearData = Year.objects.all()
        if request.method == 'POST':
            try:
                studid=request.POST['studid'].split(",")
                class1 = int(request.POST['colbonaclass'])
                year = str(request.POST['colbonayear'])
                stream = str(request.POST['colbonastream'])
                for x in range(0,len(studid)):
                    colData=CollegeAdm.objects.get(pk=studid[x])
                    colbona=ColBonafide()
                    colbona.prn=colData.prn
                    colbona.lname=colData.lname
                    colbona.fname=colData.fname
                    colbona.faname=colData.faname
                    colbona.breligion=colData.religion
                    colbona.bcast=colData.cast
                    colbona.col_academic=colData
                    colbona.bona_class=class1
                    colbona.bona_stream=stream
                    colbona.bona_year=str(year[0:4])

                    # from adm to bonafide
                    date=colData.dob.split('-')
                    dobirth=date[2]+'-'+date[1]+'-'+date[0]
                    d=int(date[2])
                    m=int(date[1])
                    y=int(date[0])
                    print(dobirth)
                    colbona.dob=dobirth

                     # for dob in words
                    yy=p.number_to_words(y).capitalize()
                    yy=yy.replace(" and",'')
                    print(dd[d],mm[m],yy.upper())
                    colbona.dobinwords=dd[d]+' '+mm[m]+' '+yy.upper()


                    # for issuedate
                    date=request.POST['dateofissue'].split('-')
                    doissue=date[2]+'-'+date[1]+'-'+date[0]
                    print(doissue)
                    colbona.issuedate=doissue

                    colbona.save()
                messages.success(request,'Bonafide issued Successfully!')
                return redirect('admission_colbonafide')
            except:
                messages.error(request,"Invalid header found in Student Bonafide form... Try again")
                return redirect('admission_colbonafide')
        else:
            pass
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Bonafide /",
            'fname':fname,
            "divData":divData,
            "yearData":yearData,
            "page_path":"College Bonafide Issue",
            "menu_icon":"far fa-address-card nav-icon",
            }    
        return render(request,'schoolviews/bonafide/collegebonafidegenerate.html',context) 
    else:
        return redirect('login')


# for College Student  
def load_colstudentsbona(request):
    class1 = int(request.GET.get('class1'))
    year = request.GET.get('year')
    div = request.GET.get('div')
    stream = request.GET.get('stream')
    if class1 == 11:
        students = CollegeAdm.objects.filter(updateclass11=class1,updateyear11=year[0:4],updatedivision11=div,updatestream11=stream,updateclass12=None,lcgenerated=0,terminatebyprincipal=0)
    elif class1 == 12:
        students = CollegeAdm.objects.filter(updateclass12=class1,updateyear12=year[0:4],updatedivision12=div,updatestream12=stream,lcgenerated=0,terminatebyprincipal=0)
    print(students)
    return render(request,'schoolviews/bonafide/studentsbona.html',{"students":students})




# for College bonafide  list 
def admission_colbonafidelist(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy[0:4])
                    colbonaData=ColBonafide.objects.filter(bona_year=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Bonafide /",
                    'fname':fname,
                    "page_path":" College Bonafide List",
                    "menu_icon":"far fa-address-card nav-icon",
                    "colbonaData":colbonaData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/bonafide/college_bonafidelist.html',context) 
                except:
                    messages.error(request,"Invalid header found in College Student List form... Try again")
                    return redirect('admission_colbonafidelist')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            colbonaData=ColBonafide.objects.filter(bona_year=cy)
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Bonafide /",
            'fname':fname,
            "page_path":" College Bonafide List",
            "menu_icon":"nav-icon far fa-address-card",
            "colbonaData":colbonaData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request,'schoolviews/bonafide/college_bonafidelist.html',context) 
    else:
        return redirect('login')




# for College bonafide  View 
def admission_colbonafideview(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        colbonaData=ColBonafide.objects.get(pk=id)
        colData=CollegeAdm.objects.get(prn=colbonaData.prn)
        acad_year=int(colbonaData.bona_year)
        acad_year+=1
        context = {
            "colData":colData,
            "colbonaData":colbonaData,
            "acad_year":acad_year,
            "schnameabove":schnameabove,
            "schname":schname,
            "schnamebelow":schnamebelow,
            "schUDISEno":schUDISEno,
            }
        return render(request, 'schoolviews/bonafide/collegebonafide_view.html',context)
    else:
        return redirect('login')



# for College bonafide Delete 
def admission_colbonafidedelete(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        try:
            colbona=ColBonafide.objects.get(pk=id)
            colbona.delete()
            messages.success(request,'Bonafide Deleted Sucessfully!')
            return redirect('admission_colbonafidelist')
        except:
            messages.error(request,"Invalid header found in Bonafide form... Try again")
            return redirect('admission_colbonafidelist')    
    else:
        return redirect('login') 