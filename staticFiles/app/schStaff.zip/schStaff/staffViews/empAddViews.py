from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User,auth
from django.conf import settings as conf_set
from django.contrib import messages
from schStaff.staffModels.empModels import EmployeeEnrol
from schStaff.staffForms.empForms import EmployeeEnrolForm




sname=conf_set.SCHOOL_NAME






# Employee Add View
def staff_addEmp(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            empAddForm= EmployeeEnrolForm(request.POST,request.FILES)
            print("before form valid")
            if empAddForm.is_valid():
                try:
                    if EmployeeEnrol.objects.filter(aadhar__iexact=empAddForm.cleaned_data['aadhar']).exists():
                        messages.error(request,"Aadhar Number Already Exists")
                        return redirect('staff_empadd')
                    elif EmployeeEnrol.objects.filter(email__iexact=empAddForm.cleaned_data['email']).exists():
                        messages.error(request,"Email Id Already Exists")
                        return redirect('staff_empadd')  
                    elif EmployeeEnrol.objects.filter(pan__iexact=empAddForm.cleaned_data['pan']).exists():
                        messages.error(request,"PAN Already Exists")
                        return redirect('staff_empadd')                                               
                    else:
                        empAddModule=EmployeeEnrol()
                        empAddModule.role=empAddForm.cleaned_data['role']
                        empAddModule.designation=empAddForm.cleaned_data['designation']
                        empAddModule.shalarth_id=empAddForm.cleaned_data['shalarth_id']
                        empAddModule.lname=empAddForm.cleaned_data['lname']
                        empAddModule.fname=empAddForm.cleaned_data['fname']
                        empAddModule.faname=empAddForm.cleaned_data['faname']
                        empAddModule.moname=empAddForm.cleaned_data['moname']
                        empAddModule.mrname=empAddForm.cleaned_data['mrname']
                        empAddModule.pob=empAddForm.cleaned_data['pob']
                        empAddModule.dob=empAddForm.cleaned_data['dob']
                        empAddModule.marital_status=empAddForm.cleaned_data['marital_status']
                        empAddModule.aadhar=empAddForm.cleaned_data['aadhar']
                        empAddModule.pan=empAddForm.cleaned_data['pan']
                        empAddModule.email=empAddForm.cleaned_data['email']
                        empAddModule.mob=empAddForm.cleaned_data['mob']
                        empAddModule.nationality=empAddForm.cleaned_data['nationality']
                        empAddModule.tongue=empAddForm.cleaned_data['tongue']
                        empAddModule.religion=empAddForm.cleaned_data['religion']
                        empAddModule.cast=empAddForm.cleaned_data['cast']
                        empAddModule.category=empAddForm.cleaned_data['category']
                        empAddModule.subcast=empAddForm.cleaned_data['subcast']
                        empAddModule.minority=empAddForm.cleaned_data['minority']
                        empAddModule.sex=empAddForm.cleaned_data['sex']
                        empAddModule.pwd=empAddForm.cleaned_data['pwd']
                        empAddModule.bgroup=empAddForm.cleaned_data['bgroup']
                        empAddModule.enroldate=empAddForm.cleaned_data['enroldate']
                        y=empAddForm.cleaned_data['enroldate']                   
                        empAddModule.enrolyear=y[0:4]
                        print(y)
                        empAddModule.enrol_for=empAddForm.cleaned_data['enrol_for']
                        empAddModule.enrol_faculty=empAddForm.cleaned_data['enrol_faculty']
                        empAddModule.areaType=empAddForm.cleaned_data['areaType']
                        empAddModule.caddress=empAddForm.cleaned_data['caddress']
                        empAddModule.ca_is_pa_addr=empAddForm.cleaned_data['ca_is_pa_addr']
                        empAddModule.paddress=empAddForm.cleaned_data['paddress']
                        empAddModule.qualification=empAddForm.cleaned_data['qualification']
                        empAddModule.experience=empAddForm.cleaned_data['experience']
                        empAddModule.epf_num=empAddForm.cleaned_data['epf_num']
                        empAddModule.salary=empAddForm.cleaned_data['salary']
                        empAddModule.contract=empAddForm.cleaned_data['contract']
                        empAddModule.scale=empAddForm.cleaned_data['scale']
                        empAddModule.senior_scale=empAddForm.cleaned_data['senior_scale']
                        empAddModule.most_senior_scale=empAddForm.cleaned_data['most_senior_scale']
                        #Bank Account Details
                        empAddModule.saccount=empAddForm.cleaned_data['saccount']
                        empAddModule.sbankname=empAddForm.cleaned_data['sbankname']
                        empAddModule.sifsc=empAddForm.cleaned_data['sifsc']
                        empAddModule.sbranch=empAddForm.cleaned_data['sbranch']
                        empAddModule.smicr=empAddForm.cleaned_data['smicr']
                        empAddModule.paccount=empAddForm.cleaned_data['paccount']
                        empAddModule.pbankname=empAddForm.cleaned_data['pbankname']
                        empAddModule.pifsc=empAddForm.cleaned_data['pifsc']
                        empAddModule.pbranch=empAddForm.cleaned_data['pbranch']
                        empAddModule.pmicr=empAddForm.cleaned_data['pmicr']
                        #Documents                     
                        empAddModule.addhar_img=empAddForm.cleaned_data['addhar_img']
                        empAddModule.pan_img=empAddForm.cleaned_data['pan_img']
                        empAddModule.emp_img=empAddForm.cleaned_data['emp_img']
                        # Create User for Employee
                        print("sgds")
                        user=User.objects.create_user(username=empAddForm.cleaned_data['aadhar'],email=empAddForm.cleaned_data['email'],password="Employee@123",first_name=empAddForm.cleaned_data['fname'],last_name=empAddForm.cleaned_data['lname'])
                        user.save()
                        my_group=Group.objects.get(name=empAddForm.cleaned_data['role'])
                        #my_group.user_set.add(user)
                        user.groups.add(my_group)
                        empAddModule.user=user
                        # empAddModule.lcgenrated=False
                        empAddModule.save()
                        messages.success(request, empAddForm.cleaned_data['fname']+" "+empAddForm.cleaned_data['faname']+" "+empAddForm.cleaned_data['lname']+' Employee Enrolled Sucessfully!')
                        return redirect('staff_empadd')
                except:
                    messages.error(request,"Invalid header found in Enroll Employee form... Try again")
                    return redirect('staff_empadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            empAddForm= EmployeeEnrolForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Enroll Employees  /",
            'fname':fname,
            "page_path":" Employees Enrollment",
            "menu_icon":"nav-icon fas fa-user-tie",
            "empAddForm":empAddForm,
            }    
        return render(request, 'schoolviews/employee/emp_enroll.html',context) 
    else:
        return redirect('login')

