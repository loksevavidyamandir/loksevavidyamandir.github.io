from django.shortcuts import redirect,render
from django.http import HttpResponse, HttpResponseRedirect
import xlwt
from xlwt.Formatting import Borders
from schStaff.staffModels.empModels import EmployeeEnrol
from django.contrib.auth.models import Group,User,auth
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Designation, MTongue







# Staff Export View
def schStaff_export_xls(request):
    # print("export",cy)
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=StaffList.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('StaffList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Role","Designation","Shalarth_id","Last Name","First Name","Father Name","Mother Name","Name in Devnagari","Place of Birth","Date of Birth","Marital_status","Aadhar","PAN","Email","Mobile","Nationality","Mother Tongue","Religion","Caste","Caste category","SubCaste","Minority","Gender","Person With Disability","Blood Group","Rural/Urban","Current Address","Permanent Address","Enroldate","Enrol_for","Enrol_faculty","Qualification","Experience","Epf_number","Salary","Contract","Scale","Senior_scale","Most_senior_scale","saccount","Sbankname","Sifsc","Sbranch","Smicr","Paccount","Pbankname","Pifsc","Pbranch","Pmicr"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = EmployeeEnrol.objects.all().values_list('role','designation','shalarth_id','lname','fname','faname','moname','mrname','pob','dob','marital_status','aadhar','pan','email','mob','nationality','tongue','religion','cast','category','subcast','minority','sex','pwd','bgroup','areaType','caddress','paddress','enroldate','enrol_for','enrol_faculty','qualification','experience','epf_num','salary','contract','scale','senior_scale','most_senior_scale','saccount','sbankname','sifsc','sbranch','smicr','paccount','pbankname','pifsc','pbranch','pmicr')
    for row in rows:
        # row[9]-m_tongue,row[10]-religion,row[11]-cast,
        # row[12]- category,row[13]-subcast,row[17]-last_school,row[20]-division
        row=list(row)
        # ro=Group.objects.get(id=row[1])
        # row[1]=ro.Group

        di=Designation.objects.get(id=row[1])
        row[1]=di.designation

        t=MTongue.objects.get(id=row[16])
        row[16]=t.m_tongue

        r=Religion.objects.get(id=row[17])
        row[17]=r.religionName

        c=Cast.objects.get(id=row[18])
        row[18]=c.castName

        cc=CastCategory.objects.get(id=row[19])
        row[19]=cc.castCategoryName

        if row[20]!=None:
            sc=SubCast.objects.get(id=row[20])
            row[20]=sc.subCastName   

                    
        row=tuple(row)
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
        
    wb.save(response)
    return response
