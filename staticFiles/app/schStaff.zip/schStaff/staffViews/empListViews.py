from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User,auth
from django.conf import settings as conf_set
from django.contrib import messages
from schStaff.staffModels.empModels import EmployeeEnrol
from schStaff.staffForms.empForms import EmployeeEnrolForm
from schAdmission.admForms.admissionForms import GetAdmYearForm
import datetime



sname=conf_set.SCHOOL_NAME



# Employee List View
def staff_listEmp(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        empEnrollData=EmployeeEnrol.objects.all()
            #print(cy)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Enroll Employees  /",
            'fname':fname,
            "page_path":" List Employee",
            "menu_icon":"nav-icon fas fa-user-tie",
            "empEnrollData":empEnrollData,    
            
            }    
        return render(request, 'schoolviews/employee/emp_enroll_list.html',context) 
    else:
        return redirect('login') 



