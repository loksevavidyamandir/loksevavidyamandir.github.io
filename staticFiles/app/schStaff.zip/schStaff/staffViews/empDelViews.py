from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User,auth
from django.conf import settings as conf_set
from django.contrib import messages
from schStaff.staffModels.empModels import EmployeeEnrol



# Primary Delete View
def staff_delEmp(request,user_id):
    if request.method == 'POST':
        pi=EmployeeEnrol.objects.get(pk=user_id)
        ui=User.objects.get(pk=user_id)
        pi.delete()
        ui.delete()
        messages.success(request, 'Employee Deleted Successfully!')
        return redirect('staff_emplist')

