from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User,auth
from django.conf import settings as conf_set
from django.contrib import messages
from schStaff.staffModels.empModels import EmployeeEnrol
from schStaff.staffForms.empForms import EmployeeEnrolForm




sname=conf_set.SCHOOL_NAME







# Employee Edit View
def staff_editEmp(request,user_id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        #priAdmData=PrimAdm.objects.all()
        if request.method == 'POST':
            pi=EmployeeEnrol.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            # print("user ID",ui.id)
            # print("student ID",pi.user_id)
            empAddForm= EmployeeEnrolForm(request.POST,request.FILES,instance=pi)
            if empAddForm.is_valid():
                try:
                    ui.username=empAddForm.cleaned_data['aadhar']
                    ui.email=empAddForm.cleaned_data['email']
                    #password="Admin@123"
                    ui.first_name=empAddForm.cleaned_data['fname']
                    ui.last_name=empAddForm.cleaned_data['lname']
                    print("user save")
                    ui.save()
                    y=empAddForm.cleaned_data['enroldate']                   
                    pi.enrolyear=y[0:4]
                    print("year save")
                    pi.save()
                    ui.groups.clear()
                    print("group clear")
                    my_group=Group.objects.get(name=empAddForm.cleaned_data['role'])
                    #my_group.user_set.add(user)
                    ui.groups.add(my_group)
                    print("form save")
                    empAddForm.save()
                    messages.success(request,empAddForm.cleaned_data['fname']+" "+empAddForm.cleaned_data['faname']+" "+empAddForm.cleaned_data['lname']+' Employee Enroll Fileds Edited Successfully!')
                    return redirect('staff_empadd')
                except:
                    messages.error(request,"Invalid header found in Edit Employee Enroll form... Try again")
                    return redirect('staff_empadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=EmployeeEnrol.objects.get(pk=user_id)
            ui=User.objects.get(pk=user_id)
            empAddForm= EmployeeEnrolForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Enroll Employees  /",
            'fname':fname,
            "page_path":" Edit-Employees Enrollment",
            "menu_icon":"nav-icon fas fa-user-tie",
            "empAddForm":empAddForm,
            }     
        return render(request, 'schoolviews/employee/emp_enroll.html',context) 
    else:
        return redirect('login')
