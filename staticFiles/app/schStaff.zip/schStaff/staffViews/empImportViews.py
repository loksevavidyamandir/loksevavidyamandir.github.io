from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import  Division,MTongue,OtherSch,ImportData,Designation
from schStaff.staffModels.empModels import EmployeeEnrol,EmpImportData
from schStaff.staffForms.empForms import EmpImportDataForm
import re

import xlwt
from xlwt.Formatting import Borders
import xlrd
import os

basedir=conf_set.BASE_DIR
sname=conf_set.SCHOOL_NAME





# Staff Import
def schStaff_xls_impo(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = EmpImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=EmpImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr) # 1
                        filename=os.path.join(basedir,'media/empimpdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):

                                try:
                                    aadhar=str(int(inputWorksheet.cell_value(y,11)))
                                except:
                                    messages.error(request,"Aadhar Number should contain only numbers")
                                    return redirect('schStaff_xls_impo')
                                
                                pan=str(inputWorksheet.cell_value(y,12)).upper()

                                if EmployeeEnrol.objects.filter(aadhar__iexact=aadhar).exists():
                                    messages.error(request,"Aadhar Number Already Exists")
                                    return redirect('schStaff_xls_impo')
                                elif EmployeeEnrol.objects.filter(email__iexact=str(inputWorksheet.cell_value(y,13))).exists():
                                    messages.error(request,"Email Id Already Exists")
                                    return redirect('schStaff_xls_impo')
                                elif EmployeeEnrol.objects.filter(pan__iexact=pan).exists():
                                    messages.error(request,"Pan Number Already Exists")
                                    return redirect('schStaff_xls_impo')
                                else:
                                    empEnrolModule=EmployeeEnrol()

                                    #for role validation
                                    rolelist=['prim_admin', 'prim_operator', 'prim_teacher','prim_other','sec_admin', 'sec_operator','sec_teacher','sec_other','jrc_admin', 'jrc_operator','jrc_teacher','jrc_other']
                                    role=str(inputWorksheet.cell_value(y,0)).lower()
                                    if role in rolelist:
                                        print(role)
                                        empEnrolModule.role=role
                                    else:
                                        messages.error(request,"Emlopyee Role Does not exists : "+role)
                                        return redirect('schStaff_xls_impo')
                                    
                                    # For Designation 
                                    desig=str(inputWorksheet.cell_value(y,1)).upper()
                                    if Designation.objects.filter(designation=desig).exists():
                                        empEnrolModule.designation=Designation.objects.get(designation=desig)
                                    else:
                                        messages.error(request,"Designation Does not exists "+tong)
                                        return redirect('schStaff_xls_impo')

                                    # For shalarth_id
                                    empEnrolModule.shalarth_id=str(inputWorksheet.cell_value(y,2)).upper()

                                    # for Last name
                                    if inputWorksheet.cell_value(y,3) == "":
                                        messages.error(request,"Employee Last Name required")
                                        return redirect('schStaff_xls_impo')
                                    empEnrolModule.lname=str(inputWorksheet.cell_value(y,3)).upper()
                                    # for first name    
                                    if inputWorksheet.cell_value(y,4) == "":
                                        messages.error(request,"Employee First Name required")
                                        return redirect('schStaff_xls_impo')
                                    empEnrolModule.fname=str(inputWorksheet.cell_value(y,4)).upper()
                                    # for Father name  
                                    if inputWorksheet.cell_value(y,5) == "":
                                        messages.error(request,"Employee Father Name required")
                                        return redirect('schStaff_xls_impo')  
                                    empEnrolModule.faname=str(inputWorksheet.cell_value(y,5)).upper()
                                    # for Mother name    
                                    if inputWorksheet.cell_value(y,6) == "":
                                        messages.error(request,"Employee Mother Name required")
                                        return redirect('schStaff_xls_impo')
                                    empEnrolModule.moname=str(inputWorksheet.cell_value(y,6)).upper()
                                    empEnrolModule.mrname=str(inputWorksheet.cell_value(y,7))

                                    # for pob
                                    # if inputWorksheet.cell_value(y,8) == "":
                                    #     messages.error(request,"Place of Birth is required")
                                    #     return redirect('schStaff_xls_impo')
                                    empEnrolModule.pob=str(inputWorksheet.cell_value(y,8)).upper()
                                    # for dob
                                    dob=str(inputWorksheet.cell_value(y,9))
                                    leng=len(dob)
                                    if leng==10:
                                        if dob[4]=='-' and dob[7]=='-':
                                            empEnrolModule.dob=dob
                                        else:
                                            messages.error(request,"Invalid Date Of Birth "+dob)
                                            return redirect('schStaff_xls_impo')
                                    else:
                                        messages.error(request,"Invalid Date Of Birth "+dob)
                                        return redirect('schStaff_xls_impo')
                                    # Marital_status
                                    minlist=['MARRIED','UNMARRIED']
                                    mino = str(inputWorksheet.cell_value(y,10)).upper()
                                    if mino in minlist:
                                        print(mino)
                                        empEnrolModule.marital_status=mino
                                    else:
                                        messages.error(request,"Marital status Does not exists : "+mino)
                                        return redirect('schStaff_xls_impo')

                                    #for aadhar validation
                                    leng=len(aadhar)
                                    if leng == 12 or leng == 13:
                                        empEnrolModule.aadhar=aadhar
                                    else:
                                        messages.error(request,"Aadhar Number is 12 or 13 digits")
                                        return redirect('schStaff_xls_impo')

                                    #for pan validation
                                    
                                    leng=len(pan)
                                    if leng == 10:
                                        empEnrolModule.pan=pan
                                    else:
                                        messages.error(request,"PAN Number should be 10 digits")
                                        return redirect('schStaff_xls_impo')
                                        
                                    #for Email validation
                                    email=str(inputWorksheet.cell_value(y,13))
                                    regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'
                                    if(re.search(regex, email)):
                                        empEnrolModule.email=email
                                    else:
                                        messages.error(request,"Invalid Email Id"+email)
                                        return redirect('schStaff_xls_impo')

                                    #for mobile no
                                    try:
                                        mob=str(int(inputWorksheet.cell_value(y,14)))
                                    except:
                                        messages.error(request,"Mobile Number should contain only numbers")
                                        return redirect('schStaff_xls_impo')
                                    leng=len(mob)
                                    if leng == 10:
                                        empEnrolModule.mob=mob
                                    else:
                                        messages.error(request,"Mobile Number should be 10 digits")
                                        return redirect('schStaff_xls_impo')
                                    
                                    natlist=['INDIAN','AFGHAN','BANGLADESHI','NEPALESE']
                                    n=str(inputWorksheet.cell_value(y,15)).upper()
                                    if n in natlist:
                                        print(n)
                                        empEnrolModule.nationality=n
                                    else:
                                        messages.error(request,"Nationality Does not exists : "+n)
                                        return redirect('schStaff_xls_impo')
                                    tong=str(inputWorksheet.cell_value(y,16)).upper()
                                    # For Mother Tongue
                                    if MTongue.objects.filter(m_tongue=tong).exists():
                                        empEnrolModule.tongue=MTongue.objects.get(m_tongue=tong)
                                    else:
                                        messages.error(request,"Mother Tongue Does not exists "+tong)
                                        return redirect('schStaff_xls_impo')
                                    #for Religion
                                    rel=str(inputWorksheet.cell_value(y,17)).upper()
                                    if Religion.objects.filter(religionName=rel).exists():
                                        empEnrolModule.religion=Religion.objects.get(religionName=rel)
                                    else:
                                        messages.error(request,"Religion Does not exists "+rel)
                                        return redirect('schStaff_xls_impo')
                                    # For Caste
                                    cast=str(inputWorksheet.cell_value(y,18)).upper()
                                    if Cast.objects.filter(castName=cast).exists():
                                        empEnrolModule.cast=Cast.objects.get(castName=cast)
                                    else:
                                        messages.error(request,"Caste Does not exists "+cast)
                                        return redirect('schStaff_xls_impo')
                                    # For Caste Category
                                    castcat=str(inputWorksheet.cell_value(y,19)).upper()
                                    if CastCategory.objects.filter(castCategoryName=castcat).exists():
                                        empEnrolModule.category=CastCategory.objects.get(castCategoryName=castcat)
                                    else:
                                        messages.error(request,"Caste Category Does not exists "+castcat)
                                        return redirect('schStaff_xls_impo')
                                    # For SubCaste
                                    scast=str(inputWorksheet.cell_value(y,20)).upper()
                                    if SubCast.objects.filter(subCastName=scast).exists():
                                        empEnrolModule.subcast=SubCast.objects.get(subCastName=scast)
                                    elif scast=="":
                                        pass
                                    else:
                                        messages.error(request,"SubCaste Does not exists "+scast)
                                        return redirect('schStaff_xls_impo')
                                    minlist=['YES','NO']
                                    mino = str(inputWorksheet.cell_value(y,21)).upper()
                                    if mino in minlist:
                                        print(mino)
                                        empEnrolModule.minority=mino
                                    else:
                                        messages.error(request,"Minority Does not exists : "+mino)
                                        return redirect('schStaff_xls_impo')

                                    # for Gender
                                    sex=str(inputWorksheet.cell_value(y,22)).upper()
                                    sexlist=['MALE','FEMALE','OTHER']
                                    if sex in sexlist:
                                        empEnrolModule.sex=sex
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('schStaff_xls_impo')
                                    empEnrolModule.pwd=str(inputWorksheet.cell_value(y,23)).upper()
                                    empEnrolModule.bgroup=str(inputWorksheet.cell_value(y,24)).upper()

                                    # for areaType
                                    areaType=str(inputWorksheet.cell_value(y,25)).upper()
                                    areaTypelist=['RURAL','URBAN']
                                    if areaType in areaTypelist:
                                        empEnrolModule.areaType=areaType
                                    else:
                                        messages.error(request,"Invalid Gender")
                                        return redirect('schStaff_xls_impo')
                                    empEnrolModule.caddress=str(inputWorksheet.cell_value(y,26)).upper()


                                    #for current address == permanent adderss
                                    # if inputWorksheet.cell_value(y,26).upper()==inputWorksheet.cell_value(y,27).upper():
                                    #     empEnrolModule.ca_is_pa_addr="YES"
                                    # else:
                                    #     empEnrolModule.ca_is_pa_addr="NO"
                                    #     empEnrolModule.paddress=str(inputWorksheet.cell_value(y,27)).upper()
                                    


                                    if inputWorksheet.cell_value(y,26).upper()==inputWorksheet.cell_value(y,27).upper():
                                        empEnrolModule.ca_is_pa_addr="YES"
                                        empEnrolModule.paddress=str(inputWorksheet.cell_value(y,26)).upper()
                                    else:
                                        empEnrolModule.ca_is_pa_addr="NO"
                                        empEnrolModule.paddress=str(inputWorksheet.cell_value(y,27)).upper()
                                    


                                    
                                    # for enroll date
                                    enroldate=str(inputWorksheet.cell_value(y,28))
                                    leng=len(enroldate)
                                    if leng==10:
                                        if enroldate[4]=='-' and enroldate[7]=='-':
                                            empEnrolModule.enroldate=enroldate
                                        else:
                                            messages.error(request,"Invalid Enroll Date "+enroldate)
                                            return redirect('schStaff_xls_impo')
                                    else:
                                        messages.error(request,"Invalid Enroll Date "+enroldate)
                                        return redirect('schStaff_xls_impo')
                                    
                                    empEnrolModule.enrolyear=enroldate[0:4]

                                    # enroll for
                                    enrolfor=str(inputWorksheet.cell_value(y,29)).upper()
                                    enrollist=['PRIMARY','SECONDARY','JR.COLLEGE','NA']
                                    if enrolfor in enrollist:
                                        empEnrolModule.enrol_for=enrolfor
                                    else:
                                        messages.error(request,"Invalid Enrol For value"+enrolfor)
                                        return redirect('schStaff_xls_impo')

                                    # for Faculty
                                    faculty=str(inputWorksheet.cell_value(y,30)).upper()
                                    facultylist=['SCIENCE','COMMERCE','ARTS','VOCATIONAL','NA']
                                    if faculty in facultylist:
                                            empEnrolModule.enrol_faculty=faculty
                                    else:
                                            messages.error(request,"Invalid Faculty"+faculty)
                                            return redirect('schStaff_xls_impo')
                                    
                                    # # for areaType
                                    # areaType=str(inputWorksheet.cell_value(y,28)).upper()
                                    # areaTypelist=['RURAL','URBAN']
                                    # if areaType in areaTypelist:
                                    #     empEnrolModule.areaType=areaType
                                    # else:
                                    #     messages.error(request,"Invalid Gender")
                                    #     return redirect('schStaff_xls_impo')
                                    # empEnrolModule.caddress=str(inputWorksheet.cell_value(y,29)).upper()

                                    # # for current address == permanent adderss
                                    # if inputWorksheet.cell_value(y,29).upper()==inputWorksheet.cell_value(y,30).upper():
                                    #     empEnrolModule.ca_is_pa_addr="YES"
                                    # else:
                                    #     empEnrolModule.ca_is_pa_addr="NO"
                                    #     empEnrolModule.paddress=str(inputWorksheet.cell_value(y,30)).upper()
                                    
                                    empEnrolModule.qualification=str(inputWorksheet.cell_value(y,31)).upper()
                                    
                                    empEnrolModule.experience=str(inputWorksheet.cell_value(y,32)).upper()

                                    empEnrolModule.epf_num=inputWorksheet.cell_value(y,33)

                                    if inputWorksheet.cell_value(y,34) != "":
                                        try:
                                            salary=int(inputWorksheet.cell_value(y,34))
                                            empEnrolModule.salary=salary
                                        except:
                                            messages.error(request,"Invalid Salary")
                                            return redirect('schStaff_xls_impo')
                                    contract=str(inputWorksheet.cell_value(y,35)).upper()
                                    contlist=['PERMANENT','PROBATION','TEMPORARY']
                                    if contract in contlist:
                                        empEnrolModule.contract=contract
                                    
                                    empEnrolModule.scale=str(inputWorksheet.cell_value(y,36)).upper()
                                    empEnrolModule.senior_scale=str(inputWorksheet.cell_value(y,37)).upper()
                                    empEnrolModule.most_senior_scale=str(inputWorksheet.cell_value(y,38)).upper()

                                    try:
                                        if inputWorksheet.cell_value(y,39)=="":
                                            pass
                                        else:
                                            empEnrolModule.saccount=str(int(inputWorksheet.cell_value(y,39)))
                                    except:
                                        messages.error(request,"Invalid Salary Bank Account Number")
                                        return redirect('schStaff_xls_impo')

                                    empEnrolModule.sbankname=str(inputWorksheet.cell_value(y,40)).upper()
                                    empEnrolModule.sifsc=str(inputWorksheet.cell_value(y,41))
                                    empEnrolModule.sbranch=str(inputWorksheet.cell_value(y,42)).upper()
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,43)=="":
                                            pass
                                        else:
                                            empEnrolModule.smicr=str(int(inputWorksheet.cell_value(y,43)))
                                    except:
                                        messages.error(request,"Invalid Salary MICR Code")
                                        return redirect('schStaff_xls_impo')
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,44)=="":
                                            pass
                                        else:
                                            empEnrolModule.paccount=str(int(inputWorksheet.cell_value(y,44)))
                                    except:
                                        messages.error(request,"Invalid Pension  Bank Account Number")
                                        return redirect('schStaff_xls_impo')

                                    empEnrolModule.pbankname=str(inputWorksheet.cell_value(y,45)).upper()
                                    empEnrolModule.pifsc=str(inputWorksheet.cell_value(y,46))
                                    empEnrolModule.pbranch=str(inputWorksheet.cell_value(y,47)).upper()
                                    
                                    try:
                                        if inputWorksheet.cell_value(y,48)=="":
                                            pass
                                        else:
                                            empEnrolModule.pmicr=str(int(inputWorksheet.cell_value(y,48)))
                                    except:
                                        messages.error(request,"Invalid Pension MICR Code")
                                        return redirect('schStaff_xls_impo')
                                    
                                    print(aadhar)
                                    # Create User for Employee
                                    user=User.objects.create_user(username=str(aadhar),email=inputWorksheet.cell_value(y,13),password="Employee@123",first_name=str(inputWorksheet.cell_value(y,4)).upper(),last_name=str(inputWorksheet.cell_value(y,3)).upper())
                                    print(fr)
                                    user.save()
                                    print(fr)
                                    my_group=Group.objects.get(name=role)
                                    user.groups.add(my_group)
                                    empEnrolModule.user=user
                                    empEnrolModule.save()
                                    print(fr)
                        messages.success(request, "File Imported Successfully")
                        return redirect('schStaff_xls_impo')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('schStaff_xls_impo')
                finally:
                    fl=EmpImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=EmpImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = EmpImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Employee Enrol  /",
            'fname':fname,
            "page_path":"Import-Employee Enrol",
            "menu_icon":"nav-icon fas fa-address-card",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/employee/empimport.html',context)
    else:
        return redirect('login')