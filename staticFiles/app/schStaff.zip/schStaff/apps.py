from django.apps import AppConfig


class SchstaffConfig(AppConfig):
    name = 'schStaff'
