from django import forms
from django.contrib.auth.models import Group,User
from seedData.validators import file_size_pdf,file_size_photo
from django.core.validators import FileExtensionValidator
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Designation,MTongue
from schStaff.staffModels.empModels import EmployeeEnrol




ENROLL = (
    ('', 'Choose...'),
    ('PRIMARY', 'PRIMARY'),
    ('SECONDARY', 'SECONDARY'),
    ('JR.COLLEGE', 'JR.COLLEGE'),
    ('NA', 'NA')
)

NATION=(('', 'Choose...'),
    ('INDIAN', 'INDIAN'),
    ('AFGHAN', 'AFGHAN'),('BANGLADESHI', 'BANGLADESHI'),('NEPALESE', 'NEPALESE'),)  

IS=(('', 'Choose...'),
    ('YES', 'YES'),
    ('NO', 'NO'),) 

AREA=(('', 'Choose...'),
    ('RURAL', 'RURAL'),
    ('URBAN', 'URBAN'),) 


BG=(
    ('', 'Choose...'),
    ('A', 'A'),
    ('A+', 'A+'),
    ('A-', 'A-'),
    ('B', 'B'),('B+', 'B+'),('B-', 'B-'),('AB', 'AB'),('AB+', 'AB+'),('AB-', 'AB-'),
    ('O', 'O'),
    ('O+', 'O+'),('O-', 'O-'),
)  


ROLL = (
    ('', 'Choose...'),
    ('admin', 'Admin'),
    ('teacher', 'Teacher'),
    ('operator', 'Operator'),('other', 'Other'))

PWDS=(('', 'Choose...'),
    ('YES', 'YES'),
    ('NO', 'NO'),) 


MINORITY=(('', 'Choose...'),
    ('YES', 'YES'),
    ('NO', 'NO'),)

FACULTY = (
    ('', 'Choose...'),
    ('SCIENCE', 'SCIENCE'),
    ('COMMERCE', 'COMMERCE'),
    ('ARTS', 'ARTS'),
    ('VOCATIONAL', 'VOCATIONAL'),
    ('NA', 'NA')
)

GENDERS = (
    ('', 'Choose...'),
    ('MALE', 'MALE'),
    ('FEMALE', 'FEMALE'),
    ('OTHER', 'OTHER')
)


MSTATUS=(('', 'Choose...'),
    ('MARRIED', 'MARRIED'),
    ('UNMARRIED', 'UNMARRIED'),)

CONTRACT=(('', 'Choose...'),
    ('PERMANENT', 'PERMANENT'),
    ('PROBATION', 'PROBATION'),('TEMPORARY', 'TEMPORARY'),)


# Staff Enroll Form
class EmployeeEnrolForm(forms.ModelForm):
    role=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select employee roll"}),label="Employee Roll",choices=ROLL,required=True)
    designation=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select employee designation"}),label="Designation",queryset=Designation.objects.all(),required=True)
    shalarth_id=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter employee shalarth id",'placeholder': "शालार्थ क्रमांक  "}),label="Employee Shalartha ID",max_length=25,min_length=2,required=False)   
    lname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter employee surname",'placeholder': "कर्मचारीचे अडनाव "}),label="Employee Last Name",max_length=20,min_length=2,required=True)   
    fname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter employee first name",'placeholder': "कर्मचारीचे नाव "}),label="Employee First Name",max_length=20,min_length=2,required=True)   
    faname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter employee father name",'placeholder': "कर्मचारीच्या वडिलांचे नाव"}),label="Employee Father Name",max_length=20,min_length=2,required=True) 
    moname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter employee mother name",'placeholder': "कर्मचारीच्या आईचे नाव"}),label="Employee Mother Name",max_length=20,min_length=2,required=True) 
    mrname=forms.CharField(widget=forms.TextInput(attrs={'title': "कर्मचारीचे पूर्ण नाव लिहा",'placeholder': "कर्मचारीचे पूर्ण नाव मराठी मध्ये "}),label="Employee Name in Devnagari",max_length=50,min_length=2,required=False)  
    pob=forms.CharField(widget=forms.TextInput(attrs={'title': "Employee place of Birth",'placeholder': "जन्म ठिकाण "}),label="Place of Birth",max_length=100,min_length=3,required=False)  
    dob=forms.CharField(label="Date of Birth",widget=forms.TextInput(attrs={'title':"Enter employee birthdate",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    marital_status=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select employee marital_status"}),label="Marital Status",choices=MSTATUS,required=True)
    aadhar=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter employee Aadhar number",'placeholder': "कर्मचारीचे आधार कार्ड नंबर "}),label="Aadhar",max_length=13,min_length=12,required=True)
    pan=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter employee PAN number",'placeholder': "कर्मचारीचे पॅन क्रमांक "}),label="PAN",max_length=15,min_length=2,required=True) 
    email=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter employee email",'placeholder': "Email"}),label="Email",max_length=50,min_length=4,required=True) 
    mob=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter mobile number",'placeholder': "फोन नंबर"}),label="Employee Mobile",max_length=10,min_length=10,required=True)
    nationality=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select nationality"}),label="Nationality",choices=NATION,initial="INDIAN",required=True)
    tongue=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select mother tongue"}),label="Mother Tongue",queryset=MTongue.objects.all(),required=True)
    religion=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select religion"}),label="Religion",queryset=Religion.objects.all(),required=True)
    cast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select caste"}),label="Caste",queryset=Cast.objects.all(),required=True)
    category=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select cast-category"}),label="Cast category",queryset=CastCategory.objects.all(),required=True)
    subcast=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select sub-caste"}),label="SubCaste",queryset=SubCast.objects.all(),required=False)
    minority=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select minority status"}),label="Minority",choices=MINORITY,initial="NO",required=True)
    #Helth details
    sex=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select gender"}),label="Gender",choices=GENDERS,required=True)
    pwd=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select PWD status"}),label="Person With Disability",choices=PWDS,initial="NO",required=True)
    bgroup=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select blood group"}),label="Blood Group",choices=BG,required=False)     
    #Enrol details
    enroldate=forms.CharField(label="Date of Joining",widget=forms.TextInput(attrs={'title':"Enter Date of Joining",'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)
    enrol_for=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Employee Enroll for"}),label="Employee Enroll For",choices=ENROLL,initial="NA",required=True)
    enrol_faculty=forms.ChoiceField(widget=forms.Select(attrs={'title': "Employee teaching faculty "}),label="Faculty",choices=FACULTY,initial="NA",required=False)
    #Address
    areaType=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Rural/Urban",choices=AREA,required=False) 
    caddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter current postal address",'placeholder': "सध्याचा पत्ता"}),label="Current Address",max_length=100,min_length=4,required=True) 
    ca_is_pa_addr=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select if Current Address is Permanent Address "}),label="Current Address is Permanent Address",choices=IS,initial="YES",required=True)     
    paddress=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter permanent postal address",'placeholder': "कायमचा पत्ता"}),label="Permanent Address",max_length=100,min_length=4,required=False) 
    #Qualification & Experience Details
    qualification=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter employee qualification details",'placeholder': "शैक्षणिक पात्रता"}),label="Qualification Details",max_length=200,min_length=4,required=False) 
    experience=forms.CharField(widget=forms.Textarea(attrs={'cols':20,'rows':1,'style':'height:2.5em;','title': "Enter employee experience details",'placeholder': "अनुभव तपशील"}),label="Experience Details",max_length=200,min_length=4,required=False) 
    #Payrole Details
    epf_num=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter employee EPF number",'placeholder': "EPF Number "}),label="EPF Number",max_length=20,min_length=2,required=False)   
    salary=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Enter employee salary",'placeholder': "Employee Salary"}),label="Salary",max_length=13,min_length=3,required=False)
    contract=forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select Contract type"}),label="Contract type",choices=CONTRACT,required=False)
    scale=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter employee scale",'placeholder': "Scale "}),label="Scale",max_length=30,min_length=2,required=False)   
    senior_scale=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter employee senior_scale",'placeholder': "Senior Scale "}),label="Senior Scale",max_length=30,min_length=2,required=False)   
    most_senior_scale=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter employee most_senior_scale",'placeholder': "Most Senior Scale "}),label="Most Senior Scale",max_length=30,min_length=2,required=False)   
    #Bank Details s-salary , p-pension
    saccount=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Bank account number",'placeholder': "सॅलरी बँक अकाऊंट नंबर"}),label="Salary Bank Account Number",max_length=15,min_length=1,required=False)
    sbankname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Name",'placeholder': "सॅलरी बँकेचे नाव "}),label="Salary Bank Name",max_length=20,min_length=2,required=False) 
    sifsc=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank IFSC",'placeholder': "सॅलरी IFSC नंबर"}),label="Salary Bank IFSC Code",max_length=15,min_length=2,required=False) 
    sbranch=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Branch Name",'placeholder': "सॅलरी ब्रांचचे नाव "}),label="Salary Bank Branch Name",max_length=15,min_length=2,required=False) 
    smicr=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank MICR Code",'placeholder': "सॅलरी MICR नंबर"}),label="Salary Bank MICR Code",max_length=15,min_length=2,required=False) 
    paccount=forms.CharField(widget=forms.TextInput(attrs={'type':'number','title':"Bank account number",'placeholder': "पेन्शन बँक अकाऊंट नंबर"}),label="Pension Bank Account Number",max_length=15,min_length=1,required=False)
    pbankname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Name",'placeholder': "पेन्शन बँकेचे नाव "}),label="Pension Bank Name",max_length=20,min_length=2,required=False) 
    pifsc=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank IFSC",'placeholder': "पेन्शन IFSC नंबर"}),label="Pension Bank IFSC Code",max_length=15,min_length=2,required=False) 
    pbranch=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank Branch Name",'placeholder': "पेन्शन ब्रांचचे नाव "}),label="Pension Bank Branch Name",max_length=15,min_length=2,required=False) 
    pmicr=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Bank MICR Code",'placeholder': "पेन्शन MICR नंबर"}),label="Pension Bank MICR Code",max_length=15,min_length=2,required=False) 
    #Documents
    addhar_img=forms.ImageField(allow_empty_file=True,label="Aadhar Card",help_text='accept JPG/PNG file,max size 60 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    pan_img=forms.ImageField(allow_empty_file=True,label="PAN Card",help_text='accept JPG/PNG file,max size 60 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    emp_img=forms.ImageField(allow_empty_file=True,label="Employee Photo",help_text='accept JPG/PNG file,max size 60 kb',required=False,validators=[file_size_photo,FileExtensionValidator(allowed_extensions=['jpg','png'])])
    class Meta:
        model = EmployeeEnrol
        fields = ('role','designation','shalarth_id','lname','fname','faname','moname','mrname','aadhar','pan','mob','marital_status','nationality','tongue','religion','cast','category','subcast','minority','pob','dob','sex','pwd','bgroup','email','areaType','caddress','ca_is_pa_addr','paddress','saccount','sbankname','sifsc','sbranch','smicr','paccount','pbankname','pifsc','pbranch','pmicr','pan_img','emp_img','addhar_img','qualification','experience','epf_num','salary','contract','scale','senior_scale','most_senior_scale','enroldate','enrol_for','enrol_faculty')
