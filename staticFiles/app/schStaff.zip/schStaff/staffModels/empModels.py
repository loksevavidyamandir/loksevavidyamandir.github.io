from django.db import models
from django.contrib.auth.models import Group,User
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Designation, MTongue
# Create your models here.



# Staff Enroll Model
class EmployeeEnrol(models.Model):
    role=models.CharField(max_length=20)
    designation=models.ForeignKey(Designation,on_delete=models.CASCADE,null=True)
    shalarth_id=models.CharField(max_length=25,null=True)
    lname=models.CharField(max_length=20)   
    fname=models.CharField(max_length=20)    
    faname=models.CharField(max_length=20) 
    moname=models.CharField(max_length=20) 
    mrname=models.CharField(max_length=50,null=True)  
    pob=models.CharField(max_length=100,null=True)  
    dob=models.CharField(max_length=10)
    id_dob=models.CharField(null=True,max_length=10)
    marital_status=models.CharField(max_length=10,null=True)
    aadhar=models.CharField(max_length=13,unique=True)
    pan=models.CharField(max_length=15,unique=True)
    email=models.CharField(max_length=50)
    mob=models.CharField(max_length=10,null=True)
    nationality=models.CharField(max_length=15) 
    tongue=models.ForeignKey(MTongue,on_delete=models.CASCADE,null=True)
    religion=models.ForeignKey(Religion,on_delete=models.CASCADE,null=True)
    cast=models.ForeignKey(Cast,on_delete=models.CASCADE,null=True)
    category=models.ForeignKey(CastCategory,on_delete=models.CASCADE,null=True)
    subcast=models.ForeignKey(SubCast,on_delete=models.CASCADE,null=True)
    minority=models.CharField(max_length=4)
    #Helth details
    sex=models.CharField(max_length=6)
    pwd=models.CharField(max_length=4)
    bgroup=models.CharField(max_length=4,null=True) 
    #Enrol details
    enroldate=models.CharField(max_length=10)
    enrolyear=models.CharField(max_length=4)
    enrol_for=models.CharField(max_length=30)
    enrol_faculty=models.CharField(max_length=15,null=True) 
    #Address
    areaType=models.CharField(max_length=6,null=True)
    caddress=models.CharField(max_length=100) 
    ca_is_pa_addr=models.CharField(max_length=3,null=True)  
    paddress=models.CharField(max_length=100,null=True) 
    #Qualification & Experience Details
    qualification=models.CharField(max_length=200,null=True) 
    experience=models.CharField(max_length=200,null=True) 
    #Payrole Details
    epf_num=models.CharField(max_length=50,null=True)
    salary=models.CharField(max_length=7,null=True)
    contract=models.CharField(max_length=10,null=True)
    scale=models.CharField(max_length=30,null=True)
    senior_scale=models.CharField(max_length=30,null=True)
    most_senior_scale=models.CharField(max_length=30,null=True)
    #Bank Details s-salary , p-pension
    saccount=models.CharField(max_length=20,null=True)
    sbankname=models.CharField(max_length=20,null=True) 
    sifsc=models.CharField(max_length=15,null=True) 
    sbranch=models.CharField(max_length=20,null=True) 
    smicr=models.CharField(max_length=20,null=True) 
    paccount=models.CharField(max_length=20,null=True)
    pbankname=models.CharField(max_length=20,null=True) 
    pifsc=models.CharField(max_length=15,null=True) 
    pbranch=models.CharField(max_length=20,null=True) 
    pmicr=models.CharField(max_length=20,null=True) 
    #Documents
    addhar_img=models.ImageField(upload_to="imgs/secondadm/aadhar",null=True)
    pan_img=models.ImageField(upload_to="imgs/secondadm/cast",null=True)
    emp_img=models.ImageField(upload_to="imgs/emp/empimg",null=True)
    user=models.OneToOneField(User,on_delete=models.CASCADE,primary_key=True)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"empenrol"



# Employee Import Data
class EmpImportData(models.Model):
    ifile=models.FileField(upload_to="empimpdata")
    def delete(self, *args, **kwargs):
        self.ifile.delete()
        super().delete(*args, **kwargs)
    class Meta:
        db_table="empimportdata"




