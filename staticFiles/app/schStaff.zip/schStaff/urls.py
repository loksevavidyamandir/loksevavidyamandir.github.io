from django.urls import path,include
from schStaff.staffViews import empAddViews as empadd
from schStaff.staffViews import empEditViews as empedit
from schStaff.staffViews import empListViews as emplist
from schStaff.staffViews import empExportViews as empexpo
from schStaff.staffViews import empImportViews as empimpo
from schStaff.staffViews import empDelViews as empdel


#from django.conf import settings
#from django.conf.urls.static import static

urlpatterns = [
    # Add Views
    path('employee_register',empadd.staff_addEmp,name='staff_empadd'),
    # List Views
    path('employee_list',emplist.staff_listEmp,name='staff_emplist'),
    # Edit Views
    path('employee_edit/<int:user_id>',empedit.staff_editEmp,name='staff_empedit'),
    # Delete Views
    path('employee_delete/<int:user_id>',empdel.staff_delEmp,name='staff_empdel'),
    # Export Views
    path('staff_export',empexpo.schStaff_export_xls,name='schStaff_xls_expo'),
    #import Views
    path('staff_import',empimpo.schStaff_xls_impo,name='schStaff_xls_impo'),

]
