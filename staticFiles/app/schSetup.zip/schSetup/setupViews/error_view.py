from django.shortcuts import render,redirect



def setup_errorPageExpir(request):
    return render(request,"schoolviews/error/page_expired.html")
