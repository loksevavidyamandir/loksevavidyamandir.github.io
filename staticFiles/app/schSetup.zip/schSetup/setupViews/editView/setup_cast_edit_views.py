from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schSetup.setupForms.setup_cast_forms import AddCastCategoryForm,AddCastForm,AddReligionForm,AddSubCastForm
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast

# This Edit Views Included ::-->  
# Cast,Cast-Category,Religion,Sub-Cast


sname=conf_set.SCHOOL_NAME


def setup_editCasteInfo(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name  
        fname=request.user.first_name
        casteinfoData=Cast.objects.all()
        if request.method == 'POST':
            pi=Cast.objects.get(pk=id)
            add_caste_form = AddCastForm(request.POST,instance=pi)
            if add_caste_form.is_valid():
                try:
                    add_caste_form.save()
                    messages.success(request, 'Caste Edited Successfully!')
                    return redirect('setup_castadd')
                except:
                    messages.error(request,"Invalid header found in Edit Caste form... Try again")
                    return redirect('setup_castadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=Cast.objects.get(pk=id)
            add_caste_form = AddCastForm(instance=pi) 
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info /",
            'fname':fname,
            "page_path":" Edit-Caste",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_caste_form":add_caste_form,
            "casteinfoData":casteinfoData
            }    
        return render(request, 'schoolviews/setup/caste.html',context) 
    else:
        return redirect('login') 






def setup_editSubCasteInfo(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        subcasteinfoData=SubCast.objects.all()
        if request.method == 'POST':
            pi=SubCast.objects.get(pk=id)
            add_subcaste_form = AddSubCastForm(request.POST,instance=pi)
            if add_subcaste_form.is_valid():
                try:
                    if SubCast.objects.filter(subCastName__iexact=add_subcaste_form.cleaned_data['subCastName']).exists():
                        messages.error(request, 'Editing Sub-Caste Already Exist!')
                        return redirect('setup_subcasteadd')
                    else:
                        add_subcaste_form.save()
                        messages.success(request, 'Sub-Caste Edited Successfully!')
                        return redirect('setup_subcasteadd')
                except:
                    messages.error(request,"Invalid header found in Edit Sub-Caste form... Try again")
                    return redirect('setup_subcasteadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=SubCast.objects.get(pk=id)
            add_subcaste_form = AddSubCastForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info /",
            'fname':fname,
            "page_path":" Edit-SubCaste",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_subcaste_form":add_subcaste_form,
            "subcasteinfoData":subcasteinfoData
            }    
        return render(request, 'schoolviews/setup/subcaste.html',context) 
    else:
        return redirect('login') 






def setup_editCasteCategInfo(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        categoryinfoData=CastCategory.objects.all()
        if request.method == 'POST':
            pi=CastCategory.objects.get(pk=id)
            add_category_form = AddCastCategoryForm(request.POST,instance=pi)
            if add_category_form.is_valid():
                try:
                    if CastCategory.objects.filter(castCategoryName__iexact=add_category_form.cleaned_data['castCategoryName']).exists():
                        messages.error(request, 'Editing Caste-Category Already Exist!')
                        return redirect('setup_categoryadd')
                    else:
                        add_category_form.save()
                        messages.success(request, 'Caste Category Edited Successfully!')
                        return redirect('setup_categoryadd')
                except:
                    messages.error(request,"Invalid header found in Edit Caste Category form... Try again")
                    return redirect('setup_categoryadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=CastCategory.objects.get(pk=id)
            add_category_form = AddCastCategoryForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info /",
            'fname':fname,
            "page_path":" Edit-CasteCategory",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_category_form":add_category_form,
            "categoryinfoData":categoryinfoData
            }    
        return render(request, 'schoolviews/setup/category.html',context) 
    else:
        return redirect('login') 





def setup_editReligionInfo(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        religioninfoData=Religion.objects.all()
        if request.method == 'POST':
            pi=Religion.objects.get(pk=id)
            add_religion_form = AddReligionForm(request.POST,instance=pi)
            if add_religion_form.is_valid():
                try:
                    if Religion.objects.filter(religionName__iexact=add_religion_form.cleaned_data['religionName']).exists():
                        messages.error(request, 'Editing Religion Already Exist!')
                        return redirect('setup_religionadd')
                    else:
                        add_religion_form.save()
                        messages.success(request, 'Religion Edited Successfully!')
                        return redirect('setup_religionadd')
                except:
                    messages.error(request,"Invalid header found in Edit Religion form... Try again")
                    return redirect('setup_religionadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=Religion.objects.get(pk=id)
            add_religion_form = AddReligionForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info /",
            'fname':fname,
            "page_path":" Edit-Religion",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_religion_form":add_religion_form,
            "religioninfoData":religioninfoData
            }    
        return render(request, 'schoolviews/setup/religion.html',context) 
    else:
        return redirect('login') 


# Edit End
    


