from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schSetup.setupModels.setup_models import Designation, Division, Holiday, LCRemark, MTongue, OtherSch, SchInfo
from schSetup.setupForms.setup_forms import AddDesignationForm, AddLCRemarkForm, AddOtherSchForm, DivisionForm, HolidayForm, MTongueForm, SchInfoForm



# This Edit Views Included ::-->  
# Other-School,Designation,LC-Remark,LC-Max-Count,School-Information,Holiday,Division
# MTongueEdit


sname=conf_set.SCHOOL_NAME





# MTongueEdit View
def setup_editMTongue(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        tongueData=MTongue.objects.all()
        if request.method == 'POST':
            pi=MTongue.objects.get(pk=id)
            add_MTongue_form = MTongueForm(request.POST,instance=pi)
            if add_MTongue_form.is_valid():
                try:
                    if MTongue.objects.filter(m_tongue__iexact=add_MTongue_form.cleaned_data['m_tongue']).exists():
                        messages.error(request, 'Editing MotherTongue Already Exist!')
                        return redirect('setup_mtongueadd')
                    else:
                        add_MTongue_form.save()
                        messages.success(request, 'MotherTongue Edited Successfully!')
                        return redirect('setup_mtongueadd')
                except:
                    messages.error(request,"Invalid header found in Edit MotherTongue form... Try again")
                    return redirect('setup_mtongueadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
             pi=MTongue.objects.get(pk=id)
             add_MTongue_form = MTongueForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" Edit-MotherTongue",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_MTongue_form":add_MTongue_form,
            "tongueData":tongueData
            }    
        return render(request, 'schoolviews/setup/tongue.html',context) 
    else:
        return redirect('login') 






# Holiday Edit View
def setup_editHoliday(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        holidayData=Holiday.objects.all()
        if request.method == 'POST':
            pi=Holiday.objects.get(pk=id)
            holiday_form = HolidayForm(request.POST,instance=pi)
            if holiday_form.is_valid():
                try:
                    if Holiday.objects.filter(hname__iexact=holiday_form.cleaned_data['hname']).exists():
                        messages.error(request, 'Editing Holiday Already Exist!')
                        return redirect('setup_holidayadd')
                    else:
                        holiday_form.save()
                        messages.success(request, 'Holiday Edited Successfully!')
                        return redirect('setup_holidayadd')
                except:
                    messages.error(request,"Invalid header found in Edit Holiday form... Try again")
                    return redirect('setup_holidayadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
             pi=Holiday.objects.get(pk=id)
             holiday_form = HolidayForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" Edit-Holidays",
            "menu_icon":"nav-icon fa fa-cogs",
            "holiday_form":holiday_form,
            "holidayData":holidayData
            }    
        return render(request, 'schoolviews/setup/holiday.html',context)  
    else:
        return redirect('login') 





# Division Edit View
def setup_editDivision(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divisionData=Division.objects.all()
        if request.method == 'POST':
            pi=Division.objects.get(pk=id)
            division_form = DivisionForm(request.POST,instance=pi)
            if division_form.is_valid():
                try:
                    if Division.objects.filter(division__iexact=division_form.cleaned_data['division']).exists():
                        messages.error(request, 'Editing Division Already Exist!')
                        return redirect('setup_divisionadd')
                    else:
                        division_form.save()
                        messages.success(request, 'Division Edited Successfully!')
                        return redirect('setup_divisionadd')
                except:
                    messages.error(request,"Invalid header found in Edit Division form... Try again")
                    return redirect('setup_divisionadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
             pi=Division.objects.get(pk=id)
             division_form = DivisionForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Academics /",
            'fname':fname,
            "page_path":" Edit-Division",
            "menu_icon":"nav-icon fa fa-cogs",
            "division_form":division_form,
            "divisionData":divisionData
            }    
        return render(request, 'schoolviews/setup/division.html',context) 
    else:
        return redirect('login') 




  
# Designation Edit View
def setup_editDesignation(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        designationData=Designation.objects.all()
        if request.method == 'POST':
            pi=Designation.objects.get(pk=id)
            add_designation_form = AddDesignationForm(request.POST,instance=pi)
            if add_designation_form.is_valid():
                try:
                    if Designation.objects.filter(designation__iexact=add_designation_form.cleaned_data['designation']).exists():
                        messages.error(request, 'Editing Designation Already Exist!')
                        return redirect('setup_designationadd')
                    else:
                        add_designation_form.save()
                        messages.success(request, 'Designation Edited Successfully!')
                        return redirect('setup_designationadd')
                except:
                    messages.error(request,"Invalid header found in Edit Designation form... Try again")
                    return redirect('setup_designationadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=Designation.objects.get(pk=id)
            add_designation_form = AddDesignationForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" Edit-Staff Designation",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_designation_form":add_designation_form,
            "designationData":designationData
            }    
        return render(request, 'schoolviews/setup/designation.html',context) 
    else:
        return redirect('login') 






# LC Remark Edit View
def setup_editLCRemark(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        lcRemarkData=LCRemark.objects.all()
        if request.method == 'POST':
            pi=LCRemark.objects.get(pk=id)
            add_lcremark_form = AddLCRemarkForm(request.POST,instance=pi)
            if add_lcremark_form.is_valid():
                try:
                    if LCRemark.objects.filter(lc_remark__iexact=add_lcremark_form.cleaned_data['lc_remark']).exists():
                        messages.error(request, 'Editing LC Remark Already Exist!')
                        return redirect('setup_lcremarkadd')
                    else:
                        add_lcremark_form.save()
                        messages.success(request, 'LC Remark Edited Successfully!')
                        return redirect('setup_lcremarkadd')
                except:
                    messages.error(request,"Invalid header found in Edit LC Remark form... Try again")
                    return redirect('setup_lcremarkadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
             pi=LCRemark.objects.get(pk=id)
             add_lcremark_form = AddLCRemarkForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" Edit-LC Remark",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_lcremark_form":add_lcremark_form,
            "lcRemarkData":lcRemarkData
            }    
        return render(request, 'schoolviews/setup/lcremark.html',context) 
    else:
        return redirect('login') 





# Other School Edit View
def setup_editOtherSch(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        otherSchData=OtherSch.objects.all()
        if request.method == 'POST':
            pi=OtherSch.objects.get(pk=id)
            add_othersch_form = AddOtherSchForm(request.POST,instance=pi)
            if add_othersch_form.is_valid():
                try:
                    if OtherSch.objects.filter(schName__iexact=add_othersch_form.cleaned_data['schName']).exists():
                        messages.error(request, 'Editing Other School Already Exist!')
                        return redirect('setup_otherschadd')
                    else:
                        add_othersch_form.save()
                        messages.success(request, 'Other School Edited Successfully!')
                        return redirect('setup_otherschadd')
                except:
                    messages.error(request,"Invalid header found in Edit Other School form... Try again")
                    return redirect('setup_otherschadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=OtherSch.objects.get(pk=id)
            add_othersch_form = AddOtherSchForm(instance=pi)  
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" Edit-Other School",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_othersch_form":add_othersch_form,
            "otherSchData":otherSchData
            }    
        return render(request, 'schoolviews/setup/othersch.html',context) 
    else:
        return redirect('login') 



# School Information Edit View
def setup_editSchoolInfo(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        schoolinfoData=SchInfo.objects.all()
        if request.method == 'POST':
            pi=SchInfo.objects.get(pk=1)
            sch_info_form = SchInfoForm(request.POST,instance=pi)
            if sch_info_form.is_valid():
                try:
                    sch_info_form.save()
                    messages.success(request, 'School Information Added Successfully!')
                    return redirect('setup_schinfoedit')
                except:
                    messages.error(request,"Invalid header found in Add School Information form... Try again")
                    return redirect('setup_schinfoedit')
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=SchInfo.objects.get(pk=1)
            sch_info_form = SchInfoForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" School Info",
            "menu_icon":"nav-icon fa fa-cogs",
            "sch_info_form":sch_info_form,
            "schoolinfoData":schoolinfoData
            }    
        return render(request, 'schoolviews/setup/schoolinfo.html',context) 
    else:
        return redirect('login') 
    


