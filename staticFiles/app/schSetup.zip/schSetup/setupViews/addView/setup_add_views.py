from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schSetup.setupModels.setup_models import Designation, Division, Holiday, LCRemark, MTongue, OtherSch, SchInfo
from schSetup.setupForms.setup_forms import AddDesignationForm, AddLCRemarkForm, AddOtherSchForm, DivisionForm, HolidayForm, MTongueForm, SchInfoForm

# This Add Views Included ::-->  
# Other-School,Designation,LC-Remark,LC-Max-Count,School-Information,Devision,Holiday




sname=conf_set.SCHOOL_NAME




# MTongue View
def setup_addMTongue(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        tongueData=MTongue.objects.all()
        if request.method == 'POST':
            add_MTongue_form = MTongueForm(request.POST)
            if add_MTongue_form.is_valid():
                try:
                    if MTongue.objects.filter(m_tongue__iexact=add_MTongue_form.cleaned_data['m_tongue']).exists():
                        messages.error(request, 'Mother Tongue Already Exist!')
                        return redirect('setup_mtongueadd')
                    else:
                        add_MTongue_model=MTongue()
                        add_MTongue_model.m_tongue=add_MTongue_form.cleaned_data['m_tongue'].upper()
                        add_MTongue_model.save()
                        messages.success(request, 'Mother Tongue Added Successfully!')
                        return redirect('setup_mtongueadd')
                except:
                    messages.error(request,"Invalid header found in Add Mother Tongue form... Try again")
                    return redirect('setup_mtongueadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            add_MTongue_form = MTongueForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" Mother-Tongue",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_MTongue_form":add_MTongue_form,
            "tongueData":tongueData
            }    
        return render(request, 'schoolviews/setup/tongue.html',context) 
    else:
        return redirect('login') 






   
# Designation View
def setup_addDesignation(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        designationData=Designation.objects.all()
        if request.method == 'POST':
            add_designation_form = AddDesignationForm(request.POST)
            if add_designation_form.is_valid():
                try:
                    if Designation.objects.filter(designation__iexact=add_designation_form.cleaned_data['designation']).exists():
                        messages.error(request, 'Designation Already Exist!')
                        return redirect('setup_designationadd')
                    else:
                        add_designation_model=Designation()
                        add_designation_model.designation=add_designation_form.cleaned_data['designation'].upper()
                        add_designation_model.save()
                        messages.success(request, 'Designation Added Successfully!')
                        return redirect('setup_designationadd')
                except:
                    messages.error(request,"Invalid header found in Add Designation form... Try again")
                    return redirect('setup_designationadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            add_designation_form = AddDesignationForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" Staff Designation",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_designation_form":add_designation_form,
            "designationData":designationData
            }    
        return render(request, 'schoolviews/setup/designation.html',context) 
    else:
        return redirect('login') 





# School Information View
def setup_addSchoolInfo(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        schoolinfoData=SchInfo.objects.all()
        if request.method == 'POST':
            sch_info_form = SchInfoForm(request.POST)
            if sch_info_form.is_valid():
                try:
                    add_schinfo_model=SchInfo()
                    add_schinfo_model.orgName=sch_info_form.cleaned_data['orgName'].upper()
                    add_schinfo_model.schName=sch_info_form.cleaned_data['schName'].upper()
                    add_schinfo_model.areaType=sch_info_form.cleaned_data['areaType'].upper()
                    add_schinfo_model.address=sch_info_form.cleaned_data['address'].upper()
                    add_schinfo_model.state=sch_info_form.cleaned_data['state'].upper()
                    add_schinfo_model.district=sch_info_form.cleaned_data['district'].upper()
                    add_schinfo_model.taluka=sch_info_form.cleaned_data['taluka'].upper()
                    add_schinfo_model.village=sch_info_form.cleaned_data['village'].upper()
                    add_schinfo_model.email_sch=sch_info_form.cleaned_data['email_sch'].upper()
                    add_schinfo_model.email_org=sch_info_form.cleaned_data['email_org'].upper()
                    add_schinfo_model.phone1=sch_info_form.cleaned_data['phone1']
                    add_schinfo_model.phone2=sch_info_form.cleaned_data['phone2']
                    add_schinfo_model.fax=sch_info_form.cleaned_data['fax']
                    add_schinfo_model.doe=sch_info_form.cleaned_data['doe']
                    add_schinfo_model.udise=sch_info_form.cleaned_data['udise'].upper()
                    add_schinfo_model.indxNumber=sch_info_form.cleaned_data['indxNumber'].upper()
                    add_schinfo_model.grn=sch_info_form.cleaned_data['grn'].upper()
                    add_schinfo_model.website=sch_info_form.cleaned_data['website'].upper()
                    #add_schinfo_model.save()
                    messages.success(request, 'School Information Added Successfully!')
                    return redirect('setup_addschinfo')
                except:
                    messages.error(request,"Invalid header found in Add School Information form... Try again")
                    return redirect('setup_addschinfo')
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            sch_info_form = SchInfoForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" School Info",
            "menu_icon":"nav-icon fa fa-cogs",
            "sch_info_form":sch_info_form,
            "schoolinfoData":schoolinfoData
            }    
        return render(request, 'schoolviews/setup/schoolinfo.html',context) 
    else:
        return redirect('login') 
    



# Other School View
def setup_addOtherSch(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        otherSchData=OtherSch.objects.all()
        if request.method == 'POST':
            add_othersch_form = AddOtherSchForm(request.POST)
            if add_othersch_form.is_valid():
                try:
                    if OtherSch.objects.filter(schName__iexact=add_othersch_form.cleaned_data['schName']).exists():
                        messages.error(request, 'Other School Already Exist!')
                        return redirect('setup_otherschadd')
                    elif (add_othersch_form.cleaned_data['schName']).upper() == "NA":
                        messages.error(request, 'NA is not allowed')
                        return redirect('setup_otherschadd')
                    else:
                        add_othersch_model=OtherSch()
                        add_othersch_model.schName=add_othersch_form.cleaned_data['schName'].upper()
                        add_othersch_model.save()
                        messages.success(request, 'Other School Added Successfully!')
                        return redirect('setup_otherschadd')
                except:
                    messages.error(request,"Invalid header found in Add Other School form... Try again")
                    return redirect('setup_otherschadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            add_othersch_form = AddOtherSchForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" Other School",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_othersch_form":add_othersch_form,
            "otherSchData":otherSchData
            }    
        return render(request, 'schoolviews/setup/othersch.html',context) 
    else:
        return redirect('login') 






# LC Remark View
def setup_addLCRemark(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        lcRemarkData=LCRemark.objects.all()
        if request.method == 'POST':
            add_lcremark_form = AddLCRemarkForm(request.POST)
            if add_lcremark_form.is_valid():
                try:
                    if LCRemark.objects.filter(lc_remark__iexact=add_lcremark_form.cleaned_data['lc_remark']).exists():
                        messages.error(request, 'LC Remark Already Exist!')
                        return redirect('setup_lcremarkadd')
                    elif (add_lcremark_form.cleaned_data['lc_remark']).upper() == "NA":
                        messages.error(request, 'NA is not allowed')
                        return redirect('setup_lcremarkadd')
                    else:
                        add_lcremark_model=LCRemark()
                        add_lcremark_model.lc_remark=add_lcremark_form.cleaned_data['lc_remark'].upper()
                        add_lcremark_model.save()
                        messages.success(request, 'LC Remark Added Successfully!')
                        return redirect('setup_lcremarkadd')
                except:
                    messages.error(request,"Invalid header found in Add LC Remark form... Try again")
                    return redirect('setup_lcremarkadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            add_lcremark_form = AddLCRemarkForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" LC Remark",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_lcremark_form":add_lcremark_form,
            "lcRemarkData":lcRemarkData
            }    
        return render(request, 'schoolviews/setup/lcremark.html',context) 
    else:
        return redirect('login') 





# Holiday add View
def setup_addHoliday(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        holidayData=Holiday.objects.all()
        if request.method == 'POST':
            holiday_form = HolidayForm(request.POST)
            if holiday_form.is_valid():
                try:
                    if Holiday.objects.filter(hname__iexact=holiday_form.cleaned_data['hname']).exists():
                        messages.error(request, 'Holiday Name Already Exist!')
                        return redirect('setup_holidayadd')
                    else:
                        holiday_model=Holiday()
                        holiday_model.hname=holiday_form.cleaned_data['hname'].upper()
                        holiday_model.hdate=holiday_form.cleaned_data['hdate']
                        holiday_model.save()
                        messages.success(request, 'Holiday Added Successfully!')
                        return redirect('setup_holidayadd')
                except:
                    messages.error(request,"Invalid header found in Add Holiday form... Try again")
                    return redirect('setup_holidayadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            holiday_form = HolidayForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":" Holidays",
            "menu_icon":"nav-icon fa fa-cogs",
            "holiday_form":holiday_form,
            "holidayData":holidayData
            }    
        return render(request, 'schoolviews/setup/holiday.html',context) 
    else:
        return redirect('login') 





# Division View
def setup_addDivision(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        divisionData=Division.objects.all()
        if request.method == 'POST':
            division_form = DivisionForm(request.POST)
            if division_form.is_valid():
                try:
                    if Division.objects.filter(division__iexact=division_form.cleaned_data['division']).exists():
                        messages.error(request, 'Division Already Exist!')
                        return redirect('setup_divisionadd')
                    elif (division_form.cleaned_data['division']).upper() == "NA":
                        messages.error(request, 'NA is not allowed')
                        return redirect('setup_divisionadd')
                    else:
                        add_Division_model=Division()
                        add_Division_model.division=division_form.cleaned_data['division'].upper()
                        add_Division_model.save()
                        messages.success(request, 'Division Added Successfully!')
                        return redirect('setup_divisionadd')
                except:
                    messages.error(request,"Invalid header found in Add Division form... Try again")
                    return redirect('setup_divisionadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            division_form = DivisionForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Academics /",
            'fname':fname,
            "page_path":" Division",
            "menu_icon":"nav-icon fa fa-cogs",
            "division_form":division_form,
            "divisionData":divisionData
            }    
        return render(request, 'schoolviews/setup/division.html',context) 
    else:
        return redirect('login') 
