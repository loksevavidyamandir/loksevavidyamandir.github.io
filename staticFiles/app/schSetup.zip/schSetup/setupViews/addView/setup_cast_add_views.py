from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schSetup.setupForms.setup_cast_forms import AddCastCategoryForm,AddCastForm,AddReligionForm,AddSubCastForm
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast

# This Add Views Included ::-->  
# Cast,Cast-Category,Religion,Sub-Cast


sname=conf_set.SCHOOL_NAME


# Add Start   

def setup_addCasteInfo(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        casteinfoData=Cast.objects.all()
        if request.method == 'POST':
            add_caste_form = AddCastForm(request.POST)
            if add_caste_form.is_valid():
                try:
                    if Cast.objects.filter(castName__iexact=add_caste_form.cleaned_data['castName'],castCat=add_caste_form.cleaned_data['castCat']).exists():
                        messages.error(request, 'Caste Already Exist with Caste Category!')
                        return redirect('setup_castadd')
                    else:
                        add_caste_model=Cast()
                        add_caste_model.castName=add_caste_form.cleaned_data['castName'].upper()
                        add_caste_model.castCat=add_caste_form.cleaned_data['castCat']
                        add_caste_model.save()
                        messages.success(request, 'Caste Added Successfully!')
                        return redirect('setup_castadd')
                except:
                    messages.error(request,"Invalid header found in Add Caste form... Try again")
                    return redirect('setup_castadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            add_caste_form = AddCastForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info /",
            'fname':fname,
            "page_path":" Add-Caste",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_caste_form":add_caste_form,
            "casteinfoData":casteinfoData
            }    
        return render(request, 'schoolviews/setup/caste.html',context) 
    else:
        return redirect('login') 




def setup_addSubCasteInfo(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        subcasteinfoData=SubCast.objects.all()
        if request.method == 'POST':
            add_subcaste_form = AddSubCastForm(request.POST)
            if add_subcaste_form.is_valid():
                try:
                    if SubCast.objects.filter(subCastName__iexact=add_subcaste_form.cleaned_data['subCastName']).exists():
                        messages.error(request, 'Sub-Caste Already Exist!')
                        return redirect('setup_subcasteadd')
                    elif (add_subcaste_form.cleaned_data['subCastName']).upper() == "NA":
                        messages.error(request, 'NA is not allowed')
                        return redirect('setup_subcasteadd')
                    else:
                        add_subcaste_model=SubCast()
                        add_subcaste_model.subCastName=add_subcaste_form.cleaned_data['subCastName'].upper()
                        add_subcaste_model.save()
                        messages.success(request, 'Sub-Caste Added Successfully!')
                        return redirect('setup_subcasteadd')
                except:
                    messages.error(request,"Invalid header found in Add Sub-Caste form... Try again")
                    return redirect('setup_subcasteadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            add_subcaste_form = AddSubCastForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info /",
            'fname':fname,
            "page_path":" Add-SubCaste",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_subcaste_form":add_subcaste_form,
            "subcasteinfoData":subcasteinfoData
            }    
        return render(request, 'schoolviews/setup/subcaste.html',context) 
    else:
        return redirect('login') 






def setup_addCasteCategInfo(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        categoryinfoData=CastCategory.objects.all()
        if request.method == 'POST':
            add_category_form = AddCastCategoryForm(request.POST)
            if add_category_form.is_valid():
                try:
                    if CastCategory.objects.filter(castCategoryName__iexact=add_category_form.cleaned_data['castCategoryName']).exists():
                        messages.error(request, 'Caste-Category Already Exist!')
                        return redirect('setup_categoryadd')
                    else:
                        add_castecat_model=CastCategory()
                        add_castecat_model.castCategoryName=add_category_form.cleaned_data['castCategoryName'].upper()
                        add_castecat_model.save()
                        messages.success(request, 'Caste Category Added Successfully!')
                        return redirect('setup_categoryadd')
                except:
                    messages.error(request,"Invalid header found in Add Caste Category form... Try again")
                    return redirect('setup_categoryadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            add_category_form = AddCastCategoryForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info /",
            'fname':fname,
            "page_path":" Add-CasteCategory",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_category_form":add_category_form,
            "categoryinfoData":categoryinfoData
            }    
        return render(request, 'schoolviews/setup/category.html',context) 
    else:
        return redirect('login') 





def setup_addReligionInfo(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        religioninfoData=Religion.objects.all()
        if request.method == 'POST':
            add_religion_form = AddReligionForm(request.POST)
            if add_religion_form.is_valid():
                try:
                    if Religion.objects.filter(religionName__iexact=add_religion_form.cleaned_data['religionName']).exists():
                        messages.error(request, 'Religion Already Exist!')
                        return redirect('setup_religionadd')
                    else:
                        add_religion_model=Religion()
                        add_religion_model.religionName=add_religion_form.cleaned_data['religionName'].upper()
                        add_religion_model.save()
                        messages.success(request, 'Religion Added Successfully!')
                        return redirect('setup_religionadd')
                except:
                    messages.error(request,"Invalid header found in Add Religion form... Try again")
                    return redirect('setup_religionadd')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            add_religion_form = AddReligionForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info /",
            'fname':fname,
            "page_path":" Add-Religion",
            "menu_icon":"nav-icon fa fa-cogs",
            "add_religion_form":add_religion_form,
            "religioninfoData":religioninfoData
            }    
        return render(request, 'schoolviews/setup/religion.html',context) 
    else:
        return redirect('login') 


# Add End
    


