import os
from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from django.contrib.auth.models import User,auth
from schSetup.setupModels.setup_cast_models import Cast,Religion,SubCast,CastCategory
from schSetup.setupModels.setup_models import OtherSch,Designation,LCRemark,MTongue,ImportData
from schSetup.setupForms.setup_forms import ImportDataForm


# import pandas as pd
import xlwt
import xlrd
import os



basedir=conf_set.BASE_DIR
sname=conf_set.SCHOOL_NAME




#Caste Import
def setup_importCaste(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr)
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):
                                if Cast.objects.filter(castName__iexact=inputWorksheet.cell_value(y,0)).exists():
                                    messages.error(request, 'Caste Already Exist!...Check Excel Sheet')
                                    return redirect('setup_castimport')
                                else:
                                    cast_model=Cast()
                                    cast_model.castName=inputWorksheet.cell_value(y,0)
                                    # For Caste Category
                                    castcat=str(inputWorksheet.cell_value(y,1)).upper()
                                    if CastCategory.objects.filter(castCategoryName=castcat).exists():
                                        cast_model.castCat=CastCategory.objects.get(castCategoryName=castcat)
                                    else:
                                        messages.error(request,"Caste Category Does not exists "+castcat)
                                        return redirect('setup_castimport')
                                    cast_model.save()
                        messages.success(request, "File Imported Successfully")
                        return redirect('setup_castadd')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('setup_castimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info / ",
            'fname':fname,
            "page_path":"  Import-Caste",
            "menu_icon":"nav-icon fa fa-cogs",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context) 
    else:
        return redirect('login')





#Religion Import
def setup_importReligion(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr)
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):
                                if Religion.objects.filter(religionName__iexact=inputWorksheet.cell_value(y,0)).exists():
                                    messages.error(request, 'Religion Already Exist!...Check Excel Sheet')
                                    return redirect('setup_religionimport')
                                else:
                                    cast_model=Religion()
                                    cast_model.religionName=inputWorksheet.cell_value(y,0)
                                    cast_model.save()
                        messages.success(request, "File Imported Successfully")
                        return redirect('setup_religionadd')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('setup_religionimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info / ",
            'fname':fname,
            "page_path":"  Import-Religion",
            "menu_icon":"nav-icon fa fa-cogs",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)  
    else:
        return redirect('login')





#SubCast Import
def setup_importSubCast(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr)
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):
                                if SubCast.objects.filter(subCastName__iexact=inputWorksheet.cell_value(y,0)).exists():
                                    messages.error(request, 'Religion Already Exist!...Check Excel Sheet')
                                    return redirect('setup_subcastimport')
                                else:
                                    cast_model=SubCast()
                                    cast_model.subCastName=inputWorksheet.cell_value(y,0)
                                    cast_model.save()
                        messages.success(request, "File Imported Successfully")
                        return redirect('setup_subcasteadd')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('setup_subcastimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info / ",
            'fname':fname,
            "page_path":"  Import-SubCaste",
            "menu_icon":"nav-icon fa fa-cogs",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)  
    else:
        return redirect('login')







#CastCategory Import
def setup_importCastCatg(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr)
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):
                                if CastCategory.objects.filter(castCategoryName__iexact=inputWorksheet.cell_value(y,0)).exists():
                                    messages.error(request, 'CasteCategory Already Exist!...Check Excel Sheet')
                                    return redirect('setup_castcatgimport')
                                else:
                                    cast_model=CastCategory()
                                    cast_model.castCategoryName=inputWorksheet.cell_value(y,0)
                                    cast_model.save()
                        messages.success(request, "File Imported Successfully")
                        return redirect('setup_categoryadd')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('setup_castcatgimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup / Caste Info / ",
            'fname':fname,
            "page_path":"  Import-CasteCategory",
            "menu_icon":"nav-icon fa fa-cogs",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)  
    else:
        return redirect('login')






#Other School Import
def setup_importOtherSch(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr)
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):
                                if OtherSch.objects.filter(schName__iexact=inputWorksheet.cell_value(y,0)).exists():
                                    messages.error(request, 'Other School Already Exist!...Check Excel Sheet')
                                    return redirect('setup_otherschimport')
                                else:
                                    cast_model=OtherSch()
                                    cast_model.schName=inputWorksheet.cell_value(y,0)
                                    cast_model.save()
                        messages.success(request, "File Imported Successfully")
                        return redirect('setup_otherschadd')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('setup_otherschimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":"  Import-OtherSchool",
            "menu_icon":"nav-icon fa fa-cogs",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)  
    else:
        return redirect('login')








#Designation School Import
def setup_importDegignation(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr)
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):
                                if Designation.objects.filter(designation__iexact=inputWorksheet.cell_value(y,0)).exists():
                                    messages.error(request, 'Designation Already Exist!...Check Excel Sheet')
                                    return redirect('setup_designationimport')
                                else:
                                    cast_model=Designation()
                                    cast_model.designation=inputWorksheet.cell_value(y,0)
                                    cast_model.save()
                        messages.success(request, "File Imported Successfully")
                        return redirect('setup_designationadd')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('setup_designationimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":"  Import-Designation",
            "menu_icon":"nav-icon fa fa-cogs",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context)  
    else:
        return redirect('login')





#LCRemark Import
def setup_importLCRemark(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr)
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):
                                if LCRemark.objects.filter(lc_remark__iexact=inputWorksheet.cell_value(y,0)).exists():
                                    messages.error(request, 'LC Remark Already Exist!...Check Excel Sheet')
                                    return redirect('setup_lcremarkimport')
                                else:
                                    cast_model=LCRemark()
                                    cast_model.lc_remark=inputWorksheet.cell_value(y,0)
                                    cast_model.save()
                        messages.success(request, "File Imported Successfully")
                        return redirect('setup_lcremarkadd')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('setup_lcremarkimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":"  Import-LCRemark",
            "menu_icon":"nav-icon fa fa-cogs",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context) 
    else:
        return redirect('login')






#MTongue Import
def setup_importMotherTongue(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            fileForm = ImportDataForm(request.POST,request.FILES)
            if fileForm.is_valid():
                try:
                    fileModel=ImportData()
                    fileModel.ifile=fileForm.cleaned_data['ifile']
                    print("before save File")
                    fileModel.save()
                    print("Save File")
                    try:
                        fr=str(fileForm.cleaned_data['ifile'])
                        print(fr)
                        filename=os.path.join(basedir,'media/importdata/'+fr)
                        data=xlrd.open_workbook(filename)
                        for i in range(len(data.sheet_names())):
                            inputWorksheet=data.sheet_by_index(i)
                            for y in range(1,inputWorksheet.nrows):
                                if MTongue.objects.filter(m_tongue__iexact=inputWorksheet.cell_value(y,0)).exists():
                                    messages.error(request, 'Mother Tongue Already Exist!...Check Excel Sheet')
                                    return redirect('setup_mtoungeimport')
                                else:
                                    cast_model=MTongue()
                                    cast_model.m_tongue=inputWorksheet.cell_value(y,0)
                                    cast_model.save()
                        messages.success(request, "File Imported Successfully")
                        return redirect('setup_mtongueadd')
                    except:
                        messages.error(request,"File not read ... Try again")       
                except:
                    messages.error(request,"Invalid header ... Try again")
                    return redirect('setup_mtoungeimport')
                finally:
                    fl=ImportData.objects.last()
                    print("Deleted File",fl.id)
                    f=ImportData.objects.get(pk=fl.id)
                    f.delete()
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            fileForm = ImportDataForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Setup /",
            'fname':fname,
            "page_path":"  Import-MotherTongue",
            "menu_icon":"nav-icon fa fa-cogs",
            "fileForm":fileForm,
            }
        return render(request, 'schoolviews/setup/import.html',context) 
    else:
        return redirect('login')




