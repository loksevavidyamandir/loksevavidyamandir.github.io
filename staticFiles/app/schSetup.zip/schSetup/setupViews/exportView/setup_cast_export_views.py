from django.shortcuts import redirect,render
from django.http import HttpResponse, HttpResponseRedirect
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
import xlwt
from xlwt.Formatting import Borders

# This Export Views Included only excel export ::-->  
# Cast,Cast-Category,Religion,Sub-Cast


def setup_export_cast_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="CasteList.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('casteList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["CasteName","Caste Category"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = Cast.objects.all().values_list('castName','castCat')
    for row in rows:

        row=list(row)

        cc=CastCategory.objects.get(id=row[1])
        row[1]=cc.castCategoryName

        row=tuple(row)

        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response






def setup_export_religion_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="ReligionList.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('religionList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["ReligionName"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = Religion.objects.all().values_list('religionName')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response






def setup_export_subcast_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="SubCasteList.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('subcasteList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["SubCasteName"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = SubCast.objects.all().values_list('subCastName')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response





def setup_export_category_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="CategoryList.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('categoryList')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["CasteCategoryName"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = CastCategory.objects.all().values_list('castCategoryName')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response
