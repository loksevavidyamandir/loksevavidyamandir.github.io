from django.shortcuts import redirect,render
from django.http import HttpResponse, HttpResponseRedirect
from schSetup.setupModels.setup_models import SchInfo,Designation,LCRemark,OtherSch,MTongue,Holiday,Division
import xlwt
from xlwt.Formatting import Borders

# This Export Views Included only excel export ::-->  
# Other-School,Designation,LC-Remark,LC-Max-Count,School-Information,m_tongue,Holiday,Division

#School Info
def setup_export_schoolinfo_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="SchoolInfo.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('schoolinfo')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Organization Name","School Name","Address","State","District","Taluka","Village","Organization Email ","School Email","Phone/Mobile Number","Phone/Mobile Number","FAX Number","Date of Establishment","U-DISE Number","Index Number","Government Recognition Number","Website domain Name"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = SchInfo.objects.all().values_list('orgName','schName','address','state','district','taluka','village','email_org','email_sch','phone1','phone2','fax','doe','udise','indxNumber','grn','website')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response




#Designation
def setup_export_designation_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="Designation.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('designation')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["DesignationName"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = Designation.objects.all().values_list('designation')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response





#LC-Remark
def setup_export_lcremarkn_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="lc_remark.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('lc_remark')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["LCRemark"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = LCRemark.objects.all().values_list('lc_remark')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response





#OtherSch
def setup_export_otherSch_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="OtherSchool.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('OtherSchool')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["OtherSchoolName"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = OtherSch.objects.all().values_list('schName')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response






#Mother Tounge
def setup_export_mothertongue_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="MotherTongue.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('MotherTongue')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["MotherTongue"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = MTongue.objects.all().values_list('m_tongue')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response





#Holidays
def setup_export_holidays_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="Holidays.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Holidays')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Holiday Name","Holiday Date"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = Holiday.objects.all().values_list('hname','hdate')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response





#Division
def setup_export_division_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="Division.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Division')
    # Sheet header, first row
    row_num = 0
    excel_style = xlwt.XFStyle()
    excel_style.font.bold = True
    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1
    excel_style.borders = borders
    columns = ["Division Name"]
    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], excel_style)
    # Sheet body, remaining rows
    excel_style = xlwt.XFStyle()
    excel_style.borders = borders
    rows = Division.objects.all().values_list('division')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], excel_style)
    wb.save(response)
    return response

