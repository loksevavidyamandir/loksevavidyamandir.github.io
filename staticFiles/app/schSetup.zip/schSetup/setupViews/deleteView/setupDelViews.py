from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User,auth
from django.conf import settings as conf_set
from django.contrib import messages
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import Designation, Division, Holiday, LCRemark, MTongue, OtherSch, SchInfo

# This Delete Views Included ::-->  
# Other-School,Designation,LC-Remark,LC-Max-Count,School-Information,Holiday,Division
# MTongueEdit,cast,religion,subcast,castcategory




def setup_delOthSch(request,id):
    if request.method == 'POST':
        pi=OtherSch.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'Other School Deleted Successfully!')
        return redirect('setup_otherschadd')



def setup_delDesign(request,id):
    if request.method == 'POST':
        pi=Designation.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'Designation Deleted Successfully!')
        return redirect('setup_designationadd')



def setup_delLCRemark(request,id):
    if request.method == 'POST':
        pi=LCRemark.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'LC-Remark Deleted Successfully!')
        return redirect('setup_lcremarkadd')



def setup_delSchInfo(request,id):
    if request.method == 'POST':
        pi=SchInfo.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'School Information Deleted Successfully!')
        return redirect('setup_addschinfo')   



def setup_delHoliday(request,id):
    if request.method == 'POST':
        pi=Holiday.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'Holiday Deleted Successfully!')
        return redirect('setup_holidayadd') 



def setup_delDivision(request,id):
    if request.method == 'POST':
        pi=Division.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'Division Deleted Successfully!')
        return redirect('setup_divisionadd') 



def setup_delMTongue(request,id):
    if request.method == 'POST':
        pi=MTongue.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'Mother-Tongue Deleted Successfully!')
        return redirect('setup_mtongueadd') 



def setup_delCast(request,id):
    if request.method == 'POST':
        pi=Cast.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'Caste Deleted Successfully!')
        return redirect('setup_castadd') 



def setup_delReligion(request,id):
    if request.method == 'POST':
        pi=Religion.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'Religion Deleted Successfully!')
        return redirect('setup_religionadd') 





def setup_delSubCast(request,id):
    if request.method == 'POST':
        pi=SubCast.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'SubCaste Deleted Successfully!')
        return redirect('setup_subcasteadd') 



def setup_delCastCategory(request,id):
    if request.method == 'POST':
        pi=CastCategory.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'Caste-Category Deleted Successfully!')
        return redirect('setup_categoryadd') 
