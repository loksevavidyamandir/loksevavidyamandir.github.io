from django.db import models


# mother_mobile=models.CharField(max_length=10)
# Create your models here



class CastCategory(models.Model):
    castCategoryName=models.CharField(max_length=20)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"castecategory"                        
    
    def __str__(self):
        return self.castCategoryName



class Cast(models.Model):
    castName=models.CharField(max_length=20)
    castCat=models.ForeignKey(CastCategory,on_delete=models.SET_NULL,null=True)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"caste"

    def __str__(self):
        return self.castName




class Religion(models.Model):
    religionName=models.CharField(max_length=20)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"religion"

    def __str__(self):
        return self.religionName




class SubCast(models.Model):
    subCastName=models.CharField(max_length=20)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"subcaste"

    def __str__(self):
        return self.subCastName




