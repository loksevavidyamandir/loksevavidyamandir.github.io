from django.db import models

# This Model Included ::-->  
# Other-School,Designation,LC-Remark,LC-Max-Count,School-Information,Holiday,Division,Mother-Tonug,ImportData


# Other School Model
class OtherSch(models.Model):
    schName=models.CharField(max_length=200)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"otherschool"

    def __str__(self):
        return self.schName




# Designation Model
class Designation(models.Model):
    designation=models.CharField(max_length=20)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"designation"

    def __str__(self):
        return self.designation




# LC Remark Model
class LCRemark(models.Model):
    lc_remark=models.CharField(max_length=50)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"lcremark"

    def __str__(self):
        return self.lc_remark




# LC Max Count Model
class LCMaxCount(models.Model):
    lc_max=models.CharField(max_length=2)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"lcmaxcount"  

    def __str__(self):
        return self.lc_max




# School Information Model
class SchInfo(models.Model):
    orgName=models.CharField(max_length=100,null=True)
    schName=models.CharField(max_length=100,null=True)
    areaType=models.CharField(max_length=6,null=True)
    address=models.CharField(max_length=200,null=True)
    state=models.CharField(max_length=20,null=True) 
    district=models.CharField(max_length=20,null=True) 
    taluka=models.CharField(max_length=20,null=True) 
    village=models.CharField(max_length=20,null=True)       
    email_sch=models.CharField(max_length=50) 
    email_org=models.CharField(max_length=50,null=True) 
    phone1=models.CharField(max_length=10)     
    phone2=models.CharField(max_length=10,null=True)     
    fax=models.CharField(max_length=10,null=True)     
    doe=models.CharField(max_length=10)       
    udise=models.CharField(max_length=50)     
    indxNumber=models.CharField(max_length=50,null=True)     
    grn=models.CharField(max_length=50)     
    website=models.CharField(max_length=50)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"schinfo"                




# Holiday Model
class Holiday(models.Model):
    hname=models.CharField(max_length=20)
    hdate=models.CharField(max_length=10)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
       db_table:"holiday"





# Division Model
class Division(models.Model):
    division=models.CharField(max_length=2)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"devision"

    def __str__(self):
        return self.division




# Mother Tongue Model
class MTongue(models.Model):
    m_tongue=models.CharField(max_length=15)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"mtongue"

    def __str__(self):
        return self.m_tongue      


# Import Data
class ImportData(models.Model):
    ifile=models.FileField(upload_to="importdata")
    def delete(self, *args, **kwargs):
        self.ifile.delete()
        super().delete(*args, **kwargs)
    class Meta:
        db_table="importdata"

     