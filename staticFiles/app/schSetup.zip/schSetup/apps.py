from django.apps import AppConfig


class SchsetupConfig(AppConfig):
    name = 'schSetup'
