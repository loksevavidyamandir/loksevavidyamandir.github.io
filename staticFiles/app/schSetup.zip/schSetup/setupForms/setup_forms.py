from django import forms
from django.core.validators import FileExtensionValidator
from schSetup.setupModels.setup_models import Designation, Division, Holiday, LCMaxCount, LCRemark, MTongue, OtherSch, SchInfo,ImportData

# This Forms Included ::-->  
# Other-School,Designation,LC-Remark,LC-Max-Count,School-Information





AREA=(('', 'Choose...'),
    ('RURAL', 'RURAL'),
    ('URBAN', 'URBAN'),) 

STATE=(('', 'Choose...'),
    ('MAHARASHTRA', 'MAHARASHTRA'),
    ('KARNATAKA', 'KARNATAKA'),) 

DISTRICT=(('', 'Choose...'),
    ('SOLAPUR', 'SOLAPUR'),
    ('LATUR', 'LATUR'),) 

TALUKA=(('', 'Choose...'),
    ('N.SOLAPUR', 'NORTH SOLAPUR'),
    ('S.SOLAPUR', 'SOUTH SOLAPUR'),('MOHOL', 'MOHOL'),)   

VILAGE=(('', 'Choose...'),
    ('MANDRUP', 'MANDRUP'),
   )                

# School Information Form
class SchInfoForm(forms.ModelForm):
    orgName=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Organization Name",'placeholder': 'संस्थेचे पूर्ण नाव'}),label='Organization Name',max_length=100,min_length=5,required=True)
    schName=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter School Name",'placeholder': 'शाळेचे पूर्ण नाव'}),label='School Name',max_length=100,min_length=5,required=True)
    areaType=forms.ChoiceField(widget=forms.Select(attrs={'title': "Select Rural/Urban",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Rural/Urban",choices=AREA,required=True) 
    address=forms.CharField(widget=forms.Textarea(attrs={'title': "Enter School Address",'cols':20,'rows':1,'style':'height:2.5em;','placeholder': 'शाळेचा पत्ता '}),label='School Address',max_length=200,min_length=4,required=True)      
    state=forms.ChoiceField(widget=forms.Select(attrs={'title': "Select State",'class':"form-control select2bs4",'style':"width: 100%;"}),label="State",choices=STATE,required=True) 
    district=forms.ChoiceField(widget=forms.Select(attrs={'title': "Select District Name",'class':"form-control select2bs4",'style':"width: 100%;"}),label="District",choices=DISTRICT,required=True) 
    taluka=forms.ChoiceField(widget=forms.Select(attrs={'title': "Select Taluka Name",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Taluka",choices=TALUKA,required=True) 
    village=forms.ChoiceField(widget=forms.Select(attrs={'title': "Select Village Name",'class':"form-control select2bs4",'style':"width: 100%;"}),label="Village",choices=VILAGE,required=False)       
    email_sch=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter School email",'placeholder': "शाळेचा ई-मेल"}),label="School Email",max_length=50,min_length=8,required=True) 
    email_org=forms.CharField(widget=forms.EmailInput(attrs={'title': "Enter Organization email",'placeholder': "संस्थेचा ई-मेल"}),label="Organization Email",max_length=50,min_length=8,required=False) 
    phone1=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Phone/Mobile Number",'placeholder': "फोन किंवा मोबाईल क्रमांक "}),label="Phone/Mobile Number1",max_length=10,min_length=6,required=True)     
    phone2=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Phone/Mobile Number",'placeholder': "फोन किंवा मोबाईल क्रमांक "}),label="Phone/Mobile Number2",max_length=10,min_length=6,required=False)     
    fax=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter FAX Number",'placeholder': "फॅक्स क्रमांक"}),label="FAX Number",max_length=10,min_length=4,required=False)     
    doe=forms.CharField(label="Date of Establishment",widget=forms.TextInput(attrs={'type': 'date','placeholder': "DD/MM/YYYY"}),required=True)       
    udise=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter U-DISE Number",'placeholder': "U-DISE क्रमांक"}),label="U-DISE Number",max_length=50,min_length=4,required=True)     
    indxNumber=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Index Number",'placeholder': "इंडेक्स क्रमांक "}),label="Index Number",max_length=50,min_length=4,required=False)     
    grn=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Government Recognition Number",'placeholder': "शासकीय मान्यता क्रमांक "}),label="Government Recognition Number",max_length=50,min_length=4,required=True)     
    website=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Website domain Name",'placeholder': "वेबसाइटचे नाव"}),label="Website domain Name",max_length=50,min_length=4,required=True)     
    class Meta:
        model = SchInfo
        fields = ('orgName','schName','areaType','address','state','district','taluka','village','email_sch','email_org','phone1','phone2','fax','doe','udise','indxNumber','grn','website')






# Other School Form
class AddOtherSchForm(forms.ModelForm):
    schName=forms.CharField(widget=forms.Textarea(attrs={'title': "Enter Other School Name",'cols':20,'rows':1,'style':'height:2.5em;','placeholder': 'इतर शाळा '}),label='Other School',max_length=200,min_length=2,required=True)      
    class Meta:
        model = OtherSch
        fields = ('schName',)





# Designation Form
class AddDesignationForm(forms.ModelForm):
    designation=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Designation",'placeholder': 'हुद्दा'}),label='Designation',max_length=20,min_length=3,required=True)
    class Meta:
        model = Designation
        fields = ('designation',)





# LC-Remark Form
class AddLCRemarkForm(forms.ModelForm):
    lc_remark=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter LC Remark",'placeholder': 'शाळेच्या दाखल्यावरील नोंद'}),label='LC Remark',max_length=50,min_length=3,required=True)
    class Meta:
        model = LCRemark
        fields = ('lc_remark',)
    



# LC-MAX Count Form
class AddLCMaxCountForm(forms.ModelForm):
    lc_max=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter LC Max Count ",'placeholder': 'शाळेच्या दाखल्याची कमाल संख्या '}),label='Enter LC Max Count',max_length=2,min_length=1,required=True)
    class Meta:
        model = LCMaxCount
        fields = ('lc_max',)





# Holiday Form
class HolidayForm(forms.ModelForm):
    hname=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Holiday Name ",'placeholder': 'सुट्टीचा दिवस'}),label='Enter Holiday',max_length=20,min_length=2,required=True)
    hdate=forms.CharField(widget=forms.TextInput(attrs={'type':"date",'title': "Select Holiday Date ",'placeholder': 'DD/MM/YYYY'}),label='Holiday Date',max_length=10,min_length=10,required=True)
    class Meta:
        model = Holiday
        fields = ('hname','hdate',)



# Devision Form
class DivisionForm(forms.ModelForm):
    division=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter division",'placeholder': 'तुकडी'}),label='Division',max_length=2,min_length=1,required=True)
    class Meta:
        model = Division
        fields = ('division',)





# Devision Form
class MTongueForm(forms.ModelForm):
    m_tongue=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Mother Tongue",'placeholder': 'मातृभाषा'}),label='Mother Tongue',max_length=15,min_length=2,required=True)
    class Meta:
        model = MTongue
        fields = ('m_tongue',)



class ImportDataForm(forms.ModelForm):
      ifile=forms.FileField(allow_empty_file=True,label="Import File",help_text='accept XLS file,File name must be - Imp.xls',required=True,validators=[FileExtensionValidator(allowed_extensions=['xls'])])
      class Meta:
          model=ImportData
          fields=("ifile",)
