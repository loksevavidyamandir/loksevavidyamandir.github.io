from django import forms
from website.validators import file_size_pdf,file_size_photo
from django.core.validators import FileExtensionValidator


class ChangePasswd(forms.Form):
    old_passwd=forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Type Your Old Password'}),label='Old Password',max_length=15,min_length=8,empty_value=False,required=True)
    passwd1=forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Type New Password'}),label='New Password',max_length=15,min_length=8,empty_value=False,required=True)
    passwd2=forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Re-Type New Password'}),label='Re-Enter New Password',max_length=15,min_length=8,empty_value=False,required=True)
