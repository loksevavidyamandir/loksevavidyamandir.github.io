from django import forms
from schSetup.setupModels.setup_cast_models import Cast,CastCategory,Religion,SubCast




class AddCastForm(forms.ModelForm):
    castName=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Caste Name",'placeholder': 'जातीचे नाव '}),label='Caste',max_length=20,min_length=2,required=True)
    castCat=forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select cast-category"}),label="Cast category",queryset=CastCategory.objects.all(),required=True)
    class Meta:
        model = Cast
        fields = ('castName','castCat',)
    

class AddReligionForm(forms.ModelForm):
    religionName=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Religion Name",'placeholder': 'धर्माचे नाव '}),label='Religion',max_length=20,min_length=2,required=True)
    class Meta:
        model = Religion
        fields = ('religionName',)


class AddSubCastForm(forms.ModelForm):
    subCastName=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Sub-Caste Name",'placeholder': 'पोट-जातीचे नाव '}),label='Sub-Caste',max_length=20,min_length=2,required=True)
    class Meta:
        model = SubCast
        fields = ('subCastName',)


class AddCastCategoryForm(forms.ModelForm):
    castCategoryName=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Caste Category Name",'placeholder': 'जाती वर्ग'}),label='Caste Category',max_length=20,min_length=2,required=True)
    class Meta:
        model = CastCategory
        fields = ('castCategoryName',)


