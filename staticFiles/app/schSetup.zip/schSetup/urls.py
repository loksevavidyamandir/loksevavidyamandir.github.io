from django.urls import path,include
from schSetup.setupViews import error_view
from django.contrib.auth import views 
from schSetup.setupViews.addView import setup_cast_add_views as castaddview
from schSetup.setupViews.addView import setup_add_views as setupaddview
from schSetup.setupViews.editView import setup_cast_edit_views as casteditview
from schSetup.setupViews.editView import setup_edit_views as setupeditview
from schSetup.setupViews.deleteView import setupDelViews as schdel
from schSetup.setupViews.exportView import setup_cast_export_views as castexportview
from schSetup.setupViews.exportView import setup_export_views as setupExportV
from schSetup.setupViews.importView import setupImportViews as impv



#from django.conf import settings
#from django.conf.urls.static import static

urlpatterns = [
   #Import View
   path('caste_import',impv.setup_importCaste,name='setup_castimport'),
   path('religion_import',impv.setup_importReligion,name='setup_religionimport'),
   path('subcaste_import',impv.setup_importSubCast,name='setup_subcastimport'),
   path('caste_category_import',impv.setup_importCastCatg,name='setup_castcatgimport'),
   path('other_school_import',impv.setup_importOtherSch,name='setup_otherschimport'),
   path('designation_import',impv.setup_importDegignation,name='setup_designationimport'),
   path('lcremark_import',impv.setup_importLCRemark,name='setup_lcremarkimport'),
   path('mothertongue_import',impv.setup_importMotherTongue,name='setup_mtoungeimport'),
   #Export View
   path('division_list',setupExportV.setup_export_division_xls,name='setup_divisionxls'),
   path('holiday_list',setupExportV.setup_export_holidays_xls,name='setup_holidayxls'),
   path('mother_tongue_list',setupExportV.setup_export_mothertongue_xls,name='setup_mtonguexls'),
   path('otherschool_list',setupExportV.setup_export_otherSch_xls,name='setup_otherschxls'),
   path('lcremark_list',setupExportV.setup_export_lcremarkn_xls,name='setup_lcreamrkxls'),
   path('designation_list',setupExportV.setup_export_designation_xls,name='setup_designationxls'),
   path('school_Info',setupExportV.setup_export_schoolinfo_xls,name='setup_schoolinfoxls'),
   path('caste_list',castexportview.setup_export_cast_xls,name='setup_castxls'),
   path('category_list',castexportview.setup_export_category_xls,name='setup_categoryxls'),
   path('subcaste_list',castexportview.setup_export_subcast_xls,name='setup_subcastxls'),
   path('religion_list',castexportview.setup_export_religion_xls,name='setup_religionxls'),
   #Del View
   path('otherschooldel/<int:id>',schdel.setup_delOthSch,name='setup_otschdel'),
   path('castedel/<int:id>',schdel.setup_delCast,name='setup_castdel'),
   path('categorydel/<int:id>',schdel.setup_delCastCategory,name='setup_castcatdel'),
   path('religiondel/<int:id>',schdel.setup_delReligion,name='setup_religiondel'),
   path('subcastedel/<int:id>',schdel.setup_delSubCast,name='setup_subcastdel'),
   path('designationdel/<int:id>',schdel.setup_delDesign,name='setup_disigndel'),
   path('divisiondel/<int:id>',schdel.setup_delDivision,name='setup_divisiondel'),
   path('holidaydel/<int:id>',schdel.setup_delHoliday,name='setup_holidaydel'),
   path('lcremarldel/<int:id>',schdel.setup_delLCRemark,name='setup_lcremarkdel'),
   path('mothertonguedel/<int:id>',schdel.setup_delMTongue,name='setup_mtonguedel'),
   path('schoolinfodel/<int:id>',schdel.setup_delSchInfo,name='setup_schinfodel'),
   #Edit View
   path('mtounge_edit/<int:id>',setupeditview.setup_editMTongue,name='setup_mtongueedit'),
   path('divisions_edit/<int:id>',setupeditview.setup_editDivision,name='setup_divisionedit'),
   path('holiday_edit/<int:id>',setupeditview.setup_editHoliday,name='setup_holidayedit'),
   path('schoolinfo_edit',setupeditview.setup_editSchoolInfo,name='setup_schinfoedit'),
   path('otherschool_edit/<int:id>',setupeditview.setup_editOtherSch,name='setup_othschedit'),
   path('lcremark_edit/<int:id>',setupeditview.setup_editLCRemark,name='setup_lcremaedit'),
   path('designation_edit/<int:id>',setupeditview.setup_editDesignation,name='setup_desigedit'),
   path('caste_edit/<int:id>',casteditview.setup_editCasteInfo,name='setup_castedit'),
   path('category_edit/<int:id>',casteditview.setup_editCasteCategInfo,name='setup_categoryedit'),
   path('subcaste_edit/<int:id>',casteditview.setup_editSubCasteInfo,name='setup_subcastedit'),
   path('religion_edit/<int:id>',casteditview.setup_editReligionInfo,name='setup_religionedit'),
   # Add View
   path('mtongue',setupaddview.setup_addMTongue,name='setup_mtongueadd'),
   path('divisions',setupaddview.setup_addDivision,name='setup_divisionadd'),
   path('holidays',setupaddview.setup_addHoliday,name='setup_holidayadd'),
   path('schoolinfo',setupaddview.setup_addSchoolInfo,name='setup_addschinfo'),
   path('designation',setupaddview.setup_addDesignation,name='setup_designationadd'),
   path('lcremark',setupaddview.setup_addLCRemark,name='setup_lcremarkadd'),
   path('otherschool',setupaddview.setup_addOtherSch,name='setup_otherschadd'),
   path("caste_info",castaddview.setup_addCasteInfo,name='setup_castadd'),
   path("caste_category_info",castaddview.setup_addCasteCategInfo,name='setup_categoryadd'),
   path("religion_info",castaddview.setup_addReligionInfo,name='setup_religionadd'),
   path("subcaste_info",castaddview.setup_addSubCasteInfo,name='setup_subcasteadd'),
                           
]
