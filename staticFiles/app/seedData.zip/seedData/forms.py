from django import forms
from .models import Year
class YearForm(forms.ModelForm):
    year=forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Year",'placeholder': 'Year'}),label='Year',max_length=9,min_length=9,empty_value=False,required=True)
    class Meta:
        model = Year
        fields = ('year',)