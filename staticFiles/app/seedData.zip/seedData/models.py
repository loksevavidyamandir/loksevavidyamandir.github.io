from django.db import models

# Create your models here.




class Year(models.Model):
    year=models.CharField(max_length=9,unique=True)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"year"

    def __str__(self):
        return self.year 
