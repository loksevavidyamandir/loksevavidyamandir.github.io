from django.apps import AppConfig


class SeeddataConfig(AppConfig):
    name = 'seedData'
