from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import Group,User
from django.conf import settings as conf_set
from django.contrib import messages
from schSetup.setupModels.setup_models import SchInfo
from schSetup.setupModels.setup_cast_models import CastCategory,Cast,Religion,SubCast
from schSetup.setupModels.setup_models import  MTongue
from seedData.models import Year
from seedData.forms import YearForm


# Create your views here.

sname=conf_set.SCHOOL_NAME

def admin_seeddata(request):
    GROUPS = ['admin', 'operator', 'student', 'teacher','other']
    for group in GROUPS:
        new_group, created = Group.objects.get_or_create(name=group)
    user=User.objects.create_user(username="bodhi2020211",email="bodhi.technology@outlook.com",password="bodh73!@tech21",first_name="Bodhi",last_name="Technology",is_superuser="True",is_staff="True",is_active="True")
    user=User.objects.create_user(username="schoolschool",email="vaishnavi.technology@outlook.com",password="School@123",first_name="Trust",last_name="Solapur",is_superuser="True",is_staff="True",is_active="True")
    user.save()
    scool=SchInfo()
    scool.id=1
    scool.save() 
    return HttpResponse("<h1>data seed sucessfuly....<h1>")




def seeddata_addYear(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        yearData=Year.objects.all()
        if request.method == 'POST':
            add_Year_form = YearForm(request.POST)
            if add_Year_form.is_valid():
                try:
                    if Year.objects.filter(year__iexact=add_Year_form.cleaned_data['year']).exists():
                        messages.error(request, 'Year Already Exist!')
                        return redirect('seeddata_yearadd')
                    else:
                        add_Year_model=Year()
                        add_Year_model.year=add_Year_form.cleaned_data['year']
                        add_Year_model.save()
                        messages.success(request, add_Year_form.cleaned_data["year"]+' Year Added Successfully!')
                        return redirect('seeddata_yearadd')
                except:
                    messages.error(request,"Invalid header found in Add Mother Tongue form... Try again")
                    return redirect('seeddata_yearadd')
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            add_Year_form = YearForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Seed Data /",
            'fname':fname,
            "page_path":" Year",
            "menu_icon":"nav-icon fa fa-calendar-check-o",
            "add_Year_form":add_Year_form,
            "yearData":yearData
            }    
        return render(request, 'schoolviews/seeddata/year.html',context) 
    else:
        return redirect('login')




def seeddata_editYear(request,id):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        yearData=Year.objects.all()
        if request.method == 'POST':
            pi=Year.objects.get(pk=id)
            add_Year_form = YearForm(request.POST,instance=pi)
            if add_Year_form.is_valid():
                try:
                    if Year.objects.filter(year__iexact=add_Year_form.cleaned_data['year']).exists():
                        messages.error(request, 'Editing Year Already Exist!')
                        return redirect('seeddata_yearedit')
                    else:
                        add_Year_form.save()
                        messages.success(request, 'Year Edited Successfully!')
                        return redirect('seeddata_yearadd')
                except:
                    messages.error(request,"Invalid header found in Edit Year form... Try again")
                    return redirect('seeddata_yearedit')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
             pi=Year.objects.get(pk=id)
             add_Year_form = YearForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" SeedData /",
            'fname':fname,
            "page_path":" Edit-Year",
            "menu_icon":"nav-icon fa fa-calendar-check-o",
            "add_Year_form":add_Year_form,
            "yearData":yearData
            }    
        return render(request, 'schoolviews/seeddata/year.html',context) 
    else:
        return redirect('login') 




def setup_delYear(request,id):
    if request.method == 'POST':
        pi=Year.objects.get(pk=id)
        pi.delete()
        messages.success(request, 'Year Deleted Successfully!')
        return redirect('seeddata_yearadd') 




# GROUPS = ['group_admin', 'group_operator', 'group_student', 'group_teacher','group_classteacher']
# for group in GROUPS:
#     new_group, created = Group.objects.get_or_create(name=group)