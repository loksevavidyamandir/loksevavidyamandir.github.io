from django.urls import path,include
from seedData import views
#from django.conf import settings
#from django.conf.urls.static import static

urlpatterns = [
    path('seeddata',views.admin_seeddata,name='seeddata'),
    # Year Add views
    path('year_add',views.seeddata_addYear,name='seeddata_yearadd'),                
    # Year Edit views
    path('year_edit/<int:id>/',views.seeddata_editYear,name='seeddata_yearedit'),
    # Year Delete views
    path('year_delete/<int:id>/',views.setup_delYear,name='seeddata_yeardelete'),
                        
]
